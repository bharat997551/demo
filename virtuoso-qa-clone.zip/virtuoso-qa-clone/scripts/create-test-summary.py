#!/usr/bin/env python3
"""
Create a test summary for notifications and reporting
"""

import os
import json
import argparse
from datetime import datetime
from pathlib import Path


def create_summary(results_dir):
    """Create a summary from aggregated test results"""
    
    # Find the most recent aggregated results file
    result_files = sorted(
        Path(results_dir).glob('aggregated-results-*.json'),
        key=lambda x: x.stat().st_mtime,
        reverse=True
    )
    
    if not result_files:
        raise ValueError("No aggregated results found")
    
    # Load the most recent results
    with open(result_files[0], 'r') as f:
        results = json.load(f)
    
    # Create summary
    summary = {
        'run_id': results['run_id'],
        'timestamp': results['timestamp'],
        'total_tests': results['summary']['total_tests'],
        'passed_tests': results['summary']['passed_tests'],
        'failed_tests': results['summary']['failed_tests'],
        'skipped_tests': results['summary']['skipped_tests'],
        'pass_rate': results['summary']['pass_rate'],
        'duration': format_duration(results['summary']['total_duration']),
        'duration_seconds': results['summary']['total_duration'],
        'test_suites': results['summary']['test_suites'],
        'top_failures': [],
        'slow_tests': [],
        'summary_text': ''
    }
    
    # Add top failures
    if results['failures']:
        summary['top_failures'] = results['failures'][:10]  # Top 10 failures
    
    # Add slow tests
    if results['performance']:
        summary['slow_tests'] = sorted(
            results['performance'],
            key=lambda x: x['duration'],
            reverse=True
        )[:5]  # Top 5 slowest tests
    
    # Generate summary text
    summary_parts = [
        f"Test Run: {results['run_id']}",
        f"Total Tests: {summary['total_tests']}",
        f"Passed: {summary['passed_tests']} ({summary['pass_rate']}%)",
        f"Failed: {summary['failed_tests']}",
        f"Duration: {summary['duration']}"
    ]
    
    if summary['failed_tests'] > 0:
        summary_parts.append(f"\nTop Failures:")
        for i, failure in enumerate(summary['top_failures'][:3], 1):
            summary_parts.append(f"{i}. {failure['suite']}: {failure['test']}")
    
    summary['summary_text'] = '\n'.join(summary_parts)
    
    return summary


def format_duration(seconds):
    """Format duration in seconds to human-readable format"""
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    seconds = int(seconds % 60)
    
    parts = []
    if hours > 0:
        parts.append(f"{hours}h")
    if minutes > 0:
        parts.append(f"{minutes}m")
    parts.append(f"{seconds}s")
    
    return ' '.join(parts)


def main():
    parser = argparse.ArgumentParser(description='Create test summary')
    parser.add_argument('--results-dir', required=True, help='Directory containing test results')
    parser.add_argument('--output', default='summary.json', help='Output file for summary')
    
    args = parser.parse_args()
    
    try:
        summary = create_summary(args.results_dir)
        
        # Save summary
        with open(args.output, 'w') as f:
            json.dump(summary, f, indent=2)
        
        print(f"Summary created: {args.output}")
        print(f"\nSummary:")
        print(summary['summary_text'])
        
    except Exception as e:
        print(f"Error creating summary: {e}")
        # Create a minimal summary for error cases
        error_summary = {
            'error': str(e),
            'total_tests': 0,
            'passed_tests': 0,
            'failed_tests': 0,
            'pass_rate': 0,
            'duration': '0s'
        }
        with open(args.output, 'w') as f:
            json.dump(error_summary, f, indent=2)


if __name__ == '__main__':
    main() 