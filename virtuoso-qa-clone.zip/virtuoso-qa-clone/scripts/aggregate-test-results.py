#!/usr/bin/env python3
"""
Aggregate test results from multiple test runs for analysis
"""

import os
import json
import glob
import argparse
from datetime import datetime
from pathlib import Path
import xml.etree.ElementTree as ET


def parse_junit_xml(file_path):
    """Parse JUnit XML test results"""
    tree = ET.parse(file_path)
    root = tree.getroot()
    
    results = {
        'total': 0,
        'passed': 0,
        'failed': 0,
        'skipped': 0,
        'duration': 0,
        'tests': []
    }
    
    for testsuite in root.findall('.//testsuite'):
        results['total'] += int(testsuite.get('tests', 0))
        results['failed'] += int(testsuite.get('failures', 0))
        results['skipped'] += int(testsuite.get('skipped', 0))
        results['duration'] += float(testsuite.get('time', 0))
        
        for testcase in testsuite.findall('.//testcase'):
            test = {
                'name': testcase.get('name'),
                'classname': testcase.get('classname'),
                'time': float(testcase.get('time', 0)),
                'status': 'passed'
            }
            
            if testcase.find('failure') is not None:
                test['status'] = 'failed'
                test['failure'] = testcase.find('failure').text
            elif testcase.find('skipped') is not None:
                test['status'] = 'skipped'
                
            results['tests'].append(test)
    
    results['passed'] = results['total'] - results['failed'] - results['skipped']
    return results


def parse_jest_json(file_path):
    """Parse Jest JSON test results"""
    with open(file_path, 'r') as f:
        data = json.load(f)
    
    return {
        'total': data.get('numTotalTests', 0),
        'passed': data.get('numPassedTests', 0),
        'failed': data.get('numFailedTests', 0),
        'skipped': data.get('numPendingTests', 0),
        'duration': data.get('totalTime', 0) / 1000,  # Convert to seconds
        'tests': []
    }


def aggregate_results(input_dir, output_dir, run_id):
    """Aggregate all test results"""
    results = {
        'run_id': run_id,
        'timestamp': datetime.utcnow().isoformat(),
        'summary': {
            'total_tests': 0,
            'passed_tests': 0,
            'failed_tests': 0,
            'skipped_tests': 0,
            'total_duration': 0,
            'test_suites': {}
        },
        'failures': [],
        'performance': []
    }
    
    # Process all test result files
    for suite_type in ['web', 'desktop', 'api', 'mainframe', 'e2e']:
        suite_results = {
            'total': 0,
            'passed': 0,
            'failed': 0,
            'skipped': 0,
            'duration': 0
        }
        
        # Look for JUnit XML files
        xml_files = glob.glob(f"{input_dir}/*{suite_type}*/junit.xml")
        for xml_file in xml_files:
            junit_results = parse_junit_xml(xml_file)
            suite_results['total'] += junit_results['total']
            suite_results['passed'] += junit_results['passed']
            suite_results['failed'] += junit_results['failed']
            suite_results['skipped'] += junit_results['skipped']
            suite_results['duration'] += junit_results['duration']
            
            # Collect failures
            for test in junit_results['tests']:
                if test['status'] == 'failed':
                    results['failures'].append({
                        'suite': suite_type,
                        'test': test['name'],
                        'class': test['classname'],
                        'failure': test.get('failure', 'Unknown failure')
                    })
                    
                # Collect performance data
                if test['time'] > 10:  # Tests taking more than 10 seconds
                    results['performance'].append({
                        'suite': suite_type,
                        'test': test['name'],
                        'duration': test['time']
                    })
        
        # Look for Jest JSON files
        json_files = glob.glob(f"{input_dir}/*{suite_type}*/jest-results.json")
        for json_file in json_files:
            jest_results = parse_jest_json(json_file)
            suite_results['total'] += jest_results['total']
            suite_results['passed'] += jest_results['passed']
            suite_results['failed'] += jest_results['failed']
            suite_results['skipped'] += jest_results['skipped']
            suite_results['duration'] += jest_results['duration']
        
        if suite_results['total'] > 0:
            results['summary']['test_suites'][suite_type] = suite_results
            results['summary']['total_tests'] += suite_results['total']
            results['summary']['passed_tests'] += suite_results['passed']
            results['summary']['failed_tests'] += suite_results['failed']
            results['summary']['skipped_tests'] += suite_results['skipped']
            results['summary']['total_duration'] += suite_results['duration']
    
    # Calculate pass rate
    if results['summary']['total_tests'] > 0:
        results['summary']['pass_rate'] = round(
            (results['summary']['passed_tests'] / results['summary']['total_tests']) * 100, 2
        )
    else:
        results['summary']['pass_rate'] = 0
    
    # Save aggregated results
    os.makedirs(output_dir, exist_ok=True)
    output_file = os.path.join(output_dir, f'aggregated-results-{run_id}.json')
    with open(output_file, 'w') as f:
        json.dump(results, f, indent=2)
    
    print(f"Aggregated results saved to: {output_file}")
    return results


def main():
    parser = argparse.ArgumentParser(description='Aggregate test results')
    parser.add_argument('--input-dir', required=True, help='Directory containing test artifacts')
    parser.add_argument('--output-dir', required=True, help='Output directory for aggregated results')
    parser.add_argument('--run-id', required=True, help='Test run ID')
    
    args = parser.parse_args()
    
    aggregate_results(args.input_dir, args.output_dir, args.run_id)


if __name__ == '__main__':
    main() 