#!/usr/bin/env python3
"""
Analyze test result trends over time
"""

import os
import json
import glob
import argparse
from datetime import datetime, timedelta
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path


def load_historical_results(data_dir, history_days):
    """Load historical test results"""
    cutoff_date = datetime.utcnow() - timedelta(days=history_days)
    results = []
    
    # Find all aggregated result files
    result_files = glob.glob(os.path.join(data_dir, 'aggregated-results-*.json'))
    
    for file_path in result_files:
        with open(file_path, 'r') as f:
            data = json.load(f)
        
        # Parse timestamp
        timestamp = datetime.fromisoformat(data['timestamp'].replace('Z', '+00:00'))
        
        if timestamp >= cutoff_date:
            results.append({
                'run_id': data['run_id'],
                'timestamp': timestamp,
                'total_tests': data['summary']['total_tests'],
                'passed_tests': data['summary']['passed_tests'],
                'failed_tests': data['summary']['failed_tests'],
                'pass_rate': data['summary']['pass_rate'],
                'duration': data['summary']['total_duration']
            })
    
    return pd.DataFrame(results).sort_values('timestamp')


def generate_trend_charts(df, output_dir):
    """Generate trend analysis charts"""
    os.makedirs(output_dir, exist_ok=True)
    
    # Set style
    plt.style.use('seaborn-v0_8-darkgrid')
    
    # 1. Pass rate trend
    fig, ax = plt.subplots(figsize=(12, 6))
    ax.plot(df['timestamp'], df['pass_rate'], marker='o', linewidth=2, markersize=8)
    ax.set_title('Test Pass Rate Trend', fontsize=16, fontweight='bold')
    ax.set_xlabel('Date', fontsize=12)
    ax.set_ylabel('Pass Rate (%)', fontsize=12)
    ax.set_ylim(0, 105)
    
    # Add horizontal line at 95% (target)
    ax.axhline(y=95, color='green', linestyle='--', alpha=0.7, label='Target (95%)')
    
    # Add average line
    avg_pass_rate = df['pass_rate'].mean()
    ax.axhline(y=avg_pass_rate, color='orange', linestyle='--', alpha=0.7, 
               label=f'Average ({avg_pass_rate:.1f}%)')
    
    ax.legend()
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'pass_rate_trend.png'), dpi=300)
    plt.close()
    
    # 2. Test count trend
    fig, ax = plt.subplots(figsize=(12, 6))
    ax.plot(df['timestamp'], df['total_tests'], label='Total', marker='o')
    ax.plot(df['timestamp'], df['passed_tests'], label='Passed', marker='s', color='green')
    ax.plot(df['timestamp'], df['failed_tests'], label='Failed', marker='^', color='red')
    ax.set_title('Test Count Trend', fontsize=16, fontweight='bold')
    ax.set_xlabel('Date', fontsize=12)
    ax.set_ylabel('Number of Tests', fontsize=12)
    ax.legend()
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'test_count_trend.png'), dpi=300)
    plt.close()
    
    # 3. Test duration trend
    fig, ax = plt.subplots(figsize=(12, 6))
    ax.plot(df['timestamp'], df['duration'] / 60, marker='o', linewidth=2, markersize=8)
    ax.set_title('Test Execution Time Trend', fontsize=16, fontweight='bold')
    ax.set_xlabel('Date', fontsize=12)
    ax.set_ylabel('Duration (minutes)', fontsize=12)
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'duration_trend.png'), dpi=300)
    plt.close()
    
    # 4. Failure distribution heatmap (by day of week and hour)
    if len(df) > 7:
        df['day_of_week'] = df['timestamp'].dt.day_name()
        df['hour'] = df['timestamp'].dt.hour
        
        pivot_table = df.pivot_table(
            values='failed_tests',
            index='day_of_week',
            columns='hour',
            aggfunc='mean',
            fill_value=0
        )
        
        # Reorder days
        days_order = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
        pivot_table = pivot_table.reindex([d for d in days_order if d in pivot_table.index])
        
        fig, ax = plt.subplots(figsize=(14, 8))
        sns.heatmap(pivot_table, annot=True, fmt='.1f', cmap='YlOrRd', ax=ax)
        ax.set_title('Average Test Failures by Day and Hour', fontsize=16, fontweight='bold')
        ax.set_xlabel('Hour of Day', fontsize=12)
        ax.set_ylabel('Day of Week', fontsize=12)
        plt.tight_layout()
        plt.savefig(os.path.join(output_dir, 'failure_heatmap.png'), dpi=300)
        plt.close()


def generate_trend_report(df, output_dir):
    """Generate trend analysis report"""
    report = {
        'analysis_date': datetime.utcnow().isoformat(),
        'period': {
            'start': df['timestamp'].min().isoformat(),
            'end': df['timestamp'].max().isoformat(),
            'days': (df['timestamp'].max() - df['timestamp'].min()).days
        },
        'summary': {
            'total_runs': len(df),
            'average_pass_rate': round(df['pass_rate'].mean(), 2),
            'min_pass_rate': round(df['pass_rate'].min(), 2),
            'max_pass_rate': round(df['pass_rate'].max(), 2),
            'pass_rate_std': round(df['pass_rate'].std(), 2),
            'average_duration_minutes': round(df['duration'].mean() / 60, 2),
            'total_tests_executed': int(df['total_tests'].sum()),
            'total_failures': int(df['failed_tests'].sum())
        },
        'trends': {
            'pass_rate_trend': 'improving' if df.tail(5)['pass_rate'].mean() > df.head(5)['pass_rate'].mean() else 'declining',
            'duration_trend': 'increasing' if df.tail(5)['duration'].mean() > df.head(5)['duration'].mean() else 'decreasing'
        },
        'alerts': []
    }
    
    # Check for alerts
    recent_runs = df.tail(3)
    if recent_runs['pass_rate'].mean() < 90:
        report['alerts'].append({
            'type': 'low_pass_rate',
            'message': f"Recent pass rate ({recent_runs['pass_rate'].mean():.1f}%) is below 90%",
            'severity': 'high'
        })
    
    if recent_runs['duration'].mean() > df['duration'].mean() * 1.5:
        report['alerts'].append({
            'type': 'slow_tests',
            'message': "Recent test runs are 50% slower than average",
            'severity': 'medium'
        })
    
    # Find consistently failing tests
    # This would require more detailed data, but we can simulate
    if df.tail(5)['failed_tests'].min() > 0:
        report['alerts'].append({
            'type': 'consistent_failures',
            'message': "Tests are consistently failing in recent runs",
            'severity': 'high'
        })
    
    # Save report
    report_file = os.path.join(output_dir, 'trend_analysis_report.json')
    with open(report_file, 'w') as f:
        json.dump(report, f, indent=2)
    
    print(f"Trend analysis report saved to: {report_file}")
    return report


def main():
    parser = argparse.ArgumentParser(description='Analyze test result trends')
    parser.add_argument('--data-dir', required=True, help='Directory containing historical data')
    parser.add_argument('--history-days', type=int, default=30, help='Days of history to analyze')
    parser.add_argument('--output-dir', required=True, help='Output directory for reports')
    
    args = parser.parse_args()
    
    # Load historical data
    df = load_historical_results(args.data_dir, args.history_days)
    
    if len(df) == 0:
        print("No historical data found")
        return
    
    print(f"Loaded {len(df)} test runs from the past {args.history_days} days")
    
    # Generate charts
    generate_trend_charts(df, args.output_dir)
    
    # Generate report
    generate_trend_report(df, args.output_dir)
    
    print(f"Trend analysis complete. Results saved to: {args.output_dir}")


if __name__ == '__main__':
    main() 