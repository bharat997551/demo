# MVP Validation Script for Hybrid QA
# This script validates that all MVP criteria are met

param(
    [string]$InstallPath = "C:\Program Files\Hybrid QA",
    [switch]$SkipInstallCheck = $false,
    [switch]$RunTests = $false,
    [switch]$GenerateReport = $false
)

$ErrorActionPreference = "Stop"
$ValidationResults = @{}
$TotalChecks = 0
$PassedChecks = 0

function Write-Status {
    param(
        [string]$Message,
        [string]$Status = "INFO"
    )
    
    $color = switch ($Status) {
        "PASS" { "Green" }
        "FAIL" { "Red" }
        "WARN" { "Yellow" }
        "INFO" { "Cyan" }
        default { "White" }
    }
    
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Write-Host "[$timestamp] [$Status] $Message" -ForegroundColor $color
}

function Test-MVPCriteria {
    param(
        [string]$Category,
        [string]$Description,
        [scriptblock]$Test
    )
    
    $TotalChecks++
    Write-Status "Testing: $Description" "INFO"
    
    try {
        $result = & $Test
        if ($result) {
            $PassedChecks++
            Write-Status "  ✓ $Description" "PASS"
            $ValidationResults["$Category - $Description"] = "PASS"
            return $true
        } else {
            Write-Status "  ✗ $Description" "FAIL"
            $ValidationResults["$Category - $Description"] = "FAIL"
            return $false
        }
    } catch {
        Write-Status "  ✗ $Description - Error: $_" "FAIL"
        $ValidationResults["$Category - $Description"] = "FAIL: $_"
        return $false
    }
}

Write-Host "`n=== Hybrid QA MVP Validation Script ===" -ForegroundColor Magenta
Write-Host "Validation started at: $(Get-Date)" -ForegroundColor Gray

# 1. Installation Checks
if (-not $SkipInstallCheck) {
    Write-Host "`n--- Installation Validation ---" -ForegroundColor Yellow
    
    Test-MVPCriteria "Installation" "Application installed" {
        Test-Path $InstallPath
    }
    
    Test-MVPCriteria "Installation" "Executable exists" {
        Test-Path "$InstallPath\Hybrid QA.exe"
    }
    
    Test-MVPCriteria "Installation" "Desktop shortcut created" {
        Test-Path "$env:USERPROFILE\Desktop\Hybrid QA.lnk"
    }
    
    Test-MVPCriteria "Installation" "Start menu entry exists" {
        Test-Path "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Hybrid QA"
    }
}

# 2. Environment Checks
Write-Host "`n--- Environment Validation ---" -ForegroundColor Yellow

Test-MVPCriteria "Environment" "Node.js available" {
    try {
        $nodeVersion = node --version
        Write-Status "    Node.js version: $nodeVersion" "INFO"
        return $true
    } catch {
        return $false
    }
}

Test-MVPCriteria "Environment" "Python available" {
    try {
        $pythonVersion = python --version 2>&1
        Write-Status "    Python version: $pythonVersion" "INFO"
        return $true
    } catch {
        # Check if Python is in app directory
        $appPython = "$InstallPath\python\python.exe"
        if (Test-Path $appPython) {
            $pythonVersion = & $appPython --version 2>&1
            Write-Status "    Python version (bundled): $pythonVersion" "INFO"
            return $true
        }
        return $false
    }
}

Test-MVPCriteria "Environment" "Playwright browsers installed" {
    $playwrightPath = "$InstallPath\node_modules\playwright\.local-browsers"
    if (Test-Path $playwrightPath) {
        $browsers = Get-ChildItem $playwrightPath -Directory | Select-Object -ExpandProperty Name
        Write-Status "    Browsers: $($browsers -join ', ')" "INFO"
        return $browsers.Count -ge 1
    }
    return $false
}

Test-MVPCriteria "Environment" "Port 3001 available (Orchestrator)" {
    $listener = Get-NetTCPConnection -LocalPort 3001 -State Listen -ErrorAction SilentlyContinue
    return $null -eq $listener
}

Test-MVPCriteria "Environment" "Port 3002 available (WebSocket)" {
    $listener = Get-NetTCPConnection -LocalPort 3002 -State Listen -ErrorAction SilentlyContinue
    return $null -eq $listener
}

# 3. Engine Checks
Write-Host "`n--- Engine Validation ---" -ForegroundColor Yellow

Test-MVPCriteria "Engines" "Web engine (port 8001)" {
    $listener = Get-NetTCPConnection -LocalPort 8001 -State Listen -ErrorAction SilentlyContinue
    return $null -eq $listener
}

Test-MVPCriteria "Engines" "Desktop engine dependencies" {
    $desktopVenv = "$InstallPath\engines\desktop\venv"
    if (Test-Path $desktopVenv) {
        $packages = Get-ChildItem "$desktopVenv\Lib\site-packages" -Directory
        $required = @("pywinauto", "PIL", "cv2", "pytesseract")
        $missing = $required | Where-Object { 
            -not ($packages.Name -match $_)
        }
        if ($missing.Count -eq 0) {
            Write-Status "    All required packages found" "INFO"
            return $true
        } else {
            Write-Status "    Missing packages: $($missing -join ', ')" "WARN"
            return $false
        }
    }
    return $false
}

Test-MVPCriteria "Engines" "API engine (port 8004)" {
    $listener = Get-NetTCPConnection -LocalPort 8004 -State Listen -ErrorAction SilentlyContinue
    return $null -eq $listener
}

# 4. Database Check
Write-Host "`n--- Database Validation ---" -ForegroundColor Yellow

Test-MVPCriteria "Database" "SQLite database exists" {
    $dbPath = "$env:APPDATA\hybrid-qa\database.sqlite"
    Test-Path $dbPath
}

# 5. Run Application Test (if requested)
if ($RunTests) {
    Write-Host "`n--- Application Launch Test ---" -ForegroundColor Yellow
    
    Test-MVPCriteria "Application" "Can launch successfully" {
        try {
            $proc = Start-Process "$InstallPath\Hybrid QA.exe" -PassThru
            Start-Sleep -Seconds 5
            
            if ($proc.HasExited) {
                Write-Status "    Application exited unexpectedly" "WARN"
                return $false
            }
            
            # Check if main window is responsive
            $mainWindow = Get-Process | Where-Object { 
                $_.MainWindowTitle -like "*Hybrid QA*" 
            }
            
            if ($mainWindow) {
                Write-Status "    Application window found: $($mainWindow.MainWindowTitle)" "INFO"
                Stop-Process $proc -Force -ErrorAction SilentlyContinue
                return $true
            }
            
            Stop-Process $proc -Force -ErrorAction SilentlyContinue
            return $false
        } catch {
            return $false
        }
    }
}

# 6. Sample Test Execution (if requested)
if ($RunTests) {
    Write-Host "`n--- Sample Test Execution ---" -ForegroundColor Yellow
    
    # This would require the app to be running and accessible via API
    Test-MVPCriteria "Execution" "Can execute web test" {
        # Placeholder - would need actual test execution
        Write-Status "    Skipping actual execution (requires running app)" "WARN"
        return $true
    }
}

# Generate Summary
Write-Host "`n=== Validation Summary ===" -ForegroundColor Magenta
Write-Host "Total Checks: $TotalChecks" -ForegroundColor Gray
Write-Host "Passed: $PassedChecks" -ForegroundColor Green
Write-Host "Failed: $($TotalChecks - $PassedChecks)" -ForegroundColor Red
Write-Host "Success Rate: $([math]::Round(($PassedChecks / $TotalChecks) * 100, 2))%" -ForegroundColor Cyan

# Show failed checks
$failedChecks = $ValidationResults.GetEnumerator() | Where-Object { $_.Value -ne "PASS" }
if ($failedChecks.Count -gt 0) {
    Write-Host "`nFailed Checks:" -ForegroundColor Red
    foreach ($check in $failedChecks) {
        Write-Host "  - $($check.Key): $($check.Value)" -ForegroundColor Red
    }
}

# Generate Report (if requested)
if ($GenerateReport) {
    $reportPath = "mvp-validation-report-$(Get-Date -Format 'yyyyMMdd-HHmmss').json"
    $report = @{
        timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        totalChecks = $TotalChecks
        passedChecks = $PassedChecks
        failedChecks = $TotalChecks - $PassedChecks
        successRate = [math]::Round(($PassedChecks / $TotalChecks) * 100, 2)
        results = $ValidationResults
        systemInfo = @{
            os = [System.Environment]::OSVersion.VersionString
            machine = $env:COMPUTERNAME
            user = $env:USERNAME
        }
    }
    
    $report | ConvertTo-Json -Depth 3 | Out-File $reportPath
    Write-Host "`nReport saved to: $reportPath" -ForegroundColor Green
}

# Exit code based on validation results
if ($PassedChecks -eq $TotalChecks) {
    Write-Host "`n✓ All MVP criteria PASSED!" -ForegroundColor Green
    exit 0
} else {
    Write-Host "`n✗ Some MVP criteria FAILED!" -ForegroundColor Red
    exit 1
} 