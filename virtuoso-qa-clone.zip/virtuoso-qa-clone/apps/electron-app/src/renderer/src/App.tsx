import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Dashboard } from './components/Dashboard';
import { ProjectView } from './components/ProjectView';
import { FlowEditor } from './components/FlowEditor';
import { RecorderPanel } from './components/RecorderPanel';
import { Layout } from './components/Layout';

function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/project/:id" element={<ProjectView />} />
          <Route path="/flow/:id" element={<FlowEditor />} />
          <Route path="/recorder" element={<RecorderPanel />} />
        </Routes>
      </Layout>
    </Router>
  );
}

export default App;