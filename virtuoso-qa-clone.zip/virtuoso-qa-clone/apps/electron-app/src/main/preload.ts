import { contextBridge, ipcRenderer } from 'electron';

export interface ElectronAPI {
  orchestrator: {
    ping: () => Promise<{ status: string; timestamp: string }>;
    getProjects: () => Promise<any[]>;
  };
}

contextBridge.exposeInMainWorld('electronAPI', {
  orchestrator: {
    ping: () => ipcRenderer.invoke('orchestrator:ping'),
    getProjects: () => ipcRenderer.invoke('orchestrator:getProjects'),
  },
} as ElectronAPI); 