import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';

export default defineConfig({
  plugins: [react()],
  root: './src/renderer',
  base: './',
  build: {
    outDir: '../../dist/renderer',
    emptyOutDir: true
  },
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src/renderer'),
      '@/components': path.resolve(__dirname, './src/renderer/components'),
      '@/lib': path.resolve(__dirname, './src/renderer/lib'),
      '@/stores': path.resolve(__dirname, './src/renderer/stores'),
      '@/types': path.resolve(__dirname, './src/renderer/types'),
      '@/hooks': path.resolve(__dirname, './src/renderer/hooks')
    }
  },
  server: {
    port: 5173,
    strictPort: true
  }
}); 