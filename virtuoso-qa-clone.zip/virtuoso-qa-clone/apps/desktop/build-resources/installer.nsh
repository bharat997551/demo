; Hybrid QA Custom Installer Script
; This script handles Python runtime and dependency installation

!include "MUI2.nsh"
!include "LogicLib.nsh"
!include "FileFunc.nsh"
!include "nsDialogs.nsh"

; Variables
Var PythonInstalled
Var PythonPath
Var S3270Installed
Var WinAppDriverInstalled
Var PlaywrightBrowsersInstalled

; Custom pages
Page custom CheckDependencies CheckDependenciesLeave
Page custom InstallDependencies

; Macros
!macro customInit
  ; Check if Python is installed
  Call CheckPython
  
  ; Check other dependencies
  Call CheckS3270
  Call CheckWinAppDriver
  Call CheckPlaywrightBrowsers
!macroend

; Check Python installation
Function CheckPython
  ; Check registry for Python
  ReadRegStr $PythonPath HKLM "SOFTWARE\Python\PythonCore\3.11\InstallPath" ""
  ${If} $PythonPath == ""
    ReadRegStr $PythonPath HKLM "SOFTWARE\Python\PythonCore\3.10\InstallPath" ""
  ${EndIf}
  ${If} $PythonPath == ""
    ReadRegStr $PythonPath HKLM "SOFTWARE\Python\PythonCore\3.9\InstallPath" ""
  ${EndIf}
  
  ${If} $PythonPath != ""
    StrCpy $PythonInstalled "1"
  ${Else}
    StrCpy $PythonInstalled "0"
  ${EndIf}
FunctionEnd

; Check s3270 installation
Function CheckS3270
  ; Check if s3270 is in PATH or common locations
  nsExec::ExecToStack 'cmd /c where s3270.exe'
  Pop $0
  Pop $1
  
  ${If} $0 == 0
    StrCpy $S3270Installed "1"
  ${Else}
    ; Check common installation paths
    ${If} ${FileExists} "$PROGRAMFILES\wc3270\s3270.exe"
      StrCpy $S3270Installed "1"
    ${ElseIf} ${FileExists} "$PROGRAMFILES64\wc3270\s3270.exe"
      StrCpy $S3270Installed "1"
    ${Else}
      StrCpy $S3270Installed "0"
    ${EndIf}
  ${EndIf}
FunctionEnd

; Check WinAppDriver
Function CheckWinAppDriver
  ${If} ${FileExists} "$PROGRAMFILES\Windows Application Driver\WinAppDriver.exe"
    StrCpy $WinAppDriverInstalled "1"
  ${ElseIf} ${FileExists} "$PROGRAMFILES64\Windows Application Driver\WinAppDriver.exe"
    StrCpy $WinAppDriverInstalled "1"
  ${Else}
    StrCpy $WinAppDriverInstalled "0"
  ${EndIf}
FunctionEnd

; Check Playwright browsers
Function CheckPlaywrightBrowsers
  ; This will be checked after Python venv is set up
  StrCpy $PlaywrightBrowsersInstalled "0"
FunctionEnd

; Dependencies check page
Function CheckDependencies
  !insertmacro MUI_HEADER_TEXT "Checking Dependencies" "Verifying required components..."
  
  nsDialogs::Create 1018
  Pop $0
  
  ${NSD_CreateLabel} 0 0 100% 20u "Hybrid QA requires the following components:"
  Pop $0
  
  ; Python status
  ${NSD_CreateLabel} 10 30u 40% 12u "Python 3.9+:"
  Pop $0
  ${If} $PythonInstalled == "1"
    ${NSD_CreateLabel} 50% 30u 50% 12u "✓ Installed"
    Pop $0
    SetCtlColors $0 0x008000 ${CLR_DEFAULT}
  ${Else}
    ${NSD_CreateLabel} 50% 30u 50% 12u "✗ Not Found"
    Pop $0
    SetCtlColors $0 0xFF0000 ${CLR_DEFAULT}
  ${EndIf}
  
  ; s3270 status (for mainframe)
  ${NSD_CreateLabel} 10 50u 40% 12u "s3270 (Mainframe):"
  Pop $0
  ${If} $S3270Installed == "1"
    ${NSD_CreateLabel} 50% 50u 50% 12u "✓ Installed"
    Pop $0
    SetCtlColors $0 0x008000 ${CLR_DEFAULT}
  ${Else}
    ${NSD_CreateLabel} 50% 50u 50% 12u "✗ Optional"
    Pop $0
    SetCtlColors $0 0xFFA500 ${CLR_DEFAULT}
  ${EndIf}
  
  ; WinAppDriver status
  ${NSD_CreateLabel} 10 70u 40% 12u "WinAppDriver:"
  Pop $0
  ${If} $WinAppDriverInstalled == "1"
    ${NSD_CreateLabel} 50% 70u 50% 12u "✓ Installed"
    Pop $0
    SetCtlColors $0 0x008000 ${CLR_DEFAULT}
  ${Else}
    ${NSD_CreateLabel} 50% 70u 50% 12u "✗ Optional"
    Pop $0
    SetCtlColors $0 0xFFA500 ${CLR_DEFAULT}
  ${EndIf}
  
  ${NSD_CreateLabel} 0 100u 100% 40u "Missing components will be installed automatically.$\r$\nOptional components can be installed later if needed."
  Pop $0
  
  nsDialogs::Show
FunctionEnd

Function CheckDependenciesLeave
FunctionEnd

; Install dependencies page
Function InstallDependencies
  ${If} $PythonInstalled == "0"
    !insertmacro MUI_HEADER_TEXT "Installing Python" "Setting up Python runtime..."
    
    ; Install embedded Python
    DetailPrint "Installing Python runtime..."
    SetOutPath "$INSTDIR\python"
    File /r "${BUILD_RESOURCES_DIR}\python\*.*"
    
    ; Add to PATH
    ${EnvVarUpdate} $0 "PATH" "A" "HKLM" "$INSTDIR\python"
    ${EnvVarUpdate} $0 "PATH" "A" "HKLM" "$INSTDIR\python\Scripts"
  ${EndIf}
  
  ; Set up Python virtual environments
  DetailPrint "Setting up Python virtual environments..."
  
  ; Desktop engine venv
  ExecWait '"$INSTDIR\python\python.exe" -m venv "$INSTDIR\engines\desktop\venv"'
  ExecWait '"$INSTDIR\engines\desktop\venv\Scripts\pip.exe" install -r "$INSTDIR\engines\desktop\requirements.txt"'
  
  ; Mainframe engine venv
  ExecWait '"$INSTDIR\python\python.exe" -m venv "$INSTDIR\engines\mainframe\venv"'
  ExecWait '"$INSTDIR\engines\mainframe\venv\Scripts\pip.exe" install -r "$INSTDIR\engines\mainframe\requirements.txt"'
  
  ; Install Playwright browsers
  DetailPrint "Installing Playwright browsers..."
  ExecWait '"$INSTDIR\node_modules\.bin\playwright.cmd" install chromium firefox webkit'
FunctionEnd

; Custom install finish actions
!macro customInstFinishRun
  ; Create first-run flag
  FileOpen $0 "$INSTDIR\first-run" w
  FileClose $0
!macroend

; Uninstall cleanup
!macro customUnInit
  ; Remove Python venvs
  RMDir /r "$INSTDIR\engines\desktop\venv"
  RMDir /r "$INSTDIR\engines\mainframe\venv"
  
  ; Remove from PATH
  ${un.EnvVarUpdate} $0 "PATH" "R" "HKLM" "$INSTDIR\python"
  ${un.EnvVarUpdate} $0 "PATH" "R" "HKLM" "$INSTDIR\python\Scripts"
!macroend 