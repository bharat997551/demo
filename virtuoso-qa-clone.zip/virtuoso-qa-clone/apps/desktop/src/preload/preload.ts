import { contextBridge, ipcRenderer } from 'electron';

// Expose protected methods that allow the renderer process to use
// the ipcRenderer without exposing the entire object
contextBridge.exposeInMainWorld('electronAPI', {
  // App info
  getAppVersion: () => ipcRenderer.invoke('get-app-version'),
  
  // Dialog methods
  showMessageBox: (options: any) => ipcRenderer.invoke('show-message-box', options),
  showOpenDialog: (options: any) => ipcRenderer.invoke('show-open-dialog', options),
  showSaveDialog: (options: any) => ipcRenderer.invoke('show-save-dialog', options),
  
  // Recording controls
  startWebRecording: (config: any) => ipcRenderer.invoke('start-web-recording', config),
  stopWebRecording: () => ipcRenderer.invoke('stop-web-recording'),
  startDesktopRecording: (config: any) => ipcRenderer.invoke('start-desktop-recording', config),
  stopDesktopRecording: () => ipcRenderer.invoke('stop-desktop-recording'),
  
  // File operations
  readFile: (filePath: string) => ipcRenderer.invoke('read-file', filePath),
  writeFile: (filePath: string, content: string) => ipcRenderer.invoke('write-file', filePath, content),
  
  // Window controls
  minimizeWindow: () => ipcRenderer.invoke('minimize-window'),
  maximizeWindow: () => ipcRenderer.invoke('maximize-window'),
  closeWindow: () => ipcRenderer.invoke('close-window'),
  
  // Event listeners
  onRecordingStep: (callback: (step: any) => void) => {
    ipcRenderer.on('recording-step', (_, step) => callback(step));
    return () => ipcRenderer.removeAllListeners('recording-step');
  },
  
  onRecordingStatusChange: (callback: (status: any) => void) => {
    ipcRenderer.on('recording-status-change', (_, status) => callback(status));
    return () => ipcRenderer.removeAllListeners('recording-status-change');
  }
});

// Type definitions for the exposed API
export interface ElectronAPI {
  getAppVersion(): Promise<string>;
  showMessageBox(options: any): Promise<any>;
  showOpenDialog(options: any): Promise<any>;
  showSaveDialog(options: any): Promise<any>;
  startWebRecording(config: any): Promise<any>;
  stopWebRecording(): Promise<any>;
  startDesktopRecording(config: any): Promise<any>;
  stopDesktopRecording(): Promise<any>;
  readFile(filePath: string): Promise<{ success: boolean; content?: string; error?: string }>;
  writeFile(filePath: string, content: string): Promise<{ success: boolean; error?: string }>;
  minimizeWindow(): Promise<void>;
  maximizeWindow(): Promise<void>;
  closeWindow(): Promise<void>;
  onRecordingStep(callback: (step: any) => void): () => void;
  onRecordingStatusChange(callback: (status: any) => void): () => void;
}

declare global {
  interface Window {
    electronAPI: ElectronAPI;
  }
} 