import React from 'react'
import { motion } from 'framer-motion'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { TestEditor } from '@/components/editor/test-editor'
import { FlowCanvas } from '@/components/flow/flow-canvas'
import { RunView } from '@/components/run/run-view'
import { 
  Rocket, 
  CheckCircle2, 
  Code, 
  GitBranch, 
  Play,
  Bug,
  Terminal,
  Circle,
  Monitor
} from 'lucide-react'

// Sample test steps for the editor
const sampleSteps = [
  {
    id: 'step-1',
    kind: 'web.navigate',
    description: 'Navigate to login page',
    config: { url: 'https://example.com/login' }
  },
  {
    id: 'step-2',
    kind: 'web.type',
    description: 'Enter username',
    config: { selector: '#username', text: 'test@example.com' }
  },
  {
    id: 'step-3',
    kind: 'web.type',
    description: 'Enter password',
    config: { selector: '#password', text: '********' }
  },
  {
    id: 'step-4',
    kind: 'web.click',
    description: 'Click login button',
    config: { selector: 'button[type="submit"]' }
  }
]

// Sample nodes for flow canvas
const sampleNodes = [
  {
    id: '1',
    type: 'step',
    position: { x: 100, y: 100 },
    data: { label: 'Login Test', description: 'User authentication flow' }
  },
  {
    id: '2',
    type: 'condition',
    position: { x: 300, y: 100 },
    data: { label: 'Check Login', condition: 'response.status === 200' }
  },
  {
    id: '3',
    type: 'step',
    position: { x: 500, y: 50 },
    data: { label: 'Dashboard Test', description: 'Verify dashboard loads' }
  },
  {
    id: '4',
    type: 'step',
    position: { x: 500, y: 150 },
    data: { label: 'Error Handler', description: 'Handle login failure' }
  }
]

const sampleEdges = [
  { id: 'e1-2', source: '1', target: '2', type: 'smoothstep' },
  { id: 'e2-3', source: '2', target: '3', label: 'Success' },
  { id: 'e2-4', source: '2', target: '4', label: 'Failure' }
]

export function DemoPage() {
  const [activeDemo, setActiveDemo] = React.useState<'overview' | 'editor' | 'flow' | 'run'>('overview')

  const features = [
    {
      icon: Code,
      title: 'Test Editor',
      description: 'Visual and YAML modes with validation',
      demo: 'editor'
    },
    {
      icon: GitBranch,
      title: 'Flow Canvas',
      description: 'Create test flows with React Flow',
      demo: 'flow'
    },
    {
      icon: Play,
      title: 'Run View',
      description: 'Real-time logs and artifacts',
      demo: 'run'
    },
    {
      icon: Circle,
      title: 'Web Recorder',
      description: 'Floating widget with step capture',
      action: () => {
        const event = new KeyboardEvent('keydown', {
          key: 'R',
          ctrlKey: true,
          shiftKey: true
        })
        window.dispatchEvent(event)
      }
    },
    {
      icon: Monitor,
      title: 'Desktop Recorder',
      description: 'Full-screen overlay recording',
      action: () => {
        const event = new KeyboardEvent('keydown', {
          key: 'D',
          ctrlKey: true,
          shiftKey: true
        })
        window.dispatchEvent(event)
      }
    },
    {
      icon: Bug,
      title: 'Debug Mode',
      description: 'Breakpoints and element inspection',
      action: () => {
        const event = new KeyboardEvent('keydown', {
          key: 'F5',
          shiftKey: true
        })
        window.dispatchEvent(event)
      }
    },
    {
      icon: Terminal,
      title: 'DevTools',
      description: 'Structured logs and artifacts',
      action: () => {
        const event = new KeyboardEvent('keydown', {
          key: 'F12'
        })
        window.dispatchEvent(event)
      }
    }
  ]

  return (
    <div className="h-full overflow-hidden">
      <Tabs value={activeDemo} onValueChange={(value) => setActiveDemo(value as any)} className="h-full flex flex-col">
        <div className="border-b px-6 py-4">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-2xl font-bold flex items-center gap-2">
                <Rocket className="h-6 w-6 text-primary" />
                Hybrid QA Desktop Demo
              </h1>
              <p className="text-muted-foreground">
                Explore all the implemented features of the test automation platform
              </p>
            </div>
          </div>
          
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="editor">Test Editor</TabsTrigger>
            <TabsTrigger value="flow">Flow Canvas</TabsTrigger>
            <TabsTrigger value="run">Run View</TabsTrigger>
          </TabsList>
        </div>

        <div className="flex-1 overflow-hidden">
          <TabsContent value="overview" className="h-full p-6 overflow-y-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="max-w-6xl mx-auto"
            >
              <div className="mb-8 text-center">
                <h2 className="text-3xl font-bold mb-4">Welcome to Hybrid QA</h2>
                <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                  A comprehensive desktop test automation platform with intelligent orchestration, 
                  self-healing selectors, and advanced debugging capabilities.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                {features.map((feature) => (
                  <motion.div
                    key={feature.title}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <Card 
                      className="h-full cursor-pointer hover:shadow-lg transition-all"
                      onClick={() => feature.demo ? setActiveDemo(feature.demo as any) : feature.action?.()}
                    >
                      <CardHeader>
                        <feature.icon className="h-8 w-8 text-primary mb-2" />
                        <CardTitle>{feature.title}</CardTitle>
                        <CardDescription>{feature.description}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <Button variant="ghost" className="w-full">
                          {feature.demo ? 'View Demo' : 'Launch'}
                        </Button>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>

              <Card className="mb-8">
                <CardHeader>
                  <CardTitle>Key Features Implemented</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="h-5 w-5 text-green-500" />
                        <span>Main layout with sidebar navigation</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="h-5 w-5 text-green-500" />
                        <span>Web & Desktop recorder panels</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="h-5 w-5 text-green-500" />
                        <span>Visual/YAML test editor</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="h-5 w-5 text-green-500" />
                        <span>React Flow DAG builder</span>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="h-5 w-5 text-green-500" />
                        <span>Real-time run monitoring</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="h-5 w-5 text-green-500" />
                        <span>Debug mode with breakpoints</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="h-5 w-5 text-green-500" />
                        <span>DevTools with structured logs</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="h-5 w-5 text-green-500" />
                        <span>Dark theme with animations</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Keyboard Shortcuts</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4 font-mono text-sm">
                    <div>
                      <kbd className="px-2 py-1 bg-muted rounded">F5</kbd> Run/Stop
                    </div>
                    <div>
                      <kbd className="px-2 py-1 bg-muted rounded">Shift+F5</kbd> Debug Mode
                    </div>
                    <div>
                      <kbd className="px-2 py-1 bg-muted rounded">F12</kbd> DevTools
                    </div>
                    <div>
                      <kbd className="px-2 py-1 bg-muted rounded">Ctrl+Shift+R</kbd> Web Recorder
                    </div>
                    <div>
                      <kbd className="px-2 py-1 bg-muted rounded">Ctrl+Shift+D</kbd> Desktop Recorder
                    </div>
                    <div>
                      <kbd className="px-2 py-1 bg-muted rounded">F10</kbd> Step Over (Debug)
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>

          <TabsContent value="editor" className="h-full">
            <TestEditor 
              initialSteps={sampleSteps}
              onStepsChange={(steps) => console.log('Steps changed:', steps)}
              onSave={(content) => console.log('Save:', content)}
              onRun={(steps) => console.log('Run:', steps)}
            />
          </TabsContent>

          <TabsContent value="flow" className="h-full">
            <FlowCanvas
              initialNodes={sampleNodes}
              initialEdges={sampleEdges}
              onNodesChange={(nodes) => console.log('Nodes changed:', nodes)}
              onEdgesChange={(edges) => console.log('Edges changed:', edges)}
              onSave={(flow) => console.log('Save flow:', flow)}
              onRun={(startNode) => console.log('Run from:', startNode)}
            />
          </TabsContent>

          <TabsContent value="run" className="h-full">
            <RunView
              runId="demo-run-123"
              isRunning={false}
              onStop={() => console.log('Stop')}
              onRerun={(stepId) => console.log('Rerun:', stepId)}
              onSkipStep={(stepId) => console.log('Skip:', stepId)}
            />
          </TabsContent>
        </div>
      </Tabs>
    </div>
  )
} 