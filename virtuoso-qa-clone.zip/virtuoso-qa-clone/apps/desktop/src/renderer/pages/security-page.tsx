import React from 'react'
import { motion } from 'framer-motion'
import { EnvironmentManager } from '@/components/security/environment-manager'

export function SecurityPage() {
  // In a real app, this would come from router params or context
  const projectId = 'demo-project';

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
      className="h-full overflow-auto p-6"
    >
      <EnvironmentManager projectId={projectId} />
    </motion.div>
  )
} 