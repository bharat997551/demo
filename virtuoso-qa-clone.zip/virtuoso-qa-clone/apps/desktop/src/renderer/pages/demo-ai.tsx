import React from 'react'
import { motion } from 'framer-motion'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { AIAssistantPanel } from '@/components/assistant/ai-assistant-panel'
import { TestEditor } from '@/components/editor/test-editor'
import { Bot, Sparkles, Lightbulb, Code, CheckCircle2 } from 'lucide-react'

export function DemoAIPage() {
  const [generatedSteps, setGeneratedSteps] = React.useState<any[]>([])

  const handleAcceptSteps = (steps: any[]) => {
    setGeneratedSteps(steps)
  }

  return (
    <div className="h-full overflow-hidden">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
        className="h-full flex flex-col"
      >
        {/* Header */}
        <div className="px-6 py-4 border-b">
          <div className="flex items-center gap-3 mb-4">
            <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
              <Bot className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">AI Assistant Demo</h1>
              <p className="text-muted-foreground">
                Experience intelligent test automation with natural language
              </p>
            </div>
          </div>

          {/* Feature Cards */}
          <div className="grid grid-cols-4 gap-4">
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-3 mb-2">
                  <Code className="h-5 w-5 text-blue-500" />
                  <h3 className="font-semibold">NL to DSL</h3>
                </div>
                <p className="text-sm text-muted-foreground">
                  Convert plain English to test steps
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-3 mb-2">
                  <Lightbulb className="h-5 w-5 text-yellow-500" />
                  <h3 className="font-semibold">Smart Debugging</h3>
                </div>
                <p className="text-sm text-muted-foreground">
                  AI-powered failure analysis
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-3 mb-2">
                  <Sparkles className="h-5 w-5 text-purple-500" />
                  <h3 className="font-semibold">Optimization</h3>
                </div>
                <p className="text-sm text-muted-foreground">
                  Improve test performance
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-3 mb-2">
                  <CheckCircle2 className="h-5 w-5 text-green-500" />
                  <h3 className="font-semibold">Best Practices</h3>
                </div>
                <p className="text-sm text-muted-foreground">
                  Stable selector suggestions
                </p>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 flex overflow-hidden">
          {/* AI Assistant Panel */}
          <div className="w-[400px] border-r">
            <AIAssistantPanel onAcceptSteps={handleAcceptSteps} />
          </div>

          {/* Test Editor */}
          <div className="flex-1 p-6">
            <Card className="h-full">
              <CardHeader>
                <CardTitle>Generated Test</CardTitle>
                <CardDescription>
                  AI-generated steps appear here when you accept them
                </CardDescription>
              </CardHeader>
              <CardContent className="h-[calc(100%-5rem)]">
                {generatedSteps.length > 0 ? (
                  <div className="h-full">
                    <TestEditor initialSteps={generatedSteps} />
                  </div>
                ) : (
                  <div className="h-full flex items-center justify-center text-muted-foreground">
                    <div className="text-center">
                      <Bot className="h-16 w-16 mx-auto mb-4 opacity-20" />
                      <p className="text-lg font-medium mb-2">No steps generated yet</p>
                      <p className="text-sm">
                        Try asking the AI Assistant to create a test for you!
                      </p>
                      <div className="mt-6 space-y-2 text-sm">
                        <p className="font-medium">Example prompts:</p>
                        <p className="italic">"Create a login test"</p>
                        <p className="italic">"Test the checkout flow"</p>
                        <p className="italic">"Verify API response"</p>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </motion.div>
    </div>
  )
} 