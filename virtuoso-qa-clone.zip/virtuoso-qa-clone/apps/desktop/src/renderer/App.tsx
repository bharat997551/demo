import React from 'react'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import { MainLayout } from './components/layout/main-layout'
import { TestEditor } from './components/editor/test-editor'
import { FlowCanvas } from './components/flow/flow-canvas'
import { RunsDashboard } from './components/runs/runs-dashboard'
import { RunDetail } from './components/runs/run-detail'
import { DemoPage } from './pages/demo-page'
import { DemoAIPage } from './pages/demo-ai'
import './styles/globals.css'

// Page Components
const ProjectsPage = () => (
  <div className="p-6">
    <h1 className="text-2xl font-bold mb-4">Projects</h1>
    <p className="text-muted-foreground">Manage your test projects here.</p>
  </div>
)

const FlowsPage = () => (
  <div className="h-full">
    <FlowCanvas />
  </div>
)

const RecordersPage = () => (
  <div className="p-6">
    <h1 className="text-2xl font-bold mb-4">Recorders</h1>
    <p className="text-muted-foreground">Web and Desktop recorders are available via floating buttons.</p>
  </div>
)

const ReportsPage = () => (
  <div className="p-6">
    <h1 className="text-2xl font-bold mb-4">Reports</h1>
    <p className="text-muted-foreground">View test execution reports and analytics.</p>
  </div>
)

const SettingsPage = () => (
  <div className="p-6">
    <h1 className="text-2xl font-bold mb-4">Settings</h1>
    <p className="text-muted-foreground">Configure application settings and preferences.</p>
  </div>
)

const TestEditorPage = () => (
  <div className="h-full">
    <TestEditor />
  </div>
)

function App() {
  // Set dark theme by default
  React.useEffect(() => {
    document.documentElement.classList.add('dark')
  }, [])

  return (
    <Router>
      <div className="app dark">
        <Routes>
          <Route path="/" element={<MainLayout />}>
            <Route index element={<Navigate to="/demo" replace />} />
            <Route path="demo" element={<DemoPage />} />
            <Route path="projects" element={<ProjectsPage />} />
            <Route path="projects/:id" element={<ProjectsPage />} />
            <Route path="flows" element={<FlowsPage />} />
            <Route path="flows/:id" element={<FlowsPage />} />
            <Route path="editor" element={<TestEditorPage />} />
            <Route path="editor/:id" element={<TestEditorPage />} />
            <Route path="recorders" element={<RecordersPage />} />
            <Route path="recorders/web" element={<RecordersPage />} />
            <Route path="recorders/desktop" element={<RecordersPage />} />
            <Route path="runs" element={<RunsDashboard />} />
            <Route path="runs/:runId" element={<RunDetail />} />
            <Route path="reports" element={<ReportsPage />} />
            <Route path="settings" element={<SettingsPage />} />
            <Route path="ai-demo" element={<DemoAIPage />} />
          </Route>
        </Routes>
      </div>
    </Router>
  )
}

export default App 