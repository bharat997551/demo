import React from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Terminal,
  Search,
  Filter,
  Download,
  Trash2,
  Copy,
  Check,
  AlertCircle,
  Info,
  Bug,
  Clock,
  FileText,
  Image,
  Video,
  Database,
  Network,
  Cpu,
  HardDrive,
  ChevronRight,
  ChevronDown,
  ExternalLink,
  Code
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { cn } from '@/lib/utils'

interface LogEntry {
  id: string
  timestamp: number
  level: 'debug' | 'info' | 'warning' | 'error'
  category: 'system' | 'test' | 'network' | 'performance' | 'artifact'
  message: string
  data?: any
  source?: {
    file?: string
    line?: number
    function?: string
  }
  breadcrumbs?: string[]
  artifacts?: ArtifactLink[]
  duration?: number
  metadata?: Record<string, any>
}

interface ArtifactLink {
  id: string
  type: 'screenshot' | 'video' | 'log' | 'data' | 'report'
  name: string
  path: string
  size?: number
  preview?: string
}

interface Breadcrumb {
  id: string
  label: string
  timestamp: number
  metadata?: Record<string, any>
}

interface DevToolsPanelProps {
  logs?: LogEntry[]
  breadcrumbs?: Breadcrumb[]
  onClearLogs?: () => void
  onExportLogs?: () => void
  onOpenArtifact?: (artifact: ArtifactLink) => void
}

export function DevToolsPanel({
  logs = [],
  breadcrumbs = [],
  onClearLogs,
  onExportLogs,
  onOpenArtifact
}: DevToolsPanelProps) {
  const [activeTab, setActiveTab] = React.useState<'console' | 'network' | 'performance' | 'artifacts'>('console')
  const [searchQuery, setSearchQuery] = React.useState('')
  const [selectedLevels, setSelectedLevels] = React.useState<Set<string>>(
    new Set(['debug', 'info', 'warning', 'error'])
  )
  const [selectedCategories, setSelectedCategories] = React.useState<Set<string>>(
    new Set(['system', 'test', 'network', 'performance', 'artifact'])
  )
  const [expandedLogs, setExpandedLogs] = React.useState<Set<string>>(new Set())
  const [copiedId, setCopiedId] = React.useState<string | null>(null)
  const [showFilters, setShowFilters] = React.useState(false)

  const filteredLogs = React.useMemo(() => {
    return logs.filter(log => {
      if (!selectedLevels.has(log.level)) return false
      if (!selectedCategories.has(log.category)) return false
      if (searchQuery && !log.message.toLowerCase().includes(searchQuery.toLowerCase())) {
        if (!JSON.stringify(log.data).toLowerCase().includes(searchQuery.toLowerCase())) {
          return false
        }
      }
      return true
    })
  }, [logs, selectedLevels, selectedCategories, searchQuery])

  const toggleLogExpanded = (logId: string) => {
    setExpandedLogs(prev => {
      const newSet = new Set(prev)
      if (newSet.has(logId)) {
        newSet.delete(logId)
      } else {
        newSet.add(logId)
      }
      return newSet
    })
  }

  const toggleLevel = (level: string) => {
    setSelectedLevels(prev => {
      const newSet = new Set(prev)
      if (newSet.has(level)) {
        newSet.delete(level)
      } else {
        newSet.add(level)
      }
      return newSet
    })
  }

  const toggleCategory = (category: string) => {
    setSelectedCategories(prev => {
      const newSet = new Set(prev)
      if (newSet.has(category)) {
        newSet.delete(category)
      } else {
        newSet.add(category)
      }
      return newSet
    })
  }

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text)
    setCopiedId(id)
    setTimeout(() => setCopiedId(null), 2000)
  }

  const getLevelIcon = (level: LogEntry['level']) => {
    switch (level) {
      case 'error':
        return <AlertCircle className="h-4 w-4 text-red-500" />
      case 'warning':
        return <AlertCircle className="h-4 w-4 text-yellow-500" />
      case 'info':
        return <Info className="h-4 w-4 text-blue-500" />
      case 'debug':
        return <Bug className="h-4 w-4 text-muted-foreground" />
    }
  }

  const getCategoryIcon = (category: LogEntry['category']) => {
    switch (category) {
      case 'system':
        return <Cpu className="h-4 w-4" />
      case 'test':
        return <FileText className="h-4 w-4" />
      case 'network':
        return <Network className="h-4 w-4" />
      case 'performance':
        return <Clock className="h-4 w-4" />
      case 'artifact':
        return <HardDrive className="h-4 w-4" />
    }
  }

  const getArtifactIcon = (type: ArtifactLink['type']) => {
    switch (type) {
      case 'screenshot':
        return <Image className="h-4 w-4" />
      case 'video':
        return <Video className="h-4 w-4" />
      case 'log':
        return <FileText className="h-4 w-4" />
      case 'data':
        return <Database className="h-4 w-4" />
      case 'report':
        return <FileText className="h-4 w-4" />
    }
  }

  const formatTimestamp = (timestamp: number) => {
    const date = new Date(timestamp)
    return date.toLocaleTimeString('en-US', { 
      hour12: false,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      fractionalSecondDigits: 3
    })
  }

  const networkLogs = filteredLogs.filter(log => log.category === 'network')
  const performanceLogs = filteredLogs.filter(log => log.category === 'performance')
  const artifactLogs = filteredLogs.filter(log => log.artifacts && log.artifacts.length > 0)

  return (
    <div className="h-full flex flex-col bg-background border-t">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b">
        <div className="flex items-center gap-2">
          <Terminal className="h-5 w-5 text-primary" />
          <h2 className="text-lg font-semibold">DevTools</h2>
          <span className="text-sm text-muted-foreground">
            {filteredLogs.length} / {logs.length} logs
          </span>
        </div>
        
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={() => setShowFilters(!showFilters)}
          >
            <Filter className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={onExportLogs}
          >
            <Download className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={onClearLogs}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="p-4 border-b space-y-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search logs..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        
        {showFilters && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="space-y-3 overflow-hidden"
          >
            {/* Level Filters */}
            <div>
              <label className="text-sm font-medium mb-2 block">Levels</label>
              <div className="flex gap-2">
                {(['debug', 'info', 'warning', 'error'] as const).map(level => (
                  <Button
                    key={level}
                    variant={selectedLevels.has(level) ? 'default' : 'outline'}
                    size="sm"
                    className="gap-2"
                    onClick={() => toggleLevel(level)}
                  >
                    {getLevelIcon(level)}
                    {level}
                  </Button>
                ))}
              </div>
            </div>
            
            {/* Category Filters */}
            <div>
              <label className="text-sm font-medium mb-2 block">Categories</label>
              <div className="flex gap-2 flex-wrap">
                {(['system', 'test', 'network', 'performance', 'artifact'] as const).map(category => (
                  <Button
                    key={category}
                    variant={selectedCategories.has(category) ? 'default' : 'outline'}
                    size="sm"
                    className="gap-2"
                    onClick={() => toggleCategory(category)}
                  >
                    {getCategoryIcon(category)}
                    {category}
                  </Button>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </div>

      {/* Breadcrumbs */}
      {breadcrumbs.length > 0 && (
        <div className="px-4 py-2 border-b bg-muted/30">
          <div className="flex items-center gap-1 text-xs">
            {breadcrumbs.map((crumb, index) => (
              <React.Fragment key={crumb.id}>
                {index > 0 && <ChevronRight className="h-3 w-3 text-muted-foreground" />}
                <span className="text-muted-foreground hover:text-foreground cursor-pointer">
                  {crumb.label}
                </span>
              </React.Fragment>
            ))}
          </div>
        </div>
      )}

      {/* Content Tabs */}
      <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as any)} className="flex-1 flex flex-col">
        <TabsList className="mx-4 mt-4 w-fit">
          <TabsTrigger value="console" className="gap-2">
            <Terminal className="h-4 w-4" />
            Console
          </TabsTrigger>
          <TabsTrigger value="network" className="gap-2">
            <Network className="h-4 w-4" />
            Network ({networkLogs.length})
          </TabsTrigger>
          <TabsTrigger value="performance" className="gap-2">
            <Clock className="h-4 w-4" />
            Performance
          </TabsTrigger>
          <TabsTrigger value="artifacts" className="gap-2">
            <HardDrive className="h-4 w-4" />
            Artifacts ({artifactLogs.reduce((acc, log) => acc + (log.artifacts?.length || 0), 0)})
          </TabsTrigger>
        </TabsList>

        {/* Console Tab */}
        <TabsContent value="console" className="flex-1 overflow-y-auto mt-4 mx-4 mb-4">
          <div className="space-y-1">
            <AnimatePresence>
              {filteredLogs.map((log) => (
                <motion.div
                  key={log.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className={cn(
                    "font-mono text-sm p-2 rounded border",
                    log.level === 'error' && "bg-red-500/10 border-red-500/20",
                    log.level === 'warning' && "bg-yellow-500/10 border-yellow-500/20",
                    log.level === 'info' && "bg-blue-500/10 border-blue-500/20",
                    log.level === 'debug' && "bg-muted/50 border-border"
                  )}
                >
                  <div className="flex items-start gap-3">
                    <div className="flex-shrink-0 mt-0.5">
                      {getLevelIcon(log.level)}
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xs text-muted-foreground">
                          {formatTimestamp(log.timestamp)}
                        </span>
                        <span className="text-xs bg-muted px-2 py-0.5 rounded">
                          {log.category}
                        </span>
                        {log.source?.file && (
                          <span className="text-xs text-muted-foreground">
                            {log.source.file}:{log.source.line}
                          </span>
                        )}
                        {log.duration && (
                          <span className="text-xs text-muted-foreground">
                            {log.duration}ms
                          </span>
                        )}
                      </div>
                      
                      <div className="break-words">{log.message}</div>
                      
                      {/* Data and Details */}
                      {(log.data || log.metadata || log.artifacts) && (
                        <div className="mt-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-6 gap-1 text-xs p-1"
                            onClick={() => toggleLogExpanded(log.id)}
                          >
                            {expandedLogs.has(log.id) ? (
                              <ChevronDown className="h-3 w-3" />
                            ) : (
                              <ChevronRight className="h-3 w-3" />
                            )}
                            Details
                          </Button>
                          
                          {expandedLogs.has(log.id) && (
                            <div className="mt-2 space-y-2">
                              {log.data && (
                                <div>
                                  <div className="flex items-center justify-between mb-1">
                                    <span className="text-xs font-medium">Data</span>
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      className="h-5 w-5"
                                      onClick={() => copyToClipboard(
                                        JSON.stringify(log.data, null, 2),
                                        `${log.id}-data`
                                      )}
                                    >
                                      {copiedId === `${log.id}-data` ? (
                                        <Check className="h-3 w-3 text-green-500" />
                                      ) : (
                                        <Copy className="h-3 w-3" />
                                      )}
                                    </Button>
                                  </div>
                                  <pre className="text-xs bg-muted p-2 rounded overflow-x-auto">
                                    {JSON.stringify(log.data, null, 2)}
                                  </pre>
                                </div>
                              )}
                              
                              {log.artifacts && log.artifacts.length > 0 && (
                                <div>
                                  <span className="text-xs font-medium">Artifacts</span>
                                  <div className="mt-1 space-y-1">
                                    {log.artifacts.map(artifact => (
                                      <div
                                        key={artifact.id}
                                        className="flex items-center gap-2 p-1 hover:bg-muted rounded cursor-pointer"
                                        onClick={() => onOpenArtifact?.(artifact)}
                                      >
                                        {getArtifactIcon(artifact.type)}
                                        <span className="text-xs flex-1">{artifact.name}</span>
                                        <ExternalLink className="h-3 w-3" />
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                    
                    <div className="flex-shrink-0">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6"
                        onClick={() => copyToClipboard(
                          JSON.stringify(log, null, 2),
                          log.id
                        )}
                      >
                        {copiedId === log.id ? (
                          <Check className="h-3 w-3 text-green-500" />
                        ) : (
                          <Code className="h-3 w-3" />
                        )}
                      </Button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
            
            {filteredLogs.length === 0 && (
              <div className="flex items-center justify-center h-64 text-muted-foreground">
                <div className="text-center">
                  <Terminal className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">No logs to display</p>
                  <p className="text-xs">Adjust filters or wait for new logs</p>
                </div>
              </div>
            )}
          </div>
        </TabsContent>

        {/* Network Tab */}
        <TabsContent value="network" className="flex-1 overflow-y-auto mt-4 mx-4 mb-4">
          <div className="space-y-2">
            {networkLogs.map(log => (
              <Card key={log.id} className="p-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Network className="h-4 w-4 text-primary" />
                    <div>
                      <p className="text-sm font-medium">{log.message}</p>
                      <p className="text-xs text-muted-foreground">
                        {formatTimestamp(log.timestamp)}
                      </p>
                    </div>
                  </div>
                  {log.duration && (
                    <span className="text-sm font-mono">{log.duration}ms</span>
                  )}
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Performance Tab */}
        <TabsContent value="performance" className="flex-1 overflow-y-auto mt-4 mx-4 mb-4">
          <div className="space-y-2">
            {performanceLogs.map(log => (
              <Card key={log.id} className="p-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Clock className="h-4 w-4 text-primary" />
                    <div>
                      <p className="text-sm font-medium">{log.message}</p>
                      <p className="text-xs text-muted-foreground">
                        {formatTimestamp(log.timestamp)}
                      </p>
                    </div>
                  </div>
                  {log.duration && (
                    <span className="text-sm font-mono">{log.duration}ms</span>
                  )}
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Artifacts Tab */}
        <TabsContent value="artifacts" className="flex-1 overflow-y-auto mt-4 mx-4 mb-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {artifactLogs.flatMap(log => 
              log.artifacts?.map(artifact => (
                <Card 
                  key={artifact.id} 
                  className="cursor-pointer hover:shadow-md transition-all"
                  onClick={() => onOpenArtifact?.(artifact)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      {getArtifactIcon(artifact.type)}
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm truncate">{artifact.name}</p>
                        <p className="text-xs text-muted-foreground">{artifact.type}</p>
                      </div>
                      <ExternalLink className="h-4 w-4 text-muted-foreground" />
                    </div>
                    {artifact.preview && (
                      <div className="mt-3">
                        <img 
                          src={artifact.preview} 
                          alt={artifact.name}
                          className="w-full h-24 object-cover rounded"
                        />
                      </div>
                    )}
                  </CardContent>
                </Card>
              )) || []
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
} 