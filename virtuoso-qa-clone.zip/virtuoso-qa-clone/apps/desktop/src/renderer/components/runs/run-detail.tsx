import React from 'react'
import { useParams, Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import {
  ArrowLeft,
  Play,
  CheckCircle,
  XCircle,
  Clock,
  AlertCircle,
  Download,
  ExternalLink,
  FileText,
  Image,
  Code,
  Terminal,
  MoreVertical,
  ChevronRight,
  Maximize2,
  Copy,
  RefreshCw
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { InlineArtifactViewer } from './artifact-viewers/inline-artifact-viewer'

interface TestStep {
  id: string
  name: string
  type: 'web' | 'api' | 'desktop' | 'mainframe'
  status: 'running' | 'passed' | 'failed' | 'skipped' | 'pending'
  startTime?: Date
  endTime?: Date
  duration?: number
  logs: LogEntry[]
  artifacts: Artifact[]
  error?: {
    message: string
    stackTrace?: string
  }
}

interface LogEntry {
  id: string
  timestamp: Date
  level: 'debug' | 'info' | 'warn' | 'error'
  message: string
  data?: any
}

interface Artifact {
  id: string
  name: string
  type: 'screenshot' | 'har' | 'json' | 'text' | '3270-grid' | 'video' | 'log'
  size: number
  url: string
  metadata?: any
}

interface RunDetailProps {
  className?: string
}

export function RunDetail({ className }: RunDetailProps) {
  const { runId } = useParams<{ runId: string }>()
  const [selectedStep, setSelectedStep] = React.useState<TestStep | null>(null)
  const [activeTab, setActiveTab] = React.useState('timeline')

  // Mock data for demonstration
  const run = {
    id: runId,
    name: 'E2E Test Suite - Login Flow',
    status: 'failed' as const,
    startTime: new Date(Date.now() - 1000 * 60 * 30),
    endTime: new Date(Date.now() - 1000 * 60 * 25),
    duration: 300000,
    environment: 'production',
    triggeredBy: 'CI Pipeline',
    commitHash: 'abc123def',
    branch: 'main',
    tags: ['smoke', 'login', 'critical']
  }

  const steps: TestStep[] = [
    {
      id: 'step-1',
      name: 'Navigate to Login Page',
      type: 'web',
      status: 'passed',
      startTime: new Date(Date.now() - 1000 * 60 * 30),
      endTime: new Date(Date.now() - 1000 * 60 * 29.5),
      duration: 30000,
      logs: [
        {
          id: 'log-1',
          timestamp: new Date(Date.now() - 1000 * 60 * 30),
          level: 'info',
          message: 'Navigating to https://example.com/login'
        },
        {
          id: 'log-2',
          timestamp: new Date(Date.now() - 1000 * 60 * 29.8),
          level: 'debug',
          message: 'Page loaded successfully',
          data: { loadTime: 1200 }
        }
      ],
      artifacts: [
        {
          id: 'art-1',
          name: 'login-page-screenshot.png',
          type: 'screenshot',
          size: 245760,
          url: '/artifacts/screenshot-1.png'
        }
      ]
    },
    {
      id: 'step-2',
      name: 'Enter Credentials',
      type: 'web',
      status: 'passed',
      startTime: new Date(Date.now() - 1000 * 60 * 29.5),
      endTime: new Date(Date.now() - 1000 * 60 * 29),
      duration: 30000,
      logs: [
        {
          id: 'log-3',
          timestamp: new Date(Date.now() - 1000 * 60 * 29.5),
          level: 'info',
          message: 'Filling username field'
        },
        {
          id: 'log-4',
          timestamp: new Date(Date.now() - 1000 * 60 * 29.2),
          level: 'info',
          message: 'Filling password field'
        }
      ],
      artifacts: []
    },
    {
      id: 'step-3',
      name: 'Submit Login Form',
      type: 'web',
      status: 'failed',
      startTime: new Date(Date.now() - 1000 * 60 * 29),
      endTime: new Date(Date.now() - 1000 * 60 * 28),
      duration: 60000,
      error: {
        message: 'Element not found: button[type="submit"]',
        stackTrace: `Error: Element not found: button[type="submit"]
  at Locator.click (playwright/src/locator.ts:123:45)
  at LoginPage.submit (tests/pages/login.page.ts:45:12)
  at Context.<anonymous> (tests/login.spec.ts:23:5)`
      },
      logs: [
        {
          id: 'log-5',
          timestamp: new Date(Date.now() - 1000 * 60 * 29),
          level: 'info',
          message: 'Clicking submit button'
        },
        {
          id: 'log-6',
          timestamp: new Date(Date.now() - 1000 * 60 * 28.5),
          level: 'error',
          message: 'Failed to find element',
          data: { selector: 'button[type="submit"]', timeout: 30000 }
        }
      ],
      artifacts: [
        {
          id: 'art-2',
          name: 'failure-screenshot.png',
          type: 'screenshot',
          size: 312320,
          url: '/artifacts/screenshot-2.png'
        },
        {
          id: 'art-3',
          name: 'network.har',
          type: 'har',
          size: 89600,
          url: '/artifacts/network-1.har'
        }
      ]
    },
    {
      id: 'step-4',
      name: 'Verify Dashboard',
      type: 'web',
      status: 'skipped',
      logs: [
        {
          id: 'log-7',
          timestamp: new Date(Date.now() - 1000 * 60 * 28),
          level: 'info',
          message: 'Step skipped due to previous failure'
        }
      ],
      artifacts: []
    }
  ]

  React.useEffect(() => {
    // Select first step by default
    if (!selectedStep && steps.length > 0) {
      setSelectedStep(steps[0])
    }
  }, [selectedStep, steps])

  const getStepIcon = (status: TestStep['status']) => {
    switch (status) {
      case 'running':
        return <Play className="h-4 w-4" />
      case 'passed':
        return <CheckCircle className="h-4 w-4" />
      case 'failed':
        return <XCircle className="h-4 w-4" />
      case 'skipped':
        return <AlertCircle className="h-4 w-4" />
      case 'pending':
        return <Clock className="h-4 w-4" />
    }
  }

  const getStepColor = (status: TestStep['status']) => {
    switch (status) {
      case 'running':
        return 'text-blue-500 bg-blue-50 border-blue-200'
      case 'passed':
        return 'text-green-500 bg-green-50 border-green-200'
      case 'failed':
        return 'text-red-500 bg-red-50 border-red-200'
      case 'skipped':
        return 'text-yellow-500 bg-yellow-50 border-yellow-200'
      case 'pending':
        return 'text-gray-500 bg-gray-50 border-gray-200'
    }
  }

  const getLogColor = (level: LogEntry['level']) => {
    switch (level) {
      case 'debug':
        return 'text-gray-500'
      case 'info':
        return 'text-blue-500'
      case 'warn':
        return 'text-yellow-500'
      case 'error':
        return 'text-red-500'
    }
  }

  const formatDuration = (ms?: number) => {
    if (!ms) return '--'
    const seconds = Math.floor(ms / 1000)
    const minutes = Math.floor(seconds / 60)
    
    if (minutes > 0) {
      return `${minutes}m ${seconds % 60}s`
    } else {
      return `${seconds}s`
    }
  }

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
  }

  const handleExport = () => {
    console.log('Export run:', runId)
    // TODO: Implement export functionality
  }

  const handleRerun = () => {
    console.log('Rerun:', runId)
    // TODO: Implement rerun functionality
  }

  return (
    <div className={cn("flex h-full", className)}>
      {/* Left Panel - Timeline */}
      <div className="w-80 border-r flex flex-col">
        <div className="p-4 border-b">
          <Link to="/runs" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-4">
            <ArrowLeft className="h-4 w-4" />
            Back to Runs
          </Link>
          
          <h2 className="font-semibold mb-1">{run.name}</h2>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Badge variant={run.status === 'passed' ? 'success' : 'destructive'}>
              {run.status}
            </Badge>
            <span>{formatDuration(run.duration)}</span>
          </div>
        </div>

        <ScrollArea className="flex-1">
          <div className="p-4">
            <h3 className="text-sm font-medium mb-3">Test Steps</h3>
            <div className="space-y-1">
              {steps.map((step, index) => (
                <motion.button
                  key={step.id}
                  onClick={() => setSelectedStep(step)}
                  className={cn(
                    "w-full text-left p-3 rounded-lg border transition-all",
                    selectedStep?.id === step.id
                      ? getStepColor(step.status)
                      : "hover:bg-accent"
                  )}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <div className="flex items-start gap-3">
                    <div className={cn("mt-0.5", 
                      selectedStep?.id === step.id ? '' : getStepColor(step.status).split(' ')[0]
                    )}>
                      {getStepIcon(step.status)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-sm truncate">{step.name}</div>
                      <div className="text-xs text-muted-foreground mt-1">
                        Step {index + 1} • {step.type} • {formatDuration(step.duration)}
                      </div>
                      {step.error && (
                        <div className="text-xs text-red-500 mt-1 truncate">
                          {step.error.message}
                        </div>
                      )}
                    </div>
                  </div>
                </motion.button>
              ))}
            </div>
          </div>
        </ScrollArea>

        <div className="p-4 border-t">
          <div className="flex gap-2">
            <Button onClick={handleRerun} variant="outline" size="sm" className="flex-1">
              <RefreshCw className="h-4 w-4 mr-1" />
              Rerun
            </Button>
            <Button onClick={handleExport} variant="outline" size="sm" className="flex-1">
              <Download className="h-4 w-4 mr-1" />
              Export
            </Button>
          </div>
        </div>
      </div>

      {/* Right Panel - Step Details */}
      <div className="flex-1 flex flex-col">
        {selectedStep ? (
          <>
            <div className="p-4 border-b">
              <div className="flex items-start justify-between">
                <div>
                  <h1 className="text-xl font-semibold flex items-center gap-2">
                    {selectedStep.name}
                    <span className={cn("flex items-center gap-1 text-sm", 
                      getStepColor(selectedStep.status).split(' ')[0]
                    )}>
                      {getStepIcon(selectedStep.status)}
                      {selectedStep.status}
                    </span>
                  </h1>
                  <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                    <span>Type: {selectedStep.type}</span>
                    <span>Duration: {formatDuration(selectedStep.duration)}</span>
                    {selectedStep.startTime && (
                      <span>Started: {selectedStep.startTime.toLocaleTimeString()}</span>
                    )}
                  </div>
                </div>

                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon">
                      <MoreVertical className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem>
                      <RefreshCw className="h-4 w-4 mr-2" />
                      Rerun Step
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <Copy className="h-4 w-4 mr-2" />
                      Copy Step Details
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>

            <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
              <TabsList className="mx-4 mt-4">
                <TabsTrigger value="logs">
                  Logs {selectedStep.logs.length > 0 && `(${selectedStep.logs.length})`}
                </TabsTrigger>
                <TabsTrigger value="artifacts">
                  Artifacts {selectedStep.artifacts.length > 0 && `(${selectedStep.artifacts.length})`}
                </TabsTrigger>
                {selectedStep.error && (
                  <TabsTrigger value="error">
                    Error Details
                  </TabsTrigger>
                )}
              </TabsList>

              <div className="flex-1 overflow-hidden">
                <TabsContent value="logs" className="h-full p-4">
                  <ScrollArea className="h-full">
                    <div className="space-y-2">
                      {selectedStep.logs.map((log) => (
                        <div 
                          key={log.id}
                          className="flex items-start gap-3 p-2 rounded hover:bg-accent/50 font-mono text-sm"
                        >
                          <span className="text-xs text-muted-foreground whitespace-nowrap">
                            {log.timestamp.toLocaleTimeString('en-US', { 
                              hour12: false,
                              hour: '2-digit',
                              minute: '2-digit',
                              second: '2-digit',
                              fractionalSecondDigits: 3
                            })}
                          </span>
                          <span className={cn("uppercase font-medium", getLogColor(log.level))}>
                            [{log.level}]
                          </span>
                          <span className="flex-1">{log.message}</span>
                          {log.data && (
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-6 px-2 text-xs"
                              onClick={() => console.log('Show data:', log.data)}
                            >
                              <Code className="h-3 w-3 mr-1" />
                              Data
                            </Button>
                          )}
                        </div>
                      ))}

                      {selectedStep.logs.length === 0 && (
                        <div className="text-center py-8 text-muted-foreground">
                          No logs available for this step
                        </div>
                      )}
                    </div>
                  </ScrollArea>
                </TabsContent>

                <TabsContent value="artifacts" className="h-full p-4">
                  <div className="space-y-4">
                    {selectedStep.artifacts.map((artifact) => (
                      <Card key={artifact.id}>
                        <CardHeader className="pb-3">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              {artifact.type === 'screenshot' && <Image className="h-5 w-5" />}
                              {artifact.type === 'har' && <Terminal className="h-5 w-5" />}
                              {artifact.type === 'json' && <Code className="h-5 w-5" />}
                              {artifact.type === 'text' && <FileText className="h-5 w-5" />}
                              <div>
                                <CardTitle className="text-base">{artifact.name}</CardTitle>
                                <CardDescription className="text-xs">
                                  {artifact.type} • {formatFileSize(artifact.size)}
                                </CardDescription>
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              <Button variant="ghost" size="icon" title="Open in new window">
                                <ExternalLink className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="icon" title="Download">
                                <Download className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <InlineArtifactViewer artifact={artifact} />
                        </CardContent>
                      </Card>
                    ))}

                    {selectedStep.artifacts.length === 0 && (
                      <div className="text-center py-8 text-muted-foreground">
                        No artifacts available for this step
                      </div>
                    )}
                  </div>
                </TabsContent>

                {selectedStep.error && (
                  <TabsContent value="error" className="h-full p-4">
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-red-500">Error Details</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div>
                          <h4 className="font-medium mb-2">Message</h4>
                          <p className="text-sm text-muted-foreground">{selectedStep.error.message}</p>
                        </div>
                        
                        {selectedStep.error.stackTrace && (
                          <div>
                            <h4 className="font-medium mb-2">Stack Trace</h4>
                            <pre className="text-xs bg-muted p-3 rounded overflow-x-auto">
                              {selectedStep.error.stackTrace}
                            </pre>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </TabsContent>
                )}
              </div>
            </Tabs>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-muted-foreground">
            Select a step to view details
          </div>
        )}
      </div>
    </div>
  )
} 