import React from 'react'
import { 
  ChevronRight, 
  ChevronDown, 
  Copy, 
  Download,
  Search,
  Filter
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'

interface JsonViewerProps {
  artifact: {
    id: string
    name: string
    url: string
    metadata?: any
  }
  className?: string
}

interface JsonNodeProps {
  keyName?: string
  value: any
  level: number
  path: string[]
  searchTerm?: string
  expandedPaths: Set<string>
  onToggle: (path: string) => void
}

function JsonNode({ keyName, value, level, path, searchTerm, expandedPaths, onToggle }: JsonNodeProps) {
  const currentPath = path.join('.')
  const isExpanded = expandedPaths.has(currentPath)
  
  const renderValue = () => {
    if (value === null) return <span className="text-purple-500">null</span>
    if (value === undefined) return <span className="text-gray-500">undefined</span>
    
    switch (typeof value) {
      case 'string':
        return <span className="text-green-600">"{value}"</span>
      case 'number':
        return <span className="text-blue-600">{value}</span>
      case 'boolean':
        return <span className="text-purple-500">{value.toString()}</span>
      case 'object':
        if (Array.isArray(value)) {
          if (value.length === 0) return <span className="text-gray-500">[]</span>
          if (isExpanded) {
            return (
              <div>
                <span className="text-gray-500">[</span>
                <div className="ml-4">
                  {value.map((item, index) => (
                    <div key={index} className="my-1">
                      <JsonNode
                        value={item}
                        level={level + 1}
                        path={[...path, String(index)]}
                        searchTerm={searchTerm}
                        expandedPaths={expandedPaths}
                        onToggle={onToggle}
                      />
                      {index < value.length - 1 && <span className="text-gray-500">,</span>}
                    </div>
                  ))}
                </div>
                <span className="text-gray-500">]</span>
              </div>
            )
          } else {
            return <span className="text-gray-500">[{value.length} items]</span>
          }
        } else {
          const keys = Object.keys(value)
          if (keys.length === 0) return <span className="text-gray-500">{'{}'}</span>
          if (isExpanded) {
            return (
              <div>
                <span className="text-gray-500">{'{'}</span>
                <div className="ml-4">
                  {keys.map((key, index) => (
                    <div key={key} className="my-1">
                      <JsonNode
                        keyName={key}
                        value={value[key]}
                        level={level + 1}
                        path={[...path, key]}
                        searchTerm={searchTerm}
                        expandedPaths={expandedPaths}
                        onToggle={onToggle}
                      />
                      {index < keys.length - 1 && <span className="text-gray-500">,</span>}
                    </div>
                  ))}
                </div>
                <span className="text-gray-500">{'}'}</span>
              </div>
            )
          } else {
            return <span className="text-gray-500">{`{${keys.length} keys}`}</span>
          }
        }
      default:
        return <span>{String(value)}</span>
    }
  }

  const isCollapsible = typeof value === 'object' && value !== null && 
    (Array.isArray(value) ? value.length > 0 : Object.keys(value).length > 0)

  const handleToggle = () => {
    if (isCollapsible) {
      onToggle(currentPath)
    }
  }

  const highlightMatch = (text: string) => {
    if (!searchTerm) return text
    const parts = text.split(new RegExp(`(${searchTerm})`, 'gi'))
    return parts.map((part, i) => 
      part.toLowerCase() === searchTerm.toLowerCase() 
        ? <mark key={i} className="bg-yellow-200">{part}</mark> 
        : part
    )
  }

  return (
    <div className="flex items-start">
      {isCollapsible && (
        <button
          onClick={handleToggle}
          className="mr-1 hover:bg-accent rounded p-0.5"
        >
          {isExpanded ? (
            <ChevronDown className="h-3 w-3" />
          ) : (
            <ChevronRight className="h-3 w-3" />
          )}
        </button>
      )}
      {!isCollapsible && <span className="w-4" />}
      
      <div className="flex-1">
        {keyName && (
          <>
            <span className="text-blue-800 font-medium">
              {highlightMatch(keyName)}
            </span>
            <span className="text-gray-500">: </span>
          </>
        )}
        {renderValue()}
      </div>
    </div>
  )
}

export function JsonViewer({ artifact, className }: JsonViewerProps) {
  const [viewMode, setViewMode] = React.useState<'tree' | 'raw'>('tree')
  const [searchTerm, setSearchTerm] = React.useState('')
  const [expandedPaths, setExpandedPaths] = React.useState<Set<string>>(new Set(['']))
  const [jsonData, setJsonData] = React.useState<any>(null)
  const [rawJson, setRawJson] = React.useState('')

  // Mock JSON data for demonstration
  React.useEffect(() => {
    const mockData = {
      user: {
        id: 123,
        name: "John Doe",
        email: "john@example.com",
        active: true,
        roles: ["admin", "user"],
        metadata: {
          lastLogin: "2024-01-15T10:30:00Z",
          loginCount: 42,
          preferences: {
            theme: "dark",
            notifications: true
          }
        }
      },
      session: {
        token: "eyJhbGciOiJIUzI1NiIs...",
        expiresAt: "2024-01-16T10:30:00Z",
        refreshToken: "refresh_token_here"
      },
      data: [
        { id: 1, value: "First item" },
        { id: 2, value: "Second item" },
        { id: 3, value: "Third item" }
      ]
    }
    
    setJsonData(mockData)
    setRawJson(JSON.stringify(mockData, null, 2))
  }, [])

  const togglePath = (path: string) => {
    setExpandedPaths(prev => {
      const newSet = new Set(prev)
      if (newSet.has(path)) {
        newSet.delete(path)
      } else {
        newSet.add(path)
      }
      return newSet
    })
  }

  const expandAll = () => {
    const allPaths = new Set<string>([''])
    const traverse = (obj: any, path: string[] = []) => {
      if (typeof obj === 'object' && obj !== null) {
        if (Array.isArray(obj)) {
          obj.forEach((_, index) => {
            const newPath = [...path, String(index)]
            allPaths.add(newPath.join('.'))
            traverse(obj[index], newPath)
          })
        } else {
          Object.keys(obj).forEach(key => {
            const newPath = [...path, key]
            allPaths.add(newPath.join('.'))
            traverse(obj[key], newPath)
          })
        }
      }
    }
    traverse(jsonData)
    setExpandedPaths(allPaths)
  }

  const collapseAll = () => {
    setExpandedPaths(new Set(['']))
  }

  const copyToClipboard = () => {
    navigator.clipboard.writeText(rawJson)
    // TODO: Show toast notification
  }

  const downloadJson = () => {
    const blob = new Blob([rawJson], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = artifact.name
    link.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className={cn("h-[600px] flex flex-col", className)}>
      {/* Toolbar */}
      <div className="flex items-center justify-between mb-4">
        <Tabs value={viewMode} onValueChange={(v) => setViewMode(v as 'tree' | 'raw')}>
          <TabsList>
            <TabsTrigger value="tree">Tree View</TabsTrigger>
            <TabsTrigger value="raw">Raw JSON</TabsTrigger>
          </TabsList>
        </Tabs>

        <div className="flex items-center gap-2">
          {viewMode === 'tree' && (
            <>
              <Button variant="outline" size="sm" onClick={expandAll}>
                Expand All
              </Button>
              <Button variant="outline" size="sm" onClick={collapseAll}>
                Collapse All
              </Button>
            </>
          )}
          <Button variant="outline" size="icon" onClick={copyToClipboard}>
            <Copy className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="icon" onClick={downloadJson}>
            <Download className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Search */}
      {viewMode === 'tree' && (
        <div className="relative mb-4">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search JSON..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-9"
          />
        </div>
      )}

      {/* Content */}
      <ScrollArea className="flex-1 border rounded p-4 bg-muted/20">
        {viewMode === 'tree' ? (
          jsonData && (
            <div className="font-mono text-sm">
              <JsonNode
                value={jsonData}
                level={0}
                path={[]}
                searchTerm={searchTerm}
                expandedPaths={expandedPaths}
                onToggle={togglePath}
              />
            </div>
          )
        ) : (
          <pre className="font-mono text-sm whitespace-pre-wrap">
            <code className="language-json">
              {rawJson.split('\n').map((line, i) => {
                const lineNumber = i + 1
                return (
                  <div key={i} className="flex">
                    <span className="select-none text-muted-foreground w-12 text-right pr-4">
                      {lineNumber}
                    </span>
                    <span>{highlightJsonLine(line)}</span>
                  </div>
                )
              })}
            </code>
          </pre>
        )}
      </ScrollArea>

      {/* Status Bar */}
      <div className="mt-4 flex items-center justify-between text-sm text-muted-foreground">
        <span>
          {jsonData && (
            <>
              {typeof jsonData === 'object' && !Array.isArray(jsonData) 
                ? `${Object.keys(jsonData).length} keys`
                : Array.isArray(jsonData)
                ? `${jsonData.length} items`
                : 'Primitive value'
              }
            </>
          )}
        </span>
        <span>{(rawJson.length / 1024).toFixed(1)} KB</span>
      </div>
    </div>
  )
}

function highlightJsonLine(line: string): React.ReactNode {
  // Simple JSON syntax highlighting
  const patterns = [
    { regex: /(".*?")/g, className: 'text-green-600' }, // strings
    { regex: /\b(true|false)\b/g, className: 'text-purple-500' }, // booleans
    { regex: /\b(null)\b/g, className: 'text-purple-500' }, // null
    { regex: /\b(\d+\.?\d*)\b/g, className: 'text-blue-600' }, // numbers
    { regex: /([\{\}\[\],])/g, className: 'text-gray-500' }, // brackets
  ]

  let result = line
  patterns.forEach(({ regex, className }) => {
    result = result.replace(regex, `<span class="${className}">$1</span>`)
  })

  return <span dangerouslySetInnerHTML={{ __html: result }} />
} 