import React from 'react'
import { motion } from 'framer-motion'
import { 
  ZoomIn, 
  ZoomOut, 
  RotateCw, 
  Download, 
  Maximize2,
  SplitSquareHorizontal,
  Eye,
  EyeOff
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { Slider } from '@/components/ui/slider'
import { Toggle } from '@/components/ui/toggle'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel,
} from '@/components/ui/dropdown-menu'

interface ImageViewerProps {
  artifact: {
    id: string
    name: string
    url: string
    metadata?: any
  }
  baselineUrl?: string
  className?: string
}

export function ImageViewer({ artifact, baselineUrl, className }: ImageViewerProps) {
  const [zoom, setZoom] = React.useState(100)
  const [rotation, setRotation] = React.useState(0)
  const [compareMode, setCompareMode] = React.useState<'side-by-side' | 'overlay' | 'diff' | null>(null)
  const [overlayOpacity, setOverlayOpacity] = React.useState(50)
  const [showDiffRegions, setShowDiffRegions] = React.useState(true)
  const [diffData, setDiffData] = React.useState<{
    pixelDiff: number
    diffPercent: number
    regions: Array<{ x: number; y: number; width: number; height: number }>
  } | null>(null)

  // Mock diff data for demonstration
  React.useEffect(() => {
    if (compareMode === 'diff' && baselineUrl) {
      // In real implementation, this would calculate actual diff
      setDiffData({
        pixelDiff: 1234,
        diffPercent: 2.3,
        regions: [
          { x: 100, y: 150, width: 200, height: 50 },
          { x: 350, y: 300, width: 100, height: 100 }
        ]
      })
    }
  }, [compareMode, baselineUrl])

  const handleZoomIn = () => {
    setZoom(prev => Math.min(prev + 25, 300))
  }

  const handleZoomOut = () => {
    setZoom(prev => Math.max(prev - 25, 25))
  }

  const handleRotate = () => {
    setRotation(prev => (prev + 90) % 360)
  }

  const handleDownload = () => {
    // Create download link
    const link = document.createElement('a')
    link.href = artifact.url
    link.download = artifact.name
    link.click()
  }

  const handleFullscreen = () => {
    // Open in new window or fullscreen modal
    window.open(artifact.url, '_blank')
  }

  const renderCompareView = () => {
    if (!baselineUrl || !compareMode) return null

    switch (compareMode) {
      case 'side-by-side':
        return (
          <div className="flex gap-4">
            <div className="flex-1">
              <div className="text-sm font-medium mb-2">Baseline</div>
              <img 
                src={baselineUrl} 
                alt="Baseline"
                className="w-full rounded border"
                style={{
                  transform: `scale(${zoom / 100}) rotate(${rotation}deg)`,
                  transformOrigin: 'top left'
                }}
              />
            </div>
            <div className="flex-1">
              <div className="text-sm font-medium mb-2">Current</div>
              <img 
                src={artifact.url} 
                alt="Current"
                className="w-full rounded border"
                style={{
                  transform: `scale(${zoom / 100}) rotate(${rotation}deg)`,
                  transformOrigin: 'top left'
                }}
              />
            </div>
          </div>
        )

      case 'overlay':
        return (
          <div className="relative">
            <img 
              src={baselineUrl} 
              alt="Baseline"
              className="w-full rounded"
              style={{
                transform: `scale(${zoom / 100}) rotate(${rotation}deg)`,
                transformOrigin: 'top left'
              }}
            />
            <img 
              src={artifact.url} 
              alt="Current"
              className="absolute top-0 left-0 w-full rounded"
              style={{
                opacity: overlayOpacity / 100,
                transform: `scale(${zoom / 100}) rotate(${rotation}deg)`,
                transformOrigin: 'top left'
              }}
            />
            <div className="mt-4">
              <label className="text-sm font-medium">Overlay Opacity</label>
              <Slider
                value={[overlayOpacity]}
                onValueChange={([value]) => setOverlayOpacity(value)}
                min={0}
                max={100}
                step={1}
                className="mt-2"
              />
            </div>
          </div>
        )

      case 'diff':
        return (
          <div>
            <div className="relative">
              <img 
                src={artifact.url} 
                alt="Diff view"
                className="w-full rounded"
                style={{
                  transform: `scale(${zoom / 100}) rotate(${rotation}deg)`,
                  transformOrigin: 'top left'
                }}
              />
              {showDiffRegions && diffData?.regions.map((region, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="absolute border-2 border-red-500 bg-red-500/20"
                  style={{
                    left: `${(region.x / 100) * zoom}%`,
                    top: `${(region.y / 100) * zoom}%`,
                    width: `${(region.width / 100) * zoom}%`,
                    height: `${(region.height / 100) * zoom}%`,
                  }}
                />
              ))}
            </div>
            {diffData && (
              <div className="mt-4 p-3 bg-muted rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">Difference Analysis</span>
                  <Toggle
                    pressed={showDiffRegions}
                    onPressedChange={setShowDiffRegions}
                    size="sm"
                  >
                    {showDiffRegions ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
                  </Toggle>
                </div>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <span className="text-muted-foreground">Pixels Changed:</span>
                    <span className="ml-2 font-medium">{diffData.pixelDiff.toLocaleString()}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Difference:</span>
                    <span className="ml-2 font-medium text-red-500">{diffData.diffPercent}%</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        )
    }
  }

  return (
    <div className={cn("space-y-4", className)}>
      {/* Toolbar */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="icon"
            onClick={handleZoomOut}
            disabled={zoom <= 25}
          >
            <ZoomOut className="h-4 w-4" />
          </Button>
          <span className="text-sm font-medium w-12 text-center">{zoom}%</span>
          <Button
            variant="outline"
            size="icon"
            onClick={handleZoomIn}
            disabled={zoom >= 300}
          >
            <ZoomIn className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="icon"
            onClick={handleRotate}
          >
            <RotateCw className="h-4 w-4" />
          </Button>
        </div>

        <div className="flex items-center gap-2">
          {baselineUrl && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm">
                  <SplitSquareHorizontal className="h-4 w-4 mr-2" />
                  Compare
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Comparison Mode</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => setCompareMode('side-by-side')}>
                  Side by Side
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setCompareMode('overlay')}>
                  Overlay
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setCompareMode('diff')}>
                  Difference View
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => setCompareMode(null)}>
                  No Comparison
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
          
          <Button
            variant="outline"
            size="icon"
            onClick={handleFullscreen}
          >
            <Maximize2 className="h-4 w-4" />
          </Button>
          
          <Button
            variant="outline"
            size="icon"
            onClick={handleDownload}
          >
            <Download className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Image Display */}
      <div className="overflow-auto max-h-[600px] bg-checkered rounded-lg p-4">
        {compareMode ? (
          renderCompareView()
        ) : (
          <img 
            src={artifact.url} 
            alt={artifact.name}
            className="max-w-full h-auto rounded"
            style={{
              transform: `scale(${zoom / 100}) rotate(${rotation}deg)`,
              transformOrigin: 'top left',
              transition: 'transform 0.2s ease'
            }}
          />
        )}
      </div>
    </div>
  )
} 