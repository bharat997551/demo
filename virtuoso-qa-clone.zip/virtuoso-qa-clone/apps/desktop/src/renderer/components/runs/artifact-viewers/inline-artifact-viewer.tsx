import React from 'react'
import { ImageViewer } from './image-viewer'
import { HarViewer } from './har-viewer'
import { JsonViewer } from './json-viewer'
import { TextGridViewer } from './text-grid-viewer'
import { FileText } from 'lucide-react'

interface Artifact {
  id: string
  name: string
  type: 'screenshot' | 'har' | 'json' | 'text' | '3270-grid' | 'video' | 'log'
  size: number
  url: string
  metadata?: any
}

interface InlineArtifactViewerProps {
  artifact: Artifact
  className?: string
}

export function InlineArtifactViewer({ artifact, className }: InlineArtifactViewerProps) {
  switch (artifact.type) {
    case 'screenshot':
      return <ImageViewer artifact={artifact} className={className} />
    
    case 'har':
      return <HarViewer artifact={artifact} className={className} />
    
    case 'json':
      return <JsonViewer artifact={artifact} className={className} />
    
    case '3270-grid':
      return <TextGridViewer artifact={artifact} className={className} />
    
    case 'text':
    case 'log':
      return (
        <div className={className}>
          <pre className="text-xs bg-muted p-4 rounded overflow-auto max-h-96">
            {/* In real implementation, fetch content from artifact.url */}
            {`Sample ${artifact.type} content for ${artifact.name}...`}
          </pre>
        </div>
      )
    
    case 'video':
      return (
        <div className={className}>
          <video controls className="w-full rounded">
            <source src={artifact.url} type="video/mp4" />
            Your browser does not support the video tag.
          </video>
        </div>
      )
    
    default:
      return (
        <div className={`flex items-center justify-center p-8 text-muted-foreground ${className}`}>
          <FileText className="h-8 w-8 mr-3" />
          <span>Preview not available for {artifact.type} files</span>
        </div>
      )
  }
} 