import React from 'react'
import { 
  FileText,
  FileImage,
  Download,
  Loader2,
  CheckCircle,
  AlertCircle
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { Label } from '@/components/ui/label'
import { Checkbox } from '@/components/ui/checkbox'

interface RunExporterProps {
  runId: string
  runData: any
  steps: any[]
  className?: string
  onComplete?: (result: { url: string; filename: string }) => void
}

interface ExportOptions {
  format: 'html' | 'pdf'
  includeScreenshots: boolean
  includeHar: boolean
  includeLogs: boolean
  includeTimeline: boolean
  embedArtifacts: boolean
}

export function RunExporter({ runId, runData, steps, className, onComplete }: RunExporterProps) {
  const [isExporting, setIsExporting] = React.useState(false)
  const [progress, setProgress] = React.useState(0)
  const [currentStep, setCurrentStep] = React.useState('')
  const [exportResult, setExportResult] = React.useState<{ url: string; filename: string } | null>(null)
  const [error, setError] = React.useState<string | null>(null)
  
  const [options, setOptions] = React.useState<ExportOptions>({
    format: 'html',
    includeScreenshots: true,
    includeHar: true,
    includeLogs: true,
    includeTimeline: true,
    embedArtifacts: true
  })

  const generateHTML = async () => {
    // Generate comprehensive HTML report
    const html = `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Test Run Report - ${runData.name}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { 
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      line-height: 1.6;
      color: #333;
      background: #f5f5f5;
    }
    .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
    .header {
      background: #1a1a1a;
      color: white;
      padding: 30px;
      border-radius: 8px;
      margin-bottom: 30px;
    }
    .header h1 { font-size: 28px; margin-bottom: 10px; }
    .header .meta { display: flex; gap: 30px; font-size: 14px; opacity: 0.8; }
    .summary {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 20px;
      margin-bottom: 30px;
    }
    .stat-card {
      background: white;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .stat-card .value { font-size: 32px; font-weight: bold; }
    .stat-card .label { color: #666; font-size: 14px; }
    .timeline {
      background: white;
      border-radius: 8px;
      padding: 30px;
      margin-bottom: 30px;
    }
    .step {
      padding: 20px;
      border-left: 3px solid #e0e0e0;
      margin-left: 20px;
      position: relative;
    }
    .step::before {
      content: '';
      position: absolute;
      left: -8px;
      top: 24px;
      width: 12px;
      height: 12px;
      border-radius: 50%;
      background: #e0e0e0;
    }
    .step.passed { border-color: #4caf50; }
    .step.passed::before { background: #4caf50; }
    .step.failed { border-color: #f44336; }
    .step.failed::before { background: #f44336; }
    .step.skipped { border-color: #ff9800; }
    .step.skipped::before { background: #ff9800; }
    .step-header { display: flex; justify-content: space-between; margin-bottom: 10px; }
    .step-name { font-weight: 600; font-size: 16px; }
    .step-duration { color: #666; font-size: 14px; }
    .step-error {
      background: #ffebee;
      color: #c62828;
      padding: 15px;
      border-radius: 4px;
      margin: 10px 0;
      font-family: monospace;
      font-size: 13px;
    }
    .artifacts {
      display: flex;
      gap: 10px;
      flex-wrap: wrap;
      margin-top: 15px;
    }
    .artifact {
      background: #f5f5f5;
      padding: 8px 16px;
      border-radius: 4px;
      font-size: 14px;
      text-decoration: none;
      color: #1976d2;
    }
    .artifact:hover { background: #e0e0e0; }
    .logs {
      background: #263238;
      color: #aed581;
      padding: 20px;
      border-radius: 4px;
      font-family: 'Monaco', 'Consolas', monospace;
      font-size: 12px;
      overflow-x: auto;
      margin-top: 15px;
    }
    .log-entry { margin: 2px 0; }
    .log-debug { color: #90a4ae; }
    .log-info { color: #81c784; }
    .log-warn { color: #ffb74d; }
    .log-error { color: #e57373; }
    .screenshot {
      max-width: 100%;
      margin: 15px 0;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
    }
    @media print {
      body { background: white; }
      .header { background: white; color: black; border: 1px solid #ddd; }
      .no-print { display: none; }
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>${runData.name}</h1>
      <div class="meta">
        <span>Status: ${runData.status.toUpperCase()}</span>
        <span>Duration: ${formatDuration(runData.duration)}</span>
        <span>Environment: ${runData.environment}</span>
        <span>Started: ${new Date(runData.startTime).toLocaleString()}</span>
      </div>
    </div>
    
    <div class="summary">
      <div class="stat-card">
        <div class="value" style="color: #4caf50">${steps.filter(s => s.status === 'passed').length}</div>
        <div class="label">Passed</div>
      </div>
      <div class="stat-card">
        <div class="value" style="color: #f44336">${steps.filter(s => s.status === 'failed').length}</div>
        <div class="label">Failed</div>
      </div>
      <div class="stat-card">
        <div class="value" style="color: #ff9800">${steps.filter(s => s.status === 'skipped').length}</div>
        <div class="label">Skipped</div>
      </div>
      <div class="stat-card">
        <div class="value">${steps.length}</div>
        <div class="label">Total Steps</div>
      </div>
    </div>
    
    ${options.includeTimeline ? `
    <div class="timeline">
      <h2 style="margin-bottom: 20px;">Execution Timeline</h2>
      ${steps.map((step, index) => `
        <div class="step ${step.status}">
          <div class="step-header">
            <span class="step-name">Step ${index + 1}: ${step.name}</span>
            <span class="step-duration">${formatDuration(step.duration)}</span>
          </div>
          
          ${step.error ? `
            <div class="step-error">
              <strong>Error:</strong> ${step.error.message}
              ${step.error.stackTrace ? `<pre style="margin-top: 10px;">${step.error.stackTrace}</pre>` : ''}
            </div>
          ` : ''}
          
          ${options.includeScreenshots && step.artifacts.filter(a => a.type === 'screenshot').length > 0 ? `
            <div class="artifacts">
              ${step.artifacts.filter(a => a.type === 'screenshot').map(artifact => 
                options.embedArtifacts ? `
                  <div>
                    <img src="${artifact.url}" alt="${artifact.name}" class="screenshot" />
                  </div>
                ` : `
                  <a href="${artifact.url}" class="artifact" target="_blank">
                    📷 ${artifact.name}
                  </a>
                `
              ).join('')}
            </div>
          ` : ''}
          
          ${options.includeLogs && step.logs.length > 0 ? `
            <div class="logs">
              ${step.logs.map(log => `
                <div class="log-entry log-${log.level}">
                  [${new Date(log.timestamp).toLocaleTimeString()}] ${log.message}
                </div>
              `).join('')}
            </div>
          ` : ''}
          
          ${options.includeHar && step.artifacts.filter(a => a.type === 'har').length > 0 ? `
            <div class="artifacts">
              ${step.artifacts.filter(a => a.type === 'har').map(artifact => `
                <a href="${artifact.url}" class="artifact" target="_blank">
                  📊 ${artifact.name}
                </a>
              `).join('')}
            </div>
          ` : ''}
        </div>
      `).join('')}
    </div>
    ` : ''}
  </div>
</body>
</html>
    `
    
    return html
  }

  const generatePDF = async (html: string) => {
    // In a real implementation, this would use a library like puppeteer or jsPDF
    // For now, we'll create a print-friendly version
    const printWindow = window.open('', '_blank')
    if (printWindow) {
      printWindow.document.write(html)
      printWindow.document.close()
      setTimeout(() => {
        printWindow.print()
      }, 500)
    }
  }

  const startExport = async () => {
    setIsExporting(true)
    setProgress(0)
    setError(null)
    setExportResult(null)

    try {
      // Step 1: Generate HTML
      setCurrentStep('Generating HTML report...')
      setProgress(20)
      const html = await generateHTML()
      
      // Step 2: Process artifacts if embedding
      if (options.embedArtifacts) {
        setCurrentStep('Embedding artifacts...')
        setProgress(40)
        // In real implementation, convert image URLs to base64
        await new Promise(resolve => setTimeout(resolve, 500))
      }
      
      // Step 3: Generate final output
      setProgress(60)
      
      if (options.format === 'pdf') {
        setCurrentStep('Generating PDF...')
        await generatePDF(html)
        setProgress(100)
        
        // Mock result
        const result = {
          url: '/exports/test-run-report.pdf',
          filename: `test-run-${runId}-${Date.now()}.pdf`
        }
        setExportResult(result)
        onComplete?.(result)
      } else {
        setCurrentStep('Saving HTML report...')
        
        // Create blob and download
        const blob = new Blob([html], { type: 'text/html' })
        const url = URL.createObjectURL(blob)
        
        setProgress(100)
        
        const result = {
          url,
          filename: `test-run-${runId}-${Date.now()}.html`
        }
        setExportResult(result)
        onComplete?.(result)
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Export failed')
    } finally {
      setIsExporting(false)
    }
  }

  const formatDuration = (ms?: number) => {
    if (!ms) return '--'
    const seconds = Math.floor(ms / 1000)
    const minutes = Math.floor(seconds / 60)
    
    if (minutes > 0) {
      return `${minutes}m ${seconds % 60}s`
    } else {
      return `${seconds}s`
    }
  }

  const downloadResult = () => {
    if (exportResult) {
      const link = document.createElement('a')
      link.href = exportResult.url
      link.download = exportResult.filename
      link.click()
      
      // Clean up blob URL if it's a blob
      if (exportResult.url.startsWith('blob:')) {
        setTimeout(() => URL.revokeObjectURL(exportResult.url), 100)
      }
    }
  }

  return (
    <Card className={cn("w-full max-w-2xl", className)}>
      <CardHeader>
        <CardTitle>Export Test Run</CardTitle>
        <CardDescription>
          Generate a comprehensive report of the test execution
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {!exportResult && !error && (
          <>
            {/* Format Selection */}
            <div className="space-y-3">
              <Label>Export Format</Label>
              <RadioGroup
                value={options.format}
                onValueChange={(value) => setOptions({ ...options, format: value as 'html' | 'pdf' })}
                disabled={isExporting}
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="html" id="html" />
                  <Label htmlFor="html" className="flex items-center gap-2 cursor-pointer">
                    <FileText className="h-4 w-4" />
                    HTML Report (Self-contained)
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="pdf" id="pdf" />
                  <Label htmlFor="pdf" className="flex items-center gap-2 cursor-pointer">
                    <FileImage className="h-4 w-4" />
                    PDF Document
                  </Label>
                </div>
              </RadioGroup>
            </div>

            {/* Include Options */}
            <div className="space-y-3">
              <Label>Include in Report</Label>
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="timeline"
                    checked={options.includeTimeline}
                    onCheckedChange={(checked) => 
                      setOptions({ ...options, includeTimeline: checked as boolean })
                    }
                    disabled={isExporting}
                  />
                  <Label htmlFor="timeline" className="cursor-pointer">
                    Execution Timeline
                  </Label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="screenshots"
                    checked={options.includeScreenshots}
                    onCheckedChange={(checked) => 
                      setOptions({ ...options, includeScreenshots: checked as boolean })
                    }
                    disabled={isExporting}
                  />
                  <Label htmlFor="screenshots" className="cursor-pointer">
                    Screenshots
                  </Label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="logs"
                    checked={options.includeLogs}
                    onCheckedChange={(checked) => 
                      setOptions({ ...options, includeLogs: checked as boolean })
                    }
                    disabled={isExporting}
                  />
                  <Label htmlFor="logs" className="cursor-pointer">
                    Execution Logs
                  </Label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="har"
                    checked={options.includeHar}
                    onCheckedChange={(checked) => 
                      setOptions({ ...options, includeHar: checked as boolean })
                    }
                    disabled={isExporting}
                  />
                  <Label htmlFor="har" className="cursor-pointer">
                    Network Logs (HAR)
                  </Label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="embed"
                    checked={options.embedArtifacts}
                    onCheckedChange={(checked) => 
                      setOptions({ ...options, embedArtifacts: checked as boolean })
                    }
                    disabled={isExporting || options.format === 'pdf'}
                  />
                  <Label htmlFor="embed" className="cursor-pointer">
                    Embed Artifacts (larger file size)
                  </Label>
                </div>
              </div>
            </div>

            {/* Export Button */}
            <Button 
              onClick={startExport} 
              disabled={isExporting}
              className="w-full"
            >
              {isExporting ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Exporting...
                </>
              ) : (
                <>
                  <Download className="h-4 w-4 mr-2" />
                  Start Export
                </>
              )}
            </Button>
          </>
        )}

        {/* Progress */}
        {isExporting && (
          <div className="space-y-3">
            <Progress value={progress} className="w-full" />
            <p className="text-sm text-muted-foreground text-center">
              {currentStep}
            </p>
          </div>
        )}

        {/* Success */}
        {exportResult && (
          <div className="text-center space-y-4">
            <CheckCircle className="h-12 w-12 text-green-500 mx-auto" />
            <div>
              <h3 className="font-semibold text-lg">Export Complete!</h3>
              <p className="text-sm text-muted-foreground mt-1">
                Your report has been generated successfully
              </p>
            </div>
            <Button onClick={downloadResult} className="w-full">
              <Download className="h-4 w-4 mr-2" />
              Download {exportResult.filename}
            </Button>
          </div>
        )}

        {/* Error */}
        {error && (
          <div className="text-center space-y-4">
            <AlertCircle className="h-12 w-12 text-red-500 mx-auto" />
            <div>
              <h3 className="font-semibold text-lg">Export Failed</h3>
              <p className="text-sm text-muted-foreground mt-1">
                {error}
              </p>
            </div>
            <Button onClick={() => setError(null)} variant="outline" className="w-full">
              Try Again
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )
} 