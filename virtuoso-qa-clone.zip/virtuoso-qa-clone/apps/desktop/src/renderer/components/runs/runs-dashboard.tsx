import React from 'react'
import { motion } from 'framer-motion'
import { Link } from 'react-router-dom'
import {
  Play,
  CheckCircle,
  XCircle,
  Clock,
  AlertCircle,
  Search,
  Filter,
  Calendar,
  Download,
  MoreVertical,
  TrendingUp,
  TrendingDown,
  Activity
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'

interface TestRun {
  id: string
  name: string
  status: 'running' | 'passed' | 'failed' | 'stopped' | 'queued'
  startTime: Date
  endTime?: Date
  duration?: number
  totalSteps: number
  passedSteps: number
  failedSteps: number
  skippedSteps: number
  artifacts: number
  tags: string[]
  environment: string
  triggeredBy: string
}

interface RunsDashboardProps {
  className?: string
}

export function RunsDashboard({ className }: RunsDashboardProps) {
  const [searchQuery, setSearchQuery] = React.useState('')
  const [statusFilter, setStatusFilter] = React.useState<string>('all')
  const [timeFilter, setTimeFilter] = React.useState<string>('7days')
  const [selectedRuns, setSelectedRuns] = React.useState<Set<string>>(new Set())

  // Mock data for demonstration
  const [runs] = React.useState<TestRun[]>([
    {
      id: 'run-1',
      name: 'E2E Test Suite - Login Flow',
      status: 'passed',
      startTime: new Date(Date.now() - 1000 * 60 * 30),
      endTime: new Date(Date.now() - 1000 * 60 * 25),
      duration: 300000,
      totalSteps: 15,
      passedSteps: 15,
      failedSteps: 0,
      skippedSteps: 0,
      artifacts: 8,
      tags: ['smoke', 'login', 'critical'],
      environment: 'production',
      triggeredBy: 'CI Pipeline'
    },
    {
      id: 'run-2',
      name: 'API Integration Tests',
      status: 'failed',
      startTime: new Date(Date.now() - 1000 * 60 * 60),
      endTime: new Date(Date.now() - 1000 * 60 * 45),
      duration: 900000,
      totalSteps: 32,
      passedSteps: 28,
      failedSteps: 4,
      skippedSteps: 0,
      artifacts: 15,
      tags: ['api', 'integration'],
      environment: 'staging',
      triggeredBy: 'john.doe@example.com'
    },
    {
      id: 'run-3',
      name: 'Desktop App Smoke Tests',
      status: 'running',
      startTime: new Date(Date.now() - 1000 * 60 * 5),
      totalSteps: 20,
      passedSteps: 8,
      failedSteps: 0,
      skippedSteps: 0,
      artifacts: 3,
      tags: ['desktop', 'smoke'],
      environment: 'development',
      triggeredBy: 'Manual'
    },
    {
      id: 'run-4',
      name: 'Mainframe Batch Processing',
      status: 'stopped',
      startTime: new Date(Date.now() - 1000 * 60 * 120),
      endTime: new Date(Date.now() - 1000 * 60 * 100),
      duration: 1200000,
      totalSteps: 45,
      passedSteps: 12,
      failedSteps: 2,
      skippedSteps: 31,
      artifacts: 22,
      tags: ['mainframe', 'batch', 'nightly'],
      environment: 'production',
      triggeredBy: 'Schedule'
    }
  ])

  // Filter runs based on search and filters
  const filteredRuns = runs.filter(run => {
    // Search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      if (
        !run.name.toLowerCase().includes(query) &&
        !run.tags.some(tag => tag.toLowerCase().includes(query)) &&
        !run.environment.toLowerCase().includes(query) &&
        !run.triggeredBy.toLowerCase().includes(query)
      ) {
        return false
      }
    }

    // Status filter
    if (statusFilter !== 'all' && run.status !== statusFilter) {
      return false
    }

    // Time filter
    const now = Date.now()
    const runTime = run.startTime.getTime()
    switch (timeFilter) {
      case '1hour':
        if (now - runTime > 1000 * 60 * 60) return false
        break
      case '24hours':
        if (now - runTime > 1000 * 60 * 60 * 24) return false
        break
      case '7days':
        if (now - runTime > 1000 * 60 * 60 * 24 * 7) return false
        break
      case '30days':
        if (now - runTime > 1000 * 60 * 60 * 24 * 30) return false
        break
    }

    return true
  })

  // Calculate statistics
  const stats = React.useMemo(() => {
    const total = filteredRuns.length
    const passed = filteredRuns.filter(r => r.status === 'passed').length
    const failed = filteredRuns.filter(r => r.status === 'failed').length
    const running = filteredRuns.filter(r => r.status === 'running').length
    const passRate = total > 0 ? (passed / total) * 100 : 0

    return { total, passed, failed, running, passRate }
  }, [filteredRuns])

  const getStatusIcon = (status: TestRun['status']) => {
    switch (status) {
      case 'running':
        return <Play className="h-4 w-4" />
      case 'passed':
        return <CheckCircle className="h-4 w-4" />
      case 'failed':
        return <XCircle className="h-4 w-4" />
      case 'stopped':
        return <AlertCircle className="h-4 w-4" />
      case 'queued':
        return <Clock className="h-4 w-4" />
    }
  }

  const getStatusColor = (status: TestRun['status']) => {
    switch (status) {
      case 'running':
        return 'text-blue-500'
      case 'passed':
        return 'text-green-500'
      case 'failed':
        return 'text-red-500'
      case 'stopped':
        return 'text-yellow-500'
      case 'queued':
        return 'text-gray-500'
    }
  }

  const formatDuration = (ms?: number) => {
    if (!ms) return '--'
    const seconds = Math.floor(ms / 1000)
    const minutes = Math.floor(seconds / 60)
    const hours = Math.floor(minutes / 60)
    
    if (hours > 0) {
      return `${hours}h ${minutes % 60}m`
    } else if (minutes > 0) {
      return `${minutes}m ${seconds % 60}s`
    } else {
      return `${seconds}s`
    }
  }

  const handleExportRun = (runId: string) => {
    console.log('Export run:', runId)
    // TODO: Implement export functionality
  }

  const handleCompareRuns = () => {
    if (selectedRuns.size === 2) {
      const [run1, run2] = Array.from(selectedRuns)
      console.log('Compare runs:', run1, run2)
      // TODO: Navigate to comparison view
    }
  }

  const toggleRunSelection = (runId: string) => {
    setSelectedRuns(prev => {
      const newSet = new Set(prev)
      if (newSet.has(runId)) {
        newSet.delete(runId)
      } else {
        newSet.add(runId)
      }
      return newSet
    })
  }

  return (
    <div className={cn("flex flex-col h-full", className)}>
      {/* Header */}
      <div className="p-6 border-b">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold">Test Runs</h1>
            <p className="text-sm text-muted-foreground mt-1">
              Monitor and analyze your test execution history
            </p>
          </div>
          <div className="flex items-center gap-3">
            {selectedRuns.size === 2 && (
              <Button onClick={handleCompareRuns} variant="outline">
                Compare Selected
              </Button>
            )}
            <Button>
              <Play className="h-4 w-4 mr-2" />
              New Run
            </Button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Total Runs</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.total}</div>
              <p className="text-xs text-muted-foreground mt-1">
                In selected period
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Pass Rate</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <div className="text-2xl font-bold text-green-500">
                  {stats.passRate.toFixed(1)}%
                </div>
                {stats.passRate > 80 ? (
                  <TrendingUp className="h-4 w-4 text-green-500" />
                ) : (
                  <TrendingDown className="h-4 w-4 text-red-500" />
                )}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                {stats.passed} passed, {stats.failed} failed
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Active Runs</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <div className="text-2xl font-bold">{stats.running}</div>
                <Activity className="h-4 w-4 text-blue-500" />
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Currently executing
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Avg Duration</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <div className="text-2xl font-bold">12m</div>
                <Clock className="h-4 w-4 text-muted-foreground" />
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Per test run
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <div className="flex items-center gap-3">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search runs, tags, environment..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
            />
          </div>
          
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[140px]">
              <Filter className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="running">Running</SelectItem>
              <SelectItem value="passed">Passed</SelectItem>
              <SelectItem value="failed">Failed</SelectItem>
              <SelectItem value="stopped">Stopped</SelectItem>
              <SelectItem value="queued">Queued</SelectItem>
            </SelectContent>
          </Select>

          <Select value={timeFilter} onValueChange={setTimeFilter}>
            <SelectTrigger className="w-[140px]">
              <Calendar className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Time" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1hour">Last Hour</SelectItem>
              <SelectItem value="24hours">Last 24h</SelectItem>
              <SelectItem value="7days">Last 7 Days</SelectItem>
              <SelectItem value="30days">Last 30 Days</SelectItem>
              <SelectItem value="all">All Time</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Runs List */}
      <div className="flex-1 overflow-y-auto p-6">
        <div className="space-y-4">
          {filteredRuns.map((run) => (
            <motion.div
              key={run.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              whileHover={{ scale: 1.01 }}
              transition={{ duration: 0.2 }}
            >
              <Card className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-4">
                      <input
                        type="checkbox"
                        checked={selectedRuns.has(run.id)}
                        onChange={() => toggleRunSelection(run.id)}
                        className="mt-1"
                      />
                      <div>
                        <Link 
                          to={`/runs/${run.id}`}
                          className="text-lg font-semibold hover:underline flex items-center gap-2"
                        >
                          {run.name}
                          <span className={cn("flex items-center gap-1", getStatusColor(run.status))}>
                            {getStatusIcon(run.status)}
                            {run.status}
                          </span>
                        </Link>
                        <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                          <span>Started {run.startTime.toLocaleString()}</span>
                          <span>Duration: {formatDuration(run.duration)}</span>
                          <span>By {run.triggeredBy}</span>
                        </div>
                      </div>
                    </div>
                    
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem asChild>
                          <Link to={`/runs/${run.id}`}>
                            View Details
                          </Link>
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleExportRun(run.id)}>
                          <Download className="h-4 w-4 mr-2" />
                          Export Run
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem className="text-destructive">
                          Delete Run
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-6">
                      {/* Step Progress */}
                      <div className="flex items-center gap-4">
                        <div className="text-sm">
                          <span className="text-green-500 font-medium">{run.passedSteps}</span>
                          <span className="text-muted-foreground"> passed</span>
                        </div>
                        {run.failedSteps > 0 && (
                          <div className="text-sm">
                            <span className="text-red-500 font-medium">{run.failedSteps}</span>
                            <span className="text-muted-foreground"> failed</span>
                          </div>
                        )}
                        {run.skippedSteps > 0 && (
                          <div className="text-sm">
                            <span className="text-yellow-500 font-medium">{run.skippedSteps}</span>
                            <span className="text-muted-foreground"> skipped</span>
                          </div>
                        )}
                        <div className="text-sm text-muted-foreground">
                          of {run.totalSteps} total
                        </div>
                      </div>

                      {/* Progress Bar */}
                      <div className="w-48 h-2 bg-muted rounded-full overflow-hidden">
                        <div className="h-full flex">
                          <div 
                            className="bg-green-500"
                            style={{ width: `${(run.passedSteps / run.totalSteps) * 100}%` }}
                          />
                          <div 
                            className="bg-red-500"
                            style={{ width: `${(run.failedSteps / run.totalSteps) * 100}%` }}
                          />
                          <div 
                            className="bg-yellow-500"
                            style={{ width: `${(run.skippedSteps / run.totalSteps) * 100}%` }}
                          />
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-4">
                      {/* Tags */}
                      <div className="flex items-center gap-2">
                        {run.tags.map(tag => (
                          <Badge key={tag} variant="secondary" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>

                      {/* Environment */}
                      <Badge variant="outline">
                        {run.environment}
                      </Badge>

                      {/* Artifacts */}
                      {run.artifacts > 0 && (
                        <span className="text-sm text-muted-foreground">
                          {run.artifacts} artifacts
                        </span>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}

          {filteredRuns.length === 0 && (
            <div className="text-center py-12">
              <AlertCircle className="h-12 w-12 mx-auto text-muted-foreground mb-3" />
              <p className="text-muted-foreground">No test runs found matching your criteria</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
} 