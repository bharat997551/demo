import React from 'react'
import { 
  Grid3x3,
  MousePointer,
  Download,
  Copy,
  ZoomIn,
  ZoomOut,
  Info
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Toggle } from '@/components/ui/toggle'
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip'

interface TextGridViewerProps {
  artifact: {
    id: string
    name: string
    url: string
    metadata?: any
  }
  className?: string
}

interface FieldInfo {
  row: number
  col: number
  length: number
  type: 'input' | 'output' | 'protected'
  value: string
  attributes?: {
    color?: string
    highlight?: boolean
    underline?: boolean
    blink?: boolean
  }
}

export function TextGridViewer({ artifact, className }: TextGridViewerProps) {
  const [showGrid, setShowGrid] = React.useState(true)
  const [showFields, setShowFields] = React.useState(true)
  const [selectedField, setSelectedField] = React.useState<FieldInfo | null>(null)
  const [fontSize, setFontSize] = React.useState(14)
  
  // Mock 3270 screen data (24x80 grid)
  const screenData = React.useMemo(() => {
    const rows = 24
    const cols = 80
    
    // Create empty screen
    const screen = Array(rows).fill(null).map(() => Array(cols).fill(' '))
    
    // Add some sample mainframe screen content
    const addText = (row: number, col: number, text: string) => {
      for (let i = 0; i < text.length && col + i < cols; i++) {
        screen[row][col + i] = text[i]
      }
    }
    
    // Sample CICS screen
    addText(0, 25, "CUSTOMER INFORMATION SYSTEM")
    addText(1, 25, "==========================")
    
    addText(3, 2, "CUSTOMER ID:")
    addText(3, 15, "[________]")
    
    addText(5, 2, "NAME:")
    addText(5, 15, "[________________________]")
    
    addText(7, 2, "ADDRESS:")
    addText(7, 15, "[________________________]")
    addText(8, 15, "[________________________]")
    
    addText(10, 2, "PHONE:")
    addText(10, 15, "[____________]")
    
    addText(12, 2, "EMAIL:")
    addText(12, 15, "[________________________]")
    
    addText(14, 2, "STATUS:")
    addText(14, 15, "[ACTIVE  ]")
    
    addText(16, 2, "LAST ORDER:")
    addText(16, 15, "2024-01-15")
    
    addText(18, 2, "BALANCE:")
    addText(18, 15, "$1,234.56")
    
    addText(22, 2, "PF1=HELP  PF3=EXIT  PF5=REFRESH  PF7=BACK  PF8=FORWARD  ENTER=SUBMIT")
    
    return screen
  }, [])
  
  // Mock field definitions
  const fields: FieldInfo[] = [
    {
      row: 3,
      col: 15,
      length: 8,
      type: 'input',
      value: '',
      attributes: { color: 'green', underline: true }
    },
    {
      row: 5,
      col: 15,
      length: 24,
      type: 'input',
      value: 'JOHN DOE',
      attributes: { color: 'green', underline: true }
    },
    {
      row: 7,
      col: 15,
      length: 24,
      type: 'input',
      value: '123 MAIN STREET',
      attributes: { color: 'green', underline: true }
    },
    {
      row: 8,
      col: 15,
      length: 24,
      type: 'input',
      value: 'NEW YORK, NY 10001',
      attributes: { color: 'green', underline: true }
    },
    {
      row: 10,
      col: 15,
      length: 12,
      type: 'input',
      value: '555-1234',
      attributes: { color: 'green', underline: true }
    },
    {
      row: 12,
      col: 15,
      length: 24,
      type: 'input',
      value: 'john@example.com',
      attributes: { color: 'green', underline: true }
    },
    {
      row: 14,
      col: 15,
      length: 8,
      type: 'protected',
      value: 'ACTIVE',
      attributes: { color: 'cyan', highlight: true }
    },
    {
      row: 16,
      col: 15,
      length: 10,
      type: 'output',
      value: '2024-01-15',
      attributes: { color: 'white' }
    },
    {
      row: 18,
      col: 15,
      length: 9,
      type: 'output',
      value: '$1,234.56',
      attributes: { color: 'yellow' }
    }
  ]
  
  const getFieldAt = (row: number, col: number) => {
    return fields.find(f => 
      f.row === row && col >= f.col && col < f.col + f.length
    )
  }
  
  const getCellStyle = (row: number, col: number) => {
    const field = getFieldAt(row, col)
    if (!field) return {}
    
    const styles: React.CSSProperties = {}
    
    if (field.attributes?.color) {
      switch (field.attributes.color) {
        case 'green':
          styles.color = '#00ff00'
          break
        case 'cyan':
          styles.color = '#00ffff'
          break
        case 'yellow':
          styles.color = '#ffff00'
          break
        case 'red':
          styles.color = '#ff0000'
          break
        case 'white':
          styles.color = '#ffffff'
          break
      }
    }
    
    if (field.attributes?.highlight) {
      styles.backgroundColor = 'rgba(255, 255, 255, 0.1)'
    }
    
    if (field.attributes?.underline) {
      styles.textDecoration = 'underline'
    }
    
    if (field === selectedField) {
      styles.backgroundColor = 'rgba(59, 130, 246, 0.3)'
    }
    
    return styles
  }
  
  const handleCellClick = (row: number, col: number) => {
    const field = getFieldAt(row, col)
    setSelectedField(field || null)
  }
  
  const copyScreen = () => {
    const text = screenData.map(row => row.join('')).join('\n')
    navigator.clipboard.writeText(text)
  }
  
  const downloadScreen = () => {
    const text = screenData.map(row => row.join('')).join('\n')
    const blob = new Blob([text], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = artifact.name
    link.click()
    URL.revokeObjectURL(url)
  }

  return (
    <TooltipProvider>
      <div className={cn("space-y-4", className)}>
        {/* Toolbar */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Toggle
              pressed={showGrid}
              onPressedChange={setShowGrid}
              size="sm"
            >
              <Grid3x3 className="h-4 w-4 mr-1" />
              Grid
            </Toggle>
            
            <Toggle
              pressed={showFields}
              onPressedChange={setShowFields}
              size="sm"
            >
              <MousePointer className="h-4 w-4 mr-1" />
              Fields
            </Toggle>
            
            <div className="flex items-center gap-1 ml-4">
              <Button
                variant="outline"
                size="icon"
                onClick={() => setFontSize(prev => Math.max(10, prev - 2))}
                disabled={fontSize <= 10}
              >
                <ZoomOut className="h-4 w-4" />
              </Button>
              <span className="text-sm w-12 text-center">{fontSize}px</span>
              <Button
                variant="outline"
                size="icon"
                onClick={() => setFontSize(prev => Math.min(20, prev + 2))}
                disabled={fontSize >= 20}
              >
                <ZoomIn className="h-4 w-4" />
              </Button>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Button variant="outline" size="icon" onClick={copyScreen}>
              <Copy className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="icon" onClick={downloadScreen}>
              <Download className="h-4 w-4" />
            </Button>
          </div>
        </div>
        
        {/* Screen Display */}
        <ScrollArea className="h-[500px] border rounded bg-black p-4">
          <div 
            className="font-mono whitespace-pre"
            style={{ fontSize: `${fontSize}px` }}
          >
            {screenData.map((row, rowIndex) => (
              <div key={rowIndex} className="flex">
                {showGrid && (
                  <span className="text-gray-600 select-none pr-2 text-right w-8">
                    {String(rowIndex).padStart(2, '0')}
                  </span>
                )}
                {row.map((char, colIndex) => {
                  const field = showFields ? getFieldAt(rowIndex, colIndex) : null
                  const isFieldStart = field && field.col === colIndex
                  
                  return (
                    <span
                      key={colIndex}
                      className={cn(
                        "cursor-pointer hover:bg-white/10",
                        showGrid && colIndex % 10 === 0 && "border-l border-gray-800"
                      )}
                      style={getCellStyle(rowIndex, colIndex)}
                      onClick={() => handleCellClick(rowIndex, colIndex)}
                    >
                      {isFieldStart && field && (
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <span>{char}</span>
                          </TooltipTrigger>
                          <TooltipContent>
                            <div className="text-xs">
                              <div>Type: {field.type}</div>
                              <div>Position: {field.row},{field.col}</div>
                              <div>Length: {field.length}</div>
                              {field.value && <div>Value: {field.value}</div>}
                            </div>
                          </TooltipContent>
                        </Tooltip>
                      )}
                      {!isFieldStart && char}
                    </span>
                  )
                })}
              </div>
            ))}
            
            {showGrid && (
              <div className="flex text-gray-600 select-none mt-1">
                <span className="w-8"></span>
                {Array(80).fill(null).map((_, i) => (
                  <span key={i} className={cn(i % 10 === 0 && "border-l border-gray-800")}>
                    {i % 10}
                  </span>
                ))}
              </div>
            )}
          </div>
        </ScrollArea>
        
        {/* Field Info */}
        {selectedField && (
          <div className="p-3 bg-muted rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Info className="h-4 w-4" />
              <span className="font-medium text-sm">Field Information</span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div>
                <span className="text-muted-foreground">Type:</span>
                <span className="ml-2 font-medium capitalize">{selectedField.type}</span>
              </div>
              <div>
                <span className="text-muted-foreground">Position:</span>
                <span className="ml-2 font-medium">
                  Row {selectedField.row}, Col {selectedField.col}
                </span>
              </div>
              <div>
                <span className="text-muted-foreground">Length:</span>
                <span className="ml-2 font-medium">{selectedField.length} chars</span>
              </div>
              {selectedField.value && (
                <div>
                  <span className="text-muted-foreground">Value:</span>
                  <span className="ml-2 font-medium">{selectedField.value}</span>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </TooltipProvider>
  )
} 