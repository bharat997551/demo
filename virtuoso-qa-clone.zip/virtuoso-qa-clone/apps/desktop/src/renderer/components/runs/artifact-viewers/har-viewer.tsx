import React from 'react'
import { 
  Globe, 
  Clock, 
  Download, 
  ChevronRight,
  ChevronDown,
  AlertCircle,
  CheckCircle,
  XCircle,
  Info
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'

interface HarEntry {
  startedDateTime: string
  time: number
  request: {
    method: string
    url: string
    httpVersion: string
    headers: Array<{ name: string; value: string }>
    queryString: Array<{ name: string; value: string }>
    postData?: {
      mimeType: string
      text?: string
      params?: Array<{ name: string; value: string }>
    }
  }
  response: {
    status: number
    statusText: string
    httpVersion: string
    headers: Array<{ name: string; value: string }>
    content: {
      size: number
      mimeType: string
      text?: string
    }
    redirectURL: string
  }
  timings: {
    blocked?: number
    dns?: number
    connect?: number
    ssl?: number
    send?: number
    wait?: number
    receive?: number
  }
}

interface HarViewerProps {
  artifact: {
    id: string
    name: string
    url: string
    metadata?: any
  }
  className?: string
}

export function HarViewer({ artifact, className }: HarViewerProps) {
  const [selectedEntry, setSelectedEntry] = React.useState<HarEntry | null>(null)
  const [expandedEntries, setExpandedEntries] = React.useState<Set<number>>(new Set())
  const [filter, setFilter] = React.useState<'all' | 'xhr' | 'js' | 'css' | 'img' | 'media' | 'font' | 'doc' | 'other'>('all')

  // Mock HAR data for demonstration
  const harData: HarEntry[] = [
    {
      startedDateTime: new Date().toISOString(),
      time: 123.45,
      request: {
        method: 'GET',
        url: 'https://api.example.com/users',
        httpVersion: 'HTTP/1.1',
        headers: [
          { name: 'Accept', value: 'application/json' },
          { name: 'Authorization', value: 'Bearer token...' }
        ],
        queryString: [
          { name: 'page', value: '1' },
          { name: 'limit', value: '10' }
        ]
      },
      response: {
        status: 200,
        statusText: 'OK',
        httpVersion: 'HTTP/1.1',
        headers: [
          { name: 'Content-Type', value: 'application/json' },
          { name: 'Content-Length', value: '1234' }
        ],
        content: {
          size: 1234,
          mimeType: 'application/json',
          text: '{"users": [...]}'
        },
        redirectURL: ''
      },
      timings: {
        blocked: 1.2,
        dns: 5.3,
        connect: 15.2,
        ssl: 10.1,
        send: 0.5,
        wait: 85.4,
        receive: 5.75
      }
    },
    {
      startedDateTime: new Date().toISOString(),
      time: 234.56,
      request: {
        method: 'POST',
        url: 'https://api.example.com/login',
        httpVersion: 'HTTP/1.1',
        headers: [
          { name: 'Content-Type', value: 'application/json' },
          { name: 'Accept', value: 'application/json' }
        ],
        queryString: [],
        postData: {
          mimeType: 'application/json',
          text: '{"username":"test","password":"***"}'
        }
      },
      response: {
        status: 401,
        statusText: 'Unauthorized',
        httpVersion: 'HTTP/1.1',
        headers: [
          { name: 'Content-Type', value: 'application/json' },
          { name: 'WWW-Authenticate', value: 'Bearer' }
        ],
        content: {
          size: 89,
          mimeType: 'application/json',
          text: '{"error": "Invalid credentials"}'
        },
        redirectURL: ''
      },
      timings: {
        send: 0.8,
        wait: 220.5,
        receive: 13.26
      }
    }
  ]

  const getStatusColor = (status: number) => {
    if (status >= 200 && status < 300) return 'text-green-500'
    if (status >= 300 && status < 400) return 'text-blue-500'
    if (status >= 400 && status < 500) return 'text-yellow-500'
    if (status >= 500) return 'text-red-500'
    return 'text-gray-500'
  }

  const getStatusIcon = (status: number) => {
    if (status >= 200 && status < 300) return <CheckCircle className="h-4 w-4" />
    if (status >= 400) return <XCircle className="h-4 w-4" />
    return <AlertCircle className="h-4 w-4" />
  }

  const formatDuration = (ms: number) => {
    if (ms < 1) return `${(ms * 1000).toFixed(0)}μs`
    if (ms < 1000) return `${ms.toFixed(0)}ms`
    return `${(ms / 1000).toFixed(2)}s`
  }

  const formatSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
  }

  const getResourceType = (mimeType: string, url: string) => {
    if (mimeType.includes('json') || url.includes('/api/')) return 'xhr'
    if (mimeType.includes('javascript')) return 'js'
    if (mimeType.includes('css')) return 'css'
    if (mimeType.includes('image')) return 'img'
    if (mimeType.includes('video') || mimeType.includes('audio')) return 'media'
    if (mimeType.includes('font')) return 'font'
    if (mimeType.includes('html')) return 'doc'
    return 'other'
  }

  const filteredEntries = harData.filter(entry => {
    if (filter === 'all') return true
    const type = getResourceType(entry.response.content.mimeType, entry.request.url)
    return type === filter
  })

  const toggleEntry = (index: number) => {
    setExpandedEntries(prev => {
      const newSet = new Set(prev)
      if (newSet.has(index)) {
        newSet.delete(index)
      } else {
        newSet.add(index)
      }
      return newSet
    })
  }

  return (
    <div className={cn("h-[600px] flex flex-col", className)}>
      {/* Filter Tabs */}
      <Tabs value={filter} onValueChange={(value) => setFilter(value as any)} className="mb-4">
        <TabsList>
          <TabsTrigger value="all">All ({harData.length})</TabsTrigger>
          <TabsTrigger value="xhr">XHR</TabsTrigger>
          <TabsTrigger value="js">JS</TabsTrigger>
          <TabsTrigger value="css">CSS</TabsTrigger>
          <TabsTrigger value="img">Images</TabsTrigger>
          <TabsTrigger value="media">Media</TabsTrigger>
          <TabsTrigger value="font">Fonts</TabsTrigger>
          <TabsTrigger value="doc">Doc</TabsTrigger>
          <TabsTrigger value="other">Other</TabsTrigger>
        </TabsList>
      </Tabs>

      {/* Request List */}
      <ScrollArea className="flex-1 border rounded">
        <div className="divide-y">
          {filteredEntries.map((entry, index) => {
            const isExpanded = expandedEntries.has(index)
            const type = getResourceType(entry.response.content.mimeType, entry.request.url)
            
            return (
              <div key={index}>
                <button
                  onClick={() => toggleEntry(index)}
                  className="w-full text-left p-3 hover:bg-accent/50 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-1">
                      {isExpanded ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                      <span className={cn("flex items-center gap-1", getStatusColor(entry.response.status))}>
                        {getStatusIcon(entry.response.status)}
                        {entry.response.status}
                      </span>
                    </div>
                    
                    <Badge variant="outline" className="text-xs">
                      {entry.request.method}
                    </Badge>
                    
                    <div className="flex-1 truncate text-sm">
                      {new URL(entry.request.url).pathname}
                    </div>
                    
                    <Badge variant="secondary" className="text-xs">
                      {type}
                    </Badge>
                    
                    <div className="text-sm text-muted-foreground">
                      {formatSize(entry.response.content.size)}
                    </div>
                    
                    <div className="text-sm text-muted-foreground flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {formatDuration(entry.time)}
                    </div>
                  </div>
                </button>

                {isExpanded && (
                  <div className="border-t bg-muted/30 p-4">
                    <Tabs defaultValue="headers" className="w-full">
                      <TabsList className="grid w-full grid-cols-4">
                        <TabsTrigger value="headers">Headers</TabsTrigger>
                        <TabsTrigger value="response">Response</TabsTrigger>
                        <TabsTrigger value="timing">Timing</TabsTrigger>
                        <TabsTrigger value="request">Request</TabsTrigger>
                      </TabsList>
                      
                      <TabsContent value="headers" className="mt-4">
                        <div className="space-y-4">
                          <div>
                            <h4 className="text-sm font-medium mb-2">Request Headers</h4>
                            <div className="space-y-1">
                              {entry.request.headers.map((header, i) => (
                                <div key={i} className="text-xs font-mono">
                                  <span className="text-muted-foreground">{header.name}:</span> {header.value}
                                </div>
                              ))}
                            </div>
                          </div>
                          
                          <div>
                            <h4 className="text-sm font-medium mb-2">Response Headers</h4>
                            <div className="space-y-1">
                              {entry.response.headers.map((header, i) => (
                                <div key={i} className="text-xs font-mono">
                                  <span className="text-muted-foreground">{header.name}:</span> {header.value}
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      </TabsContent>
                      
                      <TabsContent value="response" className="mt-4">
                        {entry.response.content.text && (
                          <pre className="text-xs bg-muted p-3 rounded overflow-auto max-h-48">
                            {entry.response.content.text}
                          </pre>
                        )}
                      </TabsContent>
                      
                      <TabsContent value="timing" className="mt-4">
                        <div className="space-y-2">
                          {Object.entries(entry.timings).map(([phase, duration]) => (
                            duration && (
                              <div key={phase} className="flex items-center justify-between text-sm">
                                <span className="capitalize">{phase}:</span>
                                <span className="font-mono">{formatDuration(duration)}</span>
                              </div>
                            )
                          ))}
                          <div className="border-t pt-2 mt-2">
                            <div className="flex items-center justify-between text-sm font-medium">
                              <span>Total:</span>
                              <span className="font-mono">{formatDuration(entry.time)}</span>
                            </div>
                          </div>
                        </div>
                      </TabsContent>
                      
                      <TabsContent value="request" className="mt-4">
                        <div className="space-y-4">
                          <div className="text-sm">
                            <span className="font-medium">URL:</span>
                            <div className="font-mono text-xs mt-1 break-all">{entry.request.url}</div>
                          </div>
                          
                          {entry.request.queryString.length > 0 && (
                            <div>
                              <h4 className="text-sm font-medium mb-2">Query Parameters</h4>
                              <div className="space-y-1">
                                {entry.request.queryString.map((param, i) => (
                                  <div key={i} className="text-xs font-mono">
                                    <span className="text-muted-foreground">{param.name}:</span> {param.value}
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                          
                          {entry.request.postData && (
                            <div>
                              <h4 className="text-sm font-medium mb-2">Request Body</h4>
                              <pre className="text-xs bg-muted p-3 rounded overflow-auto max-h-48">
                                {entry.request.postData.text}
                              </pre>
                            </div>
                          )}
                        </div>
                      </TabsContent>
                    </Tabs>
                  </div>
                )}
              </div>
            )
          })}
        </div>
      </ScrollArea>

      {/* Summary */}
      <div className="mt-4 p-3 bg-muted rounded-lg">
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center gap-4">
            <span>
              <span className="font-medium">{harData.length}</span> requests
            </span>
            <span>
              <span className="font-medium">{formatSize(harData.reduce((sum, e) => sum + e.response.content.size, 0))}</span> transferred
            </span>
            <span>
              <span className="font-medium">{formatDuration(harData.reduce((sum, e) => sum + e.time, 0))}</span> total time
            </span>
          </div>
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Export HAR
          </Button>
        </div>
      </div>
    </div>
  )
} 