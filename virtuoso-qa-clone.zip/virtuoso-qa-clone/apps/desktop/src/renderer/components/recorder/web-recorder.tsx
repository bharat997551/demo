import * as React from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Circle,
  Square,
  Pause,
  Play,
  StickyNote,
  Settings,
  X,
  Minimize2,
  GripHorizontal,
  Edit3,
  Trash2,
  Eye
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { cn } from '@/lib/utils'

interface RecordedStep {
  id: string
  type: 'click' | 'type' | 'navigate' | 'wait' | 'assertion'
  target: string
  value?: string
  timestamp: number
  note?: string
}

interface WebRecorderProps {
  isVisible?: boolean
  onClose?: () => void
  onMinimize?: () => void
}

export function WebRecorder({ isVisible = false, onClose, onMinimize }: WebRecorderProps) {
  const [isRecording, setIsRecording] = React.useState(false)
  const [isPaused, setIsPaused] = React.useState(false)
  const [isMinimized, setIsMinimized] = React.useState(false)
  const [showSteps, setShowSteps] = React.useState(true)
  const [steps, setSteps] = React.useState<RecordedStep[]>([])
  const [noteInput, setNoteInput] = React.useState('')
  const [editingStep, setEditingStep] = React.useState<string | null>(null)

  const [position, setPosition] = React.useState({ x: 20, y: 20 })
  const dragConstraints = React.useRef(null)

  React.useEffect(() => {
    if (window.electronAPI && isRecording && !isPaused) {
      // Set up recording step listener
      const cleanup = window.electronAPI.onRecordingStep((step: any) => {
        const recordedStep: RecordedStep = {
          id: `step-${Date.now()}`,
          type: step.type,
          target: step.selector || step.url,
          value: step.value,
          timestamp: Date.now()
        }
        setSteps(prev => [...prev, recordedStep])
      })

      return cleanup
    }
  }, [isRecording, isPaused])

  const handleStartRecording = async () => {
    if (window.electronAPI) {
      const result = await window.electronAPI.startWebRecording({
        captureClicks: true,
        captureKeystrokes: true,
        captureNavigations: true
      })
      
      if (result.success) {
        setIsRecording(true)
        setIsPaused(false)
        setSteps([])
      }
    }
  }

  const handleStopRecording = async () => {
    if (window.electronAPI) {
      await window.electronAPI.stopWebRecording()
      setIsRecording(false)
      setIsPaused(false)
    }
  }

  const handlePauseToggle = () => {
    setIsPaused(!isPaused)
  }

  const handleAddNote = () => {
    if (noteInput.trim()) {
      const noteStep: RecordedStep = {
        id: `note-${Date.now()}`,
        type: 'assertion',
        target: 'Manual Note',
        value: noteInput.trim(),
        timestamp: Date.now(),
        note: noteInput.trim()
      }
      setSteps(prev => [...prev, noteStep])
      setNoteInput('')
    }
  }

  const handleDeleteStep = (stepId: string) => {
    setSteps(prev => prev.filter(step => step.id !== stepId))
  }

  const handleEditStep = (stepId: string, newValue: string) => {
    setSteps(prev => prev.map(step => 
      step.id === stepId 
        ? { ...step, value: newValue }
        : step
    ))
    setEditingStep(null)
  }

  const formatStepDisplay = (step: RecordedStep) => {
    switch (step.type) {
      case 'click':
        return `Click on ${step.target}`
      case 'type':
        return `Type "${step.value}" in ${step.target}`
      case 'navigate':
        return `Navigate to ${step.target}`
      case 'wait':
        return `Wait ${step.value}ms`
      case 'assertion':
        return step.note || `Assert ${step.target}`
      default:
        return `${step.type} on ${step.target}`
    }
  }

  if (!isVisible) return null

  return (
    <AnimatePresence>
      <motion.div
        ref={dragConstraints}
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
        drag
        dragConstraints={{ left: 0, right: window.innerWidth - 400, top: 0, bottom: window.innerHeight - 600 }}
        dragElastic={0}
        dragMomentum={false}
        className={cn(
          "fixed z-50 bg-card border rounded-lg shadow-2xl overflow-hidden",
          isMinimized ? "w-64 h-12" : "w-96 h-auto max-h-[600px]"
        )}
        style={{ left: position.x, top: position.y }}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-3 border-b drag-handle cursor-move">
          <div className="flex items-center gap-2">
            <div className={cn(
              "h-2 w-2 rounded-full",
              isRecording && !isPaused ? "bg-red-500 animate-pulse" : "bg-gray-400"
            )} />
            <span className="text-sm font-medium">Web Recorder</span>
            {isRecording && (
              <span className="text-xs text-muted-foreground">
                {isPaused ? "Paused" : "Recording"}
              </span>
            )}
          </div>
          
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              className="h-6 w-6"
              onClick={() => setShowSteps(!showSteps)}
            >
              <Eye className="h-3 w-3" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="h-6 w-6"
              onClick={() => setIsMinimized(!isMinimized)}
            >
              <Minimize2 className="h-3 w-3" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="h-6 w-6"
              onClick={onClose}
            >
              <X className="h-3 w-3" />
            </Button>
          </div>
        </div>

        {!isMinimized && (
          <>
            {/* Controls */}
            <div className="p-3 border-b bg-muted/30">
              <div className="flex items-center gap-2 mb-3">
                {!isRecording ? (
                  <Button
                    variant="default"
                    size="sm"
                    className="gap-2 flex-1"
                    onClick={handleStartRecording}
                  >
                    <Circle className="h-4 w-4 text-red-500" />
                    Start Recording
                  </Button>
                ) : (
                  <>
                    <Button
                      variant={isPaused ? "default" : "secondary"}
                      size="sm"
                      className="gap-2"
                      onClick={handlePauseToggle}
                    >
                      {isPaused ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />}
                      {isPaused ? "Resume" : "Pause"}
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      className="gap-2"
                      onClick={handleStopRecording}
                    >
                      <Square className="h-4 w-4" />
                      Stop
                    </Button>
                  </>
                )}
              </div>

              {/* Add Note */}
              <div className="flex gap-2">
                <Input
                  placeholder="Add note or assertion..."
                  value={noteInput}
                  onChange={(e) => setNoteInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleAddNote()}
                  className="text-sm"
                />
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleAddNote}
                  disabled={!noteInput.trim()}
                >
                  <StickyNote className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* Steps List */}
            {showSteps && (
              <div className="flex-1 overflow-hidden">
                <div className="px-3 py-2 border-b bg-muted/50">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">
                      Recorded Steps ({steps.length})
                    </span>
                    <Button variant="ghost" size="sm" className="h-6 text-xs">
                      Clear All
                    </Button>
                  </div>
                </div>
                
                <div className="h-80 overflow-y-auto custom-scrollbar">
                  {steps.length === 0 ? (
                    <div className="flex items-center justify-center h-full text-muted-foreground">
                      <div className="text-center">
                        <Circle className="h-8 w-8 mx-auto mb-2 opacity-50" />
                        <p className="text-sm">No steps recorded yet</p>
                        <p className="text-xs">Start recording to see steps here</p>
                      </div>
                    </div>
                  ) : (
                    <div className="p-2 space-y-2">
                      {steps.map((step, index) => (
                        <motion.div
                          key={step.id}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="group relative flex items-start gap-3 p-2 rounded-md hover:bg-muted/50 transition-colors"
                        >
                          <div className="text-xs text-muted-foreground font-mono min-w-[20px]">
                            {index + 1}
                          </div>
                          
                          <div className="flex-1 min-w-0">
                            {editingStep === step.id ? (
                              <Input
                                defaultValue={step.value || ''}
                                className="text-xs h-6"
                                onBlur={(e) => handleEditStep(step.id, e.target.value)}
                                onKeyDown={(e) => {
                                  if (e.key === 'Enter') {
                                    handleEditStep(step.id, e.currentTarget.value)
                                  } else if (e.key === 'Escape') {
                                    setEditingStep(null)
                                  }
                                }}
                                autoFocus
                              />
                            ) : (
                              <div className="text-xs">
                                <div className="font-medium truncate">
                                  {formatStepDisplay(step)}
                                </div>
                                <div className="text-muted-foreground mt-1">
                                  {new Date(step.timestamp).toLocaleTimeString()}
                                </div>
                              </div>
                            )}
                          </div>
                          
                          <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-6 w-6"
                              onClick={() => setEditingStep(step.id)}
                            >
                              <Edit3 className="h-3 w-3" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-6 w-6 text-destructive"
                              onClick={() => handleDeleteStep(step.id)}
                            >
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}
          </>
        )}
      </motion.div>
    </AnimatePresence>
  )
} 