import React from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Monitor,
  Square,
  Circle,
  Settings,
  X,
  MousePointer,
  Keyboard,
  Camera,
  Eye,
  EyeOff
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { cn } from '@/lib/utils'

interface DesktopRecorderProps {
  isVisible?: boolean
  onClose?: () => void
}

export function DesktopRecorder({ isVisible = false, onClose }: DesktopRecorderProps) {
  const [isRecording, setIsRecording] = React.useState(false)
  const [isOverlayVisible, setIsOverlayVisible] = React.useState(true)
  const [captureSettings, setCaptureSettings] = React.useState({
    mouse: true,
    keyboard: true,
    screenshots: true
  })

  React.useEffect(() => {
    if (window.electronAPI && isRecording) {
      // Set up recording status listener
      const cleanup = window.electronAPI.onRecordingStatusChange((status: any) => {
        if (status.type === 'desktop') {
          setIsRecording(status.isRecording)
        }
      })

      return cleanup
    }
  }, [isRecording])

  const handleStartRecording = async () => {
    if (window.electronAPI) {
      const result = await window.electronAPI.startDesktopRecording({
        captureMouse: captureSettings.mouse,
        captureKeyboard: captureSettings.keyboard,
        captureScreenshots: captureSettings.screenshots
      })
      
      if (result.success) {
        setIsRecording(true)
      }
    }
  }

  const handleStopRecording = async () => {
    if (window.electronAPI) {
      await window.electronAPI.stopDesktopRecording()
      setIsRecording(false)
    }
  }

  if (!isVisible) return null

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-40 pointer-events-none">
        {/* Recording Overlay */}
        {isRecording && isOverlayVisible && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 pointer-events-none"
          >
            {/* Corner indicators */}
            <div className="absolute top-4 left-4 h-6 w-6 border-l-4 border-t-4 border-red-500 rounded-tl-lg animate-pulse" />
            <div className="absolute top-4 right-4 h-6 w-6 border-r-4 border-t-4 border-red-500 rounded-tr-lg animate-pulse" />
            <div className="absolute bottom-4 left-4 h-6 w-6 border-l-4 border-b-4 border-red-500 rounded-bl-lg animate-pulse" />
            <div className="absolute bottom-4 right-4 h-6 w-6 border-r-4 border-b-4 border-red-500 rounded-br-lg animate-pulse" />

            {/* Recording indicator */}
            <div className="absolute top-8 left-1/2 -translate-x-1/2 pointer-events-auto">
              <motion.div
                initial={{ y: -100, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                className="flex items-center gap-2 bg-red-500 text-white px-4 py-2 rounded-full shadow-lg"
              >
                <Circle className="h-4 w-4 fill-white animate-pulse" />
                <span className="text-sm font-medium">Recording Desktop</span>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6 text-white hover:bg-white/20"
                  onClick={() => setIsOverlayVisible(false)}
                >
                  <EyeOff className="h-3 w-3" />
                </Button>
              </motion.div>
            </div>
          </motion.div>
        )}

        {/* Control Panel */}
        <motion.div
          initial={{ opacity: 0, y: 100 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 100 }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 pointer-events-auto"
        >
          <Card className="w-96 shadow-2xl border-0 bg-card/95 backdrop-blur">
            <CardHeader className="pb-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Monitor className="h-5 w-5 text-primary" />
                  <CardTitle className="text-lg">Desktop Recorder</CardTitle>
                </div>
                <div className="flex items-center gap-1">
                  {isRecording && !isOverlayVisible && (
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => setIsOverlayVisible(true)}
                    >
                      <Eye className="h-4 w-4" />
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    onClick={onClose}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>

            <CardContent className="space-y-4">
              {/* Status */}
              <div className="flex items-center gap-2 text-sm">
                <div className={cn(
                  "h-2 w-2 rounded-full",
                  isRecording ? "bg-red-500 animate-pulse" : "bg-gray-400"
                )} />
                <span className="font-medium">
                  {isRecording ? "Recording in progress" : "Ready to record"}
                </span>
              </div>

              {/* Capture Settings */}
              <div className="space-y-3">
                <h4 className="text-sm font-medium">Capture Settings</h4>
                <div className="grid grid-cols-3 gap-2">
                  <Button
                    variant={captureSettings.mouse ? "default" : "outline"}
                    size="sm"
                    className="flex flex-col gap-1 h-auto py-3"
                    onClick={() => setCaptureSettings(prev => ({ ...prev, mouse: !prev.mouse }))}
                    disabled={isRecording}
                  >
                    <MousePointer className="h-4 w-4" />
                    <span className="text-xs">Mouse</span>
                  </Button>
                  <Button
                    variant={captureSettings.keyboard ? "default" : "outline"}
                    size="sm"
                    className="flex flex-col gap-1 h-auto py-3"
                    onClick={() => setCaptureSettings(prev => ({ ...prev, keyboard: !prev.keyboard }))}
                    disabled={isRecording}
                  >
                    <Keyboard className="h-4 w-4" />
                    <span className="text-xs">Keyboard</span>
                  </Button>
                  <Button
                    variant={captureSettings.screenshots ? "default" : "outline"}
                    size="sm"
                    className="flex flex-col gap-1 h-auto py-3"
                    onClick={() => setCaptureSettings(prev => ({ ...prev, screenshots: !prev.screenshots }))}
                    disabled={isRecording}
                  >
                    <Camera className="h-4 w-4" />
                    <span className="text-xs">Screenshots</span>
                  </Button>
                </div>
              </div>

              {/* Controls */}
              <div className="flex gap-2">
                {!isRecording ? (
                  <Button
                    className="flex-1 gap-2"
                    onClick={handleStartRecording}
                    disabled={!captureSettings.mouse && !captureSettings.keyboard}
                  >
                    <Circle className="h-4 w-4 text-red-500" />
                    Start Recording
                  </Button>
                ) : (
                  <Button
                    variant="destructive"
                    className="flex-1 gap-2"
                    onClick={handleStopRecording}
                  >
                    <Square className="h-4 w-4" />
                    Stop Recording
                  </Button>
                )}
                <Button
                  variant="outline"
                  size="icon"
                  disabled={isRecording}
                >
                  <Settings className="h-4 w-4" />
                </Button>
              </div>

              {/* Instructions */}
              {!isRecording && (
                <div className="text-xs text-muted-foreground space-y-1">
                  <p>• Click "Start Recording" to begin capturing desktop interactions</p>
                  <p>• Red corners will appear to indicate active recording</p>
                  <p>• Press "Stop Recording" or use the overlay controls to finish</p>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </AnimatePresence>
  )
} 