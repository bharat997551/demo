import React from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  CheckCircle,
  XCircle,
  AlertCircle,
  Loader2,
  Play,
  Download,
  RefreshCw,
  Settings,
  Monitor,
  Server,
  Globe,
  Terminal,
  Cpu,
  Shield,
  ChevronRight,
  ChevronLeft,
  CheckCircle2
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { Switch } from '@/components/ui/switch'

interface Requirement {
  id: string
  name: string
  description: string
  type: 'required' | 'optional'
  status: 'checking' | 'passed' | 'failed' | 'warning' | 'not-checked'
  version?: string
  path?: string
  error?: string
  fixAction?: () => Promise<void>
}

interface FirstRunWizardProps {
  onComplete: () => void
}

export function FirstRunWizard({ onComplete }: FirstRunWizardProps) {
  const [currentStep, setCurrentStep] = React.useState(0)
  const [requirements, setRequirements] = React.useState<Requirement[]>([
    {
      id: 'python',
      name: 'Python Runtime',
      description: 'Python 3.9 or higher required for automation engines',
      type: 'required',
      status: 'not-checked'
    },
    {
      id: 'playwright',
      name: 'Playwright Browsers',
      description: 'Chromium, Firefox, and WebKit for web testing',
      type: 'required',
      status: 'not-checked'
    },
    {
      id: 'desktop-venv',
      name: 'Desktop Engine',
      description: 'Python virtual environment for desktop automation',
      type: 'required',
      status: 'not-checked'
    },
    {
      id: 'mainframe-venv',
      name: 'Mainframe Engine',
      description: 'Python virtual environment for mainframe automation',
      type: 'optional',
      status: 'not-checked'
    },
    {
      id: 's3270',
      name: 's3270 Terminal',
      description: '3270 terminal emulator for mainframe testing',
      type: 'optional',
      status: 'not-checked'
    },
    {
      id: 'winappdriver',
      name: 'WinAppDriver',
      description: 'Windows Application Driver for UWP app testing',
      type: 'optional',
      status: 'not-checked'
    },
    {
      id: 'permissions',
      name: 'System Permissions',
      description: 'Admin rights for desktop automation',
      type: 'required',
      status: 'not-checked'
    }
  ])

  const [isChecking, setIsChecking] = React.useState(false)
  const [isFixing, setIsFixing] = React.useState(false)
  const [progress, setProgress] = React.useState(0)

  const steps = [
    {
      title: 'Welcome',
      description: 'Get started with Hybrid QA',
      icon: <Globe className="h-6 w-6" />
    },
    {
      title: 'Environment Check',
      description: 'Validate system requirements',
      icon: <Monitor className="h-6 w-6" />
    },
    {
      title: 'Configuration',
      description: 'Set up your preferences',
      icon: <Settings className="h-6 w-6" />
    },
    {
      title: 'Ready to Go',
      description: 'Start automating',
      icon: <CheckCircle2 className="h-6 w-6" />
    }
  ]

  const checkRequirements = async () => {
    setIsChecking(true)
    const totalChecks = requirements.length
    let completed = 0

    for (const req of requirements) {
      // Update progress
      completed++
      setProgress((completed / totalChecks) * 100)

      // Simulate checking (in real app, would call IPC to check)
      await new Promise(resolve => setTimeout(resolve, 500))

      // Mock results
      const mockResults: Record<string, Partial<Requirement>> = {
        'python': {
          status: 'passed',
          version: '3.11.5',
          path: 'C:\\Program Files\\Python311'
        },
        'playwright': {
          status: 'failed',
          error: 'Browsers not installed'
        },
        'desktop-venv': {
          status: 'passed',
          path: 'C:\\HybridQA\\engines\\desktop\\venv'
        },
        'mainframe-venv': {
          status: 'warning',
          error: 'Not configured'
        },
        's3270': {
          status: 'failed',
          error: 'Not found in PATH'
        },
        'winappdriver': {
          status: 'warning',
          error: 'Not installed'
        },
        'permissions': {
          status: 'passed'
        }
      }

      setRequirements(prev => prev.map(r => 
        r.id === req.id 
          ? { ...r, ...mockResults[req.id], status: mockResults[req.id].status as any }
          : r
      ))
    }

    setIsChecking(false)
    setProgress(100)
  }

  const fixRequirement = async (req: Requirement) => {
    setIsFixing(true)

    // Mock fix actions
    const fixActions: Record<string, () => Promise<void>> = {
      'playwright': async () => {
        // Install Playwright browsers
        await window.electronAPI.runCommand('npx playwright install')
      },
      's3270': async () => {
        // Download and install s3270
        await window.electronAPI.openExternal('http://x3270.bgp.nu/download.html')
      },
      'winappdriver': async () => {
        // Open WinAppDriver download page
        await window.electronAPI.openExternal('https://github.com/Microsoft/WinAppDriver/releases')
      }
    }

    if (fixActions[req.id]) {
      await fixActions[req.id]()
      // Re-check this requirement
      setRequirements(prev => prev.map(r => 
        r.id === req.id ? { ...r, status: 'checking' } : r
      ))
      // Simulate re-check
      await new Promise(resolve => setTimeout(resolve, 2000))
      setRequirements(prev => prev.map(r => 
        r.id === req.id ? { ...r, status: 'passed' } : r
      ))
    }

    setIsFixing(false)
  }

  const getStatusIcon = (status: Requirement['status']) => {
    switch (status) {
      case 'checking':
        return <Loader2 className="h-5 w-5 animate-spin text-blue-500" />
      case 'passed':
        return <CheckCircle className="h-5 w-5 text-green-500" />
      case 'failed':
        return <XCircle className="h-5 w-5 text-red-500" />
      case 'warning':
        return <AlertCircle className="h-5 w-5 text-yellow-500" />
      default:
        return <div className="h-5 w-5 rounded-full border-2 border-muted" />
    }
  }

  const canProceed = () => {
    if (currentStep === 1) {
      // Can proceed if all required checks pass
      return requirements
        .filter(r => r.type === 'required')
        .every(r => r.status === 'passed')
    }
    return true
  }

  React.useEffect(() => {
    if (currentStep === 1 && requirements.every(r => r.status === 'not-checked')) {
      checkRequirements()
    }
  }, [currentStep])

  return (
    <div className="fixed inset-0 bg-background/95 backdrop-blur-sm z-50 flex items-center justify-center p-8">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="w-full max-w-4xl"
      >
        <Card className="border-2">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-2xl">First Run Setup</CardTitle>
                <CardDescription>
                  Let's get your environment ready for test automation
                </CardDescription>
              </div>
              <Badge variant="secondary" className="text-lg px-4 py-1">
                Step {currentStep + 1} of {steps.length}
              </Badge>
            </div>
          </CardHeader>

          <CardContent>
            {/* Progress Steps */}
            <div className="flex items-center justify-between mb-8">
              {steps.map((step, index) => (
                <div key={index} className="flex items-center">
                  <div className={cn(
                    "flex items-center justify-center h-12 w-12 rounded-full transition-colors",
                    index < currentStep ? "bg-primary text-primary-foreground" :
                    index === currentStep ? "bg-primary/20 text-primary" :
                    "bg-muted text-muted-foreground"
                  )}>
                    {index < currentStep ? <CheckCircle className="h-6 w-6" /> : step.icon}
                  </div>
                  {index < steps.length - 1 && (
                    <div className={cn(
                      "h-1 w-full mx-2 transition-colors",
                      index < currentStep ? "bg-primary" : "bg-muted"
                    )} />
                  )}
                </div>
              ))}
            </div>

            <AnimatePresence mode="wait">
              {/* Step 0: Welcome */}
              {currentStep === 0 && (
                <motion.div
                  key="welcome"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-6"
                >
                  <div className="text-center py-8">
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ delay: 0.2 }}
                      className="h-24 w-24 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4"
                    >
                      <Cpu className="h-12 w-12 text-primary" />
                    </motion.div>
                    <h2 className="text-3xl font-bold mb-2">Welcome to Hybrid QA</h2>
                    <p className="text-lg text-muted-foreground">
                      The comprehensive test automation platform
                    </p>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <Card>
                      <CardContent className="pt-6">
                        <div className="flex items-center gap-3 mb-2">
                          <Globe className="h-5 w-5 text-blue-500" />
                          <h3 className="font-semibold">Web Testing</h3>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          Automate browsers with Playwright
                        </p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="pt-6">
                        <div className="flex items-center gap-3 mb-2">
                          <Monitor className="h-5 w-5 text-green-500" />
                          <h3 className="font-semibold">Desktop Testing</h3>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          Control Windows applications
                        </p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="pt-6">
                        <div className="flex items-center gap-3 mb-2">
                          <Terminal className="h-5 w-5 text-purple-500" />
                          <h3 className="font-semibold">Mainframe Testing</h3>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          3270 terminal automation
                        </p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="pt-6">
                        <div className="flex items-center gap-3 mb-2">
                          <Server className="h-5 w-5 text-orange-500" />
                          <h3 className="font-semibold">API Testing</h3>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          REST, GraphQL, gRPC support
                        </p>
                      </CardContent>
                    </Card>
                  </div>
                </motion.div>
              )}

              {/* Step 1: Environment Check */}
              {currentStep === 1 && (
                <motion.div
                  key="environment"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-4"
                >
                  {isChecking && (
                    <div className="mb-6">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium">Checking requirements...</span>
                        <span className="text-sm text-muted-foreground">{Math.round(progress)}%</span>
                      </div>
                      <Progress value={progress} className="h-2" />
                    </div>
                  )}

                  <div className="space-y-2">
                    {requirements.map((req) => (
                      <Card key={req.id} className={cn(
                        "transition-colors",
                        req.status === 'failed' && req.type === 'required' && "border-red-500/50",
                        req.status === 'warning' && "border-yellow-500/50",
                        req.status === 'passed' && "border-green-500/50"
                      )}>
                        <CardContent className="pt-4">
                          <div className="flex items-start justify-between">
                            <div className="flex items-start gap-3">
                              {getStatusIcon(req.status)}
                              <div>
                                <div className="flex items-center gap-2">
                                  <h4 className="font-medium">{req.name}</h4>
                                  <Badge variant={req.type === 'required' ? 'default' : 'secondary'}>
                                    {req.type}
                                  </Badge>
                                </div>
                                <p className="text-sm text-muted-foreground">{req.description}</p>
                                {req.version && (
                                  <p className="text-xs text-muted-foreground mt-1">
                                    Version: {req.version}
                                  </p>
                                )}
                                {req.error && req.status !== 'passed' && (
                                  <p className="text-xs text-red-500 mt-1">{req.error}</p>
                                )}
                              </div>
                            </div>
                            {req.status === 'failed' && req.fixAction && (
                              <Button
                                size="sm"
                                onClick={() => fixRequirement(req)}
                                disabled={isFixing}
                              >
                                {isFixing ? (
                                  <Loader2 className="h-4 w-4 animate-spin" />
                                ) : (
                                  <>
                                    <Download className="h-4 w-4 mr-2" />
                                    Fix
                                  </>
                                )}
                              </Button>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>

                  <Alert>
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>Note</AlertTitle>
                    <AlertDescription>
                      Optional components can be installed later from Settings if needed.
                    </AlertDescription>
                  </Alert>
                </motion.div>
              )}

              {/* Step 2: Configuration */}
              {currentStep === 2 && (
                <motion.div
                  key="configuration"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-6"
                >
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-lg font-semibold mb-4">Quick Configuration</h3>
                      <div className="space-y-4">
                        <div className="flex items-center justify-between p-4 rounded-lg border">
                          <div>
                            <p className="font-medium">Enable Telemetry</p>
                            <p className="text-sm text-muted-foreground">
                              Help improve Hybrid QA by sending anonymous usage data
                            </p>
                          </div>
                          <Switch defaultChecked />
                        </div>
                        <div className="flex items-center justify-between p-4 rounded-lg border">
                          <div>
                            <p className="font-medium">Auto-Update</p>
                            <p className="text-sm text-muted-foreground">
                              Automatically download and install updates
                            </p>
                          </div>
                          <Switch defaultChecked />
                        </div>
                        <div className="flex items-center justify-between p-4 rounded-lg border">
                          <div>
                            <p className="font-medium">Dark Mode</p>
                            <p className="text-sm text-muted-foreground">
                              Use dark theme by default
                            </p>
                          </div>
                          <Switch defaultChecked />
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}

              {/* Step 3: Complete */}
              {currentStep === 3 && (
                <motion.div
                  key="complete"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-6"
                >
                  <div className="text-center py-8">
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ delay: 0.2 }}
                      className="h-24 w-24 bg-green-500/10 rounded-full flex items-center justify-center mx-auto mb-4"
                    >
                      <CheckCircle2 className="h-12 w-12 text-green-500" />
                    </motion.div>
                    <h2 className="text-3xl font-bold mb-2">You're All Set!</h2>
                    <p className="text-lg text-muted-foreground mb-8">
                      Hybrid QA is ready to help you automate your tests
                    </p>

                    <div className="grid grid-cols-3 gap-4 max-w-2xl mx-auto">
                      <Card className="cursor-pointer hover:shadow-lg transition-shadow">
                        <CardContent className="pt-6">
                          <Play className="h-8 w-8 text-primary mx-auto mb-2" />
                          <p className="font-medium">Quick Start</p>
                          <p className="text-sm text-muted-foreground">Create your first test</p>
                        </CardContent>
                      </Card>
                      <Card className="cursor-pointer hover:shadow-lg transition-shadow">
                        <CardContent className="pt-6">
                          <Terminal className="h-8 w-8 text-primary mx-auto mb-2" />
                          <p className="font-medium">Tutorials</p>
                          <p className="text-sm text-muted-foreground">Learn the basics</p>
                        </CardContent>
                      </Card>
                      <Card className="cursor-pointer hover:shadow-lg transition-shadow">
                        <CardContent className="pt-6">
                          <Globe className="h-8 w-8 text-primary mx-auto mb-2" />
                          <p className="font-medium">Examples</p>
                          <p className="text-sm text-muted-foreground">Browse sample tests</p>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </CardContent>

          <Separator />

          {/* Navigation */}
          <div className="p-6 flex items-center justify-between">
            <Button
              variant="outline"
              onClick={() => setCurrentStep(prev => Math.max(0, prev - 1))}
              disabled={currentStep === 0}
            >
              <ChevronLeft className="h-4 w-4 mr-2" />
              Previous
            </Button>

            {currentStep === steps.length - 1 ? (
              <Button onClick={onComplete}>
                Get Started
                <ChevronRight className="h-4 w-4 ml-2" />
              </Button>
            ) : (
              <Button
                onClick={() => setCurrentStep(prev => prev + 1)}
                disabled={!canProceed()}
              >
                Next
                <ChevronRight className="h-4 w-4 ml-2" />
              </Button>
            )}
          </div>
        </Card>
      </motion.div>
    </div>
  )
} 