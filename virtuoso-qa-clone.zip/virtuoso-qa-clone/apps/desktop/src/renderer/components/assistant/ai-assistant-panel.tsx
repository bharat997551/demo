import React from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Bot,
  Send,
  Sparkles,
  Check,
  X,
  Copy,
  RefreshCw,
  Settings,
  Info,
  Code,
  Lightbulb,
  AlertCircle,
  Loader2
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip'

interface Message {
  id: string
  role: 'user' | 'assistant'
  content: string
  timestamp: Date
  type?: 'text' | 'steps' | 'error' | 'suggestion'
  data?: any
  status?: 'pending' | 'accepted' | 'rejected'
}

interface SuggestedStep {
  type: string
  description: string
  parameters: Record<string, any>
}

interface AIAssistantPanelProps {
  className?: string
  onAcceptSteps?: (steps: any[]) => void
}

export function AIAssistantPanel({ className, onAcceptSteps }: AIAssistantPanelProps) {
  const [messages, setMessages] = React.useState<Message[]>([])
  const [inputValue, setInputValue] = React.useState('')
  const [isProcessing, setIsProcessing] = React.useState(false)
  const [activeTab, setActiveTab] = React.useState<'chat' | 'suggestions' | 'history'>('chat')
  const [aiConfig, setAiConfig] = React.useState({
    provider: 'mock',
    model: 'gpt-4',
    temperature: 0.7
  })
  const messagesEndRef = React.useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  React.useEffect(() => {
    scrollToBottom()
  }, [messages])

  // Add welcome message on mount
  React.useEffect(() => {
    setMessages([
      {
        id: '1',
        role: 'assistant',
        content: 'Hello! I\'m your AI testing assistant. I can help you create tests, debug failures, and optimize your test flows. How can I help you today?',
        timestamp: new Date(),
        type: 'text'
      }
    ])
  }, [])

  const handleSendMessage = async () => {
    if (!inputValue.trim() || isProcessing) return

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: inputValue,
      timestamp: new Date(),
      type: 'text'
    }

    setMessages(prev => [...prev, userMessage])
    setInputValue('')
    setIsProcessing(true)

    // Simulate AI processing
    setTimeout(() => {
      const response = generateMockResponse(inputValue)
      setMessages(prev => [...prev, response])
      setIsProcessing(false)
    }, 1500)
  }

  const generateMockResponse = (input: string): Message => {
    const lowerInput = input.toLowerCase()
    
    // Generate different responses based on input
    if (lowerInput.includes('login') || lowerInput.includes('sign in')) {
      return {
        id: Date.now().toString(),
        role: 'assistant',
        content: 'I\'ll help you create a login test. Here are the steps I suggest:',
        timestamp: new Date(),
        type: 'steps',
        data: {
          steps: [
            {
              type: 'web.navigate',
              url: '${baseUrl}/login',
              description: 'Navigate to login page'
            },
            {
              type: 'web.fill',
              selector: '#username',
              value: '${username}',
              description: 'Enter username'
            },
            {
              type: 'web.fill',
              selector: '#password',
              value: '${password}',
              description: 'Enter password'
            },
            {
              type: 'web.click',
              selector: 'button[type="submit"]',
              description: 'Click login button'
            },
            {
              type: 'web.waitForSelector',
              selector: '.dashboard',
              timeout: 5000,
              description: 'Wait for dashboard'
            }
          ],
          confidence: 0.92
        }
      }
    }

    if (lowerInput.includes('error') || lowerInput.includes('fail')) {
      return {
        id: Date.now().toString(),
        role: 'assistant',
        content: 'I can help debug that error. Based on the failure pattern, here\'s what I found:',
        timestamp: new Date(),
        type: 'suggestion',
        data: {
          summary: 'Element not found error - likely due to timing or selector issues',
          suggestions: [
            {
              title: 'Add explicit wait',
              description: 'Wait for element to be visible before interacting',
              confidence: 0.85
            },
            {
              title: 'Update selector',
              description: 'Use a more stable selector like data-testid',
              confidence: 0.75
            }
          ]
        }
      }
    }

    if (lowerInput.includes('optimize') || lowerInput.includes('faster')) {
      return {
        id: Date.now().toString(),
        role: 'assistant',
        content: 'I\'ve analyzed your test flow and found several optimization opportunities:',
        timestamp: new Date(),
        type: 'suggestion',
        data: {
          improvements: [
            {
              type: 'merge',
              description: 'Combine navigation and wait steps',
              impact: 'Save 2-3 seconds per test'
            },
            {
              type: 'remove',
              description: 'Remove redundant assertions',
              impact: 'Reduce complexity'
            }
          ]
        }
      }
    }

    // Default response
    return {
      id: Date.now().toString(),
      role: 'assistant',
      content: `I understand you want to ${input}. Let me help you with that. What specific aspect would you like me to focus on?`,
      timestamp: new Date(),
      type: 'text'
    }
  }

  const handleAcceptSteps = (message: Message) => {
    if (message.data?.steps && onAcceptSteps) {
      onAcceptSteps(message.data.steps)
      setMessages(prev => prev.map(m => 
        m.id === message.id ? { ...m, status: 'accepted' } : m
      ))
    }
  }

  const handleRejectSteps = (message: Message) => {
    setMessages(prev => prev.map(m => 
      m.id === message.id ? { ...m, status: 'rejected' } : m
    ))
  }

  const handleCopySteps = (steps: any[]) => {
    navigator.clipboard.writeText(JSON.stringify(steps, null, 2))
  }

  const renderMessage = (message: Message) => {
    switch (message.type) {
      case 'steps':
        return (
          <div className="space-y-3">
            <p className="text-sm">{message.content}</p>
            {message.data?.confidence && (
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="text-xs">
                  Confidence: {(message.data.confidence * 100).toFixed(0)}%
                </Badge>
              </div>
            )}
            <Card className="bg-muted/50">
              <CardContent className="pt-4">
                <div className="space-y-2">
                  {message.data?.steps?.map((step: any, index: number) => (
                    <div key={index} className="flex items-start gap-3 p-2 rounded hover:bg-background/50">
                      <div className="flex-shrink-0 w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center text-xs font-medium">
                        {index + 1}
                      </div>
                      <div className="flex-1">
                        <div className="font-medium text-sm">{step.description}</div>
                        <code className="text-xs text-muted-foreground">{step.type}</code>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
            {message.status !== 'accepted' && message.status !== 'rejected' && (
              <div className="flex items-center gap-2">
                <Button
                  size="sm"
                  onClick={() => handleAcceptSteps(message)}
                  className="gap-2"
                >
                  <Check className="h-3 w-3" />
                  Accept & Add to Flow
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleRejectSteps(message)}
                >
                  <X className="h-3 w-3" />
                  Reject
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => handleCopySteps(message.data.steps)}
                >
                  <Copy className="h-3 w-3" />
                  Copy
                </Button>
              </div>
            )}
            {message.status === 'accepted' && (
              <Badge variant="success" className="gap-1">
                <Check className="h-3 w-3" />
                Added to flow
              </Badge>
            )}
          </div>
        )

      case 'suggestion':
        return (
          <div className="space-y-3">
            <p className="text-sm">{message.content}</p>
            {message.data?.summary && (
              <Card className="bg-muted/50">
                <CardContent className="pt-4">
                  <p className="text-sm font-medium mb-3">{message.data.summary}</p>
                  {message.data.suggestions?.map((suggestion: any, index: number) => (
                    <div key={index} className="mb-3 last:mb-0">
                      <div className="flex items-start gap-2">
                        <Lightbulb className="h-4 w-4 text-yellow-500 mt-0.5" />
                        <div>
                          <div className="font-medium text-sm">{suggestion.title}</div>
                          <div className="text-xs text-muted-foreground">{suggestion.description}</div>
                          {suggestion.confidence && (
                            <Badge variant="outline" className="mt-1 text-xs">
                              {(suggestion.confidence * 100).toFixed(0)}% confidence
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                  {message.data.improvements?.map((improvement: any, index: number) => (
                    <div key={index} className="mb-2 last:mb-0 p-2 rounded bg-background/50">
                      <div className="flex items-center gap-2 mb-1">
                        <Badge variant="outline" className="text-xs">{improvement.type}</Badge>
                        <span className="text-xs text-muted-foreground">{improvement.impact}</span>
                      </div>
                      <p className="text-sm">{improvement.description}</p>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}
          </div>
        )

      case 'error':
        return (
          <div className="flex items-start gap-2">
            <AlertCircle className="h-4 w-4 text-red-500 mt-0.5" />
            <p className="text-sm">{message.content}</p>
          </div>
        )

      default:
        return <p className="text-sm">{message.content}</p>
    }
  }

  // Predefined prompts
  const prompts = [
    { icon: Code, text: "Create a login test", category: "create" },
    { icon: Lightbulb, text: "Debug failing test", category: "debug" },
    { icon: RefreshCw, text: "Optimize test performance", category: "optimize" },
    { icon: Sparkles, text: "Suggest better selectors", category: "improve" }
  ]

  return (
    <TooltipProvider>
      <div className={cn("flex flex-col h-full", className)}>
        {/* Header */}
        <div className="p-4 border-b">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="h-9 w-9 rounded-full bg-primary/10 flex items-center justify-center">
                <Bot className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h2 className="font-semibold">AI Assistant</h2>
                <p className="text-xs text-muted-foreground">
                  Powered by {aiConfig.model}
                </p>
              </div>
            </div>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <Settings className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel>AI Settings</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem>
                  <span className="text-sm">Provider: {aiConfig.provider}</span>
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <span className="text-sm">Model: {aiConfig.model}</span>
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <span className="text-sm">Temperature: {aiConfig.temperature}</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as any)} className="flex-1 flex flex-col">
          <TabsList className="mx-4 mt-4">
            <TabsTrigger value="chat">Chat</TabsTrigger>
            <TabsTrigger value="suggestions">Suggestions</TabsTrigger>
            <TabsTrigger value="history">History</TabsTrigger>
          </TabsList>

          <TabsContent value="chat" className="flex-1 flex flex-col p-4 pt-2">
            {/* Quick Actions */}
            <div className="mb-4">
              <p className="text-xs text-muted-foreground mb-2">Quick actions:</p>
              <div className="grid grid-cols-2 gap-2">
                {prompts.map((prompt, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    size="sm"
                    className="justify-start gap-2"
                    onClick={() => setInputValue(prompt.text)}
                  >
                    <prompt.icon className="h-3 w-3" />
                    <span className="text-xs">{prompt.text}</span>
                  </Button>
                ))}
              </div>
            </div>

            {/* Messages */}
            <ScrollArea className="flex-1 pr-4">
              <div className="space-y-4 pb-4">
                <AnimatePresence mode="popLayout">
                  {messages.map((message) => (
                    <motion.div
                      key={message.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className={cn(
                        "flex gap-3",
                        message.role === 'user' && "flex-row-reverse"
                      )}
                    >
                      <div className={cn(
                        "flex-shrink-0 h-8 w-8 rounded-full flex items-center justify-center",
                        message.role === 'assistant' 
                          ? "bg-primary/10" 
                          : "bg-muted"
                      )}>
                        {message.role === 'assistant' ? (
                          <Bot className="h-4 w-4 text-primary" />
                        ) : (
                          <span className="text-xs font-medium">You</span>
                        )}
                      </div>
                      
                      <div className={cn(
                        "flex-1 space-y-1",
                        message.role === 'user' && "flex flex-col items-end"
                      )}>
                        <div className={cn(
                          "rounded-lg p-3 max-w-[85%]",
                          message.role === 'assistant' 
                            ? "bg-muted" 
                            : "bg-primary text-primary-foreground"
                        )}>
                          {renderMessage(message)}
                        </div>
                        <span className="text-xs text-muted-foreground">
                          {message.timestamp.toLocaleTimeString()}
                        </span>
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>
                
                {isProcessing && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="flex gap-3"
                  >
                    <div className="flex-shrink-0 h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                      <Bot className="h-4 w-4 text-primary" />
                    </div>
                    <div className="bg-muted rounded-lg p-3 flex items-center gap-2">
                      <Loader2 className="h-3 w-3 animate-spin" />
                      <span className="text-sm">Thinking...</span>
                    </div>
                  </motion.div>
                )}
                
                <div ref={messagesEndRef} />
              </div>
            </ScrollArea>

            {/* Input */}
            <div className="pt-4 border-t">
              <form 
                onSubmit={(e) => {
                  e.preventDefault()
                  handleSendMessage()
                }}
                className="flex gap-2"
              >
                <Input
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  placeholder="Ask me anything about testing..."
                  disabled={isProcessing}
                  className="flex-1"
                />
                <Button 
                  type="submit" 
                  size="icon"
                  disabled={!inputValue.trim() || isProcessing}
                >
                  <Send className="h-4 w-4" />
                </Button>
              </form>
              <p className="text-xs text-muted-foreground mt-2">
                <Info className="h-3 w-3 inline mr-1" />
                AI suggestions are for assistance only. Always review before accepting.
              </p>
            </div>
          </TabsContent>

          <TabsContent value="suggestions" className="flex-1 p-4">
            <div className="space-y-3">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Recommended Actions</CardTitle>
                  <CardDescription>Based on your recent activity</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 rounded-lg bg-muted/50 hover:bg-muted cursor-pointer">
                    <div className="flex items-start gap-3">
                      <div className="h-8 w-8 rounded-full bg-yellow-500/10 flex items-center justify-center">
                        <Lightbulb className="h-4 w-4 text-yellow-500" />
                      </div>
                      <div>
                        <h4 className="text-sm font-medium">Add retry logic to flaky test</h4>
                        <p className="text-xs text-muted-foreground mt-1">
                          The login test has failed 3 times in the last 24 hours due to timing issues
                        </p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="p-3 rounded-lg bg-muted/50 hover:bg-muted cursor-pointer">
                    <div className="flex items-start gap-3">
                      <div className="h-8 w-8 rounded-full bg-blue-500/10 flex items-center justify-center">
                        <RefreshCw className="h-4 w-4 text-blue-500" />
                      </div>
                      <div>
                        <h4 className="text-sm font-medium">Optimize checkout flow test</h4>
                        <p className="text-xs text-muted-foreground mt-1">
                          This test takes 45s on average. Could be reduced to ~20s
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="history" className="flex-1 p-4">
            <ScrollArea className="h-full">
              <div className="space-y-3">
                {messages
                  .filter(m => m.type === 'steps' && (m.status === 'accepted' || m.status === 'rejected'))
                  .map((message) => (
                    <Card key={message.id}>
                      <CardContent className="pt-4">
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <p className="text-sm font-medium">
                              {message.data?.steps?.length || 0} steps generated
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {message.timestamp.toLocaleString()}
                            </p>
                          </div>
                          <Badge variant={message.status === 'accepted' ? 'success' : 'secondary'}>
                            {message.status}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          "{messages.find(m => m.id < message.id && m.role === 'user')?.content}"
                        </p>
                      </CardContent>
                    </Card>
                  ))}
                
                {messages.filter(m => m.type === 'steps' && (m.status === 'accepted' || m.status === 'rejected')).length === 0 && (
                  <div className="text-center py-8 text-muted-foreground">
                    <Info className="h-8 w-8 mx-auto mb-3 opacity-50" />
                    <p className="text-sm">No history yet</p>
                    <p className="text-xs mt-1">Accepted and rejected suggestions will appear here</p>
                  </div>
                )}
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </div>
    </TooltipProvider>
  )
} 