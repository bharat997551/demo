import React from 'react'
import { motion } from 'framer-motion'
import {
  Play,
  Square,
  RotateCcw,
  Settings,
  Search,
  Bell,
  User,
  Maximize2,
  Minimize2,
  X,
  Minus
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { cn } from '@/lib/utils'

interface TopBarProps {
  className?: string
  isRunning?: boolean
  onRunToggle?: () => void
  onStop?: () => void
  onRestart?: () => void
}

export function TopBar({
  className,
  isRunning = false,
  onRunToggle,
  onStop,
  onRestart
}: TopBarProps) {
  const [isMaximized, setIsMaximized] = React.useState(false)

  const handleMinimize = async () => {
    if (window.electronAPI) {
      await window.electronAPI.minimizeWindow()
    }
  }

  const handleMaximize = async () => {
    if (window.electronAPI) {
      await window.electronAPI.maximizeWindow()
      setIsMaximized(!isMaximized)
    }
  }

  const handleClose = async () => {
    if (window.electronAPI) {
      await window.electronAPI.closeWindow()
    }
  }

  return (
    <div className={cn(
      "flex h-14 items-center justify-between border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60",
      className
    )}>
      {/* Left Section - Run Controls */}
      <div className="flex items-center gap-2 px-4">
        <motion.div
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <Button
            variant={isRunning ? "destructive" : "default"}
            size="sm"
            className={cn(
              "gap-2 min-w-[100px]",
              isRunning && "animate-pulse-recording"
            )}
            onClick={onRunToggle}
          >
            {isRunning ? (
              <>
                <Square className="h-4 w-4" />
                Stop
              </>
            ) : (
              <>
                <Play className="h-4 w-4" />
                Run
              </>
            )}
          </Button>
        </motion.div>

        <Button
          variant="outline"
          size="sm"
          className="gap-2"
          onClick={onStop}
          disabled={!isRunning}
        >
          <Square className="h-4 w-4" />
          Stop
        </Button>

        <Button
          variant="outline"
          size="sm"
          className="gap-2"
          onClick={onRestart}
        >
          <RotateCcw className="h-4 w-4" />
          Restart
        </Button>

        <div className="h-6 w-px bg-border mx-2" />

        {/* Status Indicator */}
        <div className="flex items-center gap-2 text-sm">
          <div className={cn(
            "h-2 w-2 rounded-full",
            isRunning ? "bg-green-500 animate-pulse" : "bg-gray-400"
          )} />
          <span className="text-muted-foreground">
            {isRunning ? "Running" : "Ready"}
          </span>
        </div>
      </div>

      {/* Center Section - Search */}
      <div className="flex-1 max-w-md px-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search tests, flows, or runs..."
            className="pl-10 pr-4 bg-background/50"
          />
        </div>
      </div>

      {/* Right Section - Actions & Window Controls */}
      <div className="flex items-center gap-2 px-4">
        {/* Notifications */}
        <Button variant="ghost" size="icon" className="h-8 w-8">
          <Bell className="h-4 w-4" />
        </Button>

        {/* Settings */}
        <Button variant="ghost" size="icon" className="h-8 w-8">
          <Settings className="h-4 w-4" />
        </Button>

        {/* Profile */}
        <Button variant="ghost" size="icon" className="h-8 w-8">
          <User className="h-4 w-4" />
        </Button>

        <div className="h-6 w-px bg-border mx-2" />

        {/* Window Controls */}
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 hover:bg-yellow-500/20"
            onClick={handleMinimize}
          >
            <Minus className="h-3 w-3" />
          </Button>
          
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 hover:bg-green-500/20"
            onClick={handleMaximize}
          >
            {isMaximized ? (
              <Minimize2 className="h-3 w-3" />
            ) : (
              <Maximize2 className="h-3 w-3" />
            )}
          </Button>
          
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 hover:bg-destructive/20"
            onClick={handleClose}
          >
            <X className="h-3 w-3" />
          </Button>
        </div>
      </div>
    </div>
  )
} 