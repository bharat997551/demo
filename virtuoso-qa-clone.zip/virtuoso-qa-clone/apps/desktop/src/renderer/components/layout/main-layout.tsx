import React from 'react'
import { Outlet } from 'react-router-dom'
import { motion } from 'framer-motion'
import { Sidebar } from './sidebar'
import { TopBar } from './top-bar'
import { WebRecorder } from '../recorder/web-recorder'
import { DesktopRecorder } from '../recorder/desktop-recorder'
import { DebuggerPanel } from '../debugger/debugger-panel'
import { RecordDebugMode } from '../debugger/record-debug-mode'
import { DevToolsPanel } from '../devtools/devtools-panel'
import { HealedSelectorsPanel } from '../healing/healed-selectors-panel'
import { cn } from '@/lib/utils'
import { Bug, Terminal, RefreshCw } from 'lucide-react'

interface MainLayoutProps {
  className?: string
}

export function MainLayout({ className }: MainLayoutProps) {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = React.useState(false)
  const [isRunning, setIsRunning] = React.useState(false)
  const [webRecorderVisible, setWebRecorderVisible] = React.useState(false)
  const [desktopRecorderVisible, setDesktopRecorderVisible] = React.useState(false)
  const [debuggerVisible, setDebuggerVisible] = React.useState(false)
  const [devToolsVisible, setDevToolsVisible] = React.useState(false)
  const [healedSelectorsPanelVisible, setHealedSelectorsPanelVisible] = React.useState(false)
  const [debugModeActive, setDebugModeActive] = React.useState(false)
  
  // Mock data for debugging features
  const [debuggerState, setDebuggerState] = React.useState({
    isDebugging: false,
    isPaused: false,
    stack: [],
    currentStepId: null
  })
  
  const [logs, setLogs] = React.useState<any[]>([])
  const [breadcrumbs, setBreadcrumbs] = React.useState<any[]>([])

  const handleRunToggle = () => {
    setIsRunning(!isRunning)
    // TODO: Implement actual run logic
    
    // Simulate log generation when running
    if (!isRunning) {
      const mockLog = {
        id: `log-${Date.now()}`,
        timestamp: Date.now(),
        level: 'info',
        category: 'test',
        message: 'Test execution started',
        data: { testId: 'test-123', config: { timeout: 30000 } }
      }
      setLogs(prev => [...prev, mockLog])
      setBreadcrumbs([{ id: 'bc-1', label: 'Test Started', timestamp: Date.now() }])
    }
  }

  const handleStop = () => {
    setIsRunning(false)
    setDebuggerState(prev => ({ ...prev, isDebugging: false, isPaused: false }))
  }

  const handleRestart = () => {
    setIsRunning(false)
    setTimeout(() => setIsRunning(true), 500)
  }

  // Debugging controls
  const handleDebuggerStepOver = () => {
    console.log('Step over')
  }

  const handleDebuggerContinue = () => {
    setDebuggerState(prev => ({ ...prev, isPaused: false }))
  }

  const handleToggleBreakpoint = (stepId: string) => {
    console.log('Toggle breakpoint:', stepId)
  }

  React.useEffect(() => {
    // Global keyboard shortcuts
    const handleKeyDown = (event: KeyboardEvent) => {
      // Ctrl/Cmd + R for Web Recorder
      if ((event.ctrlKey || event.metaKey) && event.shiftKey && event.key === 'R') {
        event.preventDefault()
        setWebRecorderVisible(!webRecorderVisible)
      }
      
      // Ctrl/Cmd + D for Desktop Recorder
      if ((event.ctrlKey || event.metaKey) && event.shiftKey && event.key === 'D') {
        event.preventDefault()
        setDesktopRecorderVisible(!desktopRecorderVisible)
      }

      // F5 for Run/Stop toggle
      if (event.key === 'F5') {
        event.preventDefault()
        if (event.shiftKey) {
          // Shift+F5 for Debug mode
          setDebugModeActive(!debugModeActive)
          setDebuggerVisible(true)
        } else {
          handleRunToggle()
        }
      }

      // F12 for DevTools
      if (event.key === 'F12') {
        event.preventDefault()
        setDevToolsVisible(!devToolsVisible)
      }

      // F10 for Step Over (when debugging)
      if (event.key === 'F10' && debuggerState.isPaused) {
        event.preventDefault()
        handleDebuggerStepOver()
      }

      // Escape to close panels
      if (event.key === 'Escape') {
        setWebRecorderVisible(false)
        setDesktopRecorderVisible(false)
        setDebugModeActive(false)
      }
    }

    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [webRecorderVisible, desktopRecorderVisible, debugModeActive, debuggerState.isPaused])

  return (
    <div className={cn("flex h-screen bg-background", className)}>
      {/* Sidebar */}
      <Sidebar 
        isCollapsed={isSidebarCollapsed}
        className="flex-shrink-0"
      />

      {/* Main Content Area */}
      <div className="flex flex-1 flex-col min-w-0">
        {/* Top Bar */}
        <TopBar 
          isRunning={isRunning}
          onRunToggle={handleRunToggle}
          onStop={handleStop}
          onRestart={handleRestart}
        />

        {/* Central Pane with Debugger */}
        <div className="flex flex-1 overflow-hidden">
          <main className="flex-1 overflow-hidden">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3 }}
              className="h-full"
            >
              <Outlet />
            </motion.div>
          </main>

          {/* Debugger Panel */}
          {debuggerVisible && (
            <motion.div
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: 400, opacity: 1 }}
              exit={{ width: 0, opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="h-full overflow-hidden"
            >
              <DebuggerPanel
                isDebugging={debuggerState.isDebugging}
                isPaused={debuggerState.isPaused}
                currentStepId={debuggerState.currentStepId}
                stack={debuggerState.stack}
                onStepOver={handleDebuggerStepOver}
                onStepInto={() => console.log('Step into')}
                onStepOut={() => console.log('Step out')}
                onContinue={handleDebuggerContinue}
                onPause={() => setDebuggerState(prev => ({ ...prev, isPaused: true }))}
                onStop={() => setDebuggerState(prev => ({ ...prev, isDebugging: false }))}
                onToggleBreakpoint={handleToggleBreakpoint}
              />
            </motion.div>
          )}
        </div>

        {/* DevTools Panel */}
        {devToolsVisible && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 300, opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="border-t"
          >
            <DevToolsPanel
              logs={logs}
              breadcrumbs={breadcrumbs}
              onClearLogs={() => setLogs([])}
              onExportLogs={() => {
                const dataStr = JSON.stringify(logs, null, 2)
                const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr)
                const exportFileDefaultName = `devtools-logs-${Date.now()}.json`
                const linkElement = document.createElement('a')
                linkElement.setAttribute('href', dataUri)
                linkElement.setAttribute('download', exportFileDefaultName)
                linkElement.click()
              }}
              onOpenArtifact={(artifact) => console.log('Open artifact:', artifact)}
            />
          </motion.div>
        )}

        {/* Healed Selectors Panel */}
        {healedSelectorsPanelVisible && (
          <motion.div
            initial={{ width: 0, opacity: 0 }}
            animate={{ width: 400, opacity: 1 }}
            exit={{ width: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="border-l h-full"
          >
            <HealedSelectorsPanel />
          </motion.div>
        )}
      </div>

      {/* Floating Recorders */}
      <WebRecorder
        isVisible={webRecorderVisible}
        onClose={() => setWebRecorderVisible(false)}
        onMinimize={() => setWebRecorderVisible(false)}
      />

      <DesktopRecorder
        isVisible={desktopRecorderVisible}
        onClose={() => setDesktopRecorderVisible(false)}
      />

      {/* Record & Debug Mode */}
      <RecordDebugMode
        isActive={debugModeActive}
        isRecording={isRunning}
        isPaused={debuggerState.isPaused}
        onToggle={() => setDebugModeActive(false)}
        onContinue={handleDebuggerContinue}
        onStepOver={handleDebuggerStepOver}
      />

      {/* Global Tool Toggles */}
      <div className="fixed bottom-4 right-4 flex flex-col gap-2 z-30">
        {/* Debug Mode Toggle */}
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className={cn(
            "flex items-center justify-center h-12 w-12 rounded-full shadow-lg transition-colors",
            debugModeActive 
              ? "bg-red-500 text-white" 
              : "bg-card hover:bg-accent text-muted-foreground hover:text-foreground"
          )}
          onClick={() => setDebugModeActive(!debugModeActive)}
          title="Record & Debug Mode (Shift+F5)"
        >
          <Bug className="h-5 w-5" />
        </motion.button>

        {/* Debugger Toggle */}
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className={cn(
            "flex items-center justify-center h-12 w-12 rounded-full shadow-lg transition-colors",
            debuggerVisible 
              ? "bg-primary text-primary-foreground" 
              : "bg-card hover:bg-accent text-muted-foreground hover:text-foreground"
          )}
          onClick={() => setDebuggerVisible(!debuggerVisible)}
          title="Debugger Panel"
        >
          <span className="text-xs font-bold">DBG</span>
        </motion.button>

        {/* DevTools Toggle */}
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className={cn(
            "flex items-center justify-center h-12 w-12 rounded-full shadow-lg transition-colors",
            devToolsVisible 
              ? "bg-primary text-primary-foreground" 
              : "bg-card hover:bg-accent text-muted-foreground hover:text-foreground"
          )}
          onClick={() => setDevToolsVisible(!devToolsVisible)}
          title="DevTools (F12)"
        >
          <Terminal className="h-5 w-5" />
        </motion.button>

        {/* Healed Selectors Toggle */}
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className={cn(
            "flex items-center justify-center h-12 w-12 rounded-full shadow-lg transition-colors",
            healedSelectorsPanelVisible 
              ? "bg-primary text-primary-foreground" 
              : "bg-card hover:bg-accent text-muted-foreground hover:text-foreground"
          )}
          onClick={() => setHealedSelectorsPanelVisible(!healedSelectorsPanelVisible)}
          title="Healed Selectors"
        >
          <RefreshCw className="h-5 w-5" />
        </motion.button>

        <div className="h-4 w-px bg-border mx-auto" />

        {/* Recorder Toggles */}
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className={cn(
            "flex items-center justify-center h-12 w-12 rounded-full shadow-lg transition-colors",
            webRecorderVisible 
              ? "bg-primary text-primary-foreground" 
              : "bg-card hover:bg-accent text-muted-foreground hover:text-foreground"
          )}
          onClick={() => setWebRecorderVisible(!webRecorderVisible)}
          title="Web Recorder (Ctrl+Shift+R)"
        >
          <span className="text-xs font-bold">W</span>
        </motion.button>

        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className={cn(
            "flex items-center justify-center h-12 w-12 rounded-full shadow-lg transition-colors",
            desktopRecorderVisible 
              ? "bg-primary text-primary-foreground" 
              : "bg-card hover:bg-accent text-muted-foreground hover:text-foreground"
          )}
          onClick={() => setDesktopRecorderVisible(!desktopRecorderVisible)}
          title="Desktop Recorder (Ctrl+Shift+D)"
        >
          <span className="text-xs font-bold">D</span>
        </motion.button>
      </div>

      {/* Keyboard Shortcuts Help */}
      <div className="fixed bottom-4 left-4 text-xs text-muted-foreground space-y-1 font-mono z-20">
        <div>F5 - Run/Stop</div>
        <div>Shift+F5 - Debug Mode</div>
        <div>F12 - DevTools</div>
        <div>F10 - Step Over (Debug)</div>
        <div>Ctrl+Shift+R - Web Recorder</div>
        <div>Ctrl+Shift+D - Desktop Recorder</div>
        <div>Esc - Close Panels</div>
      </div>
    </div>
  )
} 