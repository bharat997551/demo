import React from 'react'
import { Link, useLocation } from 'react-router-dom'
import { motion } from 'framer-motion'
import {
  FolderOpen,
  GitBranch,
  Circle,
  Play,
  BarChart3,
  Settings,
  Plus,
  ChevronDown,
  ChevronRight,
  Rocket,
  Bot
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'

interface SidebarItem {
  id: string
  title: string
  icon: React.ElementType
  path: string
  badge?: number
  children?: SidebarItem[]
}

const sidebarItems: SidebarItem[] = [
  {
    id: 'demo',
    title: 'Demo',
    icon: Rocket,
    path: '/demo'
  },
  {
    id: 'ai-demo',
    title: 'AI Assistant',
    icon: Bot,
    path: '/ai-demo'
  },
  {
    id: 'projects',
    title: 'Projects',
    icon: FolderOpen,
    path: '/projects',
    children: [
      { id: 'project-1', title: 'E-commerce Tests', icon: FolderOpen, path: '/projects/1' },
      { id: 'project-2', title: 'API Validation', icon: FolderOpen, path: '/projects/2' },
    ]
  },
  {
    id: 'flows',
    title: 'Test Flows',
    icon: GitBranch,
    path: '/flows',
    badge: 12
  },
  {
    id: 'recorders',
    title: 'Recorders',
    icon: Circle,
    path: '/recorders',
    children: [
      { id: 'web-recorder', title: 'Web Recorder', icon: Circle, path: '/recorders/web' },
      { id: 'desktop-recorder', title: 'Desktop Recorder', icon: Circle, path: '/recorders/desktop' },
    ]
  },
  {
    id: 'runs',
    title: 'Test Runs',
    icon: Play,
    path: '/runs',
    badge: 3
  },
  {
    id: 'reports',
    title: 'Reports',
    icon: BarChart3,
    path: '/reports'
  },
  {
    id: 'settings',
    title: 'Settings',
    icon: Settings,
    path: '/settings'
  }
]

interface SidebarProps {
  className?: string
  isCollapsed?: boolean
}

export function Sidebar({ className, isCollapsed = false }: SidebarProps) {
  const location = useLocation()
  const [expandedItems, setExpandedItems] = React.useState<Set<string>>(new Set(['projects', 'recorders']))

  const toggleExpanded = (itemId: string) => {
    setExpandedItems(prev => {
      const newSet = new Set(prev)
      if (newSet.has(itemId)) {
        newSet.delete(itemId)
      } else {
        newSet.add(itemId)
      }
      return newSet
    })
  }

  const renderSidebarItem = (item: SidebarItem, level = 0) => {
    const isActive = location.pathname === item.path
    const isExpanded = expandedItems.has(item.id)
    const hasChildren = item.children && item.children.length > 0

    return (
      <div key={item.id}>
        <div className="relative">
          <Link
            to={item.path}
            className={cn(
              "flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-all hover:bg-accent",
              level > 0 && "ml-4 pl-6",
              isActive && "bg-primary text-primary-foreground hover:bg-primary/90",
              isCollapsed && "justify-center px-2",
              item.id === 'demo' && !isActive && "text-primary hover:text-primary"
            )}
          >
            <item.icon className={cn("h-4 w-4", isCollapsed ? "h-5 w-5" : "")} />
            {!isCollapsed && (
              <>
                <span className="flex-1 font-medium">{item.title}</span>
                {item.badge && (
                  <span className="flex h-5 w-5 items-center justify-center rounded-full bg-primary text-xs text-primary-foreground">
                    {item.badge}
                  </span>
                )}
                {hasChildren && (
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-4 w-4 p-0 hover:bg-transparent"
                    onClick={(e) => {
                      e.preventDefault()
                      toggleExpanded(item.id)
                    }}
                  >
                    {isExpanded ? (
                      <ChevronDown className="h-3 w-3" />
                    ) : (
                      <ChevronRight className="h-3 w-3" />
                    )}
                  </Button>
                )}
              </>
            )}
          </Link>
        </div>
        
        {hasChildren && isExpanded && !isCollapsed && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <div className="mt-1 space-y-1">
              {item.children?.map(child => renderSidebarItem(child, level + 1))}
            </div>
          </motion.div>
        )}
      </div>
    )
  }

  return (
    <motion.div
      initial={false}
      animate={{ width: isCollapsed ? 64 : 280 }}
      transition={{ duration: 0.3, ease: "easeInOut" }}
      className={cn(
        "flex h-full flex-col border-r bg-card",
        className
      )}
    >
      {/* Header */}
      <div className="p-4">
        <div className={cn(
          "flex items-center gap-3",
          isCollapsed && "justify-center"
        )}>
          <div className="flex h-8 w-8 items-center justify-center rounded bg-primary">
            <span className="text-sm font-bold text-primary-foreground">HQ</span>
          </div>
          {!isCollapsed && (
            <div>
              <h1 className="text-lg font-semibold">Hybrid QA</h1>
              <p className="text-xs text-muted-foreground">v1.0.0</p>
            </div>
          )}
        </div>
      </div>

      {/* Quick Actions */}
      {!isCollapsed && (
        <div className="px-4 pb-4">
          <Button className="w-full justify-start gap-2" size="sm">
            <Plus className="h-4 w-4" />
            New Test Flow
          </Button>
        </div>
      )}

      {/* Navigation */}
      <nav className="flex-1 space-y-1 px-3 pb-4">
        {sidebarItems.map(item => renderSidebarItem(item))}
      </nav>

      {/* Collapse Toggle */}
      {!isCollapsed && (
        <div className="p-3">
          <div className="rounded-lg bg-muted/50 p-3">
            <div className="flex items-center gap-2 text-sm">
              <div className="h-2 w-2 rounded-full bg-green-500" />
              <span className="text-muted-foreground">All engines running</span>
            </div>
          </div>
        </div>
      )}
    </motion.div>
  )
} 