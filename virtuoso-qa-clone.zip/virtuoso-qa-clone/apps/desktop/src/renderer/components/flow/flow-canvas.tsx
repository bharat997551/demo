import React from 'react'
import ReactFlow, {
  Node,
  Edge,
  addEdge,
  Connection,
  useNodesState,
  useEdgesState,
  Controls,
  MiniMap,
  Background,
  BackgroundVariant,
  NodeTypes,
  EdgeTypes,
  MarkerType
} from 'reactflow'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Play,
  Square,
  GitBranch,
  RotateCcw,
  Settings,
  Plus,
  Save,
  Download,
  Upload,
  Zap,
  AlertCircle
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { cn } from '@/lib/utils'

// Custom Node Components
const StepNode = ({ data, selected }: { data: any; selected: boolean }) => {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      className={cn(
        "px-4 py-2 rounded-lg border-2 bg-background min-w-[150px]",
        selected ? "border-primary shadow-lg" : "border-border",
        data.status === 'running' && "border-blue-500 shadow-blue-500/20",
        data.status === 'success' && "border-green-500 shadow-green-500/20",
        data.status === 'error' && "border-red-500 shadow-red-500/20"
      )}
    >
      <div className="flex items-center gap-2">
        <div className={cn(
          "h-3 w-3 rounded-full",
          data.status === 'running' && "bg-blue-500 animate-pulse",
          data.status === 'success' && "bg-green-500",
          data.status === 'error' && "bg-red-500",
          !data.status && "bg-muted-foreground"
        )} />
        <span className="font-medium text-sm">{data.label}</span>
      </div>
      {data.description && (
        <p className="text-xs text-muted-foreground mt-1">{data.description}</p>
      )}
      {data.duration && (
        <p className="text-xs text-muted-foreground mt-1">{data.duration}ms</p>
      )}
    </motion.div>
  )
}

const ConditionNode = ({ data, selected }: { data: any; selected: boolean }) => {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      className={cn(
        "px-4 py-2 bg-background border-2 min-w-[120px]",
        "transform rotate-45 rounded-lg",
        selected ? "border-primary shadow-lg" : "border-border"
      )}
    >
      <div className="transform -rotate-45 text-center">
        <GitBranch className="h-4 w-4 mx-auto mb-1" />
        <span className="text-xs font-medium">{data.label}</span>
      </div>
    </motion.div>
  )
}

const LoopNode = ({ data, selected }: { data: any; selected: boolean }) => {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      className={cn(
        "px-4 py-2 rounded-full border-2 bg-background min-w-[100px]",
        selected ? "border-primary shadow-lg" : "border-border"
      )}
    >
      <div className="flex items-center justify-center gap-2">
        <RotateCcw className="h-4 w-4" />
        <span className="text-sm font-medium">{data.label}</span>
      </div>
      {data.iterations && (
        <p className="text-xs text-muted-foreground text-center mt-1">
          {data.iterations} iterations
        </p>
      )}
    </motion.div>
  )
}

const nodeTypes: NodeTypes = {
  step: StepNode,
  condition: ConditionNode,
  loop: LoopNode
}

interface FlowCanvasProps {
  initialNodes?: Node[]
  initialEdges?: Edge[]
  onNodesChange?: (nodes: Node[]) => void
  onEdgesChange?: (edges: Edge[]) => void
  onSave?: (flow: { nodes: Node[]; edges: Edge[] }) => void
  onRun?: (startNode?: string) => void
  isRunning?: boolean
}

export function FlowCanvas({
  initialNodes = [],
  initialEdges = [],
  onNodesChange,
  onEdgesChange,
  onSave,
  onRun,
  isRunning = false
}: FlowCanvasProps) {
  const [nodes, setNodes, onNodesChangeHandler] = useNodesState(initialNodes)
  const [edges, setEdges, onEdgesChangeHandler] = useEdgesState(initialEdges)
  const [selectedNodes, setSelectedNodes] = React.useState<string[]>([])
  const [showNodePanel, setShowNodePanel] = React.useState(false)
  const [draggedNodeType, setDraggedNodeType] = React.useState<string | null>(null)

  React.useEffect(() => {
    onNodesChange?.(nodes)
  }, [nodes, onNodesChange])

  React.useEffect(() => {
    onEdgesChange?.(edges)
  }, [edges, onEdgesChange])

  const onConnect = React.useCallback(
    (params: Connection) => {
      const newEdge = {
        ...params,
        type: 'smoothstep',
        markerEnd: {
          type: MarkerType.ArrowClosed,
          color: 'hsl(var(--primary))'
        },
        style: {
          stroke: 'hsl(var(--primary))',
          strokeWidth: 2
        }
      }
      setEdges((eds) => addEdge(newEdge, eds))
    },
    [setEdges]
  )

  const onNodeDragStart = React.useCallback((event: React.DragEvent, nodeType: string) => {
    setDraggedNodeType(nodeType)
    event.dataTransfer.effectAllowed = 'move'
  }, [])

  const onDragOver = React.useCallback((event: React.DragEvent) => {
    event.preventDefault()
    event.dataTransfer.dropEffect = 'move'
  }, [])

  const onDrop = React.useCallback(
    (event: React.DragEvent) => {
      event.preventDefault()

      if (!draggedNodeType) return

      const reactFlowBounds = event.currentTarget.getBoundingClientRect()
      const position = {
        x: event.clientX - reactFlowBounds.left,
        y: event.clientY - reactFlowBounds.top,
      }

      const newNode: Node = {
        id: `${draggedNodeType}-${Date.now()}`,
        type: draggedNodeType,
        position,
        data: {
          label: `New ${draggedNodeType}`,
          description: `${draggedNodeType} description`,
          ...(draggedNodeType === 'loop' && { iterations: 5 }),
          ...(draggedNodeType === 'condition' && { condition: 'true' })
        }
      }

      setNodes((nds) => nds.concat(newNode))
      setDraggedNodeType(null)
    },
    [draggedNodeType, setNodes]
  )

  const handleSave = () => {
    onSave?.({ nodes, edges })
  }

  const handleRun = () => {
    const startNodes = nodes.filter(node => 
      !edges.some(edge => edge.target === node.id)
    )
    onRun?.(startNodes[0]?.id)
  }

  const nodeTemplates = [
    { type: 'step', label: 'Test Step', icon: Play, color: 'bg-blue-500' },
    { type: 'condition', label: 'Condition', icon: GitBranch, color: 'bg-yellow-500' },
    { type: 'loop', label: 'Loop', icon: RotateCcw, color: 'bg-green-500' }
  ]

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b bg-muted/30">
        <div className="flex items-center gap-4">
          <h2 className="text-lg font-semibold">Flow Canvas</h2>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <span>{nodes.length} nodes</span>
            <span>•</span>
            <span>{edges.length} connections</span>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            className="gap-2"
            onClick={() => setShowNodePanel(!showNodePanel)}
          >
            <Plus className="h-4 w-4" />
            Add Nodes
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="gap-2"
            onClick={handleSave}
          >
            <Save className="h-4 w-4" />
            Save
          </Button>
          <Button
            size="sm"
            className="gap-2"
            onClick={handleRun}
            disabled={isRunning || nodes.length === 0}
          >
            {isRunning ? <Square className="h-4 w-4" /> : <Play className="h-4 w-4" />}
            {isRunning ? 'Stop' : 'Run'}
          </Button>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Node Palette */}
        <AnimatePresence>
          {showNodePanel && (
            <motion.div
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: 250, opacity: 1 }}
              exit={{ width: 0, opacity: 0 }}
              className="border-r bg-muted/30 overflow-hidden"
            >
              <div className="p-4">
                <h3 className="font-medium mb-4">Node Templates</h3>
                <div className="space-y-3">
                  {nodeTemplates.map((template) => (
                    <div
                      key={template.type}
                      draggable
                      onDragStart={(event) => onNodeDragStart(event, template.type)}
                      className="cursor-grab active:cursor-grabbing"
                    >
                      <Card className="hover:shadow-md transition-all">
                        <CardContent className="p-3">
                          <div className="flex items-center gap-3">
                            <div className={cn(
                              "flex items-center justify-center h-8 w-8 rounded",
                              template.color
                            )}>
                              <template.icon className="h-4 w-4 text-white" />
                            </div>
                            <div>
                              <p className="font-medium text-sm">{template.label}</p>
                              <p className="text-xs text-muted-foreground">
                                Drag to canvas
                              </p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  ))}
                </div>

                {/* Quick Actions */}
                <div className="mt-6 space-y-2">
                  <Button variant="outline" size="sm" className="w-full gap-2">
                    <Upload className="h-4 w-4" />
                    Import Flow
                  </Button>
                  <Button variant="outline" size="sm" className="w-full gap-2">
                    <Download className="h-4 w-4" />
                    Export Flow
                  </Button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Flow Canvas */}
        <div className="flex-1 relative">
          <ReactFlow
            nodes={nodes}
            edges={edges}
            onNodesChange={onNodesChangeHandler}
            onEdgesChange={onEdgesChangeHandler}
            onConnect={onConnect}
            onDrop={onDrop}
            onDragOver={onDragOver}
            nodeTypes={nodeTypes}
            fitView
            className="bg-background"
            attributionPosition="top-right"
          >
            <Controls 
              className="bg-background border border-border"
              showZoom={true}
              showFitView={true}
              showInteractive={true}
            />
            <MiniMap
              className="bg-background border border-border"
              nodeColor={(node) => {
                switch (node.type) {
                  case 'condition': return '#eab308'
                  case 'loop': return '#22c55e'
                  default: return '#3b82f6'
                }
              }}
            />
            <Background 
              variant={BackgroundVariant.Dots}
              gap={20}
              size={1}
              className="bg-background"
            />
          </ReactFlow>

          {/* Empty State */}
          {nodes.length === 0 && (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="text-center text-muted-foreground">
                <Zap className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <h3 className="text-lg font-medium mb-2">Create Your Flow</h3>
                <p className="text-sm">
                  Drag nodes from the palette to start building your test flow
                </p>
                <Button 
                  className="mt-4 pointer-events-auto"
                  onClick={() => setShowNodePanel(true)}
                >
                  Show Node Palette
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Status Bar */}
      <div className="flex items-center justify-between p-3 border-t bg-muted/50 text-sm">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <div className="h-2 w-2 bg-blue-500 rounded-full" />
            <span>Test Steps: {nodes.filter(n => n.type === 'step').length}</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="h-2 w-2 bg-yellow-500 rounded-full" />
            <span>Conditions: {nodes.filter(n => n.type === 'condition').length}</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="h-2 w-2 bg-green-500 rounded-full" />
            <span>Loops: {nodes.filter(n => n.type === 'loop').length}</span>
          </div>
        </div>
        
        <div className="text-muted-foreground">
          {selectedNodes.length > 0 && `${selectedNodes.length} selected`}
        </div>
      </div>
    </div>
  )
} 