import React from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Editor } from '@monaco-editor/react'
import * as yaml from 'js-yaml'
import {
  Eye,
  Code,
  Save,
  Play,
  AlertCircle,
  CheckCircle,
  Plus,
  Trash2,
  Edit3,
  GripVertical
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { cn } from '@/lib/utils'

interface TestStep {
  id: string
  kind: string
  description?: string
  config: Record<string, any>
  assertions?: any[]
  extractions?: any[]
  timeout?: number
}

interface TestEditorProps {
  initialSteps?: TestStep[]
  onStepsChange?: (steps: TestStep[]) => void
  onSave?: (content: string) => void
  onRun?: (steps: TestStep[]) => void
}

export function TestEditor({ 
  initialSteps = [], 
  onStepsChange, 
  onSave, 
  onRun 
}: TestEditorProps) {
  const [steps, setSteps] = React.useState<TestStep[]>(initialSteps)
  const [activeMode, setActiveMode] = React.useState<'visual' | 'yaml'>('visual')
  const [yamlContent, setYamlContent] = React.useState('')
  const [errors, setErrors] = React.useState<string[]>([])
  const [editingStep, setEditingStep] = React.useState<string | null>(null)

  // Sync steps to YAML when in YAML mode
  React.useEffect(() => {
    if (activeMode === 'yaml') {
      try {
        const yamlData = {
          version: '1.0',
          name: 'Test Flow',
          steps: steps.map(step => ({
            kind: step.kind,
            description: step.description,
            config: step.config,
            ...(step.assertions && { assertions: step.assertions }),
            ...(step.extractions && { extractions: step.extractions }),
            ...(step.timeout && { timeout: step.timeout })
          }))
        }
        setYamlContent(yaml.dump(yamlData, { indent: 2 }))
      } catch (error) {
        setErrors([`Failed to convert to YAML: ${error}`])
      }
    }
  }, [steps, activeMode])

  // Parse YAML back to steps when switching from YAML mode
  const handleYamlToSteps = () => {
    try {
      const parsed = yaml.load(yamlContent) as any
      if (parsed && parsed.steps) {
        const newSteps = parsed.steps.map((step: any, index: number) => ({
          id: `step-${Date.now()}-${index}`,
          kind: step.kind,
          description: step.description,
          config: step.config || {},
          assertions: step.assertions,
          extractions: step.extractions,
          timeout: step.timeout
        }))
        setSteps(newSteps)
        onStepsChange?.(newSteps)
        setErrors([])
      }
    } catch (error) {
      setErrors([`YAML parsing error: ${error}`])
    }
  }

  const handleAddStep = (kind: string) => {
    const newStep: TestStep = {
      id: `step-${Date.now()}`,
      kind,
      description: `New ${kind} step`,
      config: getDefaultConfigForKind(kind)
    }
    const newSteps = [...steps, newStep]
    setSteps(newSteps)
    onStepsChange?.(newSteps)
  }

  const handleDeleteStep = (stepId: string) => {
    const newSteps = steps.filter(step => step.id !== stepId)
    setSteps(newSteps)
    onStepsChange?.(newSteps)
  }

  const handleUpdateStep = (stepId: string, updates: Partial<TestStep>) => {
    const newSteps = steps.map(step => 
      step.id === stepId 
        ? { ...step, ...updates }
        : step
    )
    setSteps(newSteps)
    onStepsChange?.(newSteps)
  }

  const handleSave = () => {
    const content = activeMode === 'yaml' 
      ? yamlContent 
      : yaml.dump({ version: '1.0', name: 'Test Flow', steps })
    onSave?.(content)
  }

  const handleRun = () => {
    if (activeMode === 'yaml') {
      handleYamlToSteps()
    }
    onRun?.(steps)
  }

  const getDefaultConfigForKind = (kind: string): Record<string, any> => {
    switch (kind) {
      case 'web.navigate':
        return { url: 'https://example.com' }
      case 'web.click':
        return { selector: '' }
      case 'web.type':
        return { selector: '', text: '' }
      case 'api.request':
        return { method: 'GET', url: '' }
      case 'wait':
        return { duration: 1000 }
      default:
        return {}
    }
  }

  const getStepIcon = (kind: string) => {
    // Return appropriate icon based on step kind
    return <div className="h-4 w-4 rounded bg-primary/20 flex items-center justify-center text-xs">
      {kind.split('.')[0]?.[0]?.toUpperCase() || 'S'}
    </div>
  }

  const stepTypes = [
    { kind: 'web.navigate', label: 'Navigate', category: 'Web' },
    { kind: 'web.click', label: 'Click', category: 'Web' },
    { kind: 'web.type', label: 'Type', category: 'Web' },
    { kind: 'web.wait', label: 'Wait', category: 'Web' },
    { kind: 'api.request', label: 'API Request', category: 'API' },
    { kind: 'api.graphql', label: 'GraphQL', category: 'API' },
    { kind: 'desktop.click', label: 'Desktop Click', category: 'Desktop' },
    { kind: 'assertion', label: 'Assertion', category: 'Validation' }
  ]

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b">
        <div className="flex items-center gap-4">
          <h2 className="text-lg font-semibold">Test Editor</h2>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <span>{steps.length} steps</span>
            {errors.length > 0 && (
              <>
                <span>•</span>
                <div className="flex items-center gap-1 text-destructive">
                  <AlertCircle className="h-4 w-4" />
                  <span>{errors.length} errors</span>
                </div>
              </>
            )}
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            className="gap-2"
            onClick={handleSave}
          >
            <Save className="h-4 w-4" />
            Save
          </Button>
          <Button
            size="sm"
            className="gap-2"
            onClick={handleRun}
            disabled={errors.length > 0}
          >
            <Play className="h-4 w-4" />
            Run
          </Button>
        </div>
      </div>

      {/* Mode Tabs */}
      <Tabs
        value={activeMode}
        onValueChange={(value) => {
          if (value === 'visual' && activeMode === 'yaml') {
            handleYamlToSteps()
          }
          setActiveMode(value as 'visual' | 'yaml')
        }}
        className="flex-1 flex flex-col"
      >
        <TabsList className="mx-4 mt-4 w-fit">
          <TabsTrigger value="visual" className="gap-2">
            <Eye className="h-4 w-4" />
            Visual
          </TabsTrigger>
          <TabsTrigger value="yaml" className="gap-2">
            <Code className="h-4 w-4" />
            YAML
          </TabsTrigger>
        </TabsList>

        {/* Visual Mode */}
        <TabsContent value="visual" className="flex-1 flex flex-col mt-4 mx-4 mb-4">
          <div className="flex gap-4 h-full">
            {/* Step Palette */}
            <div className="w-64 border rounded-lg p-4 bg-muted/30">
              <h3 className="font-medium mb-3">Add Steps</h3>
              <div className="space-y-3">
                {Object.entries(
                  stepTypes.reduce((acc, step) => {
                    if (!acc[step.category]) acc[step.category] = []
                    acc[step.category].push(step)
                    return acc
                  }, {} as Record<string, typeof stepTypes>)
                ).map(([category, categorySteps]) => (
                  <div key={category}>
                    <h4 className="text-xs font-medium text-muted-foreground mb-2">
                      {category}
                    </h4>
                    <div className="space-y-1">
                      {categorySteps.map(step => (
                        <Button
                          key={step.kind}
                          variant="ghost"
                          size="sm"
                          className="w-full justify-start gap-2 h-8 text-xs"
                          onClick={() => handleAddStep(step.kind)}
                        >
                          {getStepIcon(step.kind)}
                          {step.label}
                        </Button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Steps List */}
            <div className="flex-1 border rounded-lg bg-background">
              <div className="p-4 border-b">
                <div className="flex items-center justify-between">
                  <h3 className="font-medium">Test Steps</h3>
                  <Button
                    variant="outline"
                    size="sm"
                    className="gap-2"
                    onClick={() => handleAddStep('web.navigate')}
                  >
                    <Plus className="h-4 w-4" />
                    Add Step
                  </Button>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto custom-scrollbar">
                {steps.length === 0 ? (
                  <div className="flex items-center justify-center h-64 text-muted-foreground">
                    <div className="text-center">
                      <Plus className="h-8 w-8 mx-auto mb-2 opacity-50" />
                      <p className="text-sm">No steps added yet</p>
                      <p className="text-xs">Add steps from the palette or click "Add Step"</p>
                    </div>
                  </div>
                ) : (
                  <div className="p-4 space-y-3">
                    <AnimatePresence>
                      {steps.map((step, index) => (
                        <motion.div
                          key={step.id}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -20 }}
                          className="step-card"
                        >
                          <Card className="hover:shadow-md transition-all">
                            <CardHeader className="pb-2">
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-3">
                                  <div className="flex items-center gap-2">
                                    <GripVertical className="h-4 w-4 text-muted-foreground cursor-grab" />
                                    <span className="text-sm text-muted-foreground font-mono">
                                      {index + 1}
                                    </span>
                                  </div>
                                  {getStepIcon(step.kind)}
                                  <div>
                                    <CardTitle className="text-sm">{step.kind}</CardTitle>
                                    {editingStep === step.id ? (
                                      <Input
                                        defaultValue={step.description}
                                        className="text-xs mt-1 h-6"
                                        onBlur={(e) => {
                                          handleUpdateStep(step.id, { description: e.target.value })
                                          setEditingStep(null)
                                        }}
                                        onKeyDown={(e) => {
                                          if (e.key === 'Enter') {
                                            handleUpdateStep(step.id, { description: e.currentTarget.value })
                                            setEditingStep(null)
                                          } else if (e.key === 'Escape') {
                                            setEditingStep(null)
                                          }
                                        }}
                                        autoFocus
                                      />
                                    ) : (
                                      <p 
                                        className="text-xs text-muted-foreground cursor-pointer"
                                        onClick={() => setEditingStep(step.id)}
                                      >
                                        {step.description || 'Click to add description'}
                                      </p>
                                    )}
                                  </div>
                                </div>
                                
                                <div className="flex items-center gap-1">
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="h-6 w-6"
                                    onClick={() => setEditingStep(step.id)}
                                  >
                                    <Edit3 className="h-3 w-3" />
                                  </Button>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="h-6 w-6 text-destructive"
                                    onClick={() => handleDeleteStep(step.id)}
                                  >
                                    <Trash2 className="h-3 w-3" />
                                  </Button>
                                </div>
                              </div>
                            </CardHeader>
                            
                            <CardContent className="pt-0">
                              <div className="text-xs text-muted-foreground space-y-1">
                                {Object.entries(step.config).map(([key, value]) => (
                                  <div key={key} className="flex gap-2">
                                    <span className="font-mono">{key}:</span>
                                    <span className="truncate">{String(value)}</span>
                                  </div>
                                ))}
                              </div>
                            </CardContent>
                          </Card>
                        </motion.div>
                      ))}
                    </AnimatePresence>
                  </div>
                )}
              </div>
            </div>
          </div>
        </TabsContent>

        {/* YAML Mode */}
        <TabsContent value="yaml" className="flex-1 flex flex-col mt-4 mx-4 mb-4">
          <div className="flex-1 border rounded-lg overflow-hidden">
            <Editor
              height="100%"
              language="yaml"
              theme="vs-dark"
              value={yamlContent}
              onChange={(value) => setYamlContent(value || '')}
              options={{
                minimap: { enabled: false },
                fontSize: 14,
                lineNumbers: 'on',
                folding: true,
                wordWrap: 'on',
                automaticLayout: true
              }}
            />
          </div>
        </TabsContent>
      </Tabs>

      {/* Error Panel */}
      {errors.length > 0 && (
        <div className="border-t bg-destructive/10 p-4">
          <div className="flex items-center gap-2 mb-2">
            <AlertCircle className="h-4 w-4 text-destructive" />
            <h3 className="text-sm font-medium text-destructive">Validation Errors</h3>
          </div>
          <div className="space-y-1">
            {errors.map((error, index) => (
              <p key={index} className="text-xs text-destructive/80">{error}</p>
            ))}
          </div>
        </div>
      )}
    </div>
  )
} 