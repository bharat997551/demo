import React from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { io, Socket } from 'socket.io-client'
import {
  Play,
  Square,
  Skip,
  RotateCcw,
  Download,
  Eye,
  AlertCircle,
  CheckCircle,
  Clock,
  Zap,
  FileText,
  Image,
  Video,
  Terminal
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { cn } from '@/lib/utils'
import { formatDuration, formatTimestamp } from '@/lib/utils'

interface LogEntry {
  id: string
  timestamp: number
  level: 'debug' | 'info' | 'warning' | 'error'
  message: string
  stepId?: string
  data?: any
}

interface StepResult {
  id: string
  stepId: string
  status: 'pending' | 'running' | 'success' | 'error' | 'skipped'
  startTime?: number
  endTime?: number
  duration?: number
  error?: string
  artifacts: Artifact[]
}

interface Artifact {
  id: string
  type: 'screenshot' | 'video' | 'log' | 'data' | 'html'
  name: string
  path: string
  size: number
  timestamp: number
}

interface RunViewProps {
  runId?: string
  isRunning?: boolean
  onStop?: () => void
  onRerun?: (stepId?: string) => void
  onSkipStep?: (stepId: string) => void
}

export function RunView({
  runId,
  isRunning = false,
  onStop,
  onRerun,
  onSkipStep
}: RunViewProps) {
  const [logs, setLogs] = React.useState<LogEntry[]>([])
  const [stepResults, setStepResults] = React.useState<StepResult[]>([])
  const [selectedStep, setSelectedStep] = React.useState<string | null>(null)
  const [socket, setSocket] = React.useState<Socket | null>(null)
  const [activeTab, setActiveTab] = React.useState<'logs' | 'steps' | 'artifacts'>('logs')
  const logContainerRef = React.useRef<HTMLDivElement>(null)

  // Connect to WebSocket for real-time updates
  React.useEffect(() => {
    if (!runId) return

    const socketConnection = io('http://localhost:3001', {
      query: { runId }
    })

    socketConnection.on('log', (logEntry: LogEntry) => {
      setLogs(prev => [...prev, logEntry])
    })

    socketConnection.on('step-status', (stepResult: StepResult) => {
      setStepResults(prev => {
        const existing = prev.find(r => r.stepId === stepResult.stepId)
        if (existing) {
          return prev.map(r => r.stepId === stepResult.stepId ? stepResult : r)
        }
        return [...prev, stepResult]
      })
    })

    socketConnection.on('artifact-created', (artifact: Artifact, stepId: string) => {
      setStepResults(prev => prev.map(result => 
        result.stepId === stepId
          ? { ...result, artifacts: [...result.artifacts, artifact] }
          : result
      ))
    })

    setSocket(socketConnection)

    return () => {
      socketConnection.disconnect()
    }
  }, [runId])

  // Auto-scroll logs
  React.useEffect(() => {
    if (logContainerRef.current) {
      logContainerRef.current.scrollTop = logContainerRef.current.scrollHeight
    }
  }, [logs])

  const getLogLevelIcon = (level: LogEntry['level']) => {
    switch (level) {
      case 'error':
        return <AlertCircle className="h-4 w-4 text-red-500" />
      case 'warning':
        return <AlertCircle className="h-4 w-4 text-yellow-500" />
      case 'info':
        return <CheckCircle className="h-4 w-4 text-blue-500" />
      case 'debug':
        return <Terminal className="h-4 w-4 text-muted-foreground" />
      default:
        return <CheckCircle className="h-4 w-4 text-muted-foreground" />
    }
  }

  const getStepStatusIcon = (status: StepResult['status']) => {
    switch (status) {
      case 'running':
        return <div className="h-3 w-3 bg-blue-500 rounded-full animate-pulse" />
      case 'success':
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case 'error':
        return <AlertCircle className="h-4 w-4 text-red-500" />
      case 'skipped':
        return <Skip className="h-4 w-4 text-yellow-500" />
      default:
        return <Clock className="h-4 w-4 text-muted-foreground" />
    }
  }

  const getArtifactIcon = (type: Artifact['type']) => {
    switch (type) {
      case 'screenshot':
        return <Image className="h-4 w-4" />
      case 'video':
        return <Video className="h-4 w-4" />
      case 'log':
        return <FileText className="h-4 w-4" />
      default:
        return <FileText className="h-4 w-4" />
    }
  }

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 B'
    const k = 1024
    const sizes = ['B', 'KB', 'MB', 'GB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
  }

  const filteredLogs = selectedStep
    ? logs.filter(log => log.stepId === selectedStep)
    : logs

  const completedSteps = stepResults.filter(r => r.status === 'success').length
  const failedSteps = stepResults.filter(r => r.status === 'error').length
  const totalSteps = stepResults.length

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b">
        <div className="flex items-center gap-4">
          <h2 className="text-lg font-semibold">Test Run</h2>
          {runId && (
            <span className="text-sm text-muted-foreground font-mono">#{runId}</span>
          )}
          <div className="flex items-center gap-2 text-sm">
            <div className={cn(
              "h-2 w-2 rounded-full",
              isRunning ? "bg-green-500 animate-pulse" : "bg-gray-400"
            )} />
            <span className="text-muted-foreground">
              {isRunning ? "Running" : "Completed"}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            className="gap-2"
            onClick={() => onRerun?.()}
            disabled={isRunning}
          >
            <RotateCcw className="h-4 w-4" />
            Rerun
          </Button>
          {isRunning ? (
            <Button
              variant="destructive"
              size="sm"
              className="gap-2"
              onClick={onStop}
            >
              <Square className="h-4 w-4" />
              Stop
            </Button>
          ) : (
            <Button
              size="sm"
              className="gap-2"
              onClick={() => onRerun?.()}
            >
              <Play className="h-4 w-4" />
              Run Again
            </Button>
          )}
        </div>
      </div>

      {/* Progress Summary */}
      {totalSteps > 0 && (
        <div className="px-4 py-3 border-b bg-muted/30">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-6 text-sm">
              <div className="flex items-center gap-2">
                <div className="h-2 w-2 bg-green-500 rounded-full" />
                <span>Completed: {completedSteps}</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="h-2 w-2 bg-red-500 rounded-full" />
                <span>Failed: {failedSteps}</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="h-2 w-2 bg-blue-500 rounded-full" />
                <span>Total: {totalSteps}</span>
              </div>
            </div>
            <div className="text-sm text-muted-foreground">
              Progress: {Math.round((completedSteps + failedSteps) / totalSteps * 100)}%
            </div>
          </div>
          <div className="mt-2 h-2 bg-muted rounded-full overflow-hidden">
            <div
              className="h-full bg-primary transition-all duration-500"
              style={{
                width: `${(completedSteps + failedSteps) / totalSteps * 100}%`
              }}
            />
          </div>
        </div>
      )}

      {/* Content Tabs */}
      <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as any)} className="flex-1 flex flex-col">
        <TabsList className="mx-4 mt-4 w-fit">
          <TabsTrigger value="logs" className="gap-2">
            <Terminal className="h-4 w-4" />
            Logs ({logs.length})
          </TabsTrigger>
          <TabsTrigger value="steps" className="gap-2">
            <Zap className="h-4 w-4" />
            Steps ({stepResults.length})
          </TabsTrigger>
          <TabsTrigger value="artifacts" className="gap-2">
            <FileText className="h-4 w-4" />
            Artifacts ({stepResults.reduce((acc, r) => acc + r.artifacts.length, 0)})
          </TabsTrigger>
        </TabsList>

        {/* Logs Tab */}
        <TabsContent value="logs" className="flex-1 flex flex-col mt-4 mx-4 mb-4">
          <div className="flex-1 border rounded-lg overflow-hidden">
            <div
              ref={logContainerRef}
              className="h-full overflow-y-auto custom-scrollbar bg-card p-4 font-mono text-sm"
            >
              <AnimatePresence>
                {filteredLogs.map((log) => (
                  <motion.div
                    key={log.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className={cn("log-entry flex items-start gap-3 p-2 rounded mb-1", log.level)}
                  >
                    <div className="flex-shrink-0 mt-0.5">
                      {getLogLevelIcon(log.level)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xs text-muted-foreground">
                          {formatTimestamp(log.timestamp)}
                        </span>
                        {log.stepId && (
                          <span className="text-xs bg-muted px-2 py-0.5 rounded">
                            Step {log.stepId}
                          </span>
                        )}
                      </div>
                      <div className="break-words">{log.message}</div>
                      {log.data && (
                        <details className="mt-2">
                          <summary className="cursor-pointer text-xs text-muted-foreground">
                            Show Data
                          </summary>
                          <pre className="mt-1 text-xs bg-muted p-2 rounded overflow-x-auto">
                            {JSON.stringify(log.data, null, 2)}
                          </pre>
                        </details>
                      )}
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
              
              {logs.length === 0 && (
                <div className="flex items-center justify-center h-full text-muted-foreground">
                  <div className="text-center">
                    <Terminal className="h-8 w-8 mx-auto mb-2 opacity-50" />
                    <p className="text-sm">No logs yet</p>
                    <p className="text-xs">Logs will appear here during test execution</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </TabsContent>

        {/* Steps Tab */}
        <TabsContent value="steps" className="flex-1 flex flex-col mt-4 mx-4 mb-4">
          <div className="flex-1 overflow-y-auto custom-scrollbar space-y-2">
            {stepResults.map((result, index) => (
              <Card
                key={result.id}
                className={cn(
                  "cursor-pointer transition-all hover:shadow-md",
                  selectedStep === result.stepId && "ring-2 ring-primary",
                  result.status === 'error' && "border-red-500",
                  result.status === 'success' && "border-green-500"
                )}
                onClick={() => setSelectedStep(
                  selectedStep === result.stepId ? null : result.stepId
                )}
              >
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <span className="text-sm text-muted-foreground font-mono">
                        {index + 1}
                      </span>
                      {getStepStatusIcon(result.status)}
                      <CardTitle className="text-sm">Step {result.stepId}</CardTitle>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      {result.duration && (
                        <span className="text-xs text-muted-foreground">
                          {formatDuration(result.duration)}
                        </span>
                      )}
                      <div className="flex items-center gap-1">
                        {result.status !== 'skipped' && result.status !== 'success' && (
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6"
                            onClick={(e) => {
                              e.stopPropagation()
                              onSkipStep?.(result.stepId)
                            }}
                            disabled={result.status === 'running'}
                          >
                            <Skip className="h-3 w-3" />
                          </Button>
                        )}
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6"
                          onClick={(e) => {
                            e.stopPropagation()
                            onRerun?.(result.stepId)
                          }}
                          disabled={isRunning}
                        >
                          <RotateCcw className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardHeader>

                <CardContent className="pt-0">
                  {result.error && (
                    <div className="text-xs text-red-500 bg-red-500/10 p-2 rounded mb-2">
                      {result.error}
                    </div>
                  )}
                  {result.artifacts.length > 0 && (
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <FileText className="h-3 w-3" />
                      <span>{result.artifacts.length} artifacts</span>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}

            {stepResults.length === 0 && (
              <div className="flex items-center justify-center h-64 text-muted-foreground">
                <div className="text-center">
                  <Zap className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">No steps executed yet</p>
                  <p className="text-xs">Step results will appear here during execution</p>
                </div>
              </div>
            )}
          </div>
        </TabsContent>

        {/* Artifacts Tab */}
        <TabsContent value="artifacts" className="flex-1 flex flex-col mt-4 mx-4 mb-4">
          <div className="flex-1 overflow-y-auto custom-scrollbar space-y-4">
            {stepResults
              .filter(result => result.artifacts.length > 0)
              .map(result => (
                <div key={result.id}>
                  <h3 className="font-medium mb-2">Step {result.stepId}</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                    {result.artifacts.map(artifact => (
                      <Card key={artifact.id} className="hover:shadow-md transition-all">
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                              {getArtifactIcon(artifact.type)}
                              <span className="font-medium text-sm">{artifact.name}</span>
                            </div>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-6 w-6"
                              onClick={() => {
                                // TODO: Download or view artifact
                                console.log('View artifact:', artifact.path)
                              }}
                            >
                              <Eye className="h-3 w-3" />
                            </Button>
                          </div>
                          <div className="text-xs text-muted-foreground space-y-1">
                            <div>Size: {formatFileSize(artifact.size)}</div>
                            <div>Created: {formatTimestamp(artifact.timestamp)}</div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              ))}

            {stepResults.every(r => r.artifacts.length === 0) && (
              <div className="flex items-center justify-center h-64 text-muted-foreground">
                <div className="text-center">
                  <FileText className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">No artifacts generated</p>
                  <p className="text-xs">Screenshots and logs will appear here</p>
                </div>
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
} 