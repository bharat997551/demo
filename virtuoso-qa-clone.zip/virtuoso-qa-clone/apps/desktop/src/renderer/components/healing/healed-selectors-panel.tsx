import React from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Check,
  X,
  AlertCircle,
  Clock,
  TrendingUp,
  Eye,
  Code,
  RefreshCw
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip'
import { Separator } from '@/components/ui/separator'

interface HealedSelector {
  id: string
  testId: string
  stepId: string
  originalLocator: {
    selector: string
    type: string
  }
  healedLocator: {
    selector: string
    type: string
  }
  confidence: number
  reason: string
  diff: {
    before: string
    after: string
    changes: Array<{
      type: 'addition' | 'deletion' | 'modification'
      path: string
      value: string
    }>
  }
  timestamp: Date
  accepted: boolean
  acceptedBy?: string
  acceptedAt?: Date
}

interface HealedSelectorsPanelProps {
  className?: string
}

export function HealedSelectorsPanel({ className }: HealedSelectorsPanelProps) {
  const [healedSelectors, setHealedSelectors] = React.useState<HealedSelector[]>([])
  const [activeTab, setActiveTab] = React.useState<'pending' | 'accepted'>('pending')
  const [selectedSelector, setSelectedSelector] = React.useState<HealedSelector | null>(null)
  const [isLoading, setIsLoading] = React.useState(false)

  // Mock data for demonstration
  React.useEffect(() => {
    const mockSelectors: HealedSelector[] = [
      {
        id: '1',
        testId: 'test-123',
        stepId: 'step-1',
        originalLocator: {
          selector: '#submit-button',
          type: 'css'
        },
        healedLocator: {
          selector: '[data-testid="submit-form-button"]',
          type: 'data-testid'
        },
        confidence: 0.92,
        reason: 'Element attributes match. DOM structure is preserved. Text content remains similar.',
        diff: {
          before: 'css: #submit-button',
          after: 'data-testid: [data-testid="submit-form-button"]',
          changes: [
            {
              type: 'modification',
              path: 'type',
              value: 'css → data-testid'
            },
            {
              type: 'modification',
              path: 'selector',
              value: '#submit-button → [data-testid="submit-form-button"]'
            }
          ]
        },
        timestamp: new Date(Date.now() - 1000 * 60 * 5),
        accepted: false
      },
      {
        id: '2',
        testId: 'test-456',
        stepId: 'step-3',
        originalLocator: {
          selector: '.login-button',
          type: 'css'
        },
        healedLocator: {
          selector: 'button[type="submit"]',
          type: 'css'
        },
        confidence: 0.85,
        reason: 'Text content remains similar. Same element type is preserved.',
        diff: {
          before: 'css: .login-button',
          after: 'css: button[type="submit"]',
          changes: [
            {
              type: 'modification',
              path: 'selector',
              value: '.login-button → button[type="submit"]'
            }
          ]
        },
        timestamp: new Date(Date.now() - 1000 * 60 * 30),
        accepted: true,
        acceptedBy: 'john.doe@example.com',
        acceptedAt: new Date(Date.now() - 1000 * 60 * 15)
      }
    ]
    setHealedSelectors(mockSelectors)
  }, [])

  const pendingSelectors = healedSelectors.filter(s => !s.accepted)
  const acceptedSelectors = healedSelectors.filter(s => s.accepted)

  const handleAccept = async (selector: HealedSelector) => {
    setIsLoading(true)
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000))
    
    setHealedSelectors(prev => prev.map(s => 
      s.id === selector.id 
        ? { ...s, accepted: true, acceptedBy: 'current.user@example.com', acceptedAt: new Date() }
        : s
    ))
    setIsLoading(false)
  }

  const handleReject = async (selector: HealedSelector) => {
    setIsLoading(true)
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 500))
    
    setHealedSelectors(prev => prev.filter(s => s.id !== selector.id))
    setSelectedSelector(null)
    setIsLoading(false)
  }

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 0.9) return 'text-green-500'
    if (confidence >= 0.7) return 'text-yellow-500'
    return 'text-orange-500'
  }

  const getConfidenceBadge = (confidence: number) => {
    if (confidence >= 0.9) return 'success'
    if (confidence >= 0.7) return 'warning'
    return 'secondary'
  }

  const renderSelectorCard = (selector: HealedSelector) => (
    <motion.div
      key={selector.id}
      layoutId={`selector-${selector.id}`}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      whileHover={{ scale: 1.02 }}
      onClick={() => setSelectedSelector(selector)}
      className="cursor-pointer"
    >
      <Card className="hover:shadow-lg transition-all">
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <CardTitle className="text-base flex items-center gap-2">
                {selector.testId}
                <Badge variant={getConfidenceBadge(selector.confidence)}>
                  {(selector.confidence * 100).toFixed(0)}% confidence
                </Badge>
              </CardTitle>
              <CardDescription className="text-xs mt-1">
                Step: {selector.stepId} • {new Date(selector.timestamp).toLocaleString()}
              </CardDescription>
            </div>
            {selector.accepted ? (
              <Badge variant="success" className="ml-2">
                <Check className="h-3 w-3 mr-1" />
                Accepted
              </Badge>
            ) : (
              <Badge variant="outline" className="ml-2">
                <Clock className="h-3 w-3 mr-1" />
                Pending
              </Badge>
            )}
          </div>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="space-y-2">
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div>
                <span className="text-muted-foreground">Original:</span>
                <code className="ml-1 text-xs bg-muted px-1 py-0.5 rounded">
                  {selector.originalLocator.selector}
                </code>
              </div>
              <div>
                <span className="text-muted-foreground">Healed:</span>
                <code className="ml-1 text-xs bg-muted px-1 py-0.5 rounded">
                  {selector.healedLocator.selector}
                </code>
              </div>
            </div>
            <p className="text-xs text-muted-foreground line-clamp-2">
              {selector.reason}
            </p>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  )

  return (
    <TooltipProvider>
      <div className={cn("flex flex-col h-full", className)}>
        <div className="p-4 border-b">
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <RefreshCw className="h-5 w-5" />
            Healed Selectors
          </h2>
          <p className="text-sm text-muted-foreground mt-1">
            Review and accept selector healing suggestions
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as any)} className="flex-1 flex flex-col">
          <TabsList className="mx-4 mt-4">
            <TabsTrigger value="pending" className="flex items-center gap-2">
              <AlertCircle className="h-4 w-4" />
              Pending ({pendingSelectors.length})
            </TabsTrigger>
            <TabsTrigger value="accepted" className="flex items-center gap-2">
              <Check className="h-4 w-4" />
              Accepted ({acceptedSelectors.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="pending" className="flex-1 p-4 pt-2">
            <ScrollArea className="h-full">
              <div className="space-y-3">
                <AnimatePresence mode="popLayout">
                  {pendingSelectors.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      <AlertCircle className="h-12 w-12 mx-auto mb-3 opacity-30" />
                      <p>No pending healing suggestions</p>
                    </div>
                  ) : (
                    pendingSelectors.map(selector => renderSelectorCard(selector))
                  )}
                </AnimatePresence>
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="accepted" className="flex-1 p-4 pt-2">
            <ScrollArea className="h-full">
              <div className="space-y-3">
                <AnimatePresence mode="popLayout">
                  {acceptedSelectors.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      <Check className="h-12 w-12 mx-auto mb-3 opacity-30" />
                      <p>No accepted healing suggestions yet</p>
                    </div>
                  ) : (
                    acceptedSelectors.map(selector => renderSelectorCard(selector))
                  )}
                </AnimatePresence>
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>

        {/* Detail Modal */}
        <AnimatePresence>
          {selectedSelector && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
              onClick={() => setSelectedSelector(null)}
            >
              <motion.div
                layoutId={`selector-${selectedSelector.id}`}
                className="bg-card rounded-lg shadow-xl max-w-2xl w-full max-h-[80vh] overflow-hidden"
                onClick={e => e.stopPropagation()}
              >
                <div className="p-6 border-b">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="text-xl font-semibold">Selector Healing Details</h3>
                      <p className="text-sm text-muted-foreground mt-1">
                        {selectedSelector.testId} • {selectedSelector.stepId}
                      </p>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => setSelectedSelector(null)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                <ScrollArea className="max-h-[calc(80vh-200px)]">
                  <div className="p-6 space-y-6">
                    {/* Confidence Score */}
                    <div>
                      <h4 className="text-sm font-medium mb-2">Confidence Score</h4>
                      <div className="flex items-center gap-4">
                        <div className="flex-1 bg-muted rounded-full h-2 overflow-hidden">
                          <motion.div
                            initial={{ width: 0 }}
                            animate={{ width: `${selectedSelector.confidence * 100}%` }}
                            className={cn("h-full", {
                              'bg-green-500': selectedSelector.confidence >= 0.9,
                              'bg-yellow-500': selectedSelector.confidence >= 0.7 && selectedSelector.confidence < 0.9,
                              'bg-orange-500': selectedSelector.confidence < 0.7
                            })}
                          />
                        </div>
                        <span className={cn("text-sm font-medium", getConfidenceColor(selectedSelector.confidence))}>
                          {(selectedSelector.confidence * 100).toFixed(0)}%
                        </span>
                      </div>
                    </div>

                    {/* Locator Changes */}
                    <div>
                      <h4 className="text-sm font-medium mb-2">Locator Changes</h4>
                      <div className="space-y-2">
                        <div className="flex items-center gap-2 text-sm">
                          <span className="text-muted-foreground">Before:</span>
                          <code className="flex-1 bg-red-500/10 text-red-500 px-2 py-1 rounded font-mono text-xs">
                            {selectedSelector.diff.before}
                          </code>
                        </div>
                        <div className="flex items-center gap-2 text-sm">
                          <span className="text-muted-foreground">After:</span>
                          <code className="flex-1 bg-green-500/10 text-green-500 px-2 py-1 rounded font-mono text-xs">
                            {selectedSelector.diff.after}
                          </code>
                        </div>
                      </div>
                    </div>

                    {/* Change Details */}
                    <div>
                      <h4 className="text-sm font-medium mb-2">Change Details</h4>
                      <div className="space-y-1">
                        {selectedSelector.diff.changes.map((change, index) => (
                          <div key={index} className="flex items-center gap-2 text-sm">
                            <Badge
                              variant={
                                change.type === 'addition' ? 'success' :
                                change.type === 'deletion' ? 'destructive' :
                                'secondary'
                              }
                              className="text-xs"
                            >
                              {change.type}
                            </Badge>
                            <span className="text-muted-foreground">{change.path}:</span>
                            <span className="font-mono text-xs">{change.value}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Reason */}
                    <div>
                      <h4 className="text-sm font-medium mb-2">Healing Reason</h4>
                      <p className="text-sm text-muted-foreground">
                        {selectedSelector.reason}
                      </p>
                    </div>

                    {/* Metadata */}
                    {selectedSelector.accepted && (
                      <div>
                        <h4 className="text-sm font-medium mb-2">Acceptance Info</h4>
                        <div className="text-sm text-muted-foreground space-y-1">
                          <div>Accepted by: {selectedSelector.acceptedBy}</div>
                          <div>Accepted at: {selectedSelector.acceptedAt?.toLocaleString()}</div>
                        </div>
                      </div>
                    )}
                  </div>
                </ScrollArea>

                <div className="p-6 border-t">
                  {!selectedSelector.accepted ? (
                    <div className="flex gap-3">
                      <Button
                        variant="default"
                        className="flex-1"
                        onClick={() => handleAccept(selectedSelector)}
                        disabled={isLoading}
                      >
                        <Check className="h-4 w-4 mr-2" />
                        Accept Healing
                      </Button>
                      <Button
                        variant="destructive"
                        className="flex-1"
                        onClick={() => handleReject(selectedSelector)}
                        disabled={isLoading}
                      >
                        <X className="h-4 w-4 mr-2" />
                        Reject
                      </Button>
                    </div>
                  ) : (
                    <div className="text-center text-sm text-muted-foreground">
                      This healing suggestion has been accepted
                    </div>
                  )}
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </TooltipProvider>
  )
} 