import React from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Bug,
  Play,
  Pause,
  SkipForward,
  StepForward,
  RefreshCw,
  Eye,
  EyeOff,
  Plus,
  Trash2,
  ChevronRight,
  ChevronDown,
  Hash,
  Type,
  ToggleLeft,
  List,
  Clock,
  Layers,
  AlertCircle,
  Square
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { cn } from '@/lib/utils'

interface StackFrame {
  id: string
  name: string
  type: 'step' | 'flow' | 'loop' | 'condition'
  file?: string
  line?: number
  status: 'active' | 'paused' | 'completed'
  variables: Record<string, any>
}

interface WatchVariable {
  id: string
  expression: string
  value: any
  type: string
  error?: string
}

interface Breakpoint {
  id: string
  stepId: string
  condition?: string
  hitCount: number
  enabled: boolean
}

interface DebuggerPanelProps {
  isDebugging?: boolean
  isPaused?: boolean
  currentStepId?: string
  stack?: StackFrame[]
  onStepOver?: () => void
  onStepInto?: () => void
  onStepOut?: () => void
  onContinue?: () => void
  onPause?: () => void
  onStop?: () => void
  onAddWatch?: (expression: string) => void
  onRemoveWatch?: (id: string) => void
  onToggleBreakpoint?: (stepId: string) => void
}

export function DebuggerPanel({
  isDebugging = false,
  isPaused = false,
  currentStepId,
  stack = [],
  onStepOver,
  onStepInto,
  onStepOut,
  onContinue,
  onPause,
  onStop,
  onAddWatch,
  onRemoveWatch,
  onToggleBreakpoint
}: DebuggerPanelProps) {
  const [watchVariables, setWatchVariables] = React.useState<WatchVariable[]>([])
  const [breakpoints, setBreakpoints] = React.useState<Breakpoint[]>([])
  const [expandedFrames, setExpandedFrames] = React.useState<Set<string>>(new Set())
  const [activeTab, setActiveTab] = React.useState<'stack' | 'watch' | 'breakpoints'>('stack')
  const [newWatchExpression, setNewWatchExpression] = React.useState('')
  const [selectedFrame, setSelectedFrame] = React.useState<string | null>(null)

  const toggleFrameExpanded = (frameId: string) => {
    setExpandedFrames(prev => {
      const newSet = new Set(prev)
      if (newSet.has(frameId)) {
        newSet.delete(frameId)
      } else {
        newSet.add(frameId)
      }
      return newSet
    })
  }

  const handleAddWatch = () => {
    if (newWatchExpression.trim()) {
      const newWatch: WatchVariable = {
        id: `watch-${Date.now()}`,
        expression: newWatchExpression.trim(),
        value: undefined,
        type: 'unknown'
      }
      setWatchVariables(prev => [...prev, newWatch])
      onAddWatch?.(newWatchExpression.trim())
      setNewWatchExpression('')
    }
  }

  const handleRemoveWatch = (id: string) => {
    setWatchVariables(prev => prev.filter(w => w.id !== id))
    onRemoveWatch?.(id)
  }

  const handleToggleBreakpoint = (stepId: string) => {
    const existing = breakpoints.find(bp => bp.stepId === stepId)
    if (existing) {
      setBreakpoints(prev => prev.filter(bp => bp.stepId !== stepId))
    } else {
      const newBreakpoint: Breakpoint = {
        id: `bp-${Date.now()}`,
        stepId,
        hitCount: 0,
        enabled: true
      }
      setBreakpoints(prev => [...prev, newBreakpoint])
    }
    onToggleBreakpoint?.(stepId)
  }

  const getVariableIcon = (type: string) => {
    switch (type) {
      case 'string':
        return <Type className="h-3 w-3 text-green-500" />
      case 'number':
        return <Hash className="h-3 w-3 text-blue-500" />
      case 'boolean':
        return <ToggleLeft className="h-3 w-3 text-purple-500" />
      case 'array':
        return <List className="h-3 w-3 text-yellow-500" />
      case 'object':
        return <Layers className="h-3 w-3 text-orange-500" />
      default:
        return <AlertCircle className="h-3 w-3 text-muted-foreground" />
    }
  }

  const renderVariableValue = (value: any, depth = 0): React.ReactNode => {
    if (value === null) return <span className="text-muted-foreground">null</span>
    if (value === undefined) return <span className="text-muted-foreground">undefined</span>
    
    const type = typeof value
    
    if (type === 'string') {
      return <span className="text-green-500">"{value}"</span>
    }
    
    if (type === 'number') {
      return <span className="text-blue-500">{value}</span>
    }
    
    if (type === 'boolean') {
      return <span className="text-purple-500">{value.toString()}</span>
    }
    
    if (Array.isArray(value)) {
      if (depth > 2) return <span className="text-muted-foreground">[...]</span>
      return (
        <details className="inline">
          <summary className="cursor-pointer text-yellow-500">
            Array({value.length})
          </summary>
          <div className="ml-4 mt-1">
            {value.map((item, index) => (
              <div key={index} className="text-xs">
                [{index}]: {renderVariableValue(item, depth + 1)}
              </div>
            ))}
          </div>
        </details>
      )
    }
    
    if (type === 'object') {
      if (depth > 2) return <span className="text-muted-foreground">{`{...}`}</span>
      const keys = Object.keys(value)
      return (
        <details className="inline">
          <summary className="cursor-pointer text-orange-500">
            Object({keys.length})
          </summary>
          <div className="ml-4 mt-1">
            {keys.map(key => (
              <div key={key} className="text-xs">
                {key}: {renderVariableValue(value[key], depth + 1)}
              </div>
            ))}
          </div>
        </details>
      )
    }
    
    return <span className="text-muted-foreground">{String(value)}</span>
  }

  return (
    <div className="h-full flex flex-col bg-background border-l">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b">
        <div className="flex items-center gap-2">
          <Bug className="h-5 w-5 text-primary" />
          <h2 className="text-lg font-semibold">Debugger</h2>
          {isDebugging && (
            <div className="flex items-center gap-2 text-sm">
              <div className={cn(
                "h-2 w-2 rounded-full",
                isPaused ? "bg-yellow-500" : "bg-green-500 animate-pulse"
              )} />
              <span className="text-muted-foreground">
                {isPaused ? "Paused" : "Running"}
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Debug Controls */}
      {isDebugging && (
        <div className="flex items-center gap-1 p-2 border-b bg-muted/30">
          {isPaused ? (
            <>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={onContinue}
                title="Continue (F5)"
              >
                <Play className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={onStepOver}
                title="Step Over (F10)"
              >
                <SkipForward className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={onStepInto}
                title="Step Into (F11)"
              >
                <StepForward className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={onStepOut}
                title="Step Out (Shift+F11)"
              >
                <StepForward className="h-4 w-4 rotate-180" />
              </Button>
            </>
          ) : (
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8"
              onClick={onPause}
              title="Pause"
            >
              <Pause className="h-4 w-4" />
            </Button>
          )}
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={onStop}
            title="Stop Debugging"
          >
            <Square className="h-4 w-4 text-destructive" />
          </Button>
          <div className="h-4 w-px bg-border mx-1" />
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            title="Restart"
          >
            <RefreshCw className="h-4 w-4" />
          </Button>
        </div>
      )}

      {/* Content */}
      <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as any)} className="flex-1 flex flex-col">
        <TabsList className="mx-4 mt-4 w-fit">
          <TabsTrigger value="stack" className="gap-2">
            <Layers className="h-4 w-4" />
            Call Stack
          </TabsTrigger>
          <TabsTrigger value="watch" className="gap-2">
            <Eye className="h-4 w-4" />
            Watch
          </TabsTrigger>
          <TabsTrigger value="breakpoints" className="gap-2">
            <AlertCircle className="h-4 w-4" />
            Breakpoints
          </TabsTrigger>
        </TabsList>

        {/* Call Stack */}
        <TabsContent value="stack" className="flex-1 overflow-y-auto mt-4 mx-4 mb-4">
          {stack.length === 0 ? (
            <div className="flex items-center justify-center h-32 text-muted-foreground">
              <div className="text-center">
                <Layers className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">No active call stack</p>
              </div>
            </div>
          ) : (
            <div className="space-y-2">
              {stack.map((frame, index) => (
                <Card
                  key={frame.id}
                  className={cn(
                    "cursor-pointer transition-all",
                    selectedFrame === frame.id && "ring-2 ring-primary",
                    frame.status === 'paused' && "border-yellow-500"
                  )}
                  onClick={() => setSelectedFrame(frame.id)}
                >
                  <CardHeader className="p-3 pb-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-4 w-4 p-0"
                          onClick={(e) => {
                            e.stopPropagation()
                            toggleFrameExpanded(frame.id)
                          }}
                        >
                          {expandedFrames.has(frame.id) ? (
                            <ChevronDown className="h-3 w-3" />
                          ) : (
                            <ChevronRight className="h-3 w-3" />
                          )}
                        </Button>
                        <span className="text-sm font-medium">{frame.name}</span>
                        <span className="text-xs text-muted-foreground">
                          #{index}
                        </span>
                      </div>
                      {frame.status === 'paused' && (
                        <div className="h-2 w-2 bg-yellow-500 rounded-full" />
                      )}
                    </div>
                    {frame.file && (
                      <p className="text-xs text-muted-foreground mt-1">
                        {frame.file}:{frame.line}
                      </p>
                    )}
                  </CardHeader>
                  
                  {expandedFrames.has(frame.id) && (
                    <CardContent className="pt-0 pb-3">
                      <div className="space-y-2">
                        <div className="text-xs font-medium text-muted-foreground">
                          Local Variables
                        </div>
                        {Object.entries(frame.variables).map(([key, value]) => (
                          <div key={key} className="flex items-start gap-2 text-xs">
                            {getVariableIcon(typeof value)}
                            <span className="font-mono">{key}:</span>
                            {renderVariableValue(value)}
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  )}
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* Watch Variables */}
        <TabsContent value="watch" className="flex-1 flex flex-col mt-4 mx-4 mb-4">
          <div className="flex gap-2 mb-3">
            <Input
              placeholder="Add watch expression..."
              value={newWatchExpression}
              onChange={(e) => setNewWatchExpression(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleAddWatch()}
              className="text-sm"
            />
            <Button
              variant="outline"
              size="icon"
              onClick={handleAddWatch}
              disabled={!newWatchExpression.trim()}
            >
              <Plus className="h-4 w-4" />
            </Button>
          </div>

          <div className="flex-1 overflow-y-auto space-y-2">
            {watchVariables.length === 0 ? (
              <div className="flex items-center justify-center h-32 text-muted-foreground">
                <div className="text-center">
                  <Eye className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">No watch expressions</p>
                  <p className="text-xs">Add expressions to monitor values</p>
                </div>
              </div>
            ) : (
              watchVariables.map(watch => (
                <Card key={watch.id} className="p-3">
                  <div className="flex items-start justify-between">
                    <div className="flex-1 space-y-1">
                      <div className="flex items-center gap-2">
                        {getVariableIcon(watch.type)}
                        <span className="text-sm font-mono">{watch.expression}</span>
                      </div>
                      <div className="text-xs">
                        {watch.error ? (
                          <span className="text-red-500">{watch.error}</span>
                        ) : (
                          renderVariableValue(watch.value)
                        )}
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6"
                      onClick={() => handleRemoveWatch(watch.id)}
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                </Card>
              ))
            )}
          </div>
        </TabsContent>

        {/* Breakpoints */}
        <TabsContent value="breakpoints" className="flex-1 overflow-y-auto mt-4 mx-4 mb-4">
          {breakpoints.length === 0 ? (
            <div className="flex items-center justify-center h-32 text-muted-foreground">
              <div className="text-center">
                <AlertCircle className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">No breakpoints set</p>
                <p className="text-xs">Click line numbers to add breakpoints</p>
              </div>
            </div>
          ) : (
            <div className="space-y-2">
              {breakpoints.map(breakpoint => (
                <Card key={breakpoint.id} className="p-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Button
                        variant="ghost"
                        size="icon"
                        className={cn(
                          "h-6 w-6",
                          breakpoint.enabled ? "text-red-500" : "text-muted-foreground"
                        )}
                        onClick={() => {
                          setBreakpoints(prev => prev.map(bp =>
                            bp.id === breakpoint.id
                              ? { ...bp, enabled: !bp.enabled }
                              : bp
                          ))
                        }}
                      >
                        <AlertCircle className="h-4 w-4" />
                      </Button>
                      <div>
                        <p className="text-sm font-medium">Step {breakpoint.stepId}</p>
                        {breakpoint.condition && (
                          <p className="text-xs text-muted-foreground">
                            Condition: {breakpoint.condition}
                          </p>
                        )}
                        <p className="text-xs text-muted-foreground">
                          Hit count: {breakpoint.hitCount}
                        </p>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6"
                      onClick={() => handleToggleBreakpoint(breakpoint.stepId)}
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
} 