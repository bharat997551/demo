import React from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Bug,
  Target,
  Circle,
  Square,
  Play,
  Pause,
  Edit3,
  Check,
  X,
  RefreshCw,
  Crosshair,
  MousePointer,
  Code,
  Eye,
  EyeOff,
  Copy,
  Settings
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { cn } from '@/lib/utils'

interface ElementInfo {
  selector: string
  tagName: string
  id?: string
  className?: string
  text?: string
  attributes: Record<string, string>
  computedStyles?: Record<string, string>
  boundingRect?: DOMRect
  xpath?: string
}

interface BreakpointConfig {
  stepId: string
  condition?: string
  logMessage?: string
  enabled: boolean
}

interface RecordDebugModeProps {
  isActive?: boolean
  isRecording?: boolean
  isPaused?: boolean
  currentElement?: ElementInfo
  breakpoints?: BreakpointConfig[]
  onToggle?: () => void
  onSelectElement?: () => void
  onUpdateSelector?: (selector: string) => void
  onAddBreakpoint?: (config: BreakpointConfig) => void
  onRemoveBreakpoint?: (stepId: string) => void
  onContinue?: () => void
  onStepOver?: () => void
}

export function RecordDebugMode({
  isActive = false,
  isRecording = false,
  isPaused = false,
  currentElement,
  breakpoints = [],
  onToggle,
  onSelectElement,
  onUpdateSelector,
  onAddBreakpoint,
  onRemoveBreakpoint,
  onContinue,
  onStepOver
}: RecordDebugModeProps) {
  const [isInspecting, setIsInspecting] = React.useState(false)
  const [editingSelector, setEditingSelector] = React.useState(false)
  const [customSelector, setCustomSelector] = React.useState('')
  const [showOverlay, setShowOverlay] = React.useState(true)
  const [activeTab, setActiveTab] = React.useState<'element' | 'selectors' | 'styles'>('element')
  const [copiedText, setCopiedText] = React.useState<string | null>(null)

  React.useEffect(() => {
    if (currentElement) {
      setCustomSelector(currentElement.selector)
    }
  }, [currentElement])

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text)
    setCopiedText(label)
    setTimeout(() => setCopiedText(null), 2000)
  }

  const handleStartInspecting = () => {
    setIsInspecting(true)
    onSelectElement?.()
  }

  const handleSaveSelector = () => {
    onUpdateSelector?.(customSelector)
    setEditingSelector(false)
  }

  const generateAlternativeSelectors = (element: ElementInfo): string[] => {
    const selectors: string[] = []
    
    // ID selector
    if (element.id) {
      selectors.push(`#${element.id}`)
    }
    
    // Class selector
    if (element.className) {
      const classes = element.className.split(' ').filter(c => c).map(c => `.${c}`).join('')
      if (classes) selectors.push(classes)
    }
    
    // Tag + text content
    if (element.text) {
      selectors.push(`${element.tagName.toLowerCase()}:contains("${element.text.substring(0, 20)}"`)
    }
    
    // Data attributes
    Object.entries(element.attributes).forEach(([key, value]) => {
      if (key.startsWith('data-')) {
        selectors.push(`[${key}="${value}"]`)
      }
    })
    
    // Aria labels
    if (element.attributes['aria-label']) {
      selectors.push(`[aria-label="${element.attributes['aria-label']}"]`)
    }
    
    return selectors
  }

  if (!isActive) return null

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 pointer-events-none"
      >
        {/* Debug Overlay */}
        {showOverlay && isRecording && (
          <div className="absolute top-0 left-0 right-0 bg-gradient-to-b from-red-500/20 to-transparent h-16 pointer-events-none">
            <div className="flex items-center justify-center h-full">
              <motion.div
                initial={{ y: -50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                className="flex items-center gap-2 bg-red-500 text-white px-4 py-2 rounded-full shadow-lg pointer-events-auto"
              >
                <Bug className="h-4 w-4" />
                <span className="text-sm font-medium">Debug Mode Active</span>
                {isPaused && (
                  <>
                    <div className="h-4 w-px bg-white/50" />
                    <span className="text-sm">Paused at Breakpoint</span>
                  </>
                )}
              </motion.div>
            </div>
          </div>
        )}

        {/* Element Inspector Overlay */}
        {isInspecting && (
          <div className="absolute inset-0 bg-black/20 pointer-events-auto cursor-crosshair">
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
              <motion.div
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ repeat: Infinity, duration: 1.5 }}
                className="flex items-center justify-center h-12 w-12 rounded-full bg-primary/20 border-2 border-primary"
              >
                <Crosshair className="h-6 w-6 text-primary" />
              </motion.div>
              <p className="text-center mt-4 text-white text-sm font-medium">
                Click an element to inspect
              </p>
            </div>
          </div>
        )}

        {/* Control Panel */}
        <motion.div
          initial={{ x: 100, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          className="absolute right-4 top-20 w-96 pointer-events-auto"
        >
          <Card className="shadow-2xl border-0 bg-card/95 backdrop-blur">
            <CardHeader className="pb-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Bug className="h-5 w-5 text-red-500" />
                  <CardTitle className="text-lg">Record & Debug</CardTitle>
                </div>
                <div className="flex items-center gap-1">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => setShowOverlay(!showOverlay)}
                  >
                    {showOverlay ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    onClick={onToggle}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>

            <CardContent className="space-y-4">
              {/* Status */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm">
                  <div className={cn(
                    "h-2 w-2 rounded-full",
                    isPaused ? "bg-yellow-500" : isRecording ? "bg-red-500 animate-pulse" : "bg-gray-400"
                  )} />
                  <span className="font-medium">
                    {isPaused ? "Paused at breakpoint" : isRecording ? "Recording" : "Ready"}
                  </span>
                </div>
                
                {isPaused && (
                  <div className="flex items-center gap-1">
                    <Button
                      variant="outline"
                      size="sm"
                      className="h-7 gap-1"
                      onClick={onContinue}
                    >
                      <Play className="h-3 w-3" />
                      Continue
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="h-7 gap-1"
                      onClick={onStepOver}
                    >
                      <Play className="h-3 w-3" />
                      Step
                    </Button>
                  </div>
                )}
              </div>

              {/* Quick Actions */}
              <div className="grid grid-cols-2 gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="gap-2"
                  onClick={handleStartInspecting}
                  disabled={isInspecting}
                >
                  <Target className="h-4 w-4" />
                  Inspect Element
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="gap-2"
                  onClick={() => {
                    if (currentElement) {
                      setEditingSelector(!editingSelector)
                    }
                  }}
                  disabled={!currentElement}
                >
                  <Edit3 className="h-4 w-4" />
                  Edit Selector
                </Button>
              </div>

              {/* Element Info */}
              {currentElement && (
                <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as any)}>
                  <TabsList className="w-full">
                    <TabsTrigger value="element" className="flex-1">Element</TabsTrigger>
                    <TabsTrigger value="selectors" className="flex-1">Selectors</TabsTrigger>
                    <TabsTrigger value="styles" className="flex-1">Styles</TabsTrigger>
                  </TabsList>

                  <TabsContent value="element" className="mt-4 space-y-3">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Current Selector</span>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6"
                          onClick={() => handleCopy(currentElement.selector, 'Selector')}
                        >
                          {copiedText === 'Selector' ? (
                            <Check className="h-3 w-3 text-green-500" />
                          ) : (
                            <Copy className="h-3 w-3" />
                          )}
                        </Button>
                      </div>
                      
                      {editingSelector ? (
                        <div className="flex gap-2">
                          <Input
                            value={customSelector}
                            onChange={(e) => setCustomSelector(e.target.value)}
                            className="text-xs font-mono"
                          />
                          <Button
                            size="icon"
                            className="h-8 w-8"
                            onClick={handleSaveSelector}
                          >
                            <Check className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => {
                              setEditingSelector(false)
                              setCustomSelector(currentElement.selector)
                            }}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      ) : (
                        <div className="p-2 bg-muted rounded text-xs font-mono break-all">
                          {currentElement.selector}
                        </div>
                      )}
                    </div>

                    <div className="space-y-2">
                      <h4 className="text-sm font-medium">Element Details</h4>
                      <div className="space-y-1 text-xs">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Tag:</span>
                          <span className="font-mono">{currentElement.tagName}</span>
                        </div>
                        {currentElement.id && (
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">ID:</span>
                            <span className="font-mono">{currentElement.id}</span>
                          </div>
                        )}
                        {currentElement.className && (
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Classes:</span>
                            <span className="font-mono text-right">{currentElement.className}</span>
                          </div>
                        )}
                        {currentElement.text && (
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Text:</span>
                            <span className="truncate max-w-[200px]">{currentElement.text}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="selectors" className="mt-4 space-y-3">
                    <h4 className="text-sm font-medium">Alternative Selectors</h4>
                    <div className="space-y-2">
                      {generateAlternativeSelectors(currentElement).map((selector, index) => (
                        <div
                          key={index}
                          className="flex items-center justify-between p-2 bg-muted rounded hover:bg-muted/80 cursor-pointer"
                          onClick={() => {
                            setCustomSelector(selector)
                            onUpdateSelector?.(selector)
                          }}
                        >
                          <code className="text-xs flex-1 break-all">{selector}</code>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6 ml-2"
                            onClick={(e) => {
                              e.stopPropagation()
                              handleCopy(selector, `Selector${index}`)
                            }}
                          >
                            {copiedText === `Selector${index}` ? (
                              <Check className="h-3 w-3 text-green-500" />
                            ) : (
                              <Copy className="h-3 w-3" />
                            )}
                          </Button>
                        </div>
                      ))}
                    </div>
                  </TabsContent>

                  <TabsContent value="styles" className="mt-4 space-y-3">
                    <h4 className="text-sm font-medium">Computed Styles</h4>
                    {currentElement.computedStyles ? (
                      <div className="space-y-1 max-h-64 overflow-y-auto custom-scrollbar">
                        {Object.entries(currentElement.computedStyles)
                          .slice(0, 20)
                          .map(([prop, value]) => (
                            <div key={prop} className="flex justify-between text-xs">
                              <span className="text-muted-foreground">{prop}:</span>
                              <span className="font-mono">{value}</span>
                            </div>
                          ))}
                      </div>
                    ) : (
                      <p className="text-xs text-muted-foreground">No style information available</p>
                    )}
                  </TabsContent>
                </Tabs>
              )}

              {/* Breakpoint Status */}
              {breakpoints.length > 0 && (
                <div className="space-y-2">
                  <h4 className="text-sm font-medium">Active Breakpoints</h4>
                  <div className="space-y-1">
                    {breakpoints.filter(bp => bp.enabled).map((bp, index) => (
                      <div key={index} className="flex items-center gap-2 text-xs">
                        <div className="h-2 w-2 bg-red-500 rounded-full" />
                        <span>Step {bp.stepId}</span>
                        {bp.condition && (
                          <span className="text-muted-foreground">({bp.condition})</span>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>

        {/* Element Highlight Box */}
        {currentElement?.boundingRect && !isInspecting && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="absolute pointer-events-none"
            style={{
              left: currentElement.boundingRect.left,
              top: currentElement.boundingRect.top,
              width: currentElement.boundingRect.width,
              height: currentElement.boundingRect.height
            }}
          >
            <div className="absolute inset-0 border-2 border-primary bg-primary/10" />
            <div className="absolute -top-6 left-0 bg-primary text-white text-xs px-2 py-1 rounded">
              {currentElement.tagName}
              {currentElement.id && `#${currentElement.id}`}
            </div>
          </motion.div>
        )}
      </motion.div>
    </AnimatePresence>
  )
} 