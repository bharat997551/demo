import React from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Shield,
  Plus,
  Edit,
  Trash2,
  Eye,
  EyeOff,
  Copy,
  Key,
  Globe,
  Server,
  Database,
  Lock,
  CheckCircle,
  AlertCircle,
  Settings,
  Download,
  Upload,
  RefreshCw
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Switch } from '@/components/ui/switch'
import { Textarea } from '@/components/ui/textarea'
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'

interface EnvironmentProfile {
  id: string
  name: string
  type: 'DEV' | 'UAT' | 'PROD' | 'CUSTOM'
  isDefault?: boolean
  variables: Array<{
    key: string
    value: string
    isMasked: boolean
  }>
  endpoints: {
    baseUrl?: string
    apiUrl?: string
    webUrl?: string
    mainframeHost?: string
  }
  credentials: Array<{
    id: string
    type: string
    name: string
    data: any
  }>
}

interface SecureVariable {
  id: string
  name: string
  value: string
  isMasked: boolean
  maskInExports: boolean
  environmentId?: string
  description?: string
  tags?: string[]
  lastAccessedAt?: Date
}

interface EnvironmentManagerProps {
  projectId: string
  className?: string
}

export function EnvironmentManager({ projectId, className }: EnvironmentManagerProps) {
  const [profiles, setProfiles] = React.useState<EnvironmentProfile[]>([])
  const [variables, setVariables] = React.useState<SecureVariable[]>([])
  const [selectedProfile, setSelectedProfile] = React.useState<string>('')
  const [showValues, setShowValues] = React.useState<Record<string, boolean>>({})
  const [isLoading, setIsLoading] = React.useState(false)
  const [activeTab, setActiveTab] = React.useState('profiles')

  // Mock data for demonstration
  React.useEffect(() => {
    const mockProfiles: EnvironmentProfile[] = [
      {
        id: '1',
        name: 'Development',
        type: 'DEV',
        isDefault: true,
        variables: [
          { key: 'API_URL', value: 'https://dev-api.example.com', isMasked: false },
          { key: 'DB_PASSWORD', value: '********', isMasked: true }
        ],
        endpoints: {
          baseUrl: 'https://dev.example.com',
          apiUrl: 'https://dev-api.example.com',
          webUrl: 'https://dev-app.example.com'
        },
        credentials: [
          {
            id: '1',
            type: 'basic',
            name: 'API Credentials',
            data: { username: 'dev_user', password: '********' }
          }
        ]
      },
      {
        id: '2',
        name: 'Production',
        type: 'PROD',
        variables: [
          { key: 'API_URL', value: 'https://api.example.com', isMasked: false },
          { key: 'DB_PASSWORD', value: '********', isMasked: true }
        ],
        endpoints: {
          baseUrl: 'https://example.com',
          apiUrl: 'https://api.example.com',
          webUrl: 'https://app.example.com'
        },
        credentials: [
          {
            id: '2',
            type: 'bearer',
            name: 'API Token',
            data: { token: '********' }
          }
        ]
      }
    ]

    const mockVariables: SecureVariable[] = [
      {
        id: '1',
        name: 'API_KEY',
        value: 'sk-1234567890abcdef',
        isMasked: true,
        maskInExports: true,
        description: 'Main API key for external services',
        tags: ['api', 'production'],
        lastAccessedAt: new Date()
      },
      {
        id: '2',
        name: 'DATABASE_URL',
        value: 'postgres://user:pass@localhost:5432/db',
        isMasked: true,
        maskInExports: true,
        environmentId: '1',
        description: 'Database connection string',
        tags: ['database', 'dev']
      }
    ]

    setProfiles(mockProfiles)
    setVariables(mockVariables)
    setSelectedProfile(mockProfiles[0].id)
  }, [])

  const handleToggleValue = (id: string) => {
    setShowValues(prev => ({ ...prev, [id]: !prev[id] }))
  }

  const handleCopyValue = (value: string) => {
    navigator.clipboard.writeText(value)
  }

  const getEnvironmentIcon = (type: string) => {
    switch (type) {
      case 'DEV':
        return <Server className="h-4 w-4" />
      case 'UAT':
        return <Database className="h-4 w-4" />
      case 'PROD':
        return <Globe className="h-4 w-4" />
      default:
        return <Settings className="h-4 w-4" />
    }
  }

  const getEnvironmentColor = (type: string) => {
    switch (type) {
      case 'DEV':
        return 'text-blue-500'
      case 'UAT':
        return 'text-yellow-500'
      case 'PROD':
        return 'text-red-500'
      default:
        return 'text-gray-500'
    }
  }

  const maskValue = (value: string, show: boolean) => {
    if (show) return value
    if (value.length <= 8) return '********'
    return `${value.substring(0, 2)}****${value.substring(value.length - 2)}`
  }

  const AddVariableDialog = () => {
    const [newVar, setNewVar] = React.useState({
      name: '',
      value: '',
      description: '',
      isMasked: true,
      maskInExports: true
    })

    return (
      <Dialog>
        <DialogTrigger asChild>
          <Button size="sm" className="gap-2">
            <Plus className="h-4 w-4" />
            Add Variable
          </Button>
        </DialogTrigger>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Add Secure Variable</DialogTitle>
            <DialogDescription>
              Create a new secure variable that will be encrypted at rest
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="name">Variable Name</Label>
              <Input
                id="name"
                placeholder="API_KEY"
                value={newVar.name}
                onChange={(e) => setNewVar({ ...newVar, name: e.target.value })}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="value">Value</Label>
              <Input
                id="value"
                type="password"
                placeholder="Enter secure value"
                value={newVar.value}
                onChange={(e) => setNewVar({ ...newVar, value: e.target.value })}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="description">Description (Optional)</Label>
              <Textarea
                id="description"
                placeholder="What is this variable used for?"
                value={newVar.description}
                onChange={(e) => setNewVar({ ...newVar, description: e.target.value })}
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Switch
                  id="masked"
                  checked={newVar.isMasked}
                  onCheckedChange={(checked) => setNewVar({ ...newVar, isMasked: checked })}
                />
                <Label htmlFor="masked">Mask in UI</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Switch
                  id="maskExports"
                  checked={newVar.maskInExports}
                  onCheckedChange={(checked) => setNewVar({ ...newVar, maskInExports: checked })}
                />
                <Label htmlFor="maskExports">Mask in exports</Label>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button type="submit">
              <Lock className="h-4 w-4 mr-2" />
              Create Secure Variable
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    )
  }

  const AddProfileDialog = () => {
    const [newProfile, setNewProfile] = React.useState({
      name: '',
      type: 'DEV' as const,
      baseUrl: '',
      apiUrl: '',
      webUrl: ''
    })

    return (
      <Dialog>
        <DialogTrigger asChild>
          <Button size="sm" className="gap-2">
            <Plus className="h-4 w-4" />
            Add Profile
          </Button>
        </DialogTrigger>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Create Environment Profile</DialogTitle>
            <DialogDescription>
              Define endpoints and settings for a new environment
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="profileName">Profile Name</Label>
                <Input
                  id="profileName"
                  placeholder="Development"
                  value={newProfile.name}
                  onChange={(e) => setNewProfile({ ...newProfile, name: e.target.value })}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="profileType">Environment Type</Label>
                <Select
                  value={newProfile.type}
                  onValueChange={(value) => setNewProfile({ ...newProfile, type: value as any })}
                >
                  <SelectTrigger id="profileType">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="DEV">Development</SelectItem>
                    <SelectItem value="UAT">UAT / Staging</SelectItem>
                    <SelectItem value="PROD">Production</SelectItem>
                    <SelectItem value="CUSTOM">Custom</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="baseUrl">Base URL</Label>
              <Input
                id="baseUrl"
                placeholder="https://dev.example.com"
                value={newProfile.baseUrl}
                onChange={(e) => setNewProfile({ ...newProfile, baseUrl: e.target.value })}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="apiUrl">API URL</Label>
              <Input
                id="apiUrl"
                placeholder="https://api-dev.example.com"
                value={newProfile.apiUrl}
                onChange={(e) => setNewProfile({ ...newProfile, apiUrl: e.target.value })}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="webUrl">Web App URL</Label>
              <Input
                id="webUrl"
                placeholder="https://app-dev.example.com"
                value={newProfile.webUrl}
                onChange={(e) => setNewProfile({ ...newProfile, webUrl: e.target.value })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="submit">
              <Shield className="h-4 w-4 mr-2" />
              Create Profile
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    )
  }

  return (
    <TooltipProvider>
      <div className={cn("space-y-6", className)}>
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold">Environment & Security</h2>
            <p className="text-muted-foreground">
              Manage environment profiles, secure variables, and credentials
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm">
              <Upload className="h-4 w-4 mr-2" />
              Import
            </Button>
            <Button variant="outline" size="sm">
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
          </div>
        </div>

        {/* Security Status */}
        <Card>
          <CardContent className="pt-6">
            <div className="grid grid-cols-4 gap-4">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-green-500/10 flex items-center justify-center">
                  <CheckCircle className="h-5 w-5 text-green-500" />
                </div>
                <div>
                  <p className="text-sm font-medium">Encryption</p>
                  <p className="text-xs text-muted-foreground">DPAPI Active</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-blue-500/10 flex items-center justify-center">
                  <Shield className="h-5 w-5 text-blue-500" />
                </div>
                <div>
                  <p className="text-sm font-medium">12 Secrets</p>
                  <p className="text-xs text-muted-foreground">Stored securely</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-yellow-500/10 flex items-center justify-center">
                  <Key className="h-5 w-5 text-yellow-500" />
                </div>
                <div>
                  <p className="text-sm font-medium">3 Profiles</p>
                  <p className="text-xs text-muted-foreground">Configured</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-purple-500/10 flex items-center justify-center">
                  <RefreshCw className="h-5 w-5 text-purple-500" />
                </div>
                <div>
                  <p className="text-sm font-medium">Auto-rotate</p>
                  <p className="text-xs text-muted-foreground">Every 90 days</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList>
            <TabsTrigger value="profiles">Environment Profiles</TabsTrigger>
            <TabsTrigger value="variables">Secure Variables</TabsTrigger>
            <TabsTrigger value="credentials">Credentials</TabsTrigger>
            <TabsTrigger value="audit">Audit Log</TabsTrigger>
          </TabsList>

          <TabsContent value="profiles" className="mt-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold">Environment Profiles</h3>
                <AddProfileDialog />
              </div>

              <div className="grid gap-4">
                {profiles.map((profile) => (
                  <Card key={profile.id} className={cn(
                    "cursor-pointer transition-colors",
                    selectedProfile === profile.id && "ring-2 ring-primary"
                  )}>
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className={cn("h-10 w-10 rounded-full bg-muted flex items-center justify-center", getEnvironmentColor(profile.type))}>
                            {getEnvironmentIcon(profile.type)}
                          </div>
                          <div>
                            <CardTitle className="text-base flex items-center gap-2">
                              {profile.name}
                              {profile.isDefault && (
                                <Badge variant="secondary" className="text-xs">Default</Badge>
                              )}
                            </CardTitle>
                            <CardDescription>{profile.type} Environment</CardDescription>
                          </div>
                        </div>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm">
                              <Settings className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem>
                              <Edit className="h-4 w-4 mr-2" />
                              Edit Profile
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Copy className="h-4 w-4 mr-2" />
                              Duplicate
                            </DropdownMenuItem>
                            {!profile.isDefault && (
                              <>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem className="text-destructive">
                                  <Trash2 className="h-4 w-4 mr-2" />
                                  Delete
                                </DropdownMenuItem>
                              </>
                            )}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div>
                          <p className="text-sm font-medium mb-1">Endpoints</p>
                          <div className="space-y-1 text-sm text-muted-foreground">
                            {profile.endpoints.baseUrl && (
                              <p>Base: {profile.endpoints.baseUrl}</p>
                            )}
                            {profile.endpoints.apiUrl && (
                              <p>API: {profile.endpoints.apiUrl}</p>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center gap-4 text-sm">
                          <span>{profile.variables.length} Variables</span>
                          <span>•</span>
                          <span>{profile.credentials.length} Credentials</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="variables" className="mt-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold">Secure Variables</h3>
                <AddVariableDialog />
              </div>

              <Card>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Value</TableHead>
                      <TableHead>Environment</TableHead>
                      <TableHead>Last Accessed</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {variables.map((variable) => (
                      <TableRow key={variable.id}>
                        <TableCell>
                          <div>
                            <p className="font-medium">{variable.name}</p>
                            {variable.description && (
                              <p className="text-xs text-muted-foreground">{variable.description}</p>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <code className="text-sm">
                              {maskValue(variable.value, showValues[variable.id])}
                            </code>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-6 w-6"
                                  onClick={() => handleToggleValue(variable.id)}
                                >
                                  {showValues[variable.id] ? (
                                    <EyeOff className="h-3 w-3" />
                                  ) : (
                                    <Eye className="h-3 w-3" />
                                  )}
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>
                                {showValues[variable.id] ? 'Hide' : 'Show'} value
                              </TooltipContent>
                            </Tooltip>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-6 w-6"
                                  onClick={() => handleCopyValue(variable.value)}
                                >
                                  <Copy className="h-3 w-3" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>Copy value</TooltipContent>
                            </Tooltip>
                          </div>
                        </TableCell>
                        <TableCell>
                          {variable.environmentId ? (
                            <Badge variant="outline">
                              {profiles.find(p => p.id === variable.environmentId)?.name}
                            </Badge>
                          ) : (
                            <span className="text-sm text-muted-foreground">All</span>
                          )}
                        </TableCell>
                        <TableCell>
                          {variable.lastAccessedAt ? (
                            <span className="text-sm text-muted-foreground">
                              {new Date(variable.lastAccessedAt).toLocaleDateString()}
                            </span>
                          ) : (
                            <span className="text-sm text-muted-foreground">Never</span>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm">
                                <Settings className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem>
                                <Edit className="h-4 w-4 mr-2" />
                                Edit
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <RefreshCw className="h-4 w-4 mr-2" />
                                Rotate
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem className="text-destructive">
                                <Trash2 className="h-4 w-4 mr-2" />
                                Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="credentials" className="mt-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold">Credentials</h3>
                <Button size="sm" className="gap-2">
                  <Plus className="h-4 w-4" />
                  Add Credential
                </Button>
              </div>

              <div className="grid gap-4">
                {profiles
                  .find(p => p.id === selectedProfile)
                  ?.credentials.map((cred) => (
                    <Card key={cred.id}>
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="h-10 w-10 rounded-full bg-muted flex items-center justify-center">
                              <Key className="h-5 w-5 text-muted-foreground" />
                            </div>
                            <div>
                              <CardTitle className="text-base">{cred.name}</CardTitle>
                              <CardDescription>Type: {cred.type}</CardDescription>
                            </div>
                          </div>
                          <Badge variant="outline">Active</Badge>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2">
                          {Object.entries(cred.data).map(([key, value]) => (
                            <div key={key} className="flex items-center justify-between">
                              <span className="text-sm text-muted-foreground">{key}:</span>
                              <code className="text-sm">{value}</code>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="audit" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Access Audit Log</CardTitle>
                <CardDescription>
                  Track all access to secure variables and credentials
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Timestamp</TableHead>
                      <TableHead>User</TableHead>
                      <TableHead>Action</TableHead>
                      <TableHead>Resource</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell>2024-01-10 14:23:45</TableCell>
                      <TableCell>john.doe@example.com</TableCell>
                      <TableCell>Decrypt</TableCell>
                      <TableCell>API_KEY</TableCell>
                      <TableCell>
                        <Badge variant="success">Success</Badge>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell>2024-01-10 14:20:12</TableCell>
                      <TableCell>jane.smith@example.com</TableCell>
                      <TableCell>Create</TableCell>
                      <TableCell>DATABASE_URL</TableCell>
                      <TableCell>
                        <Badge variant="success">Success</Badge>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell>2024-01-10 13:15:30</TableCell>
                      <TableCell>system</TableCell>
                      <TableCell>Rotate</TableCell>
                      <TableCell>API_TOKEN</TableCell>
                      <TableCell>
                        <Badge variant="success">Success</Badge>
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </TooltipProvider>
  )
} 