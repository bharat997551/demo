import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Checkbox } from '@/components/ui/checkbox';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Shield, BarChart3, Bug, Activity } from 'lucide-react';

interface TelemetryOption {
  id: keyof ConsentOptions;
  label: string;
  description: string;
  icon: React.ReactNode;
}

interface ConsentOptions {
  telemetryEnabled: boolean;
  errorReporting: boolean;
  performanceMetrics: boolean;
  usageAnalytics: boolean;
}

interface TelemetryConsentDialogProps {
  open: boolean;
  onConsent: (options: ConsentOptions) => void;
  onDecline: () => void;
}

export function TelemetryConsentDialog({
  open,
  onConsent,
  onDecline,
}: TelemetryConsentDialogProps) {
  const [options, setOptions] = useState<ConsentOptions>({
    telemetryEnabled: true,
    errorReporting: true,
    performanceMetrics: true,
    usageAnalytics: true,
  });

  const telemetryOptions: TelemetryOption[] = [
    {
      id: 'errorReporting',
      label: 'Error Reporting',
      description: 'Help us fix crashes and errors by sending anonymous error reports',
      icon: <Bug className="w-5 h-5" />,
    },
    {
      id: 'performanceMetrics',
      label: 'Performance Metrics',
      description: 'Share performance data to help us optimize the application',
      icon: <Activity className="w-5 h-5" />,
    },
    {
      id: 'usageAnalytics',
      label: 'Usage Analytics',
      description: 'Help us understand which features are used most',
      icon: <BarChart3 className="w-5 h-5" />,
    },
  ];

  const handleOptionChange = (optionId: keyof ConsentOptions, checked: boolean) => {
    setOptions(prev => ({
      ...prev,
      [optionId]: checked,
    }));
  };

  const handleAcceptAll = () => {
    const allEnabled = {
      telemetryEnabled: true,
      errorReporting: true,
      performanceMetrics: true,
      usageAnalytics: true,
    };
    onConsent(allEnabled);
  };

  const handleAcceptSelected = () => {
    onConsent({
      ...options,
      telemetryEnabled: options.errorReporting || options.performanceMetrics || options.usageAnalytics,
    });
  };

  const handleDeclineAll = () => {
    onDecline();
  };

  return (
    <Dialog open={open} onOpenChange={() => {}}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <div className="flex items-center gap-3">
            <Shield className="w-6 h-6 text-primary" />
            <DialogTitle>Help Improve Hybrid QA</DialogTitle>
          </div>
          <DialogDescription className="text-left pt-3">
            We'd like to collect anonymous usage data to improve Hybrid QA. This helps us
            understand how the application is used and identify issues. All data is anonymized
            and no personal information is collected.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <Alert>
            <Shield className="w-4 h-4" />
            <AlertDescription>
              <strong>Privacy First:</strong> We never collect personal data, file contents,
              test data, or any information that could identify you or your organization.
            </AlertDescription>
          </Alert>

          <div className="space-y-3">
            {telemetryOptions.map((option) => (
              <div
                key={option.id}
                className="flex items-start space-x-3 p-3 rounded-lg border bg-card"
              >
                <Checkbox
                  id={option.id}
                  checked={options[option.id]}
                  onCheckedChange={(checked) =>
                    handleOptionChange(option.id, checked as boolean)
                  }
                  className="mt-1"
                />
                <div className="flex-1 space-y-1">
                  <div className="flex items-center gap-2">
                    {option.icon}
                    <Label htmlFor={option.id} className="font-medium cursor-pointer">
                      {option.label}
                    </Label>
                  </div>
                  <p className="text-sm text-muted-foreground">{option.description}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="text-sm text-muted-foreground space-y-2">
            <p>You can change these settings at any time in Preferences → Privacy.</p>
            <p>
              For more information, see our{' '}
              <button
                className="text-primary underline"
                onClick={() => window.electronAPI.openExternal('https://hybridqa.io/privacy')}
              >
                Privacy Policy
              </button>
              .
            </p>
          </div>
        </div>

        <DialogFooter className="flex gap-2 sm:gap-2">
          <Button variant="ghost" onClick={handleDeclineAll}>
            No Thanks
          </Button>
          <Button variant="outline" onClick={handleAcceptSelected}>
            Accept Selected
          </Button>
          <Button onClick={handleAcceptAll}>Accept All</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// Settings panel for managing telemetry preferences
export function TelemetrySettings() {
  const [consent, setConsent] = useState<ConsentOptions>({
    telemetryEnabled: false,
    errorReporting: false,
    performanceMetrics: false,
    usageAnalytics: false,
  });

  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  React.useEffect(() => {
    loadConsentSettings();
  }, []);

  const loadConsentSettings = async () => {
    try {
      const settings = await window.electronAPI.getTelemetryConsent();
      setConsent(settings.options);
      setLastUpdated(settings.consentedAt ? new Date(settings.consentedAt) : null);
    } catch (error) {
      console.error('Failed to load telemetry settings:', error);
    }
  };

  const handleConsentChange = async (optionId: keyof ConsentOptions, checked: boolean) => {
    const newConsent = {
      ...consent,
      [optionId]: checked,
    };

    // If all options are disabled, disable telemetry entirely
    if (!newConsent.errorReporting && !newConsent.performanceMetrics && !newConsent.usageAnalytics) {
      newConsent.telemetryEnabled = false;
    } else {
      newConsent.telemetryEnabled = true;
    }

    try {
      await window.electronAPI.updateTelemetryConsent(newConsent);
      setConsent(newConsent);
      setLastUpdated(new Date());
    } catch (error) {
      console.error('Failed to update telemetry settings:', error);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Privacy & Telemetry</CardTitle>
        <CardDescription>
          Manage what anonymous data is shared to help improve Hybrid QA
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <Label htmlFor="telemetry">Enable Telemetry</Label>
              <p className="text-sm text-muted-foreground">
                Share anonymous usage data to help improve Hybrid QA
              </p>
            </div>
            <Switch
              id="telemetry"
              checked={consent.telemetryEnabled}
              onCheckedChange={(checked) => {
                if (!checked) {
                  // Disable all when turning off telemetry
                  handleConsentChange('telemetryEnabled', false);
                  handleConsentChange('errorReporting', false);
                  handleConsentChange('performanceMetrics', false);
                  handleConsentChange('usageAnalytics', false);
                } else {
                  handleConsentChange('telemetryEnabled', true);
                }
              }}
            />
          </div>

          {consent.telemetryEnabled && (
            <>
              <Separator />
              <div className="space-y-3 pl-6">
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <Label htmlFor="errors">Error Reporting</Label>
                    <p className="text-sm text-muted-foreground">
                      Send crash reports and errors
                    </p>
                  </div>
                  <Switch
                    id="errors"
                    checked={consent.errorReporting}
                    onCheckedChange={(checked) =>
                      handleConsentChange('errorReporting', checked)
                    }
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <Label htmlFor="performance">Performance Metrics</Label>
                    <p className="text-sm text-muted-foreground">
                      Share performance and timing data
                    </p>
                  </div>
                  <Switch
                    id="performance"
                    checked={consent.performanceMetrics}
                    onCheckedChange={(checked) =>
                      handleConsentChange('performanceMetrics', checked)
                    }
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <Label htmlFor="usage">Usage Analytics</Label>
                    <p className="text-sm text-muted-foreground">
                      Share feature usage statistics
                    </p>
                  </div>
                  <Switch
                    id="usage"
                    checked={consent.usageAnalytics}
                    onCheckedChange={(checked) =>
                      handleConsentChange('usageAnalytics', checked)
                    }
                  />
                </div>
              </div>
            </>
          )}
        </div>

        {lastUpdated && (
          <p className="text-xs text-muted-foreground">
            Last updated: {lastUpdated.toLocaleDateString()}
          </p>
        )}

        <Alert>
          <Shield className="w-4 h-4" />
          <AlertDescription className="text-sm">
            No personal information is ever collected. All data is anonymized before
            transmission. Read our{' '}
            <button
              className="text-primary underline"
              onClick={() => window.electronAPI.openExternal('https://hybridqa.io/privacy')}
            >
              Privacy Policy
            </button>{' '}
            for more details.
          </AlertDescription>
        </Alert>
      </CardContent>
    </Card>
  );
}

// Missing imports
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator'; 