import React, { useState, useEffect } from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { InfoIcon, Download, Trash2 } from 'lucide-react';

interface LoggingSettings {
  level: 'trace' | 'debug' | 'info' | 'warn' | 'error' | 'fatal';
  pretty: boolean;
  toFile: boolean;
  maxFileSize: number; // MB
  maxFiles: number;
  redactSensitive: boolean;
}

interface LoggingSettingsProps {
  onSettingsChange?: (settings: LoggingSettings) => void;
}

export function LoggingSettings({ onSettingsChange }: LoggingSettingsProps) {
  const [settings, setSettings] = useState<LoggingSettings>({
    level: 'info',
    pretty: true,
    toFile: false,
    maxFileSize: 10,
    maxFiles: 5,
    redactSensitive: true,
  });

  const [logStats, setLogStats] = useState({
    currentFileSize: 0,
    totalFiles: 0,
    oldestLog: null as Date | null,
  });

  useEffect(() => {
    // Load current settings
    loadSettings();
    // Load log statistics
    loadLogStats();
  }, []);

  useEffect(() => {
    onSettingsChange?.(settings);
  }, [settings, onSettingsChange]);

  const loadSettings = async () => {
    try {
      const saved = await window.electronAPI.getSettings('logging');
      if (saved) {
        setSettings(saved);
      }
    } catch (error) {
      console.error('Failed to load logging settings:', error);
    }
  };

  const loadLogStats = async () => {
    try {
      const stats = await window.electronAPI.getLogStats();
      setLogStats(stats);
    } catch (error) {
      console.error('Failed to load log stats:', error);
    }
  };

  const handleLevelChange = (level: string) => {
    setSettings(prev => ({ ...prev, level: level as LoggingSettings['level'] }));
  };

  const handleSave = async () => {
    try {
      await window.electronAPI.saveSettings('logging', settings);
      // Apply settings immediately
      await window.electronAPI.applyLogSettings(settings);
    } catch (error) {
      console.error('Failed to save logging settings:', error);
    }
  };

  const handleExportLogs = async () => {
    try {
      const result = await window.electronAPI.showSaveDialog({
        defaultPath: `hybrid-qa-logs-${new Date().toISOString().split('T')[0]}.zip`,
        filters: [{ name: 'ZIP Archive', extensions: ['zip'] }],
      });

      if (!result.canceled && result.filePath) {
        await window.electronAPI.exportLogs(result.filePath);
      }
    } catch (error) {
      console.error('Failed to export logs:', error);
    }
  };

  const handleClearLogs = async () => {
    const result = await window.electronAPI.showMessageBox({
      type: 'warning',
      buttons: ['Cancel', 'Clear Logs'],
      defaultId: 0,
      message: 'Clear all log files?',
      detail: 'This action cannot be undone.',
    });

    if (result.response === 1) {
      try {
        await window.electronAPI.clearLogs();
        loadLogStats();
      } catch (error) {
        console.error('Failed to clear logs:', error);
      }
    }
  };

  const logLevels = [
    { value: 'trace', label: 'Trace', description: 'Most verbose - all details' },
    { value: 'debug', label: 'Debug', description: 'Debugging information' },
    { value: 'info', label: 'Info', description: 'General information' },
    { value: 'warn', label: 'Warning', description: 'Warning messages' },
    { value: 'error', label: 'Error', description: 'Error messages only' },
    { value: 'fatal', label: 'Fatal', description: 'Critical errors only' },
  ];

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Logging Configuration</CardTitle>
          <CardDescription>
            Configure how Hybrid QA logs information for debugging and monitoring
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Log Level Selection */}
          <div className="space-y-3">
            <Label>Log Level</Label>
            <RadioGroup value={settings.level} onValueChange={handleLevelChange}>
              {logLevels.map((level) => (
                <div key={level.value} className="flex items-start space-x-3">
                  <RadioGroupItem value={level.value} id={level.value} />
                  <div className="space-y-1">
                    <Label htmlFor={level.value} className="font-normal cursor-pointer">
                      {level.label}
                    </Label>
                    <p className="text-sm text-muted-foreground">{level.description}</p>
                  </div>
                </div>
              ))}
            </RadioGroup>
          </div>

          {/* Log Format */}
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <Label htmlFor="pretty">Pretty Print Logs</Label>
              <p className="text-sm text-muted-foreground">
                Human-readable format (slower but easier to read)
              </p>
            </div>
            <Switch
              id="pretty"
              checked={settings.pretty}
              onCheckedChange={(checked) =>
                setSettings(prev => ({ ...prev, pretty: checked }))
              }
            />
          </div>

          {/* File Logging */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label htmlFor="toFile">Save Logs to File</Label>
                <p className="text-sm text-muted-foreground">
                  Persist logs for later analysis
                </p>
              </div>
              <Switch
                id="toFile"
                checked={settings.toFile}
                onCheckedChange={(checked) =>
                  setSettings(prev => ({ ...prev, toFile: checked }))
                }
              />
            </div>

            {settings.toFile && (
              <div className="space-y-4 pl-6">
                <div className="space-y-2">
                  <Label>Max File Size: {settings.maxFileSize} MB</Label>
                  <Slider
                    value={[settings.maxFileSize]}
                    onValueChange={([value]) =>
                      setSettings(prev => ({ ...prev, maxFileSize: value }))
                    }
                    min={1}
                    max={100}
                    step={1}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Max Files to Keep: {settings.maxFiles}</Label>
                  <Slider
                    value={[settings.maxFiles]}
                    onValueChange={([value]) =>
                      setSettings(prev => ({ ...prev, maxFiles: value }))
                    }
                    min={1}
                    max={20}
                    step={1}
                  />
                </div>
              </div>
            )}
          </div>

          {/* Security */}
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <Label htmlFor="redact">Redact Sensitive Data</Label>
              <p className="text-sm text-muted-foreground">
                Automatically mask passwords, tokens, and other sensitive information
              </p>
            </div>
            <Switch
              id="redact"
              checked={settings.redactSensitive}
              onCheckedChange={(checked) =>
                setSettings(prev => ({ ...prev, redactSensitive: checked }))
              }
            />
          </div>

          {/* Save Button */}
          <Button onClick={handleSave} className="w-full">
            Save Settings
          </Button>
        </CardContent>
      </Card>

      {/* Log Management */}
      <Card>
        <CardHeader>
          <CardTitle>Log Management</CardTitle>
          <CardDescription>
            Export or clear application logs
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {logStats.totalFiles > 0 && (
            <Alert>
              <InfoIcon className="h-4 w-4" />
              <AlertDescription>
                {logStats.totalFiles} log file{logStats.totalFiles > 1 ? 's' : ''} using{' '}
                {(logStats.currentFileSize / 1024 / 1024).toFixed(2)} MB
                {logStats.oldestLog && (
                  <>
                    . Oldest log from{' '}
                    {new Date(logStats.oldestLog).toLocaleDateString()}
                  </>
                )}
              </AlertDescription>
            </Alert>
          )}

          <div className="flex gap-3">
            <Button
              variant="outline"
              className="flex-1"
              onClick={handleExportLogs}
              disabled={logStats.totalFiles === 0}
            >
              <Download className="w-4 h-4 mr-2" />
              Export Logs
            </Button>
            <Button
              variant="outline"
              className="flex-1"
              onClick={handleClearLogs}
              disabled={logStats.totalFiles === 0}
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Clear Logs
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
} 