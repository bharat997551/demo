import { app } from 'electron';
import * as fs from 'fs';
import * as path from 'path';

const FIRST_RUN_FILE = path.join(app.getPath('userData'), '.first-run-complete');

export function isFirstRun(): boolean {
  try {
    // Check if first-run file exists
    return !fs.existsSync(FIRST_RUN_FILE);
  } catch (error) {
    console.error('Error checking first run status:', error);
    return false;
  }
}

export function markFirstRunComplete(): void {
  try {
    // Create the file to mark first run as complete
    fs.writeFileSync(FIRST_RUN_FILE, new Date().toISOString());
  } catch (error) {
    console.error('Error marking first run complete:', error);
  }
}

export function resetFirstRun(): void {
  try {
    // Delete the first-run file to reset
    if (fs.existsSync(FIRST_RUN_FILE)) {
      fs.unlinkSync(FIRST_RUN_FILE);
    }
  } catch (error) {
    console.error('Error resetting first run:', error);
  }
}

// Check Python installation
export async function checkPythonInstallation(): Promise<{
  installed: boolean;
  version?: string;
  path?: string;
}> {
  const { exec } = require('child_process');
  const { promisify } = require('util');
  const execAsync = promisify(exec);

  try {
    const { stdout } = await execAsync('python --version');
    const version = stdout.trim().replace('Python ', '');
    const { stdout: pathOut } = await execAsync('where python');
    const pythonPath = pathOut.trim().split('\n')[0];

    return {
      installed: true,
      version,
      path: pythonPath
    };
  } catch (error) {
    return { installed: false };
  }
}

// Check Playwright browsers
export async function checkPlaywrightBrowsers(): Promise<boolean> {
  const playwrightPath = path.join(
    app.getPath('userData'),
    'ms-playwright'
  );
  
  try {
    return fs.existsSync(playwrightPath);
  } catch {
    return false;
  }
}

// Check s3270 installation
export async function checkS3270Installation(): Promise<boolean> {
  const { exec } = require('child_process');
  const { promisify } = require('util');
  const execAsync = promisify(exec);

  try {
    await execAsync('where s3270');
    return true;
  } catch {
    // Check common installation paths
    const commonPaths = [
      'C:\\Program Files\\wc3270\\s3270.exe',
      'C:\\Program Files (x86)\\wc3270\\s3270.exe'
    ];
    
    return commonPaths.some(p => fs.existsSync(p));
  }
}

// Check WinAppDriver
export async function checkWinAppDriver(): Promise<boolean> {
  const paths = [
    'C:\\Program Files\\Windows Application Driver\\WinAppDriver.exe',
    'C:\\Program Files (x86)\\Windows Application Driver\\WinAppDriver.exe'
  ];
  
  return paths.some(p => fs.existsSync(p));
}

// Get system information
export function getSystemInfo() {
  const os = require('os');
  
  return {
    platform: os.platform(),
    arch: os.arch(),
    version: os.release(),
    memory: Math.round(os.totalmem() / (1024 * 1024 * 1024)) + ' GB',
    cpus: os.cpus().length,
    user: os.userInfo().username
  };
} 