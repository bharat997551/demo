# Hybrid QA Desktop App

The main desktop application for Hybrid QA, built with Electron, React, and TypeScript. Provides a modern interface for creating, managing, and executing test automation flows.

## 🚀 Features

- **Modern React UI**: Built with React 18, TypeScript, and Vite for fast development
- **Tailwind CSS**: Utility-first CSS framework for rapid UI development  
- **shadcn/ui Components**: High-quality, accessible UI components
- **Framer Motion**: Smooth animations and transitions
- **Lucide React**: Beautiful, consistent icons
- **Multi-platform**: Cross-platform desktop app using Electron

## 🛠️ Tech Stack

- **Frontend**: React + TypeScript + Vite
- **Styling**: Tailwind CSS + shadcn/ui
- **Icons**: Lucide React  
- **Animation**: Framer Motion
- **Desktop**: Electron
- **Build**: Electron Builder

## 📋 Development

### Prerequisites
- Node.js >= 18.0.0
- pnpm >= 8.0.0

### Setup
\`\`\`bash
# From monorepo root
pnpm install

# Or from this directory
cd apps/desktop
pnpm install
\`\`\`

### Development Scripts
\`\`\`bash
# Start development mode (main + renderer)
pnpm dev

# Start main process only
pnpm dev:main

# Start renderer only (Vite dev server)  
pnpm dev:renderer

# Build for production
pnpm build

# Package as installer
pnpm package

# Preview production build
pnpm preview
\`\`\`

## 🏗️ Project Structure

\`\`\`
src/
├── main/                 # Electron main process
│   ├── main.ts          # Main entry point
│   └── preload.ts       # Preload script for IPC
└── renderer/            # React frontend  
    ├── src/
    │   ├── components/  # React components
    │   ├── pages/       # Page components
    │   ├── hooks/       # Custom hooks
    │   ├── utils/       # Utility functions
    │   ├── App.tsx      # Main app component
    │   └── main.tsx     # React entry point
    ├── index.html       # HTML template
    └── vite.config.ts   # Vite configuration
\`\`\`

## 🔌 IPC Communication

The app communicates with the orchestrator service through IPC (Inter-Process Communication):

\`\`\`typescript
// Available through window.electronAPI
interface ElectronAPI {
  orchestrator: {
    ping: () => Promise<{ status: string; timestamp: string }>;
    getProjects: () => Promise<Project[]>;
    // ... more methods
  };
}
\`\`\`

## 🎨 UI Components

Uses shadcn/ui components with Tailwind CSS:

- **Button**: Primary and secondary action buttons
- **Dialog**: Modal dialogs and overlays
- **DropdownMenu**: Context menus and dropdowns  
- **Tabs**: Tabbed navigation
- **Select**: Dropdown selects

## 🚀 Building & Packaging

### Development Build
\`\`\`bash
pnpm build
\`\`\`

### Production Package
\`\`\`bash
pnpm package
\`\`\`

The packaged installer will be created in the \`release/\` directory.

### Configuration

Electron Builder configuration in \`package.json\`:
- **Windows**: NSIS installer
- **Output**: \`release/\` directory
- **Auto-updater**: Ready for future implementation

## 🧪 Testing

\`\`\`bash
# Run linting
pnpm lint

# Fix linting issues
pnpm lint:fix

# Type checking
pnpm type-check
\`\`\`

## 🔄 Hot Reload

Development mode supports hot reload for both main and renderer processes:
- **Renderer**: Vite dev server with HMR
- **Main**: TypeScript watch mode with auto-restart

## 📝 Notes

- The app loads the renderer from \`http://localhost:5173\` in development
- Production builds use the built renderer files
- IPC communication is set up for secure orchestrator integration
- All UI components follow the design system patterns 