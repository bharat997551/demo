const fs = require('fs-extra');
const path = require('path');
const https = require('https');
const AdmZip = require('adm-zip');
const { execSync } = require('child_process');

const PYTHON_VERSION = '3.11.7';
const PYTHON_EMBED_URL = `https://www.python.org/ftp/python/${PYTHON_VERSION}/python-${PYTHON_VERSION}-embed-amd64.zip`;
const PIP_URL = 'https://bootstrap.pypa.io/get-pip.py';

const BUILD_RESOURCES_DIR = path.join(__dirname, '..', 'build-resources');
const PYTHON_DIR = path.join(BUILD_RESOURCES_DIR, 'python');
const INSTALLERS_DIR = path.join(BUILD_RESOURCES_DIR, 'installers');

async function downloadFile(url, dest) {
  const file = fs.createWriteStream(dest);
  
  return new Promise((resolve, reject) => {
    https.get(url, (response) => {
      if (response.statusCode === 302 || response.statusCode === 301) {
        // Handle redirect
        downloadFile(response.headers.location, dest).then(resolve).catch(reject);
        return;
      }
      
      response.pipe(file);
      file.on('finish', () => {
        file.close();
        resolve();
      });
    }).on('error', (err) => {
      fs.unlink(dest, () => {});
      reject(err);
    });
  });
}

async function preparePython() {
  console.log('Preparing embedded Python...');
  
  // Create directories
  await fs.ensureDir(PYTHON_DIR);
  
  // Download Python embeddable package
  const pythonZip = path.join(PYTHON_DIR, 'python.zip');
  if (!await fs.pathExists(pythonZip)) {
    console.log(`Downloading Python ${PYTHON_VERSION}...`);
    await downloadFile(PYTHON_EMBED_URL, pythonZip);
  }
  
  // Extract Python
  console.log('Extracting Python...');
  const zip = new AdmZip(pythonZip);
  zip.extractAllTo(PYTHON_DIR, true);
  
  // Download get-pip.py
  const getPip = path.join(PYTHON_DIR, 'get-pip.py');
  if (!await fs.pathExists(getPip)) {
    console.log('Downloading pip installer...');
    await downloadFile(PIP_URL, getPip);
  }
  
  // Modify python._pth to allow site-packages
  const pthFile = path.join(PYTHON_DIR, `python${PYTHON_VERSION.replace(/\./g, '')}._pth`);
  if (await fs.pathExists(pthFile)) {
    let content = await fs.readFile(pthFile, 'utf8');
    content = content.replace('#import site', 'import site');
    await fs.writeFile(pthFile, content);
  }
  
  // Clean up zip
  await fs.remove(pythonZip);
}

async function prepareInstallers() {
  console.log('Preparing offline installers...');
  
  await fs.ensureDir(INSTALLERS_DIR);
  
  // Download s3270 installer
  const s3270Installer = path.join(INSTALLERS_DIR, 'wc3270-setup.exe');
  if (!await fs.pathExists(s3270Installer)) {
    console.log('Downloading s3270 installer...');
    // Note: Update URL to latest version
    await downloadFile(
      'https://github.com/your-repo/wc3270-installer.exe',
      s3270Installer
    );
  }
  
  // Create Python bootstrap script
  const bootstrapScript = `
import subprocess
import sys
import os

def setup_venv(venv_path, requirements_file):
    """Create and setup a Python virtual environment"""
    print(f"Creating virtual environment: {venv_path}")
    subprocess.run([sys.executable, "-m", "venv", venv_path], check=True)
    
    # Get pip path
    pip_path = os.path.join(venv_path, "Scripts", "pip.exe")
    
    # Upgrade pip
    print("Upgrading pip...")
    subprocess.run([pip_path, "install", "--upgrade", "pip"], check=True)
    
    # Install requirements
    if os.path.exists(requirements_file):
        print(f"Installing requirements from {requirements_file}")
        subprocess.run([pip_path, "install", "-r", requirements_file], check=True)
    
    print(f"Virtual environment ready: {venv_path}")

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: bootstrap.py <venv_path> <requirements_file>")
        sys.exit(1)
    
    setup_venv(sys.argv[1], sys.argv[2])
`;
  
  await fs.writeFile(
    path.join(PYTHON_DIR, 'bootstrap.py'),
    bootstrapScript
  );
}

async function createOfflinePackages() {
  console.log('Creating offline packages...');
  
  const packagesDir = path.join(BUILD_RESOURCES_DIR, 'offline-packages');
  await fs.ensureDir(packagesDir);
  
  // Download wheels for common packages
  const packages = [
    'pywinauto',
    'psutil',
    'Pillow',
    'numpy',
    'opencv-python',
    'requests',
    'websocket-client'
  ];
  
  console.log('Downloading Python packages for offline installation...');
  for (const pkg of packages) {
    try {
      execSync(
        `pip download ${pkg} --dest "${packagesDir}" --platform win_amd64 --python-version 311 --only-binary :all:`,
        { stdio: 'inherit' }
      );
    } catch (error) {
      console.warn(`Failed to download ${pkg}: ${error.message}`);
    }
  }
}

async function createBuildInfo() {
  const buildInfo = {
    version: require('../package.json').version,
    buildDate: new Date().toISOString(),
    pythonVersion: PYTHON_VERSION,
    platform: process.platform,
    arch: process.arch,
    node: process.version
  };
  
  await fs.writeJSON(
    path.join(BUILD_RESOURCES_DIR, 'build-info.json'),
    buildInfo,
    { spaces: 2 }
  );
}

async function main() {
  console.log('Preparing build resources...');
  
  try {
    await fs.ensureDir(BUILD_RESOURCES_DIR);
    
    // Prepare Python
    await preparePython();
    
    // Prepare installers
    await prepareInstallers();
    
    // Create offline packages
    await createOfflinePackages();
    
    // Create build info
    await createBuildInfo();
    
    console.log('Build preparation complete!');
  } catch (error) {
    console.error('Build preparation failed:', error);
    process.exit(1);
  }
}

// Run if called directly
if (require.main === module) {
  main();
}

module.exports = { preparePython, prepareInstallers, createOfflinePackages }; 