const builder = require('electron-builder');
const path = require('path');
const fs = require('fs-extra');
const { preparePython, prepareInstallers, createOfflinePackages } = require('./prepare-build');

async function buildInstallers() {
  console.log('Building Hybrid QA installers...');
  
  // Prepare build resources
  await preparePython();
  await prepareInstallers();
  
  const baseConfig = {
    config: path.join(__dirname, '..', 'electron-builder.yml'),
    publish: 'never' // Don't publish during build
  };
  
  // Build configurations
  const builds = [
    {
      name: 'Standard Installer',
      config: {
        ...baseConfig,
        win: ['nsis']
      }
    },
    {
      name: 'Portable Version',
      config: {
        ...baseConfig,
        win: ['portable']
      }
    },
    {
      name: 'Airgap Installer',
      config: {
        ...baseConfig,
        win: ['nsis'],
        extraMetadata: {
          name: 'hybrid-qa-airgap',
          productName: 'Hybrid QA (Airgap)'
        }
      },
      prepare: async () => {
        // Include offline packages for airgap
        await createOfflinePackages();
      }
    }
  ];
  
  // Build each configuration
  for (const build of builds) {
    console.log(`\nBuilding ${build.name}...`);
    
    if (build.prepare) {
      await build.prepare();
    }
    
    try {
      const result = await builder.build(build.config);
      console.log(`${build.name} built successfully:`, result);
    } catch (error) {
      console.error(`Failed to build ${build.name}:`, error);
      throw error;
    }
  }
  
  // Create checksums
  await createChecksums();
  
  console.log('\nAll installers built successfully!');
}

async function createChecksums() {
  const crypto = require('crypto');
  const releaseDir = path.join(__dirname, '..', 'release');
  const files = await fs.readdir(releaseDir);
  
  const checksums = {};
  
  for (const file of files) {
    if (file.endsWith('.exe') || file.endsWith('.zip')) {
      const filePath = path.join(releaseDir, file);
      const fileBuffer = await fs.readFile(filePath);
      const hash = crypto.createHash('sha256').update(fileBuffer).digest('hex');
      checksums[file] = hash;
    }
  }
  
  await fs.writeJSON(
    path.join(releaseDir, 'checksums.json'),
    checksums,
    { spaces: 2 }
  );
  
  // Create checksum text file
  const checksumText = Object.entries(checksums)
    .map(([file, hash]) => `${hash}  ${file}`)
    .join('\n');
  
  await fs.writeFile(
    path.join(releaseDir, 'SHA256SUMS.txt'),
    checksumText
  );
}

// Certificate setup helper
async function setupCertificate() {
  console.log('Setting up code signing certificate...');
  
  const certPath = process.env.WINDOWS_CERTIFICATE_FILE;
  if (!certPath) {
    console.warn('No certificate file specified. The installer will not be signed.');
    console.log('To sign the installer, set these environment variables:');
    console.log('  WINDOWS_CERTIFICATE_FILE - Path to .pfx file');
    console.log('  WINDOWS_CERTIFICATE_PASSWORD - Certificate password');
    return;
  }
  
  if (!await fs.pathExists(certPath)) {
    throw new Error(`Certificate file not found: ${certPath}`);
  }
  
  console.log('Certificate found:', certPath);
}

// Main build function
async function main() {
  try {
    // Setup certificate if available
    await setupCertificate();
    
    // Build installers
    await buildInstallers();
    
    // Print final instructions
    console.log('\n=== Build Complete ===');
    console.log('Installers are available in the release directory:');
    console.log('  - Standard installer: HybridQA-Setup.exe');
    console.log('  - Portable version: HybridQA-Portable.exe');
    console.log('  - Airgap installer: HybridQA-Airgap-Setup.exe');
    console.log('\nChecksums: release/SHA256SUMS.txt');
    
  } catch (error) {
    console.error('Build failed:', error);
    process.exit(1);
  }
}

if (require.main === module) {
  main();
}

module.exports = { buildInstallers, createChecksums }; 