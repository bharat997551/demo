# Security, Secrets & Profiles Implementation

## Overview

I've implemented a comprehensive security system for the Hybrid QA platform that provides:
- **Secure Storage**: Encryption using Windows DPAPI or AES-256-GCM file-based encryption
- **Environment Profiles**: Support for DEV/UAT/PROD environments with isolated configurations
- **Variable Masking**: Automatic masking of sensitive values in UI, logs, and exports
- **Access Control**: Project-based isolation with audit logging

## Architecture

### Core Components

1. **SecureStorageService** (`packages/common/src/security/secure-storage.service.ts`)
   - Main service coordinating encryption/decryption
   - In-memory caching with TTL for performance
   - Project-based access control
   - Comprehensive audit logging

2. **Encryption Providers**
   - **DPAPIProvider**: Uses Windows Data Protection API for maximum security
   - **FileCryptoProvider**: Cross-platform AES-256-GCM encryption
   - **Memory Provider**: For testing/development

3. **Type System** (`packages/common/src/security/types.ts`)
   - Comprehensive TypeScript interfaces
   - Security policies and validation rules
   - Error types for security violations

4. **UI Components** (`apps/desktop/src/renderer/components/security/environment-manager.tsx`)
   - Full-featured environment and secrets management UI
   - Visual masking with show/hide toggles
   - Audit log viewer

## Key Features

### 1. Windows DPAPI Integration

```typescript
// Automatic DPAPI usage on Windows
const storage = new SecureStorageService({
  provider: 'dpapi', // Falls back to file if not available
  storagePath: './secure'
});
```

**Benefits**:
- Hardware-backed encryption when available
- User or machine-level protection
- No key management required
- Automatic key rotation with Windows credentials

### 2. Environment Profiles

```typescript
interface EnvironmentProfile {
  id: string;
  name: string;
  type: 'DEV' | 'UAT' | 'PROD' | 'CUSTOM';
  variables: Array<{
    key: string;
    value: string; // Encrypted
    isMasked: boolean;
  }>;
  endpoints: {
    baseUrl?: string;
    apiUrl?: string;
    webUrl?: string;
    mainframeHost?: string;
  };
  credentials: Array<{
    id: string;
    type: 'basic' | 'bearer' | 'oauth2' | 'apikey';
    name: string;
    data: string; // Encrypted JSON
  }>;
}
```

### 3. Variable Masking

**Automatic Masking**:
- UI display: `sk-12****ef` (shows first/last 2 chars)
- Logs: Values replaced with `****`
- Exports: Configurable per variable

**Masking Configuration**:
```typescript
const maskingConfig: MaskingConfig = {
  enabled: true,
  maskPattern: '****',
  showFirstChars: 2,
  showLastChars: 2,
  excludePatterns: [/^https?:\/\//], // Don't mask URLs
  alwaysMaskPatterns: [/password|secret|key|token/i]
};
```

### 4. Project Isolation

- Secrets are encrypted with project-specific context
- Cross-project access is blocked at the service level
- Each project has its own encryption entropy

### 5. Audit Logging

Every access is logged with:
- Who accessed (user ID)
- What was accessed (secret ID)
- When (timestamp)
- Why (purpose: create/read/decrypt/export)
- From where (IP address)
- Success/failure status

## Security Measures

### Encryption

1. **DPAPI (Windows)**:
   - Uses logged-in user's credentials
   - Optional machine-level encryption
   - Additional entropy from project ID

2. **File-Based (Cross-platform)**:
   - AES-256-GCM authenticated encryption
   - PBKDF2 key derivation (100,000 iterations)
   - Random IV for each encryption
   - Master key protected by passphrase

### Access Control

1. **Context Validation**:
   ```typescript
   const context: SecureContext = {
     projectId: 'project-123',
     environmentId: 'dev',
     userId: 'user@example.com',
     sessionId: 'session-xyz',
     ipAddress: '192.168.1.1'
   };
   ```

2. **Policy Enforcement**:
   ```typescript
   const policy: ProjectSecurityPolicy = {
     projectId: 'project-123',
     allowedEnvironments: ['dev', 'uat'],
     secretRotationDays: 90,
     requireMFA: true,
     allowExportSecrets: false,
     auditAccess: true,
     ipWhitelist: ['192.168.1.0/24']
   };
   ```

### Best Practices Implemented

1. **Defense in Depth**:
   - Encryption at rest
   - Access control layers
   - Audit logging
   - Automatic masking

2. **Secure Defaults**:
   - Masking enabled by default
   - Exports masked unless explicitly allowed
   - Short cache TTL (5 minutes)
   - Automatic cleanup of decrypted values

3. **Key Management**:
   - DPAPI: Managed by Windows
   - File: Master key with optional passphrase
   - Rotation support built-in

## UI Features

The Environment Manager component provides:

1. **Environment Profiles**:
   - Visual environment indicators (colors/icons)
   - Quick switch between environments
   - Endpoint configuration per environment

2. **Secure Variables**:
   - Add/edit with description and tags
   - Show/hide values with one click
   - Copy to clipboard (with audit log)
   - Last accessed tracking

3. **Credentials Management**:
   - Multiple credential types
   - Environment-specific credentials
   - Visual status indicators

4. **Audit Log Viewer**:
   - Filterable by date, user, action
   - Success/failure tracking
   - Export capability

## Usage Examples

### Store a Secret

```typescript
const storage = new SecureStorageService({
  provider: 'dpapi',
  storagePath: './secure'
});

await storage.initialize();

const variable = await storage.storeVariable({
  name: 'API_KEY',
  value: 'sk-1234567890abcdef',
  projectId: 'my-project',
  isMasked: true,
  maskInExports: true,
  description: 'Production API key'
}, context);
```

### Create Environment Profile

```typescript
const profile = await storage.storeEnvironmentProfile({
  name: 'Production',
  projectId: 'my-project',
  type: 'PROD',
  variables: [
    { key: 'API_URL', value: 'https://api.example.com', isMasked: false },
    { key: 'API_KEY', value: 'sk-prod-key', isMasked: true }
  ],
  endpoints: {
    baseUrl: 'https://example.com',
    apiUrl: 'https://api.example.com'
  },
  credentials: [{
    id: '1',
    type: 'bearer',
    name: 'API Token',
    data: JSON.stringify({ token: 'Bearer xyz...' })
  }]
}, context);
```

### Retrieve with Masking

```typescript
const variables = await storage.exportVariables(
  'my-project',
  context,
  policy
);
// Returns: { API_KEY: 'sk-12****ef', API_URL: 'https://api.example.com' }
```

## Integration Points

1. **Test Execution**:
   - Variables decrypted only in memory during runs
   - Automatic cleanup after execution
   - Masked in all logs and reports

2. **CI/CD Pipeline**:
   - Environment profiles for different stages
   - Secure credential injection
   - Audit trail for compliance

3. **Export/Import**:
   - Encrypted export format
   - Selective export with masking
   - Import with re-encryption

## Security Benefits

1. **Data Protection**:
   - Secrets never stored in plain text
   - Hardware-backed encryption on Windows
   - Strong encryption on all platforms

2. **Access Control**:
   - Project-level isolation
   - User-based access tracking
   - Policy-based restrictions

3. **Compliance**:
   - Full audit trail
   - Automatic rotation reminders
   - Export controls

4. **Developer Experience**:
   - Simple API
   - Automatic platform detection
   - Visual masking in UI

This implementation provides enterprise-grade security for test automation secrets while maintaining ease of use. 