# Observability Implementation Summary

This document summarizes the comprehensive observability features added to the Hybrid QA platform, including structured logging, metrics collection, and opt-in telemetry.

## Overview

The observability implementation provides:
- **Structured Logging**: Using Pino (Node.js) and structlog (Python)
- **Metrics Collection**: Local Prometheus-compatible metrics endpoint
- **Telemetry**: Opt-in anonymized error reporting and usage analytics
- **UI Controls**: Log level selection and telemetry consent management

## Implementation Details

### 1. Structured Logging

#### Node.js (Pino)
**File**: `packages/common/src/observability/logger.ts`

Features:
- Structured JSON logging with Pino
- Configurable log levels (trace, debug, info, warn, error, fatal)
- Pretty printing for development
- Automatic redaction of sensitive data
- Context-aware logging with correlation IDs
- Request/response logging middleware
- Performance logging helpers

```typescript
const logger = initializeLogger({
  level: 'info',
  pretty: true,
  redact: ['password', 'token', 'apiKey']
});

logger.info('Test started', {
  testName: 'login-test',
  engine: 'web',
  correlationId: '123e4567-e89b-12d3-a456-426614174000'
});
```

#### Python (structlog)
**Files**: 
- `packages/engine-desktop/src/observability/logger.py`
- `packages/engine-mainframe/src/observability/logger.py`

Features:
- Structured logging with structlog
- Automatic context injection
- Sensitive data masking
- Performance decorators
- Engine-specific logging (window actions, mainframe transactions)

```python
logger = get_logger('engine-desktop')
logger.log_window_action(
    action='click',
    window_title='Notepad',
    success=True,
    element='Save Button'
)
```

### 2. Metrics Collection

**File**: `packages/common/src/observability/metrics.ts`

Metrics tracked:
- Test execution counts and duration
- Step execution performance
- Engine request latency
- Resource usage (memory, CPU)
- Active sessions

Endpoints:
- `/metrics` - Prometheus format
- `/metrics.json` - JSON format

Example metrics:
```
# HELP test_runs_total Total number of test runs
# TYPE test_runs_total counter
test_runs_total{test="login-test"} 42

# HELP test_duration_seconds Test execution duration in seconds
# TYPE test_duration_seconds histogram
test_duration_seconds_bucket{test="login-test",le="0.5"} 10
test_duration_seconds_bucket{test="login-test",le="1"} 35
test_duration_seconds_sum{test="login-test"} 28.5
test_duration_seconds_count{test="login-test"} 42
```

### 3. Telemetry Service

**File**: `packages/common/src/observability/telemetry.ts`

Features:
- Opt-in consent management
- Data anonymization
- Error reporting
- Performance metrics
- Usage analytics
- Batch processing

Privacy measures:
- No personal data collection
- Automatic hashing of identifiers
- Path redaction in stack traces
- Configurable exclusion fields

### 4. UI Components

#### Logging Settings
**File**: `apps/desktop/src/renderer/components/settings/logging-settings.tsx`

Features:
- Log level selection (dropdown/radio)
- Pretty printing toggle
- File logging configuration
- Log export functionality
- Log cleanup tools

#### Telemetry Consent
**File**: `apps/desktop/src/renderer/components/settings/telemetry-consent.tsx`

Features:
- Initial consent dialog
- Granular consent options
- Privacy policy links
- Settings management panel

### 5. Integration Points

#### Orchestrator Updates
**File**: `packages/orchestrator/src/index.ts`

- Integrated observability initialization
- Request logging middleware
- Metrics endpoint setup
- Event tracking for telemetry
- Log level runtime configuration

#### Service Integration
All services now accept logger instances:
```typescript
class RunnerService {
  constructor(
    private eventService: EventService,
    private logger: ContextLogger,
    private metrics: MetricsCollector
  ) {
    // Service uses structured logging
  }
}
```

## Configuration

### Environment Variables

```env
# Logging
LOG_LEVEL=info          # trace|debug|info|warn|error|fatal
LOG_PRETTY=true         # Pretty print logs
LOG_FILE=false          # Log to file

# Metrics
METRICS_ENABLED=true    # Enable metrics endpoint
METRICS_PORT=9090       # Metrics port (if separate)

# Telemetry
TELEMETRY_ENABLED=false # Opt-in telemetry
TELEMETRY_ENDPOINT=https://telemetry.hybridqa.io/v1
TELEMETRY_API_KEY=your-api-key
```

### Programmatic Configuration

```typescript
const orchestrator = createOrchestrator({
  observability: {
    logLevel: 'debug',
    logPretty: true,
    metricsEnabled: true,
    telemetryEnabled: false
  }
});
```

## Usage Examples

### Structured Logging

```typescript
// Create logger with context
const logger = getLogger().child({
  testRunId: '12345',
  userId: 'user-123'
});

// Log with additional fields
logger.info('Step executed', {
  stepName: 'click-button',
  duration: 150,
  status: 'success'
});

// Log errors with stack traces
try {
  await executeStep();
} catch (error) {
  logger.error('Step failed', error, {
    stepName: 'click-button',
    locator: '#submit-btn'
  });
}
```

### Metrics Collection

```typescript
const metrics = getMetrics();

// Record test execution
const timer = metrics.startTimer('test_duration_seconds', {
  test: 'checkout-flow'
});

// ... execute test ...

timer(); // Stop timer and record

// Record custom metrics
metrics.increment('custom_events_total', { event: 'payment_submitted' });
metrics.set('active_users', 42);
```

### Telemetry

```typescript
const telemetry = getTelemetry();

// Check consent
if (telemetry.isEnabled()) {
  // Track usage
  telemetry.trackUsage('feature_used', {
    feature: 'visual-flow-builder',
    duration: 30000
  });
  
  // Track errors (anonymized)
  telemetry.trackError(error, {
    context: 'test-execution',
    engine: 'web'
  });
}
```

## Privacy & Security

### Data Protection
- All sensitive fields automatically redacted
- No personal information collected
- Anonymized user IDs based on machine characteristics
- Stack traces sanitized to remove file paths

### Consent Management
- Explicit opt-in required
- Granular control over data types
- Easy opt-out at any time
- Consent versioning

### Secure Storage
- Telemetry consent stored locally
- No data transmitted without consent
- API keys stored securely

## Performance Impact

- Logging: < 1ms per log statement
- Metrics: Negligible (passive collection)
- Telemetry: Async batching, no blocking

## Future Enhancements

1. **Distributed Tracing**: OpenTelemetry integration
2. **Custom Dashboards**: Built-in metrics visualization
3. **Alert Rules**: Configurable alerts based on metrics
4. **Log Analysis**: Built-in log search and filtering
5. **Export Formats**: Support for various log formats (ELK, Splunk)

## Dependencies Added

### Node.js Packages
- `pino@^8.16.2` - High-performance JSON logger
- `pino-pretty@^10.2.3` - Pretty printing for development

### Python Packages
- `structlog==23.2.0` - Structured logging
- `python-json-logger==2.0.7` - JSON log formatting
- `psutil==5.9.6` - System metrics collection

## Migration Guide

For existing code using the old logger:

```typescript
// Old
import { logger } from '@hybrid-qa/common';
logger.info('Test started');

// New
import { getLogger } from '@hybrid-qa/common';
const logger = getLogger();
logger.info('Test started', { testName: 'my-test' });
```

The new logger is backward compatible but provides additional structured logging capabilities. 