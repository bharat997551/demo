# Mainframe Mock Automation Demo

This sample project demonstrates mainframe automation testing using a mock 3270 terminal environment. It showcases CICS transactions, batch job submission, and screen navigation patterns common in mainframe applications.

## Overview

This project tests:
- 3270 terminal connection and authentication
- CICS transaction processing
- Screen navigation using function keys
- Data entry on mainframe screens
- Batch job submission and monitoring
- Error handling and recovery

## Project Structure

```
mainframe-mock/
├── tests/
│   ├── connection/
│   │   ├── connect-login.test.yaml
│   │   └── disconnect.test.yaml
│   ├── cics/
│   │   ├── account-inquiry.test.yaml
│   │   ├── customer-update.test.yaml
│   │   └── transaction-history.test.yaml
│   ├── batch/
│   │   ├── job-submit.test.yaml
│   │   └── job-status.test.yaml
│   └── e2e/
│       └── full-transaction.test.yaml
├── screens/
│   ├── login-screen.yaml
│   ├── main-menu.yaml
│   ├── account-screen.yaml
│   └── job-screen.yaml
├── data/
│   ├── test-accounts.csv
│   ├── job-templates/
│   └── expected-results.json
├── config/
│   └── mainframe-config.yaml
└── mock-server/
    └── mock-screens.json
```

## Prerequisites

- Hybrid QA Desktop App installed
- Mock mainframe server running (included)
- s3270 or similar 3270 emulator

## Getting Started

1. Start the mock mainframe server:
   ```bash
   cd mock-server
   python mock_mainframe_server.py
   ```

2. Open Hybrid QA Desktop App
3. Import this project
4. Configure connection settings in `config/mainframe-config.yaml`
5. Run tests

## Sample Tests

### 1. Connect and Login (`tests/connection/connect-login.test.yaml`)

```yaml
name: Mainframe Connect and Login
description: Test mainframe connection and user authentication
tags: [mainframe, connection, authentication]
engine: mainframe

variables:
  host: "{{ env.MAINFRAME_HOST || 'localhost' }}"
  port: "{{ env.MAINFRAME_PORT || 3270 }}"
  userId: "TESTUSER"
  password: "TESTPASS"

steps:
  - action: connect
    host: "{{ host }}"
    port: "{{ port }}"
    model: "3278-2"
    description: "Connect to mainframe"
    
  - action: waitForField
    row: 24
    col: 2
    text: "READY"
    timeout: 5000
    description: "Wait for ready prompt"
    
  - action: screenshot
    name: "initial-screen"
    format: "both"  # text and image
    
  - action: type
    text: "LOGON {{ userId }}"
    description: "Enter logon command"
    
  - action: sendKey
    key: "ENTER"
    description: "Submit logon"
    
  - action: waitForField
    row: 10
    col: 20
    text: "Password"
    timeout: 3000
    description: "Wait for password prompt"
    
  - action: moveCursor
    row: 10
    col: 30
    description: "Move to password field"
    
  - action: type
    text: "{{ password }}"
    hidden: true
    description: "Enter password"
    
  - action: sendKey
    key: "ENTER"
    
  - action: waitForField
    row: 1
    col: 30
    text: "MAIN MENU"
    timeout: 5000
    description: "Wait for main menu"
    
  - action: verifyScreen
    contains:
      - text: "Welcome {{ userId }}"
        row: 3
      - text: "Last login:"
        row: 4
    description: "Verify successful login"
    
  - action: screenshot
    name: "main-menu"
    format: "both"
```

### 2. CICS Account Inquiry (`tests/cics/account-inquiry.test.yaml`)

```yaml
name: CICS Account Inquiry Transaction
description: Test account inquiry using CICS transaction
tags: [mainframe, cics, inquiry]
engine: mainframe
require: ["connect-login.test.yaml"]

variables:
  accountNumber: "1234567890"
  transactionCode: "ACCT"

steps:
  - action: clearScreen
    description: "Clear screen for new transaction"
    
  - action: type
    text: "{{ transactionCode }}"
    description: "Enter transaction code"
    
  - action: sendKey
    key: "ENTER"
    
  - action: waitForField
    row: 5
    col: 20
    text: "Account Number"
    timeout: 3000
    description: "Wait for account screen"
    
  - action: screenshot
    name: "account-inquiry-screen"
    
  - action: moveCursor
    row: 5
    col: 40
    
  - action: type
    text: "{{ accountNumber }}"
    description: "Enter account number"
    
  - action: sendKey
    key: "ENTER"
    description: "Submit inquiry"
    
  - action: waitForField
    row: 10
    col: 20
    text: "Balance:"
    timeout: 5000
    description: "Wait for results"
    
  - action: extractField
    row: 10
    col: 30
    length: 15
    variable: "accountBalance"
    description: "Extract balance"
    
  - action: extractField
    row: 11
    col: 30
    length: 20
    variable: "accountStatus"
    description: "Extract status"
    
  - action: verifyScreen
    contains:
      - text: "Account Type:"
        row: 9
      - text: "ACTIVE"
        row: 11
    description: "Verify account details displayed"
    
  - action: screenshot
    name: "account-details"
    format: "both"
    
  - action: sendKey
    key: "PF3"
    description: "Return to menu"

assertions:
  - field:
      row: 10
      col: 30
      matches: "\\$[0-9,]+\\.[0-9]{2}"
      description: "Balance format"
```

### 3. Customer Update (`tests/cics/customer-update.test.yaml`)

```yaml
name: CICS Customer Update Transaction
description: Update customer information via CICS
tags: [mainframe, cics, update]
engine: mainframe

variables:
  customerId: "C0012345"
  newPhone: "555-123-4567"
  newEmail: "updated@example.com"

steps:
  - action: type
    text: "CUST"
    description: "Enter customer transaction"
    
  - action: sendKey
    key: "ENTER"
    
  - action: waitForField
    row: 5
    col: 20
    text: "Customer ID"
    
  - action: moveCursor
    row: 5
    col: 35
    
  - action: type
    text: "{{ customerId }}"
    
  - action: sendKey
    key: "ENTER"
    description: "Retrieve customer"
    
  - action: waitForField
    row: 8
    col: 20
    text: "Name:"
    timeout: 3000
    
  - action: sendKey
    key: "PF2"
    description: "Enter edit mode"
    
  - action: waitForField
    row: 24
    col: 2
    text: "EDIT MODE"
    
  - action: moveCursor
    row: 12
    col: 35
    description: "Move to phone field"
    
  - action: eraseField
    description: "Clear current phone"
    
  - action: type
    text: "{{ newPhone }}"
    
  - action: moveCursor
    row: 13
    col: 35
    description: "Move to email field"
    
  - action: eraseField
    
  - action: type
    text: "{{ newEmail }}"
    
  - action: screenshot
    name: "before-update"
    
  - action: sendKey
    key: "PF5"
    description: "Save changes"
    
  - action: waitForField
    row: 24
    col: 2
    text: "UPDATE SUCCESSFUL"
    timeout: 5000
    
  - action: screenshot
    name: "update-confirmed"
    
  - action: sendKey
    key: "PF3"
    description: "Exit transaction"
```

### 4. Batch Job Submission (`tests/batch/job-submit.test.yaml`)

```yaml
name: Submit Batch Job
description: Submit and monitor batch job execution
tags: [mainframe, batch, job]
engine: mainframe

variables:
  jobName: "TESTJOB1"
  jobClass: "A"
  
steps:
  - action: type
    text: "TSO"
    description: "Enter TSO"
    
  - action: sendKey
    key: "ENTER"
    
  - action: waitForField
    row: 1
    col: 1
    text: "TSO"
    
  - action: type
    text: "EDIT 'TEST.JCL({{ jobName }})'"
    description: "Edit JCL"
    
  - action: sendKey
    key: "ENTER"
    
  - action: waitForField
    row: 1
    col: 1
    text: "EDIT"
    timeout: 5000
    
  # Enter JCL content
  - action: type
    text: |
      //{{ jobName }} JOB (ACCT),'TEST JOB',CLASS={{ jobClass }}
      //STEP1    EXEC PGM=IEFBR14
      //SYSPRINT DD SYSOUT=*
      //
    multiline: true
    
  - action: sendKey
    key: "PF3"
    description: "Save and exit editor"
    
  - action: waitForField
    row: 24
    col: 2
    text: "SAVE"
    
  - action: type
    text: "SUBMIT '{{ jobName }}'"
    description: "Submit job"
    
  - action: sendKey
    key: "ENTER"
    
  - action: waitForField
    row: 24
    col: 2
    pattern: "JOB [0-9]+ SUBMITTED"
    timeout: 5000
    
  - action: extractField
    row: 24
    col: 2
    pattern: "JOB ([0-9]+)"
    variable: "jobNumber"
    description: "Extract job number"
    
  - action: screenshot
    name: "job-submitted"
    
  # Check job status
  - action: clearScreen
    
  - action: type
    text: "STATUS {{ jobNumber }}"
    
  - action: sendKey
    key: "ENTER"
    
  - action: waitForField
    row: 10
    col: 20
    text: "COMPLETED"
    timeout: 30000
    description: "Wait for job completion"
    
  - action: screenshot
    name: "job-completed"
```

### 5. Full E2E Transaction (`tests/e2e/full-transaction.test.yaml`)

```yaml
name: Full E2E Transaction Flow
description: Complete transaction flow with multiple screens
tags: [mainframe, e2e, transaction]
engine: mainframe

data:
  source: "../data/test-accounts.csv"

flows:
  - name: "Login"
    use: "../connection/connect-login.test.yaml"
    
  - name: "Process Accounts"
    forEach: data
    steps:
      # Navigate to account menu
      - action: sendKey
        key: "PF1"
        description: "Go to main menu"
        
      - action: waitForField
        row: 1
        col: 30
        text: "MAIN MENU"
        
      - action: type
        text: "1"
        description: "Select account processing"
        
      - action: sendKey
        key: "ENTER"
        
      # Account inquiry
      - action: type
        text: "ACCT"
        
      - action: sendKey
        key: "ENTER"
        
      - action: waitForField
        row: 5
        col: 20
        text: "Account Number"
        
      - action: type
        text: "{{ item.accountNumber }}"
        row: 5
        col: 40
        
      - action: sendKey
        key: "ENTER"
        
      - action: waitForField
        row: 10
        col: 20
        text: "Balance:"
        
      - action: extractField
        row: 10
        col: 30
        length: 15
        variable: "balance_{{ item.accountNumber }}"
        
      # Verify balance
      - action: verifyField
        row: 10
        col: 30
        expected: "{{ item.expectedBalance }}"
        tolerance: 0.01
        
      - action: screenshot
        name: "account-{{ item.accountNumber }}"
        
      # Update if needed
      - action: if
        condition: "{{ item.needsUpdate }}"
        then:
          - action: sendKey
            key: "PF2"
            description: "Edit mode"
            
          - action: moveCursor
            row: 15
            col: 30
            
          - action: type
            text: "{{ item.newStatus }}"
            
          - action: sendKey
            key: "PF5"
            description: "Save"
            
          - action: waitForField
            row: 24
            col: 2
            text: "UPDATE SUCCESSFUL"
            
      - action: sendKey
        key: "PF3"
        description: "Back to menu"
        
  - name: "Generate Report"
    steps:
      - action: type
        text: "REPT"
        
      - action: sendKey
        key: "ENTER"
        
      - action: waitForField
        row: 5
        col: 20
        text: "Report Type"
        
      - action: type
        text: "DAILY"
        row: 5
        col: 35
        
      - action: sendKey
        key: "ENTER"
        
      - action: waitForField
        row: 24
        col: 2
        text: "REPORT GENERATED"
        timeout: 60000
        
      - action: screenshot
        name: "report-complete"
```

## Screen Definitions

### Login Screen (`screens/login-screen.yaml`)

```yaml
name: LoginScreen
identifier:
  row: 1
  col: 30
  text: "SYSTEM LOGIN"

fields:
  userid:
    row: 10
    col: 30
    length: 8
    type: alphanumeric
    
  password:
    row: 11
    col: 30
    length: 8
    type: password
    
  message:
    row: 24
    col: 2
    length: 78
    type: output

pfkeys:
  PF1: "Help"
  PF3: "Exit"
  ENTER: "Submit"
```

### Account Screen (`screens/account-screen.yaml`)

```yaml
name: AccountInquiryScreen
identifier:
  row: 1
  col: 25
  text: "ACCOUNT INQUIRY"

fields:
  accountNumber:
    row: 5
    col: 40
    length: 10
    type: numeric
    required: true
    
  accountType:
    row: 9
    col: 30
    length: 10
    type: output
    
  balance:
    row: 10
    col: 30
    length: 15
    type: output
    format: currency
    
  status:
    row: 11
    col: 30
    length: 10
    type: output
    
  lastActivity:
    row: 12
    col: 30
    length: 10
    type: output
    format: date

pfkeys:
  PF1: "Help"
  PF2: "Edit"
  PF3: "Exit"
  PF7: "Previous"
  PF8: "Next"
  ENTER: "Retrieve"
```

## Configuration

### Mainframe Configuration (`config/mainframe-config.yaml`)

```yaml
mainframe:
  connection:
    host: localhost
    port: 3270
    model: "3278-2"  # or 3279-2, 3278-4, 3279-4
    codepage: "cp037"
    ssl: false
    
  session:
    timeout: 300000  # 5 minutes
    keepalive: true
    reconnect: true
    maxReconnectAttempts: 3
    
  screen:
    rows: 24
    cols: 80
    waitForUnlock: true
    unlockTimeout: 5000
    
  keyboard:
    typeDelay: 50  # ms between keystrokes
    enterDelay: 100  # ms after ENTER
    pfkeyDelay: 200  # ms after PF keys
    
  capture:
    format: "both"  # text, image, or both
    highlightFields: true
    includeHiddenFields: false
    
  verification:
    caseSensitive: false
    trimSpaces: true
    timeout: 10000
```

## Mock Server Setup

### Starting the Mock Server

```bash
cd mock-server
python mock_mainframe_server.py --port 3270
```

### Mock Screens Configuration (`mock-server/mock-screens.json`)

```json
{
  "screens": {
    "initial": {
      "title": "MOCK MAINFRAME SYSTEM",
      "fields": [
        {"row": 24, "col": 2, "text": "READY"}
      ],
      "transitions": {
        "LOGON *": "login_prompt"
      }
    },
    "login_prompt": {
      "title": "SYSTEM LOGIN",
      "fields": [
        {"row": 10, "col": 20, "text": "Userid:"},
        {"row": 11, "col": 20, "text": "Password:"}
      ],
      "transitions": {
        "TESTUSER": "password_prompt"
      }
    },
    "main_menu": {
      "title": "MAIN MENU",
      "fields": [
        {"row": 6, "col": 10, "text": "1. CICS Transaction Processing"},
        {"row": 7, "col": 10, "text": "2. TSO/ISPF"},
        {"row": 24, "col": 2, "text": "Enter selection:"}
      ],
      "transitions": {
        "1": "cics_menu",
        "2": "tso_menu"
      }
    }
  }
}
```

## Running Tests

### Individual Tests

```bash
# Run connection test
hybridqa run tests/connection/connect-login.test.yaml

# Run with specific host
hybridqa run tests/cics/account-inquiry.test.yaml --env MAINFRAME_HOST=mainframe.example.com

# Debug mode with screen capture
hybridqa debug tests/e2e/full-transaction.test.yaml --capture always
```

### Test Suites

```bash
# Run all CICS tests
hybridqa run tests/cics/

# Run full regression
hybridqa run tests/ --parallel
```

## Best Practices

1. **Screen Identification**: Always wait for unique screen identifiers
2. **Field Navigation**: Use explicit cursor positioning
3. **Function Keys**: Use appropriate PF keys for navigation
4. **Error Handling**: Check message fields for errors
5. **Data Validation**: Verify data after updates
6. **Session Management**: Handle disconnections gracefully

## Troubleshooting

### Common Issues

1. **Connection Failed**
   - Verify host and port
   - Check firewall settings
   - Ensure 3270 emulator is installed

2. **Screen Not Found**
   - Increase timeout values
   - Verify screen identifiers
   - Check for intermediate screens

3. **Field Input Issues**
   - Ensure cursor is positioned correctly
   - Check field length limits
   - Verify field is not protected

4. **Transaction Errors**
   - Check transaction codes
   - Verify user permissions
   - Look for error messages on row 24

## Advanced Features

### Custom Screen Handlers

```yaml
customHandlers:
  handleError:
    trigger:
      row: 24
      col: 2
      pattern: "ERROR.*"
    actions:
      - screenshot: "error-screen"
      - extractField:
          row: 24
          col: 2
          variable: "errorMessage"
      - sendKey: "PF3"  # Try to recover
```

### Batch Processing

```yaml
batchProcess:
  accounts:
    source: "accounts.csv"
    parallel: false  # Process sequentially
    errorHandling: "continue"  # or "stop"
    reporting: "detailed"
``` 