# API CRUD Mock Demo

This sample project demonstrates comprehensive API testing including REST, GraphQL, and gRPC endpoints. It covers CRUD operations, authentication, error handling, and performance testing.

## Overview

This project tests:
- RESTful API CRUD operations
- GraphQL queries and mutations
- gRPC service calls
- Authentication (OAuth2, JWT, API Keys)
- Request/Response validation
- Error scenarios
- Performance benchmarks
- WebSocket real-time updates

## Project Structure

```
api-crud-mock/
├── tests/
│   ├── rest/
│   │   ├── users-crud.test.yaml
│   │   ├── products-api.test.yaml
│   │   └── orders-workflow.test.yaml
│   ├── graphql/
│   │   ├── queries.test.yaml
│   │   ├── mutations.test.yaml
│   │   └── subscriptions.test.yaml
│   ├── grpc/
│   │   ├── user-service.test.yaml
│   │   └── payment-service.test.yaml
│   ├── websocket/
│   │   └── real-time-updates.test.yaml
│   └── performance/
│       └── load-test.test.yaml
├── collections/
│   ├── postman/
│   │   └── API-Collection.json
│   └── openapi/
│       └── swagger.yaml
├── data/
│   ├── users.json
│   ├── products.csv
│   └── test-data-generator.js
├── schemas/
│   ├── user-schema.json
│   ├── product-schema.json
│   └── order-schema.json
├── environments/
│   ├── local.env.yaml
│   ├── staging.env.yaml
│   └── production.env.yaml
└── mocks/
    └── mock-server-config.json
```

## Prerequisites

- Hybrid QA Desktop App installed
- Mock API server (included) or real API endpoints
- Node.js for mock server

## Getting Started

1. Start the mock API server:
   ```bash
   cd mocks
   npm install
   npm start
   ```

2. Open Hybrid QA Desktop App
3. Import this project
4. Select environment (local/staging/production)
5. Run tests

## Sample Tests

### 1. REST API Users CRUD (`tests/rest/users-crud.test.yaml`)

```yaml
name: Users CRUD Operations
description: Test Create, Read, Update, Delete operations for users
tags: [api, rest, crud, users]
engine: api

variables:
  baseUrl: "{{ env.API_BASE_URL }}"
  authToken: "{{ env.API_TOKEN }}"
  testUser:
    name: "Test User {{ timestamp }}"
    email: "test.{{ timestamp }}@example.com"
    password: "SecurePass123!"
    role: "user"

setup:
  - action: api.request
    method: POST
    url: "{{ baseUrl }}/auth/token"
    body:
      grant_type: "client_credentials"
      client_id: "{{ env.CLIENT_ID }}"
      client_secret: "{{ env.CLIENT_SECRET }}"
    extract:
      - jsonPath: "$.access_token"
        variable: "authToken"

steps:
  # CREATE - Post new user
  - action: api.request
    method: POST
    url: "{{ baseUrl }}/users"
    headers:
      Authorization: "Bearer {{ authToken }}"
      Content-Type: "application/json"
    body: "{{ testUser }}"
    description: "Create new user"
    
  - action: api.expect
    status: 201
    headers:
      location: 
        pattern: "/users/[0-9]+"
    description: "Verify creation success"
    
  - action: api.extract
    jsonPath: "$.id"
    variable: "userId"
    description: "Extract created user ID"
    
  - action: api.expect
    schema: "../schemas/user-schema.json"
    description: "Validate response schema"
    
  # READ - Get created user
  - action: api.request
    method: GET
    url: "{{ baseUrl }}/users/{{ userId }}"
    headers:
      Authorization: "Bearer {{ authToken }}"
    description: "Retrieve created user"
    
  - action: api.expect
    status: 200
    body:
      id: "{{ userId }}"
      name: "{{ testUser.name }}"
      email: "{{ testUser.email }}"
      role: "{{ testUser.role }}"
    description: "Verify user data"
    
  # UPDATE - Modify user
  - action: api.request
    method: PATCH
    url: "{{ baseUrl }}/users/{{ userId }}"
    headers:
      Authorization: "Bearer {{ authToken }}"
    body:
      name: "Updated {{ testUser.name }}"
      role: "admin"
    description: "Update user details"
    
  - action: api.expect
    status: 200
    body:
      name: 
        contains: "Updated"
      role: "admin"
    description: "Verify update success"
    
  # LIST - Get all users with filters
  - action: api.request
    method: GET
    url: "{{ baseUrl }}/users"
    headers:
      Authorization: "Bearer {{ authToken }}"
    params:
      role: "admin"
      limit: 10
      offset: 0
    description: "List users with filters"
    
  - action: api.expect
    status: 200
    body:
      items:
        minLength: 1
        each:
          role: "admin"
    description: "Verify filtered results"
    
  # DELETE - Remove user
  - action: api.request
    method: DELETE
    url: "{{ baseUrl }}/users/{{ userId }}"
    headers:
      Authorization: "Bearer {{ authToken }}"
    description: "Delete user"
    
  - action: api.expect
    status: 204
    description: "Verify deletion success"
    
  # Verify deletion
  - action: api.request
    method: GET
    url: "{{ baseUrl }}/users/{{ userId }}"
    headers:
      Authorization: "Bearer {{ authToken }}"
    description: "Verify user deleted"
    
  - action: api.expect
    status: 404
    body:
      error: "User not found"
    description: "Confirm user no longer exists"

teardown:
  - action: api.request
    method: DELETE
    url: "{{ baseUrl }}/test-data/cleanup"
    headers:
      Authorization: "Bearer {{ authToken }}"
    body:
      testRun: "{{ testRunId }}"
```

### 2. GraphQL Queries and Mutations (`tests/graphql/mutations.test.yaml`)

```yaml
name: GraphQL Product Management
description: Test GraphQL queries and mutations for products
tags: [api, graphql, products]
engine: api

variables:
  graphqlUrl: "{{ env.GRAPHQL_ENDPOINT }}"
  authToken: "{{ env.API_TOKEN }}"

steps:
  # Create Product Mutation
  - action: api.request
    method: POST
    url: "{{ graphqlUrl }}"
    headers:
      Authorization: "Bearer {{ authToken }}"
      Content-Type: "application/json"
    body:
      query: |
        mutation CreateProduct($input: ProductInput!) {
          createProduct(input: $input) {
            id
            name
            price
            category
            inStock
            createdAt
          }
        }
      variables:
        input:
          name: "Test Product {{ timestamp }}"
          price: 99.99
          category: "Electronics"
          description: "A test product"
          inStock: true
    description: "Create product via GraphQL"
    
  - action: api.expect
    status: 200
    body:
      data:
        createProduct:
          id: 
            pattern: "[0-9]+"
          price: 99.99
    description: "Verify creation"
    
  - action: api.extract
    jsonPath: "$.data.createProduct.id"
    variable: "productId"
    
  # Query Single Product
  - action: api.request
    method: POST
    url: "{{ graphqlUrl }}"
    headers:
      Authorization: "Bearer {{ authToken }}"
    body:
      query: |
        query GetProduct($id: ID!) {
          product(id: $id) {
            id
            name
            price
            category
            reviews {
              rating
              comment
              user {
                name
              }
            }
          }
        }
      variables:
        id: "{{ productId }}"
    description: "Query product details"
    
  - action: api.expect
    status: 200
    body:
      data:
        product:
          id: "{{ productId }}"
    
  # Query with Filters and Pagination
  - action: api.request
    method: POST
    url: "{{ graphqlUrl }}"
    body:
      query: |
        query SearchProducts($filter: ProductFilter, $pagination: Pagination) {
          products(filter: $filter, pagination: $pagination) {
            items {
              id
              name
              price
            }
            totalCount
            pageInfo {
              hasNextPage
              endCursor
            }
          }
        }
      variables:
        filter:
          category: "Electronics"
          minPrice: 50
          maxPrice: 500
        pagination:
          first: 10
          after: null
    
  # Update Product Mutation
  - action: api.request
    method: POST
    url: "{{ graphqlUrl }}"
    body:
      query: |
        mutation UpdateProduct($id: ID!, $input: ProductUpdateInput!) {
          updateProduct(id: $id, input: $input) {
            id
            name
            price
            updatedAt
          }
        }
      variables:
        id: "{{ productId }}"
        input:
          price: 89.99
          inStock: false
    
  - action: api.expect
    body:
      data:
        updateProduct:
          price: 89.99
    
  # Subscription Test (WebSocket)
  - action: api.subscribe
    url: "{{ graphqlUrl }}"
    protocol: "graphql-ws"
    subscription:
      query: |
        subscription OnProductUpdated($productId: ID!) {
          productUpdated(id: $productId) {
            id
            name
            price
            inStock
          }
        }
      variables:
        productId: "{{ productId }}"
    timeout: 30000
    expect:
      - message:
          data:
            productUpdated:
              id: "{{ productId }}"
```

### 3. gRPC Service Test (`tests/grpc/user-service.test.yaml`)

```yaml
name: gRPC User Service Test
description: Test gRPC user service methods
tags: [api, grpc, users]
engine: api

variables:
  grpcUrl: "{{ env.GRPC_HOST }}:{{ env.GRPC_PORT }}"
  
setup:
  - action: api.loadProto
    file: "../protos/user_service.proto"
    service: "UserService"

steps:
  # Unary RPC - Create User
  - action: api.grpc
    method: "CreateUser"
    url: "{{ grpcUrl }}"
    request:
      name: "gRPC Test User"
      email: "grpc.test@example.com"
      age: 25
    metadata:
      authorization: "Bearer {{ authToken }}"
    description: "Create user via gRPC"
    
  - action: api.expect
    response:
      id:
        exists: true
      name: "gRPC Test User"
    
  - action: api.extract
    path: "id"
    variable: "grpcUserId"
    
  # Server Streaming RPC - List Users
  - action: api.grpc
    method: "ListUsers"
    url: "{{ grpcUrl }}"
    request:
      pageSize: 10
    streamType: "server"
    description: "Stream users from server"
    
  - action: api.expectStream
    messages:
      minCount: 1
      each:
        id:
          exists: true
    
  # Client Streaming RPC - Batch Create
  - action: api.grpc
    method: "BatchCreateUsers"
    url: "{{ grpcUrl }}"
    streamType: "client"
    requests:
      - name: "User 1"
        email: "user1@example.com"
      - name: "User 2"
        email: "user2@example.com"
      - name: "User 3"
        email: "user3@example.com"
    description: "Batch create users"
    
  - action: api.expect
    response:
      createdCount: 3
      
  # Bidirectional Streaming RPC
  - action: api.grpc
    method: "Chat"
    url: "{{ grpcUrl }}"
    streamType: "bidirectional"
    conversation:
      - send:
          message: "Hello"
          userId: "{{ grpcUserId }}"
      - expect:
          message:
            contains: "Hello"
      - send:
          message: "How are you?"
      - expect:
          message:
            contains: "response"
    timeout: 10000
```

### 4. WebSocket Real-time Test (`tests/websocket/real-time-updates.test.yaml`)

```yaml
name: WebSocket Real-time Updates
description: Test WebSocket connections and real-time data
tags: [api, websocket, realtime]
engine: api

variables:
  wsUrl: "{{ env.WS_URL }}/updates"
  
steps:
  - action: api.wsConnect
    url: "{{ wsUrl }}"
    headers:
      Authorization: "Bearer {{ authToken }}"
    description: "Connect to WebSocket"
    
  - action: api.wsSend
    message:
      type: "subscribe"
      channels: ["orders", "inventory"]
    description: "Subscribe to channels"
    
  - action: api.wsExpect
    timeout: 5000
    message:
      type: "subscribed"
      channels:
        includes: ["orders", "inventory"]
    description: "Verify subscription"
    
  # Trigger update via REST API
  - action: api.request
    method: POST
    url: "{{ baseUrl }}/orders"
    body:
      product: "TEST-001"
      quantity: 5
    
  # Expect WebSocket notification
  - action: api.wsExpect
    timeout: 10000
    message:
      type: "order_created"
      data:
        product: "TEST-001"
    description: "Verify real-time update"
    
  - action: api.wsClose
    code: 1000
    reason: "Test complete"
```

### 5. Performance Load Test (`tests/performance/load-test.test.yaml`)

```yaml
name: API Performance Test
description: Load test critical API endpoints
tags: [api, performance, load]
engine: api

config:
  concurrent: 10
  iterations: 100
  rampUp: 30  # seconds
  
scenarios:
  - name: "User API Load"
    weight: 40  # 40% of traffic
    steps:
      - action: api.request
        method: GET
        url: "{{ baseUrl }}/users/{{ random(1, 1000) }}"
        headers:
          Authorization: "Bearer {{ authToken }}"
        
  - name: "Product Search Load"
    weight: 30
    steps:
      - action: api.request
        method: GET
        url: "{{ baseUrl }}/products"
        params:
          q: "{{ randomWord() }}"
          limit: 20
          
  - name: "Order Creation Load"
    weight: 30
    steps:
      - action: api.request
        method: POST
        url: "{{ baseUrl }}/orders"
        body:
          userId: "{{ random(1, 100) }}"
          productId: "{{ random(1, 500) }}"
          quantity: "{{ random(1, 5) }}"

assertions:
  - metric: "response_time_p95"
    threshold: 2000  # 95th percentile < 2s
    
  - metric: "error_rate"
    threshold: 0.01  # < 1% errors
    
  - metric: "throughput"
    threshold: 100  # > 100 req/s

report:
  format: "html"
  includeGraphs: true
  saveTo: "../reports/load-test-{{ timestamp }}.html"
```

## Schema Definitions

### User Schema (`schemas/user-schema.json`)

```json
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "type": "object",
  "required": ["id", "name", "email", "role"],
  "properties": {
    "id": {
      "type": "integer",
      "minimum": 1
    },
    "name": {
      "type": "string",
      "minLength": 1,
      "maxLength": 100
    },
    "email": {
      "type": "string",
      "format": "email"
    },
    "role": {
      "type": "string",
      "enum": ["user", "admin", "moderator"]
    },
    "createdAt": {
      "type": "string",
      "format": "date-time"
    },
    "updatedAt": {
      "type": "string",
      "format": "date-time"
    }
  }
}
```

## Environment Configuration

### Local Environment (`environments/local.env.yaml`)

```yaml
name: Local Development
variables:
  API_BASE_URL: "http://localhost:3000/api/v1"
  GRAPHQL_ENDPOINT: "http://localhost:4000/graphql"
  WS_URL: "ws://localhost:3000"
  GRPC_HOST: "localhost"
  GRPC_PORT: "50051"
  CLIENT_ID: "test-client"
  CLIENT_SECRET: "test-secret"
  API_TOKEN: "local-dev-token"
  
settings:
  timeout: 30000
  retries: 2
  retryDelay: 1000
  validateSSL: false
  proxy: null
  
headers:
  X-API-Version: "1.0"
  X-Test-Environment: "local"
```

### Staging Environment (`environments/staging.env.yaml`)

```yaml
name: Staging
variables:
  API_BASE_URL: "https://staging-api.example.com/v1"
  GRAPHQL_ENDPOINT: "https://staging-graphql.example.com"
  WS_URL: "wss://staging-ws.example.com"
  GRPC_HOST: "staging-grpc.example.com"
  GRPC_PORT: "443"
  
secrets:
  CLIENT_ID: "{{ vault.staging.client_id }}"
  CLIENT_SECRET: "{{ vault.staging.client_secret }}"
  API_TOKEN: "{{ vault.staging.api_token }}"
  
settings:
  timeout: 60000
  retries: 3
  validateSSL: true
  
monitoring:
  enabled: true
  datadog:
    apiKey: "{{ vault.datadog.api_key }}"
```

## Mock Server Configuration

### Mock Server Setup (`mocks/mock-server-config.json`)

```json
{
  "port": 3000,
  "delay": 100,
  "routes": {
    "/api/v1/users": {
      "GET": {
        "response": {
          "items": "@collection:users:10",
          "total": 100,
          "page": 1
        }
      },
      "POST": {
        "response": {
          "id": "@uuid",
          "name": "@request.body.name",
          "email": "@request.body.email",
          "role": "@request.body.role",
          "createdAt": "@now"
        },
        "status": 201,
        "headers": {
          "Location": "/api/v1/users/@response.id"
        }
      }
    },
    "/api/v1/users/:id": {
      "GET": {
        "response": "@store.users.@params.id",
        "status": "@store.users.@params.id ? 200 : 404"
      },
      "PATCH": {
        "response": "@merge(@store.users.@params.id, @request.body)"
      },
      "DELETE": {
        "status": 204
      }
    }
  },
  "graphql": {
    "endpoint": "/graphql",
    "schema": "./schema.graphql",
    "resolvers": "./resolvers.js"
  },
  "websocket": {
    "path": "/updates",
    "events": {
      "order_created": {
        "trigger": "POST:/api/v1/orders",
        "payload": {
          "type": "order_created",
          "data": "@request.body"
        }
      }
    }
  }
}
```

## Data Generation

### Test Data Generator (`data/test-data-generator.js`)

```javascript
const faker = require('faker');
const fs = require('fs');

// Generate users
const users = Array.from({ length: 100 }, (_, i) => ({
  id: i + 1,
  name: faker.name.findName(),
  email: faker.internet.email(),
  role: faker.random.arrayElement(['user', 'admin', 'moderator']),
  createdAt: faker.date.past()
}));

// Generate products
const products = Array.from({ length: 500 }, (_, i) => ({
  id: i + 1,
  name: faker.commerce.productName(),
  price: parseFloat(faker.commerce.price()),
  category: faker.commerce.department(),
  inStock: faker.random.boolean()
}));

// Save to files
fs.writeFileSync('users.json', JSON.stringify(users, null, 2));
fs.writeFileSync('products.json', JSON.stringify(products, null, 2));

console.log('Test data generated successfully!');
```

## Running Tests

### Individual Tests

```bash
# Run REST API tests
hybridqa run tests/rest/users-crud.test.yaml

# Run GraphQL tests
hybridqa run tests/graphql/mutations.test.yaml

# Run with specific environment
hybridqa run tests/rest/products-api.test.yaml --env staging
```

### Test Suites

```bash
# Run all API tests
hybridqa run tests/

# Run performance tests
hybridqa run tests/performance/ --report detailed

# Run with custom timeout
hybridqa run tests/ --timeout 120000
```

### Importing Collections

```bash
# Import Postman collection
hybridqa import collections/postman/API-Collection.json

# Import OpenAPI/Swagger
hybridqa import collections/openapi/swagger.yaml --type openapi
```

## Best Practices

1. **Authentication**: Store tokens securely and refresh as needed
2. **Validation**: Always validate response schema and data
3. **Error Handling**: Test both success and error scenarios
4. **Performance**: Monitor response times and set thresholds
5. **Data Cleanup**: Clean up test data after execution
6. **Idempotency**: Make tests repeatable without side effects

## Troubleshooting

### Common Issues

1. **Authentication Failures**
   - Check token expiration
   - Verify credentials in environment
   - Ensure correct auth headers

2. **Schema Validation Errors**
   - Update schemas when API changes
   - Check for optional vs required fields
   - Verify data types match

3. **Timeout Issues**
   - Increase timeout for slow endpoints
   - Check network connectivity
   - Verify server performance

4. **WebSocket Disconnections**
   - Implement reconnection logic
   - Check for heartbeat/ping-pong
   - Monitor connection stability

## CI/CD Integration

```yaml
name: API Tests

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    
    steps:
      - uses: actions/checkout@v3
      
      - name: Start Mock Server
        run: |
          cd mocks
          npm install
          npm start &
          sleep 5
          
      - name: Run API Tests
        run: |
          hybridqa run tests/ \
            --env local \
            --report junit \
            --parallel 4
            
      - name: Upload Results
        uses: actions/upload-artifact@v3
        with:
          name: api-test-results
          path: reports/
``` 