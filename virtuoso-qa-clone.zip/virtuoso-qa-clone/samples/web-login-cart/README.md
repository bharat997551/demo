# Web Login & Shopping Cart Demo

This sample project demonstrates web automation testing for an e-commerce application, including user authentication and shopping cart functionality.

## Overview

This project tests:
- User registration and login
- Product browsing and search
- Adding items to cart
- Checkout process
- Order confirmation

## Project Structure

```
web-login-cart/
├── tests/
│   ├── auth/
│   │   ├── login.test.yaml
│   │   ├── register.test.yaml
│   │   └── logout.test.yaml
│   ├── shopping/
│   │   ├── browse-products.test.yaml
│   │   ├── search.test.yaml
│   │   ├── add-to-cart.test.yaml
│   │   └── checkout.test.yaml
│   └── e2e/
│       └── complete-purchase.test.yaml
├── data/
│   ├── users.csv
│   ├── products.json
│   └── credit-cards.csv
├── page-objects/
│   ├── login-page.yaml
│   ├── product-page.yaml
│   └── cart-page.yaml
├── config/
│   └── environments.yaml
└── reports/
```

## Prerequisites

- Hybrid QA Desktop App installed
- Target e-commerce site URL (we'll use a demo site)
- Test data prepared

## Getting Started

1. Open Hybrid QA Desktop App
2. Import this project: File → Import Project → Select this folder
3. Configure environment in `config/environments.yaml`
4. Run tests individually or as a suite

## Sample Tests

### 1. Login Test (`tests/auth/login.test.yaml`)

```yaml
name: User Login Test
description: Test successful login with valid credentials
tags: [auth, smoke, critical]
engine: web

variables:
  baseUrl: "{{ env.BASE_URL }}"
  validUser: "{{ data.users[0] }}"

steps:
  - action: navigate
    url: "{{ baseUrl }}/login"
    description: "Go to login page"
    
  - action: waitFor
    selector: "#login-form"
    timeout: 5000
    description: "Wait for login form"
    
  - action: fill
    selector: "#email"
    value: "{{ validUser.email }}"
    description: "Enter email"
    
  - action: fill
    selector: "#password"
    value: "{{ validUser.password }}"
    description: "Enter password"
    
  - action: screenshot
    name: "login-form-filled"
    description: "Capture filled form"
    
  - action: click
    selector: "button[type='submit']"
    description: "Submit login form"
    
  - action: waitFor
    selector: ".user-dashboard"
    timeout: 10000
    description: "Wait for dashboard"
    
  - action: expect
    selector: ".welcome-message"
    text: "Welcome back, {{ validUser.name }}"
    description: "Verify welcome message"
    
  - action: screenshot
    name: "dashboard-loaded"
    description: "Capture dashboard"

assertions:
  - cookies:
      name: "session_id"
      exists: true
  - localStorage:
      key: "user_token"
      exists: true
```

### 2. Add to Cart Test (`tests/shopping/add-to-cart.test.yaml`)

```yaml
name: Add Product to Cart
description: Test adding multiple products to shopping cart
tags: [shopping, cart, smoke]
engine: web
require: ["login.test.yaml"]  # Run login first

variables:
  product1: "Laptop"
  product2: "Mouse"
  quantity: 2

steps:
  - action: navigate
    url: "{{ baseUrl }}/products"
    description: "Go to products page"
    
  - action: fill
    selector: "#search-input"
    value: "{{ product1 }}"
    description: "Search for laptop"
    
  - action: keyboard
    keys: "Enter"
    description: "Submit search"
    
  - action: waitFor
    selector: ".product-grid"
    timeout: 5000
    
  - action: click
    selector: ".product-card:first-child .add-to-cart"
    description: "Add first product to cart"
    
  - action: waitFor
    selector: ".cart-notification"
    text: "Added to cart"
    timeout: 3000
    
  - action: fill
    selector: "#search-input"
    value: "{{ product2 }}"
    clear: true
    
  - action: keyboard
    keys: "Enter"
    
  - action: waitFor
    selector: ".product-grid"
    
  - action: fill
    selector: ".product-card:first-child .quantity-input"
    value: "{{ quantity }}"
    description: "Set quantity"
    
  - action: click
    selector: ".product-card:first-child .add-to-cart"
    
  - action: click
    selector: ".cart-icon"
    description: "Open cart"
    
  - action: waitFor
    selector: ".cart-drawer"
    
  - action: expect
    selector: ".cart-items-count"
    text: "3 items"
    description: "Verify total items (1 laptop + 2 mice)"
    
  - action: screenshot
    name: "cart-contents"
    fullPage: true
```

### 3. Complete Purchase E2E Test (`tests/e2e/complete-purchase.test.yaml`)

```yaml
name: Complete Purchase Flow
description: End-to-end test of entire purchase process
tags: [e2e, critical, payment]
engine: web
timeout: 300000  # 5 minutes for complete flow

data:
  source: "../data/credit-cards.csv"
  
variables:
  shippingAddress:
    street: "123 Test St"
    city: "Test City"
    state: "CA"
    zip: "90210"

flows:
  - name: "Login"
    use: "../auth/login.test.yaml"
    
  - name: "Add Products"
    steps:
      - action: custom
        name: "addMultipleProducts"
        products:
          - name: "Laptop"
            quantity: 1
          - name: "Mouse"
            quantity: 2
          - name: "Keyboard"
            quantity: 1
            
  - name: "Checkout"
    steps:
      - action: click
        selector: ".checkout-button"
        
      - action: waitFor
        selector: "#checkout-form"
        
      - action: fill
        selector: "#shipping-street"
        value: "{{ shippingAddress.street }}"
        
      - action: fill
        selector: "#shipping-city"
        value: "{{ shippingAddress.city }}"
        
      - action: select
        selector: "#shipping-state"
        value: "{{ shippingAddress.state }}"
        
      - action: fill
        selector: "#shipping-zip"
        value: "{{ shippingAddress.zip }}"
        
      - action: click
        selector: "#same-as-billing"
        description: "Use same address for billing"
        
      - action: click
        selector: ".continue-to-payment"
        
      - action: waitFor
        selector: "#payment-form"
        
      - action: fill
        selector: "#card-number"
        value: "{{ data.cardNumber }}"
        
      - action: fill
        selector: "#card-name"
        value: "{{ data.cardName }}"
        
      - action: fill
        selector: "#card-expiry"
        value: "{{ data.expiry }}"
        
      - action: fill
        selector: "#card-cvv"
        value: "{{ data.cvv }}"
        
      - action: screenshot
        name: "checkout-review"
        
      - action: click
        selector: "#place-order"
        
      - action: waitFor
        selector: ".order-confirmation"
        timeout: 30000
        
      - action: expect
        selector: ".order-number"
        pattern: "Order #[0-9]{8}"
        
      - action: extract
        selector: ".order-number"
        variable: "orderNumber"
        
      - action: screenshot
        name: "order-confirmation"
        fullPage: true

cleanup:
  - action: api
    method: "POST"
    url: "{{ baseUrl }}/api/test/cleanup"
    body:
      orderNumber: "{{ orderNumber }}"
      testRun: true
```

## Page Objects

### Login Page (`page-objects/login-page.yaml`)

```yaml
name: LoginPage
url: "/login"

elements:
  emailInput:
    selector: "#email"
    type: "input"
    
  passwordInput:
    selector: "#password"
    type: "input"
    
  submitButton:
    selector: "button[type='submit']"
    type: "button"
    
  rememberMe:
    selector: "#remember-me"
    type: "checkbox"
    
  forgotPassword:
    selector: ".forgot-password-link"
    type: "link"
    
  errorMessage:
    selector: ".login-error"
    type: "text"

actions:
  login:
    parameters:
      - email
      - password
      - remember: false
    steps:
      - fill: emailInput
        value: "{{ email }}"
      - fill: passwordInput
        value: "{{ password }}"
      - if: "{{ remember }}"
        then:
          - click: rememberMe
      - click: submitButton
      
  verifyError:
    parameters:
      - message
    steps:
      - waitFor: errorMessage
      - expect: errorMessage
        text: "{{ message }}"
```

## Test Data

### Users (`data/users.csv`)

```csv
email,password,name,role
john.doe@example.com,Test123!,John Doe,customer
jane.admin@example.com,Admin123!,Jane Admin,admin
test.user@example.com,User123!,Test User,customer
```

### Products (`data/products.json`)

```json
{
  "products": [
    {
      "name": "Laptop",
      "price": 999.99,
      "category": "Electronics",
      "inStock": true
    },
    {
      "name": "Mouse",
      "price": 29.99,
      "category": "Accessories",
      "inStock": true
    },
    {
      "name": "Keyboard",
      "price": 79.99,
      "category": "Accessories",
      "inStock": false
    }
  ]
}
```

## Environment Configuration

### Environments (`config/environments.yaml`)

```yaml
environments:
  local:
    baseUrl: "http://localhost:3000"
    apiUrl: "http://localhost:3001"
    
  dev:
    baseUrl: "https://dev.shop.example.com"
    apiUrl: "https://api.dev.shop.example.com"
    
  staging:
    baseUrl: "https://staging.shop.example.com"
    apiUrl: "https://api.staging.shop.example.com"
    
  production:
    baseUrl: "https://shop.example.com"
    apiUrl: "https://api.shop.example.com"
    
default: dev

settings:
  browser: chrome
  headless: false
  screenshots: onFailure
  video: false
  timeout: 30000
  retries: 2
```

## Running the Tests

### Individual Tests

```bash
# Run login test
hybridqa run tests/auth/login.test.yaml

# Run with specific environment
hybridqa run tests/auth/login.test.yaml --env staging

# Run in headless mode
hybridqa run tests/auth/login.test.yaml --headless
```

### Test Suites

```bash
# Run all auth tests
hybridqa run tests/auth/

# Run shopping tests
hybridqa run tests/shopping/

# Run complete E2E suite
hybridqa run tests/e2e/
```

### Debugging

```bash
# Debug mode with breakpoints
hybridqa debug tests/e2e/complete-purchase.test.yaml

# Slow mode for visual debugging
hybridqa run tests/auth/login.test.yaml --slow

# With video recording
hybridqa run tests/e2e/complete-purchase.test.yaml --video
```

## CI/CD Integration

### GitHub Actions Example

```yaml
name: E-Commerce Tests

on:
  push:
    branches: [main]
  pull_request:

jobs:
  test:
    runs-on: ubuntu-latest
    
    steps:
      - uses: actions/checkout@v3
      
      - name: Setup Hybrid QA
        uses: hybrid-qa/setup-action@v1
        
      - name: Run Tests
        run: |
          hybridqa run tests/ \
            --env staging \
            --headless \
            --report junit
            
      - name: Upload Reports
        uses: actions/upload-artifact@v3
        with:
          name: test-reports
          path: reports/
```

## Tips and Best Practices

1. **Use Page Objects**: Define reusable page elements and actions
2. **Data-Driven Tests**: Separate test data from test logic
3. **Environment Variables**: Never hardcode sensitive data
4. **Proper Waits**: Use explicit waits instead of hard sleeps
5. **Meaningful Names**: Use descriptive test and step names
6. **Error Handling**: Add proper error handling and recovery
7. **Screenshots**: Capture state at critical points
8. **Cleanup**: Always clean up test data after execution

## Troubleshooting

### Common Issues

1. **Login Fails**: Check credentials in data file
2. **Elements Not Found**: Update selectors if UI changed
3. **Timeouts**: Increase wait times for slow connections
4. **Cart Issues**: Clear cart before test runs

### Debug Commands

```bash
# Enable verbose logging
hybridqa run tests/auth/login.test.yaml --verbose

# Save HAR file for network analysis
hybridqa run tests/shopping/checkout.test.yaml --save-har

# Keep browser open after test
hybridqa run tests/auth/login.test.yaml --no-close
``` 