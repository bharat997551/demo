# Combined End-to-End Flow Demo

This sample project demonstrates a comprehensive test scenario that spans multiple engines (Web, Desktop, API, and Mainframe) to test a complete business workflow. It simulates a financial institution's account opening process that involves web forms, desktop application verification, mainframe account creation, and API confirmation.

## Overview

This project demonstrates:
- Multi-engine test orchestration
- Data flow between different systems
- Complex business process automation
- Cross-platform validation
- Error handling across systems
- Comprehensive reporting

## Business Scenario

The test automates the following business process:
1. Customer applies for account via web portal
2. Bank employee reviews application in desktop app
3. Account is created in mainframe system
4. API confirms account creation and sends notification
5. Customer receives confirmation on web portal

## Project Structure

```
e2e-combined-flow/
├── tests/
│   ├── flows/
│   │   ├── account-opening.test.yaml
│   │   ├── loan-application.test.yaml
│   │   └── fraud-detection.test.yaml
│   ├── components/
│   │   ├── web-application.yaml
│   │   ├── desktop-review.yaml
│   │   ├── mainframe-create.yaml
│   │   └── api-notification.yaml
│   └── scenarios/
│       ├── happy-path.yaml
│       ├── error-scenarios.yaml
│       └── performance-test.yaml
├── data/
│   ├── customer-data.csv
│   ├── application-templates.json
│   └── test-scenarios.yaml
├── config/
│   ├── engines.yaml
│   ├── environments.yaml
│   └── orchestration.yaml
├── page-objects/
│   ├── web/
│   ├── desktop/
│   └── mainframe/
└── reports/
    └── templates/
```

## Prerequisites

- All Hybrid QA engines installed and configured
- Access to test environments for all systems
- Test data and credentials configured
- Mock services running (if applicable)

## Getting Started

1. Open Hybrid QA Desktop App
2. Import this project
3. Configure all engine connections in `config/engines.yaml`
4. Select test environment
5. Run the complete flow or individual components

## Main Test Flow

### Complete Account Opening (`tests/flows/account-opening.test.yaml`)

```yaml
name: End-to-End Account Opening Process
description: Complete account opening workflow across all systems
tags: [e2e, critical, multi-engine]
engines: [web, desktop, mainframe, api]
timeout: 600000  # 10 minutes for complete flow

variables:
  # Customer data
  customer:
    firstName: "John"
    lastName: "Doe {{ timestamp }}"
    email: "john.doe.{{ timestamp }}@example.com"
    phone: "555-123-{{ random(1000, 9999) }}"
    ssn: "{{ random(100, 999) }}-{{ random(10, 99) }}-{{ random(1000, 9999) }}"
    dateOfBirth: "1990-01-15"
  
  # Account details
  accountType: "CHECKING"
  initialDeposit: 1000
  
  # System URLs and credentials
  webPortal: "{{ env.WEB_PORTAL_URL }}"
  desktopApp: "{{ env.DESKTOP_APP_PATH }}"
  mainframeHost: "{{ env.MAINFRAME_HOST }}"
  apiEndpoint: "{{ env.API_BASE_URL }}"

flows:
  # Step 1: Customer Web Application
  - name: "Customer Application"
    engine: web
    steps:
      - action: navigate
        url: "{{ webPortal }}/apply"
        description: "Go to application page"
        
      - action: waitFor
        selector: "#application-form"
        timeout: 10000
        
      - action: screenshot
        name: "application-start"
        
      # Fill personal information
      - action: fill
        selector: "#firstName"
        value: "{{ customer.firstName }}"
        
      - action: fill
        selector: "#lastName"
        value: "{{ customer.lastName }}"
        
      - action: fill
        selector: "#email"
        value: "{{ customer.email }}"
        
      - action: fill
        selector: "#phone"
        value: "{{ customer.phone }}"
        
      - action: fill
        selector: "#ssn"
        value: "{{ customer.ssn }}"
        secure: true
        
      - action: fill
        selector: "#dateOfBirth"
        value: "{{ customer.dateOfBirth }}"
        
      # Select account type
      - action: select
        selector: "#accountType"
        value: "{{ accountType }}"
        
      - action: fill
        selector: "#initialDeposit"
        value: "{{ initialDeposit }}"
        
      # Upload documents
      - action: uploadFile
        selector: "#idDocument"
        file: "../data/sample-id.pdf"
        
      - action: uploadFile
        selector: "#proofOfAddress"
        file: "../data/sample-address.pdf"
        
      # Accept terms
      - action: click
        selector: "#termsCheckbox"
        
      - action: screenshot
        name: "application-filled"
        
      # Submit application
      - action: click
        selector: "#submitApplication"
        
      - action: waitFor
        selector: ".confirmation-message"
        timeout: 15000
        
      - action: extract
        selector: "#applicationNumber"
        variable: "applicationId"
        description: "Save application ID"
        
      - action: expect
        selector: ".status"
        text: "Pending Review"
        
      - action: screenshot
        name: "application-submitted"

  # Step 2: Bank Employee Desktop Review
  - name: "Employee Review Process"
    engine: desktop
    steps:
      - action: launch
        application: "{{ desktopApp }}"
        args: ["--env", "test"]
        
      - action: waitForWindow
        title: "Bank Review System"
        timeout: 10000
        
      # Login to desktop app
      - action: type
        text: "{{ env.REVIEWER_USERNAME }}"
        target:
          name: "Username"
          type: "edit"
          
      - action: type
        text: "{{ env.REVIEWER_PASSWORD }}"
        target:
          name: "Password"
          type: "edit"
        secure: true
        
      - action: click
        button: "Login"
        
      - action: waitForWindow
        title: "Application Dashboard"
        
      # Search for application
      - action: click
        menu: "Applications->Search"
        
      - action: type
        text: "{{ applicationId }}"
        target:
          name: "Application ID"
          
      - action: keyboard
        keys: "Enter"
        
      - action: waitFor
        control:
          name: "Search Results"
          type: "list"
        timeout: 5000
        
      # Open application
      - action: doubleClick
        control:
          type: "listitem"
          name: "{{ applicationId }}"
          
      - action: waitForWindow
        title: "Application Review - {{ applicationId }}"
        
      - action: screenshot
        name: "desktop-review-screen"
        
      # Verify information
      - action: verifyText
        control:
          name: "Customer Name"
        expected: "{{ customer.firstName }} {{ customer.lastName }}"
        
      - action: verifyText
        control:
          name: "Email"
        expected: "{{ customer.email }}"
        
      # Run verification checks
      - action: click
        button: "Run Verification"
        
      - action: waitFor
        control:
          name: "Verification Status"
          text: "PASSED"
        timeout: 30000
        
      # Approve application
      - action: click
        button: "Approve"
        
      - action: type
        text: "Application verified and approved"
        target:
          name: "Comments"
          
      - action: click
        button: "Submit Approval"
        
      - action: waitForDialog
        title: "Confirmation"
        
      - action: click
        button: "Yes"
        
      - action: screenshot
        name: "desktop-approved"

  # Step 3: Mainframe Account Creation
  - name: "Mainframe Account Setup"
    engine: mainframe
    steps:
      - action: connect
        host: "{{ mainframeHost }}"
        port: 3270
        
      - action: waitForField
        row: 24
        col: 2
        text: "READY"
        
      # Login to mainframe
      - action: type
        text: "LOGON {{ env.MAINFRAME_USER }}"
        
      - action: sendKey
        key: "ENTER"
        
      - action: waitForField
        row: 10
        col: 20
        text: "Password"
        
      - action: type
        text: "{{ env.MAINFRAME_PASS }}"
        row: 10
        col: 30
        secure: true
        
      - action: sendKey
        key: "ENTER"
        
      # Navigate to account creation
      - action: waitForField
        row: 1
        col: 30
        text: "MAIN MENU"
        
      - action: type
        text: "ACCT"
        
      - action: sendKey
        key: "ENTER"
        
      - action: waitForField
        row: 1
        col: 25
        text: "ACCOUNT MANAGEMENT"
        
      - action: sendKey
        key: "PF1"
        description: "New Account"
        
      # Enter account details
      - action: waitForField
        row: 5
        col: 20
        text: "Account Type"
        
      - action: type
        text: "CHK"
        row: 5
        col: 35
        
      - action: type
        text: "{{ customer.firstName }}"
        row: 7
        col: 35
        
      - action: type
        text: "{{ customer.lastName }}"
        row: 8
        col: 35
        
      - action: type
        text: "{{ customer.ssn }}"
        row: 10
        col: 35
        
      - action: type
        text: "{{ initialDeposit }}"
        row: 12
        col: 35
        
      - action: screenshot
        name: "mainframe-entry"
        format: "text"
        
      - action: sendKey
        key: "PF5"
        description: "Create Account"
        
      - action: waitForField
        row: 24
        col: 2
        text: "ACCOUNT CREATED"
        timeout: 10000
        
      - action: extractField
        row: 14
        col: 35
        length: 10
        variable: "accountNumber"
        description: "Extract account number"
        
      - action: screenshot
        name: "mainframe-created"
        format: "both"
        
      - action: sendKey
        key: "PF3"
        description: "Exit"

  # Step 4: API Confirmation and Notification
  - name: "API Integration"
    engine: api
    steps:
      # Verify account in API
      - action: api.request
        method: GET
        url: "{{ apiEndpoint }}/accounts/{{ accountNumber }}"
        headers:
          Authorization: "Bearer {{ env.API_TOKEN }}"
        description: "Verify account exists"
        
      - action: api.expect
        status: 200
        body:
          accountNumber: "{{ accountNumber }}"
          status: "ACTIVE"
          balance: "{{ initialDeposit }}"
          
      # Link to application
      - action: api.request
        method: PATCH
        url: "{{ apiEndpoint }}/applications/{{ applicationId }}"
        headers:
          Authorization: "Bearer {{ env.API_TOKEN }}"
        body:
          status: "COMPLETED"
          accountNumber: "{{ accountNumber }}"
          
      - action: api.expect
        status: 200
        
      # Send notification
      - action: api.request
        method: POST
        url: "{{ apiEndpoint }}/notifications"
        body:
          type: "ACCOUNT_OPENED"
          recipient: "{{ customer.email }}"
          data:
            accountNumber: "{{ accountNumber }}"
            customerName: "{{ customer.firstName }} {{ customer.lastName }}"
            
      - action: api.expect
        status: 202
        body:
          messageId:
            pattern: "[0-9a-f-]+"

  # Step 5: Customer Confirmation (Web)
  - name: "Customer Portal Verification"
    engine: web
    steps:
      - action: navigate
        url: "{{ webPortal }}/status/{{ applicationId }}"
        
      - action: waitFor
        selector: ".status-complete"
        timeout: 30000
        
      - action: expect
        selector: ".account-number"
        text: "{{ accountNumber }}"
        
      - action: expect
        selector: ".status-message"
        text: "Your account has been successfully opened"
        
      - action: screenshot
        name: "customer-confirmation"
        fullPage: true
        
      # Download welcome packet
      - action: click
        selector: "#downloadWelcomePacket"
        
      - action: waitForDownload
        filename: "welcome-packet-{{ accountNumber }}.pdf"
        timeout: 10000

validation:
  # Cross-system validation
  - action: custom
    name: "validateAccountConsistency"
    params:
      accountNumber: "{{ accountNumber }}"
      systems: ["web", "mainframe", "api"]
      
  - action: generateReport
    template: "account-opening-summary"
    data:
      applicationId: "{{ applicationId }}"
      accountNumber: "{{ accountNumber }}"
      customer: "{{ customer }}"
      duration: "{{ testDuration }}"
```

## Component Tests

### Web Application Component (`tests/components/web-application.yaml`)

```yaml
name: Web Application Component
description: Reusable web application steps
tags: [component, web]

parameters:
  - customerData
  - accountType
  - initialDeposit

steps:
  - action: navigate
    url: "{{ webPortal }}/apply"
    
  - action: custom
    name: "fillApplicationForm"
    data: "{{ customerData }}"
    
  - action: select
    selector: "#accountType"
    value: "{{ accountType }}"
    
  - action: fill
    selector: "#initialDeposit"
    value: "{{ initialDeposit }}"
    
  - action: custom
    name: "uploadRequiredDocuments"
    
  - action: click
    selector: "#termsCheckbox"
    
  - action: click
    selector: "#submitApplication"
    
  - action: waitFor
    selector: ".confirmation-message"
    
  - action: extract
    selector: "#applicationNumber"
    output: "applicationId"
```

## Error Scenarios

### Error Handling Flow (`tests/scenarios/error-scenarios.yaml`)

```yaml
name: Error Scenario Testing
description: Test error handling across systems
tags: [e2e, error-handling]

scenarios:
  - name: "Duplicate SSN"
    description: "Test duplicate SSN rejection"
    modify:
      customer.ssn: "123-45-6789"  # Known duplicate
    expect:
      web:
        - selector: ".error-message"
          text: "SSN already exists"
      desktop:
        - status: "REJECTED"
          reason: "Duplicate SSN"
          
  - name: "Mainframe Timeout"
    description: "Handle mainframe connection timeout"
    inject:
      mainframe:
        delay: 35000  # Force timeout
    expect:
      error: "Mainframe connection timeout"
      recovery: "retry"
      
  - name: "API Rate Limit"
    description: "Test API rate limiting"
    config:
      api:
        requests: 100
        duration: 1  # second
    expect:
      api:
        status: 429
        headers:
          X-RateLimit-Remaining: "0"
```

## Configuration

### Engine Configuration (`config/engines.yaml`)

```yaml
engines:
  web:
    type: playwright
    options:
      browser: chromium
      headless: false
      viewport:
        width: 1920
        height: 1080
      
  desktop:
    type: windows
    options:
      backend: uia
      timeout: 30000
      screenshot:
        onError: true
        
  mainframe:
    type: tn3270
    options:
      model: "3278-2"
      codepage: "cp037"
      timeout: 30000
      
  api:
    type: http
    options:
      followRedirects: true
      validateSSL: true
      timeout: 15000

orchestration:
  parallel: false  # Run engines sequentially
  errorHandling: "stop"  # or "continue"
  dataSharing: true  # Share variables between engines
  reporting:
    combined: true
    perEngine: true
```

### Environment Configuration (`config/environments.yaml`)

```yaml
environments:
  test:
    web:
      WEB_PORTAL_URL: "https://test.bank.example.com"
    desktop:
      DESKTOP_APP_PATH: "C:\\BankApps\\ReviewSystem.exe"
      REVIEWER_USERNAME: "reviewer01"
      REVIEWER_PASSWORD: "{{ vault.test.reviewer_pass }}"
    mainframe:
      MAINFRAME_HOST: "test-mf.bank.example.com"
      MAINFRAME_USER: "TESTOPS"
      MAINFRAME_PASS: "{{ vault.test.mf_pass }}"
    api:
      API_BASE_URL: "https://test-api.bank.example.com/v1"
      API_TOKEN: "{{ vault.test.api_token }}"
      
  production:
    # Production configuration (read-only tests)
```

## Running the Tests

### Complete Flow

```bash
# Run full account opening flow
hybridqa run tests/flows/account-opening.test.yaml --env test

# Run with specific data set
hybridqa run tests/flows/account-opening.test.yaml --data data/vip-customers.csv

# Debug mode with breakpoints
hybridqa debug tests/flows/account-opening.test.yaml
```

### Component Tests

```bash
# Test individual components
hybridqa run tests/components/web-application.yaml
hybridqa run tests/components/desktop-review.yaml

# Run error scenarios
hybridqa run tests/scenarios/error-scenarios.yaml
```

### Performance Testing

```bash
# Run performance test with 10 concurrent flows
hybridqa run tests/scenarios/performance-test.yaml --concurrent 10

# Generate performance report
hybridqa report generate --format html --output reports/perf-report.html
```

## Best Practices

1. **Data Isolation**: Use unique data for each test run
2. **Engine Coordination**: Ensure proper sequencing between engines
3. **Error Recovery**: Implement retry logic for transient failures
4. **State Management**: Clean up state between test runs
5. **Reporting**: Generate comprehensive reports for all stakeholders
6. **Security**: Never log sensitive data (SSN, passwords)

## Troubleshooting

### Common Issues

1. **Engine Communication**
   - Verify all engines are running
   - Check network connectivity
   - Ensure proper credentials

2. **Data Synchronization**
   - Allow time for data propagation
   - Implement polling with timeout
   - Verify system clocks are synchronized

3. **State Management**
   - Clean up test data after runs
   - Reset application state
   - Clear browser/desktop app cache

4. **Performance Issues**
   - Optimize wait times
   - Use parallel execution where possible
   - Monitor system resources

## CI/CD Integration

```yaml
name: E2E Combined Flow Tests

on:
  schedule:
    - cron: '0 6 * * *'  # Daily at 6 AM
  workflow_dispatch:

jobs:
  e2e-test:
    runs-on: windows-latest
    
    steps:
      - uses: actions/checkout@v3
      
      - name: Setup Test Environment
        run: |
          # Install all engines
          ./scripts/setup-all-engines.ps1
          
      - name: Configure VPN
        run: |
          # Connect to test environment VPN
          ./scripts/connect-vpn.ps1
          
      - name: Run E2E Tests
        run: |
          hybridqa run tests/flows/ \
            --env test \
            --report detailed \
            --artifact-dir artifacts/
            
      - name: Generate Combined Report
        run: |
          hybridqa report combine \
            --input artifacts/ \
            --output e2e-report.html \
            --include-screenshots \
            --include-logs
            
      - name: Upload Results
        uses: actions/upload-artifact@v3
        with:
          name: e2e-test-results
          path: |
            e2e-report.html
            artifacts/
            
      - name: Notify Teams
        if: always()
        run: |
          ./scripts/notify-teams.ps1 \
            -Status ${{ job.status }} \
            -Report e2e-report.html
```

## Reporting

The combined flow generates comprehensive reports including:

1. **Executive Summary**: High-level pass/fail status
2. **Detailed Timeline**: Step-by-step execution across all engines
3. **Screenshots**: Visual evidence from web and desktop
4. **System Logs**: Logs from all involved systems
5. **Performance Metrics**: Execution time per engine
6. **Data Flow Diagram**: Visualization of data movement
7. **Error Analysis**: Detailed failure information with remediation

Reports can be exported in multiple formats:
- HTML (interactive)
- PDF (printable)
- JSON (for further processing)
- XLSX (for management review) 