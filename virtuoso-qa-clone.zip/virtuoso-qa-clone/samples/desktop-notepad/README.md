# Desktop Notepad Automation Demo

This sample project demonstrates desktop automation testing using Windows Notepad as the target application. It showcases various desktop automation capabilities including window management, keyboard input, menu navigation, and file operations.

## Overview

This project tests:
- Launching and closing applications
- Text input and editing
- Menu navigation (File, Edit, Format menus)
- Keyboard shortcuts
- Dialog handling (Save, Open, Find/Replace)
- Window state management

## Project Structure

```
desktop-notepad/
├── tests/
│   ├── basic/
│   │   ├── launch-close.test.yaml
│   │   ├── text-input.test.yaml
│   │   └── save-file.test.yaml
│   ├── editing/
│   │   ├── cut-copy-paste.test.yaml
│   │   ├── find-replace.test.yaml
│   │   └── undo-redo.test.yaml
│   ├── formatting/
│   │   ├── font-settings.test.yaml
│   │   └── word-wrap.test.yaml
│   └── advanced/
│       ├── multi-window.test.yaml
│       └── keyboard-shortcuts.test.yaml
├── data/
│   ├── sample-text.txt
│   └── test-content.json
├── window-definitions/
│   ├── notepad-main.yaml
│   ├── save-dialog.yaml
│   └── font-dialog.yaml
└── config/
    └── desktop-settings.yaml
```

## Prerequisites

- Windows 10/11
- Hybrid QA Desktop App installed
- Notepad (comes with Windows)
- Write permissions in Documents folder

## Getting Started

1. Open Hybrid QA Desktop App
2. Import this project
3. Ensure Notepad is accessible
4. Run tests individually or as a suite

## Sample Tests

### 1. Basic Launch and Text Input (`tests/basic/text-input.test.yaml`)

```yaml
name: Notepad Text Input Test
description: Test launching Notepad and entering text
tags: [desktop, notepad, basic]
engine: desktop

variables:
  testText: |
    Hello from Hybrid QA!
    This is an automated test.
    Testing desktop automation with Notepad.

steps:
  - action: launch
    application: "notepad.exe"
    description: "Launch Notepad"
    
  - action: waitForWindow
    title: "Untitled - Notepad"
    timeout: 5000
    description: "Wait for Notepad window"
    
  - action: screenshot
    name: "notepad-launched"
    description: "Capture empty Notepad"
    
  - action: type
    text: "{{ testText }}"
    description: "Type test content"
    
  - action: keyboard
    keys: "Ctrl+Home"
    description: "Go to beginning"
    
  - action: screenshot
    name: "text-entered"
    description: "Capture with text"
    
  - action: keyboard
    keys: "Ctrl+A"
    description: "Select all text"
    
  - action: verifyText
    expected: "{{ testText }}"
    description: "Verify typed text"
    
  - action: keyboard
    keys: "Alt+F4"
    description: "Close Notepad"
    
  - action: waitForWindow
    title: "Notepad"
    text: "Do you want to save"
    timeout: 2000
    description: "Wait for save prompt"
    
  - action: click
    button: "Don't Save"
    description: "Don't save changes"
```

### 2. Save File Test (`tests/basic/save-file.test.yaml`)

```yaml
name: Save File Test
description: Test saving a file with Notepad
tags: [desktop, notepad, file-operations]
engine: desktop

variables:
  fileName: "test_output_{{ timestamp }}.txt"
  content: "This file was created by Hybrid QA automation"
  savePath: "{{ env.USERPROFILE }}\\Documents"

steps:
  - action: launch
    application: "notepad.exe"
    
  - action: waitForWindow
    title: "Untitled - Notepad"
    
  - action: type
    text: "{{ content }}"
    
  - action: keyboard
    keys: "Ctrl+S"
    description: "Open Save dialog"
    
  - action: waitForWindow
    title: "Save As"
    className: "#32770"
    timeout: 3000
    description: "Wait for Save dialog"
    
  - action: type
    text: "{{ savePath }}\\{{ fileName }}"
    description: "Enter file path"
    
  - action: screenshot
    name: "save-dialog"
    
  - action: click
    control:
      name: "Save"
      type: "button"
    description: "Click Save button"
    
  - action: waitForWindow
    title: "{{ fileName }} - Notepad"
    timeout: 5000
    description: "Verify file saved"
    
  - action: keyboard
    keys: "Alt+F4"
    description: "Close Notepad"
    
  - action: verifyFile
    path: "{{ savePath }}\\{{ fileName }}"
    exists: true
    content: "{{ content }}"
    description: "Verify file created"

cleanup:
  - action: deleteFile
    path: "{{ savePath }}\\{{ fileName }}"
    description: "Clean up test file"
```

### 3. Find and Replace (`tests/editing/find-replace.test.yaml`)

```yaml
name: Find and Replace Test
description: Test Find/Replace functionality
tags: [desktop, notepad, editing]
engine: desktop

variables:
  initialText: |
    The quick brown fox jumps over the lazy dog.
    The quick brown fox is very quick.
    The dog is not quick at all.
  findText: "quick"
  replaceText: "fast"

steps:
  - action: launch
    application: "notepad.exe"
    
  - action: waitForWindow
    title: "Untitled - Notepad"
    
  - action: type
    text: "{{ initialText }}"
    
  - action: keyboard
    keys: "Ctrl+H"
    description: "Open Replace dialog"
    
  - action: waitForWindow
    title: "Replace"
    timeout: 2000
    
  - action: type
    text: "{{ findText }}"
    description: "Enter find text"
    
  - action: keyboard
    keys: "Tab"
    description: "Move to replace field"
    
  - action: type
    text: "{{ replaceText }}"
    description: "Enter replace text"
    
  - action: screenshot
    name: "replace-dialog"
    
  - action: click
    button: "Replace All"
    description: "Replace all occurrences"
    
  - action: waitForWindow
    title: "Notepad"
    text: "3 replacements"
    timeout: 2000
    description: "Verify replacement count"
    
  - action: click
    button: "OK"
    
  - action: keyboard
    keys: "Escape"
    description: "Close Replace dialog"
    
  - action: keyboard
    keys: "Ctrl+A"
    description: "Select all text"
    
  - action: verifyText
    contains: "fast"
    notContains: "quick"
    description: "Verify replacements"
```

### 4. Multi-Window Test (`tests/advanced/multi-window.test.yaml`)

```yaml
name: Multi-Window Notepad Test
description: Test managing multiple Notepad windows
tags: [desktop, notepad, advanced, multi-window]
engine: desktop

variables:
  window1Text: "This is window 1"
  window2Text: "This is window 2"

steps:
  # Launch first Notepad
  - action: launch
    application: "notepad.exe"
    windowHandle: "notepad1"
    
  - action: waitForWindow
    title: "Untitled - Notepad"
    handle: "notepad1"
    
  - action: type
    window: "notepad1"
    text: "{{ window1Text }}"
    
  # Launch second Notepad
  - action: launch
    application: "notepad.exe"
    windowHandle: "notepad2"
    
  - action: waitForWindow
    title: "Untitled - Notepad"
    handle: "notepad2"
    excludeHandle: "notepad1"
    
  - action: type
    window: "notepad2"
    text: "{{ window2Text }}"
    
  # Switch between windows
  - action: focusWindow
    handle: "notepad1"
    description: "Switch to first window"
    
  - action: keyboard
    keys: "Ctrl+A"
    
  - action: keyboard
    keys: "Ctrl+C"
    description: "Copy from window 1"
    
  - action: focusWindow
    handle: "notepad2"
    description: "Switch to second window"
    
  - action: keyboard
    keys: "Enter Enter"
    description: "Add new lines"
    
  - action: keyboard
    keys: "Ctrl+V"
    description: "Paste to window 2"
    
  - action: screenshot
    name: "both-windows"
    allWindows: true
    
  # Close windows
  - action: closeWindow
    handle: "notepad1"
    force: true
    
  - action: closeWindow
    handle: "notepad2"
    force: true
```

### 5. Font Settings Test (`tests/formatting/font-settings.test.yaml`)

```yaml
name: Font Settings Test
description: Test changing font settings in Notepad
tags: [desktop, notepad, formatting]
engine: desktop

steps:
  - action: launch
    application: "notepad.exe"
    
  - action: waitForWindow
    title: "Untitled - Notepad"
    
  - action: type
    text: "Testing different fonts"
    
  - action: keyboard
    keys: "Alt+O"
    description: "Open Format menu"
    
  - action: keyboard
    keys: "F"
    description: "Select Font option"
    
  - action: waitForWindow
    title: "Font"
    className: "#32770"
    timeout: 3000
    
  - action: click
    control:
      type: "listbox"
      name: "Font:"
    description: "Click font list"
    
  - action: type
    text: "Consolas"
    description: "Type font name"
    
  - action: click
    control:
      type: "listbox"
      name: "Size:"
    description: "Click size list"
    
  - action: type
    text: "14"
    description: "Set font size"
    
  - action: screenshot
    name: "font-dialog"
    
  - action: click
    button: "OK"
    description: "Apply font changes"
    
  - action: screenshot
    name: "new-font-applied"
    description: "Capture with new font"
```

## Window Definitions

### Notepad Main Window (`window-definitions/notepad-main.yaml`)

```yaml
name: NotepadMainWindow
className: "Notepad"
titlePattern: ".*Notepad"

controls:
  textArea:
    className: "Edit"
    name: "Text Editor"
    
  menuBar:
    type: "menubar"
    
  statusBar:
    className: "msctls_statusbar32"
    
menus:
  file:
    - New: "Ctrl+N"
    - Open: "Ctrl+O"
    - Save: "Ctrl+S"
    - SaveAs: "Ctrl+Shift+S"
    - Exit: "Alt+F4"
    
  edit:
    - Undo: "Ctrl+Z"
    - Cut: "Ctrl+X"
    - Copy: "Ctrl+C"
    - Paste: "Ctrl+V"
    - Find: "Ctrl+F"
    - Replace: "Ctrl+H"
    
  format:
    - WordWrap: "Alt+O,W"
    - Font: "Alt+O,F"
```

## Configuration

### Desktop Settings (`config/desktop-settings.yaml`)

```yaml
desktop:
  engine: pywinauto
  backend: "uia"  # or "win32"
  
  timeouts:
    window_find: 10
    control_find: 5
    action_delay: 0.5
    
  screenshot:
    capture_method: "window"  # or "screen"
    highlight_element: true
    highlight_color: "red"
    
  error_handling:
    retry_count: 3
    retry_delay: 1000
    take_screenshot_on_error: true
    
  performance:
    use_cached_elements: true
    batch_actions: false
```

## Running Tests

### Individual Tests

```bash
# Run basic text input test
hybridqa run tests/basic/text-input.test.yaml

# Run with specific backend
hybridqa run tests/basic/save-file.test.yaml --backend win32

# Debug mode
hybridqa debug tests/editing/find-replace.test.yaml
```

### Test Suites

```bash
# Run all basic tests
hybridqa run tests/basic/

# Run all tests
hybridqa run tests/
```

## Best Practices

1. **Window Identification**: Use unique window titles or class names
2. **Timing**: Add appropriate waits for window/dialog appearance
3. **Keyboard vs Mouse**: Prefer keyboard shortcuts for reliability
4. **Error Handling**: Handle save prompts and unexpected dialogs
5. **Cleanup**: Always close applications and clean up files
6. **Screenshots**: Capture state before and after actions

## Troubleshooting

### Common Issues

1. **Window Not Found**
   - Check window title matches exactly
   - Increase timeout values
   - Verify application launched successfully

2. **Control Not Found**
   - Use UI Spy tools to verify control properties
   - Try different backend (UIA vs Win32)
   - Add explicit waits

3. **Keyboard Input Issues**
   - Ensure window has focus
   - Add delays between keystrokes
   - Use `type` for text, `keyboard` for shortcuts

4. **Dialog Handling**
   - Always handle save prompts when closing
   - Check for unexpected error dialogs
   - Use force close as last resort

## Advanced Techniques

### Custom Actions

```yaml
customActions:
  createAndSaveFile:
    parameters:
      - content
      - fileName
    steps:
      - action: launch
        application: "notepad.exe"
      - action: type
        text: "{{ content }}"
      - action: keyboard
        keys: "Ctrl+S"
      - action: type
        text: "{{ fileName }}"
      - action: click
        button: "Save"
```

### Error Recovery

```yaml
errorHandlers:
  - match: "Do you want to save"
    actions:
      - click: "Don't Save"
      
  - match: "Access is denied"
    actions:
      - screenshot: "access-denied-error"
      - fail: "Permission error encountered"
```

## CI/CD Integration

```yaml
name: Desktop Tests

on: [push, pull_request]

jobs:
  test:
    runs-on: windows-latest
    
    steps:
      - uses: actions/checkout@v3
      
      - name: Setup Hybrid QA
        uses: hybrid-qa/setup-action@v1
        with:
          install-desktop-engine: true
          
      - name: Run Desktop Tests
        run: |
          hybridqa run tests/ \
            --report junit \
            --screenshot always
            
      - name: Upload Screenshots
        if: always()
        uses: actions/upload-artifact@v3
        with:
          name: screenshots
          path: screenshots/
``` 