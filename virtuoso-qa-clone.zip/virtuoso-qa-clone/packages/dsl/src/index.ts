// Re-export all core types and schemas
export * from './types/core';
export * from './types/steps';
export * from './types/flow';

// Re-export utilities
export * from './utils/validation';
export * from './utils/schema-generator';

// Legacy exports for backward compatibility
export {
  VariableSchema as Variable,
  DataTableSchema as DataTable
} from './types/core';

export {
  TestCaseSchema as TestCase,
  TestSuiteSchema as TestSuite,
  ExecutionPlanSchema as ExecutionPlan
} from './types/flow';

export {
  StepSchema as Step
} from './types/steps';

export {
  validateDSL as validateFlow,
  validateDSL as validateProject,
  validateDSL as validateStep
} from './utils/validation'; 