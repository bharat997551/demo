import { randomUUID } from 'crypto';

/**
 * Generate a unique test suite ID
 */
export function generateTestSuiteId(): string {
  return randomUUID();
}

/**
 * Generate a unique test case ID  
 */
export function generateTestCaseId(): string {
  return randomUUID();
}

/**
 * Generate a unique step ID
 */
export function generateStepId(): string {
  return randomUUID();
}

/**
 * Generate a unique flow node ID
 */
export function generateFlowNodeId(): string {
  return randomUUID();
}

/**
 * Generate a unique flow edge ID
 */
export function generateFlowEdgeId(): string {
  return randomUUID();
}

/**
 * Generate a unique execution plan ID
 */
export function generateExecutionPlanId(): string {
  return randomUUID();
}

/**
 * Generate timestamp for filenames
 */
export function generateTimestamp(): string {
  return new Date().toISOString().replace(/[:.]/g, '-').slice(0, -5);
}

/**
 * Generate a test data identifier
 */
export function generateDataTableId(): string {
  return `dt-${randomUUID()}`;
}

// Legacy exports for backward compatibility
export const generateFlowId = generateTestCaseId;
export const generateProjectId = generateTestSuiteId;
