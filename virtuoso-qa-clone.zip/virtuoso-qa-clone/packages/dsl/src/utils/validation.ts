import { TestSuiteSchema, TestCaseSchema, ExecutionPlanSchema, ExecutionPlan, TestCase, TestSuite, Step } from '../types';

/**
 * Validation result interface
 */
export interface ValidationResult {
  valid: boolean;
  errors?: ValidationError[];
  warnings?: string[];
}

/**
 * Detailed validation error
 */
export interface ValidationError {
  path: string;
  message: string;
  code: string;
  severity: 'error' | 'warning';
}

/**
 * Environment context for compilation
 */
export interface CompilationEnvironment {
  variables?: Record<string, any>;
  settings?: Record<string, any>;
  engines?: {
    web?: boolean;
    desktop?: boolean; 
    mainframe?: boolean;
    api?: boolean;
  };
}

/**
 * Validate DSL structure (TestCase or TestSuite)
 */
export function validateDSL(dsl: any): ValidationResult {
  const errors: ValidationError[] = [];
  const warnings: string[] = [];

  try {
    // Try to parse as TestCase first
    const testCaseResult = TestCaseSchema.safeParse(dsl);
    if (testCaseResult.success) {
      const validationWarnings = validateTestCaseLogic(testCaseResult.data);
      return {
        valid: true,
        warnings: validationWarnings
      };
    }

    // Try to parse as TestSuite
    const testSuiteResult = TestSuiteSchema.safeParse(dsl);
    if (testSuiteResult.success) {
      const validationWarnings = validateTestSuiteLogic(testSuiteResult.data);
      return {
        valid: true,
        warnings: validationWarnings
      };
    }

    // Neither worked, collect all errors
    if (testCaseResult.error) {
      errors.push(...zodErrorsToValidationErrors(testCaseResult.error, 'TestCase'));
    }
    
    if (testSuiteResult.error) {
      errors.push(...zodErrorsToValidationErrors(testSuiteResult.error, 'TestSuite'));
    }

  } catch (error) {
    errors.push({
      path: 'root',
      message: error instanceof Error ? error.message : 'Unknown parsing error',
      code: 'PARSE_ERROR',
      severity: 'error'
    });
  }

  return {
    valid: false,
    errors,
    warnings: warnings.length > 0 ? warnings : undefined
  };
}

/**
 * Compile DSL to execution plan
 */
export function compileToPlan(dsl: any, env: CompilationEnvironment = {}): ExecutionPlan {
  // First validate the DSL
  const validation = validateDSL(dsl);
  if (!validation.valid) {
    throw new Error(`Invalid DSL: ${validation.errors?.map(e => e.message).join(', ')}`);
  }

  // Determine if it's a TestCase or TestSuite
  const testCaseResult = TestCaseSchema.safeParse(dsl);
  if (testCaseResult.success) {
    return compileTestCase(testCaseResult.data, env);
  }

  const testSuiteResult = TestSuiteSchema.safeParse(dsl);
  if (testSuiteResult.success) {
    return compileTestSuite(testSuiteResult.data, env);
  }

  throw new Error('Unable to parse DSL as TestCase or TestSuite');
}

/**
 * Convert Zod errors to validation errors
 */
function zodErrorsToValidationErrors(zodError: any, context: string): ValidationError[] {
  return zodError.issues.map((issue: any) => ({
    path: issue.path.join('.') || context,
    message: issue.message,
    code: issue.code.toUpperCase(),
    severity: 'error' as const
  }));
}

/**
 * Validate TestCase business logic
 */
function validateTestCaseLogic(testCase: TestCase): string[] {
  const warnings: string[] = [];

  // Check for empty test case
  if (testCase.steps.length === 0 && testCase.nodes.length === 0) {
    warnings.push('Test case has no steps or flow nodes defined');
  }

  // Check for mixed approaches (both steps and nodes)
  if (testCase.steps.length > 0 && testCase.nodes.length > 0) {
    warnings.push('Test case uses both linear steps and visual flow - consider using one approach');
  }

  // Validate variable references
  const variableNames = new Set(testCase.variables.map(v => v.name));
  const stepVariableRefs = extractVariableReferences(testCase.steps);
  
  for (const varRef of stepVariableRefs) {
    if (!variableNames.has(varRef)) {
      warnings.push(`Variable '${varRef}' referenced but not defined`);
    }
  }

  // Check for unreasonable timeouts
  if (testCase.settings.timeout > 3600000) { // 1 hour
    warnings.push('Test case timeout exceeds 1 hour - consider breaking into smaller tests');
  }

  // Validate data table references
  const dataTableNames = new Set(testCase.dataTables.map(dt => dt.id));
  for (const step of testCase.steps) {
    if (step.engine === 'flow' && step.options.dataTable) {
      if (!dataTableNames.has(step.options.dataTable)) {
        warnings.push(`Data table '${step.options.dataTable}' referenced but not defined`);
      }
    }
  }

  return warnings;
}

/**
 * Validate TestSuite business logic
 */
function validateTestSuiteLogic(testSuite: TestSuite): string[] {
  const warnings: string[] = [];

  // Check for empty test suite
  if (testSuite.testCases.length === 0) {
    warnings.push('Test suite has no test cases defined');
  }

  // Check circular dependencies
  const dependencies = testSuite.execution.dependencies;
  if (hasCircularDependencies(dependencies)) {
    warnings.push('Circular dependencies detected in test case execution order');
  }

  // Validate parallel execution settings
  if (testSuite.settings.parallel && testSuite.settings.maxConcurrency > 10) {
    warnings.push('High concurrency limit may impact system performance');
  }

  return warnings;
}

/**
 * Extract variable references from steps
 */
function extractVariableReferences(steps: Step[]): string[] {
  const references: string[] = [];
  const variablePattern = /\$\{([^}]+)\}/g;

  function extractFromValue(value: any): void {
    if (typeof value === 'string') {
      let match;
      while ((match = variablePattern.exec(value)) !== null) {
        references.push(match[1]);
      }
    } else if (typeof value === 'object' && value !== null) {
      Object.values(value).forEach(extractFromValue);
    }
  }

  steps.forEach(step => {
    extractFromValue(step.value);
    extractFromValue(step.options);
    if ('locator' in step && step.locator) {
      extractFromValue(step.locator);
    }
  });

  return [...new Set(references)]; // Remove duplicates
}

/**
 * Check for circular dependencies
 */
function hasCircularDependencies(dependencies: Array<{ testCase: string; dependsOn: string[] }>): boolean {
  const visited = new Set<string>();
  const recursionStack = new Set<string>();

  function hasCircle(testCase: string): boolean {
    if (recursionStack.has(testCase)) return true;
    if (visited.has(testCase)) return false;

    visited.add(testCase);
    recursionStack.add(testCase);

    const deps = dependencies.find(d => d.testCase === testCase)?.dependsOn || [];
    for (const dep of deps) {
      if (hasCircle(dep)) return true;
    }

    recursionStack.delete(testCase);
    return false;
  }

  for (const dep of dependencies) {
    if (hasCircle(dep.testCase)) return true;
  }

  return false;
}

/**
 * Compile TestCase to ExecutionPlan
 */
function compileTestCase(testCase: TestCase, env: CompilationEnvironment): ExecutionPlan {
  const steps = testCase.steps.map((step, index) => ({
    id: step.id,
    step,
    dependencies: index > 0 ? [testCase.steps[index - 1].id] : [],
    parallelGroup: undefined,
    retryPolicy: step.retryCount > 0 ? {
      maxRetries: step.retryCount,
      backoffStrategy: 'fixed' as const,
      backoffDelay: step.retryDelay || 1000
    } : undefined
  }));

  return {
    id: crypto.randomUUID(),
    name: testCase.name,
    type: 'testcase',
    strategy: testCase.settings.parallel ? 'parallel' : 'sequential',
    maxConcurrency: 1,
    steps,
    environment: env.settings || {},
    variables: testCase.variables.reduce((acc, v) => {
      acc[v.name] = v.value;
      return acc;
    }, {} as Record<string, any>),
    preChecks: [],
    postChecks: [],
    compiledAt: new Date(),
    compiledFrom: testCase.id,
    version: testCase.metadata.version
  };
}

/**
 * Compile TestSuite to ExecutionPlan
 */
function compileTestSuite(testSuite: TestSuite, env: CompilationEnvironment): ExecutionPlan {
  // For now, flatten all test case steps into a single plan
  // In a more sophisticated implementation, this would handle test case orchestration
  const allSteps: any[] = [];
  
  for (const testCaseRef of testSuite.testCases) {
    if (typeof testCaseRef === 'string') {
      // Reference to existing test case - would need to resolve from storage
      continue;
    } else {
      // Inline test case definition
      testCaseRef.steps.forEach((step, index) => {
        allSteps.push({
          id: step.id,
          step,
          dependencies: index > 0 ? [testCaseRef.steps[index - 1].id] : [],
          parallelGroup: testSuite.settings.parallel ? testCaseRef.id : undefined
        });
      });
    }
  }

  return {
    id: crypto.randomUUID(),
    name: testSuite.name,
    type: 'testsuite',
    strategy: testSuite.settings.parallel ? 'parallel' : 'sequential',
    maxConcurrency: testSuite.settings.maxConcurrency,
    steps: allSteps,
    environment: env.settings || {},
    variables: testSuite.variables.reduce((acc, v) => {
      acc[v.name] = v.value;
      return acc;
    }, {} as Record<string, any>),
    preChecks: [],
    postChecks: [],
    compiledAt: new Date(),
    compiledFrom: testSuite.id,
    version: testSuite.metadata.version
  };
}
