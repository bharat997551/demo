import { zodToJsonSchema } from 'zod-to-json-schema';
import {
  TestSuiteSchema,
  TestCaseSchema,
  StepSchema,
  VariableSchema,
  DataTableSchema,
  FlowNodeSchema,
  FlowEdgeSchema,
  ExecutionPlanSchema
} from '../types';

/**
 * Generate comprehensive JSON Schema for the DSL
 */
export function generateDSLSchema() {
  const testSuiteSchema = zodToJsonSchema(TestSuiteSchema, {
    name: 'TestSuite',
    $refStrategy: 'relative'
  });

  const testCaseSchema = zodToJsonSchema(TestCaseSchema, {
    name: 'TestCase', 
    $refStrategy: 'relative'
  });

  const stepSchema = zodToJsonSchema(StepSchema, {
    name: 'Step',
    $refStrategy: 'relative'
  });

  const variableSchema = zodToJsonSchema(VariableSchema, {
    name: 'Variable',
    $refStrategy: 'relative'
  });

  const dataTableSchema = zodToJsonSchema(DataTableSchema, {
    name: 'DataTable',
    $refStrategy: 'relative'
  });

  const flowNodeSchema = zodToJsonSchema(FlowNodeSchema, {
    name: 'FlowNode',
    $refStrategy: 'relative'
  });

  const flowEdgeSchema = zodToJsonSchema(FlowEdgeSchema, {
    name: 'FlowEdge',
    $refStrategy: 'relative'
  });

  const executionPlanSchema = zodToJsonSchema(ExecutionPlanSchema, {
    name: 'ExecutionPlan',
    $refStrategy: 'relative'
  });

  return {
    $schema: 'https://json-schema.org/draft/2020-12/schema',
    $id: 'https://hybrid-qa.dev/schemas/dsl.schema.json',
    title: 'Hybrid QA DSL Schema',
    description: 'JSON Schema for Hybrid QA Domain Specific Language',
    type: 'object',
    definitions: {
      TestSuite: testSuiteSchema,
      TestCase: testCaseSchema,
      Step: stepSchema,
      Variable: variableSchema,
      DataTable: dataTableSchema,
      FlowNode: flowNodeSchema,
      FlowEdge: flowEdgeSchema,
      ExecutionPlan: executionPlanSchema
    },
    // Root can be either TestSuite or TestCase
    oneOf: [
      { $ref: '#/definitions/TestSuite' },
      { $ref: '#/definitions/TestCase' }
    ],
    examples: [
      {
        // Web test case example
        id: '550e8400-e29b-41d4-a716-446655440001',
        name: 'Login Flow Test',
        description: 'Test user login functionality',
        tags: ['auth', 'web', 'smoke'],
        priority: 'high',
        steps: [
          {
            id: '550e8400-e29b-41d4-a716-446655440101',
            name: 'Navigate to login page',
            kind: 'web.navigate',
            engine: 'web',
            options: {
              url: 'https://example.com/login'
            }
          },
          {
            id: '550e8400-e29b-41d4-a716-446655440102',
            name: 'Enter username',
            kind: 'web.type',
            engine: 'web',
            locator: {
              primary: {
                strategy: 'css',
                value: '#username'
              },
              fallbacks: [
                {
                  strategy: 'test-id',
                  value: 'username-input'
                }
              ]
            },
            options: {
              text: '${username}'
            }
          },
          {
            id: '550e8400-e29b-41d4-a716-446655440103',
            name: 'Enter password',
            kind: 'web.type',
            engine: 'web',
            locator: {
              primary: {
                strategy: 'css',
                value: '#password'
              }
            },
            options: {
              text: '${password}'
            }
          },
          {
            id: '550e8400-e29b-41d4-a716-446655440104',
            name: 'Click login button',
            kind: 'web.click',
            engine: 'web',
            locator: {
              primary: {
                strategy: 'css',
                value: 'button[type="submit"]'
              }
            }
          },
          {
            id: '550e8400-e29b-41d4-a716-446655440105',
            name: 'Verify dashboard',
            kind: 'assert',
            engine: 'utility',
            assertions: [
              {
                type: 'visible',
                locator: {
                  primary: {
                    strategy: 'css',
                    value: '.dashboard'
                  }
                },
                expected: true,
                message: 'Dashboard should be visible after login'
              }
            ]
          }
        ],
        variables: [
          {
            name: 'username',
            type: 'string',
            value: 'testuser@example.com'
          },
          {
            name: 'password',
            type: 'secret',
            value: 'secret123',
            sensitive: true
          }
        ],
        metadata: {
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          version: '1.0.0',
          category: 'authentication'
        }
      },
      {
        // Desktop test case example
        id: '550e8400-e29b-41d4-a716-446655440002',
        name: 'Calculator Addition Test',
        description: 'Test calculator addition functionality',
        tags: ['desktop', 'calculator', 'smoke'],
        priority: 'medium',
        steps: [
          {
            id: '550e8400-e29b-41d4-a716-446655440201',
            name: 'Open Calculator',
            kind: 'desktop.window-focus',
            engine: 'desktop',
            options: {
              windowTitle: 'Calculator'
            }
          },
          {
            id: '550e8400-e29b-41d4-a716-446655440202',
            name: 'Click 5',
            kind: 'desktop.click',
            engine: 'desktop',
            locator: {
              primary: {
                strategy: 'uia-name',
                value: 'Five'
              }
            }
          },
          {
            id: '550e8400-e29b-41d4-a716-446655440203',
            name: 'Click Plus',
            kind: 'desktop.click',
            engine: 'desktop',
            locator: {
              primary: {
                strategy: 'uia-name',
                value: 'Plus'
              }
            }
          },
          {
            id: '550e8400-e29b-41d4-a716-446655440204',
            name: 'Click 3',
            kind: 'desktop.click',
            engine: 'desktop',
            locator: {
              primary: {
                strategy: 'uia-name',
                value: 'Three'
              }
            }
          },
          {
            id: '550e8400-e29b-41d4-a716-446655440205',
            name: 'Click Equals',
            kind: 'desktop.click',
            engine: 'desktop',
            locator: {
              primary: {
                strategy: 'uia-name',
                value: 'Equals'
              }
            }
          },
          {
            id: '550e8400-e29b-41d4-a716-446655440206',
            name: 'Verify Result',
            kind: 'assert',
            engine: 'utility',
            assertions: [
              {
                type: 'text-contains',
                locator: {
                  primary: {
                    strategy: 'uia-automation-id',
                    value: 'CalculatorResults'
                  }
                },
                expected: '8',
                message: '5 + 3 should equal 8'
              }
            ]
          }
        ],
        metadata: {
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          version: '1.0.0',
          category: 'functional'
        }
      },
      {
        // Mixed flow test suite example
        id: '550e8400-e29b-41d4-a716-446655440003',
        name: 'E2E Order Processing Suite',
        description: 'End-to-end order processing across web and API',
        tags: ['e2e', 'orders', 'integration'],
        testCases: [
          {
            id: '550e8400-e29b-41d4-a716-446655440301',
            name: 'Place Order via Web',
            steps: [
              {
                id: '550e8400-e29b-41d4-a716-446655440401',
                name: 'Navigate to shop',
                kind: 'web.navigate',
                engine: 'web',
                options: {
                  url: 'https://shop.example.com'
                }
              },
              {
                id: '550e8400-e29b-41d4-a716-446655440402',
                name: 'Add product to cart',
                kind: 'web.click',
                engine: 'web',
                locator: {
                  primary: {
                    strategy: 'test-id',
                    value: 'add-to-cart-btn'
                  }
                }
              },
              {
                id: '550e8400-e29b-41d4-a716-446655440403',
                name: 'Extract order ID',
                kind: 'web.extract',
                engine: 'web',
                locator: {
                  primary: {
                    strategy: 'css',
                    value: '.order-confirmation .order-id'
                  }
                }
              },
              {
                id: '550e8400-e29b-41d4-a716-446655440404',
                name: 'Store order ID',
                kind: 'var.set',
                engine: 'variable',
                options: {
                  name: 'orderId',
                  expression: 'extractedText'
                }
              }
            ]
          },
          {
            id: '550e8400-e29b-41d4-a716-446655440302',
            name: 'Verify Order via API',
            steps: [
              {
                id: '550e8400-e29b-41d4-a716-446655440501',
                name: 'Get order details',
                kind: 'api.request',
                engine: 'api',
                options: {
                  method: 'GET',
                  url: 'https://api.example.com/orders/${orderId}',
                  headers: {
                    'Authorization': 'Bearer ${apiToken}'
                  }
                }
              },
              {
                id: '550e8400-e29b-41d4-a716-446655440502',
                name: 'Verify order status',
                kind: 'assert',
                engine: 'utility',
                assertions: [
                  {
                    type: 'response-body-contains',
                    expected: 'confirmed',
                    message: 'Order should be confirmed'
                  }
                ]
              }
            ]
          }
        ],
        variables: [
          {
            name: 'apiToken',
            type: 'secret',
            value: 'abc123token',
            sensitive: true
          }
        ],
        settings: {
          parallel: false,
          maxConcurrency: 1,
          continueOnFailure: false
        },
        metadata: {
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          version: '1.0.0',
          category: 'integration',
          environment: 'staging'
        }
      }
    ]
  };
}

/**
 * Write DSL schema to file
 */
export function writeDSLSchemaFile(outputPath: string = './dsl.schema.json'): void {
  const fs = require('fs');
  const schema = generateDSLSchema();
  fs.writeFileSync(outputPath, JSON.stringify(schema, null, 2));
} 