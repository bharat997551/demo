import { z } from 'zod';

// Base types
export const StepIdSchema = z.string().uuid();
export const FlowIdSchema = z.string().uuid();
export const ProjectIdSchema = z.string().uuid();

export type StepId = z.infer<typeof StepIdSchema>;
export type FlowId = z.infer<typeof FlowIdSchema>;
export type ProjectId = z.infer<typeof ProjectIdSchema>;

// Engine types
export const EngineTypeSchema = z.enum([
  'web',
  'desktop', 
  'mainframe',
  'api',
]);

export type EngineType = z.infer<typeof EngineTypeSchema>;

// Variable and data types
export const VariableTypeSchema = z.enum([
  'string',
  'number',
  'boolean',
  'array',
  'object',
]);

export const VariableSchema = z.object({
  name: z.string(),
  type: VariableTypeSchema,
  value: z.any(),
  description: z.string().optional(),
});

export const DataTableSchema = z.object({
  id: z.string(),
  name: z.string(),
  columns: z.array(z.string()),
  rows: z.array(z.array(z.any())),
});

export type Variable = z.infer<typeof VariableSchema>;
export type DataTable = z.infer<typeof DataTableSchema>; 