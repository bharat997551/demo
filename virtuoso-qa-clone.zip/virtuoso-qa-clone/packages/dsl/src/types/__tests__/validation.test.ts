import { validateDSL, compileToPlan } from '../../utils/validation';
import { TestCase, TestSuite, Step } from '../..';

describe('DSL Validation', () => {
  describe('validateDSL', () => {
    it('should validate a correct web test case', () => {
      const webTestCase = {
        id: '550e8400-e29b-41d4-a716-446655440001',
        name: 'Login Test',
        description: 'Test user login flow',
        tags: ['web', 'auth'],
        priority: 'high',
        steps: [
          {
            id: '550e8400-e29b-41d4-a716-446655440101',
            name: 'Navigate to login',
            kind: 'web.navigate',
            engine: 'web',
            options: {
              url: 'https://example.com/login'
            }
          },
          {
            id: '550e8400-e29b-41d4-a716-446655440102',
            name: 'Enter credentials',
            kind: 'web.type',
            engine: 'web',
            locator: {
              primary: {
                strategy: 'css',
                value: '#username'
              }
            },
            options: {
              text: 'testuser@example.com'
            }
          }
        ],
        variables: [],
        dataTables: [],
        metadata: {
          createdAt: new Date(),
          updatedAt: new Date(),
          version: '1.0.0'
        }
      };

      const result = validateDSL(webTestCase);
      expect(result.valid).toBe(true);
      expect(result.errors).toBeUndefined();
    });

    it('should validate a correct desktop test case', () => {
      const desktopTestCase = {
        id: '550e8400-e29b-41d4-a716-446655440002',
        name: 'Calculator Test',
        description: 'Test calculator functionality',
        tags: ['desktop', 'calculator'],
        priority: 'medium',
        steps: [
          {
            id: '550e8400-e29b-41d4-a716-446655440201',
            name: 'Click number 5',
            kind: 'desktop.click',
            engine: 'desktop',
            locator: {
              primary: {
                strategy: 'uia-name',
                value: 'Five'
              }
            }
          },
          {
            id: '550e8400-e29b-41d4-a716-446655440202',
            name: 'Take screenshot',
            kind: 'screenshot',
            engine: 'utility',
            options: {
              filename: 'calculator-test.png'
            }
          }
        ],
        variables: [],
        dataTables: [],
        metadata: {
          createdAt: new Date(),
          updatedAt: new Date(),
          version: '1.0.0'
        }
      };

      const result = validateDSL(desktopTestCase);
      expect(result.valid).toBe(true);
      expect(result.errors).toBeUndefined();
    });

    it('should validate a test suite with multiple test cases', () => {
      const testSuite = {
        id: '550e8400-e29b-41d4-a716-446655440003',
        name: 'Integration Test Suite',
        description: 'End-to-end integration tests',
        tags: ['e2e', 'integration'],
        testCases: [
          {
            id: '550e8400-e29b-41d4-a716-446655440301',
            name: 'API Test',
            steps: [
              {
                id: '550e8400-e29b-41d4-a716-446655440401',
                name: 'Make API request',
                kind: 'api.request',
                engine: 'api',
                options: {
                  method: 'GET',
                  url: 'https://api.example.com/users'
                }
              }
            ],
            variables: [],
            dataTables: [],
            metadata: {
              createdAt: new Date(),
              updatedAt: new Date(),
              version: '1.0.0'
            }
          }
        ],
        variables: [],
        dataTables: [],
        settings: {
          parallel: false,
          maxConcurrency: 1
        },
        execution: {
          order: 'sequential',
          dependencies: []
        },
        metadata: {
          createdAt: new Date(),
          updatedAt: new Date(),
          version: '1.0.0'
        }
      };

      const result = validateDSL(testSuite);
      expect(result.valid).toBe(true);
      expect(result.errors).toBeUndefined();
    });

    it('should reject invalid test case - missing required fields', () => {
      const invalidTestCase = {
        // Missing id
        name: 'Incomplete Test',
        steps: []
      };

      const result = validateDSL(invalidTestCase);
      expect(result.valid).toBe(false);
      expect(result.errors).toBeDefined();
      expect(result.errors?.length).toBeGreaterThan(0);
    });

    it('should reject invalid step - unknown engine', () => {
      const invalidTestCase = {
        id: '550e8400-e29b-41d4-a716-446655440004',
        name: 'Invalid Step Test',
        steps: [
          {
            id: '550e8400-e29b-41d4-a716-446655440501',
            name: 'Invalid step',
            kind: 'web.click',
            engine: 'invalid_engine', // Invalid engine
          }
        ],
        variables: [],
        dataTables: [],
        metadata: {
          createdAt: new Date(),
          updatedAt: new Date(),
          version: '1.0.0'
        }
      };

      const result = validateDSL(invalidTestCase);
      expect(result.valid).toBe(false);
      expect(result.errors).toBeDefined();
    });

    it('should reject invalid locator strategy', () => {
      const invalidTestCase = {
        id: '550e8400-e29b-41d4-a716-446655440005',
        name: 'Invalid Locator Test',
        steps: [
          {
            id: '550e8400-e29b-41d4-a716-446655440601',
            name: 'Click with invalid locator',
            kind: 'web.click',
            engine: 'web',
            locator: {
              primary: {
                strategy: 'invalid_strategy', // Invalid strategy
                value: '#button'
              }
            }
          }
        ],
        variables: [],
        dataTables: [],
        metadata: {
          createdAt: new Date(),
          updatedAt: new Date(),
          version: '1.0.0'
        }
      };

      const result = validateDSL(invalidTestCase);
      expect(result.valid).toBe(false);
      expect(result.errors).toBeDefined();
    });

    it('should warn about undefined variables', () => {
      const testCaseWithUndefinedVar = {
        id: '550e8400-e29b-41d4-a716-446655440006',
        name: 'Undefined Variable Test',
        steps: [
          {
            id: '550e8400-e29b-41d4-a716-446655440701',
            name: 'Type with undefined variable',
            kind: 'web.type',
            engine: 'web',
            options: {
              text: '${undefinedVariable}' // Variable not defined
            }
          }
        ],
        variables: [
          {
            name: 'definedVariable',
            type: 'string',
            value: 'defined'
          }
        ],
        dataTables: [],
        metadata: {
          createdAt: new Date(),
          updatedAt: new Date(),
          version: '1.0.0'
        }
      };

      const result = validateDSL(testCaseWithUndefinedVar);
      expect(result.valid).toBe(true);
      expect(result.warnings).toBeDefined();
      expect(result.warnings).toContain('Variable \'undefinedVariable\' referenced but not defined');
    });

    it('should warn about empty test case', () => {
      const emptyTestCase = {
        id: '550e8400-e29b-41d4-a716-446655440007',
        name: 'Empty Test Case',
        steps: [],
        nodes: [],
        variables: [],
        dataTables: [],
        metadata: {
          createdAt: new Date(),
          updatedAt: new Date(),
          version: '1.0.0'
        }
      };

      const result = validateDSL(emptyTestCase);
      expect(result.valid).toBe(true);
      expect(result.warnings).toContain('Test case has no steps or flow nodes defined');
    });
  });

  describe('compileToPlan', () => {
    it('should compile a test case to execution plan', () => {
      const testCase = {
        id: '550e8400-e29b-41d4-a716-446655440008',
        name: 'Compilation Test',
        steps: [
          {
            id: '550e8400-e29b-41d4-a716-446655440801',
            name: 'First step',
            kind: 'web.navigate',
            engine: 'web',
            retryCount: 2,
            options: {
              url: 'https://example.com'
            }
          },
          {
            id: '550e8400-e29b-41d4-a716-446655440802',
            name: 'Second step',
            kind: 'web.click',
            engine: 'web',
            locator: {
              primary: {
                strategy: 'css',
                value: '#button'
              }
            }
          }
        ],
        variables: [
          {
            name: 'testVar',
            type: 'string',
            value: 'testValue'
          }
        ],
        dataTables: [],
        metadata: {
          createdAt: new Date(),
          updatedAt: new Date(),
          version: '1.0.0'
        }
      };

      const plan = compileToPlan(testCase);
      
      expect(plan).toBeDefined();
      expect(plan.type).toBe('testcase');
      expect(plan.name).toBe('Compilation Test');
      expect(plan.steps).toHaveLength(2);
      expect(plan.variables).toEqual({ testVar: 'testValue' });
      
      // Check step dependencies
      expect(plan.steps[0].dependencies).toEqual([]);
      expect(plan.steps[1].dependencies).toEqual([testCase.steps[0].id]);
      
      // Check retry policy
      expect(plan.steps[0].retryPolicy).toBeDefined();
      expect(plan.steps[0].retryPolicy?.maxRetries).toBe(2);
    });

    it('should compile a test suite to execution plan', () => {
      const testSuite = {
        id: '550e8400-e29b-41d4-a716-446655440009',
        name: 'Suite Compilation Test',
        testCases: [
          {
            id: '550e8400-e29b-41d4-a716-446655440901',
            name: 'Test Case 1',
            steps: [
              {
                id: '550e8400-e29b-41d4-a716-446655440A01',
                name: 'Step 1',
                kind: 'web.navigate',
                engine: 'web',
                options: {
                  url: 'https://example.com'
                }
              }
            ],
            variables: [],
            dataTables: [],
            metadata: {
              createdAt: new Date(),
              updatedAt: new Date(),
              version: '1.0.0'
            }
          }
        ],
        variables: [
          {
            name: 'suiteVar',
            type: 'string',
            value: 'suiteValue'
          }
        ],
        dataTables: [],
        settings: {
          parallel: true,
          maxConcurrency: 2
        },
        execution: {
          order: 'parallel',
          dependencies: []
        },
        metadata: {
          createdAt: new Date(),
          updatedAt: new Date(),
          version: '1.0.0'
        }
      };

      const plan = compileToPlan(testSuite);
      
      expect(plan).toBeDefined();
      expect(plan.type).toBe('testsuite');
      expect(plan.name).toBe('Suite Compilation Test');
      expect(plan.strategy).toBe('parallel');
      expect(plan.maxConcurrency).toBe(2);
      expect(plan.variables).toEqual({ suiteVar: 'suiteValue' });
    });

    it('should throw error for invalid DSL', () => {
      const invalidDSL = {
        // Missing required fields
        name: 'Invalid'
      };

      expect(() => compileToPlan(invalidDSL)).toThrow('Invalid DSL');
    });
  });
}); 