import { z } from 'zod';
import { ProjectIdSchema } from './base';

export const ProjectSchema = z.object({
  id: ProjectIdSchema,
  name: z.string(),
  description: z.string().optional(),
  settings: z.object({
    defaultTimeout: z.number().default(30000),
    screenshotOnFailure: z.boolean().default(true),
    videoRecording: z.boolean().default(false),
    parallelExecutionLimit: z.number().default(1),
    engines: z.object({
      web: z.object({
        browser: z.enum(['chromium', 'firefox', 'webkit']).default('chromium'),
        headless: z.boolean().default(false),
        viewport: z.object({
          width: z.number().default(1280),
          height: z.number().default(720),
        }),
      }).default({}),
      desktop: z.object({
        backend: z.enum(['uia', 'win32']).default('uia'),
        highlightElements: z.boolean().default(true),
      }).default({}),
      mainframe: z.object({
        host: z.string().optional(),
        port: z.number().default(23),
        model: z.string().default('3279-2'),
      }).default({}),
      api: z.object({
        baseUrl: z.string().optional(),
        defaultHeaders: z.record(z.string()).default({}),
        validateSSL: z.boolean().default(true),
      }).default({}),
    }).default({}),
  }).default({}),
  metadata: z.object({
    createdAt: z.date(),
    updatedAt: z.date(),
    version: z.string().default('1.0.0'),
  }),
});

export type Project = z.infer<typeof ProjectSchema>; 