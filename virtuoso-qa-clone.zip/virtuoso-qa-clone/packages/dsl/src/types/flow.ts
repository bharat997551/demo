import { z } from 'zod';
import { TestSuiteIdSchema, TestCaseIdSchema, FlowNodeIdSchema, FlowEdgeIdSchema, VariableSchema, DataTableSchema } from './core';
import { StepSchema } from './steps';

// Flow node types for visual flow representation
export const FlowNodeTypeSchema = z.enum([
  'start',
  'end', 
  'step',
  'condition',
  'loop',
  'parallel',
  'merge',
  'call',
  'data'
]);

export const FlowNodeSchema = z.object({
  id: FlowNodeIdSchema,
  type: FlowNodeTypeSchema,
  name: z.string().min(1),
  description: z.string().optional(),
  position: z.object({
    x: z.number(),
    y: z.number()
  }),
  size: z.object({
    width: z.number().positive().default(200),
    height: z.number().positive().default(100)
  }).optional(),
  // Step data (when type === 'step')
  step: StepSchema.optional(),
  // Condition data (when type === 'condition')
  condition: z.object({
    expression: z.string(),
    description: z.string().optional()
  }).optional(),
  // Loop data (when type === 'loop')
  loop: z.object({
    type: z.enum(['for', 'while', 'foreach']),
    expression: z.string().optional(),
    iterations: z.number().positive().optional(),
    dataTable: z.string().optional()
  }).optional(),
  // Call data (when type === 'call')
  call: z.object({
    target: z.string(), // TestCase or TestSuite ID
    parameters: z.record(z.any()).optional()
  }).optional(),
  // Data binding (when type === 'data')
  data: z.object({
    dataTable: z.string(),
    mapping: z.record(z.string()).optional()
  }).optional(),
  style: z.object({
    color: z.string().optional(),
    backgroundColor: z.string().optional(),
    borderColor: z.string().optional(),
    borderWidth: z.number().optional()
  }).optional(),
  metadata: z.record(z.any()).default({})
});

// Flow edge (connection between nodes)
export const FlowEdgeSchema = z.object({
  id: FlowEdgeIdSchema,
  source: FlowNodeIdSchema,
  target: FlowNodeIdSchema,
  sourceHandle: z.string().optional(), // For multiple output points
  targetHandle: z.string().optional(), // For multiple input points
  type: z.enum(['default', 'success', 'failure', 'condition']).default('default'),
  condition: z.string().optional(), // Condition for edge traversal
  label: z.string().optional(),
  style: z.object({
    color: z.string().optional(),
    strokeWidth: z.number().optional(),
    strokeDasharray: z.string().optional()
  }).optional(),
  metadata: z.record(z.any()).default({})
});

// Test Case definition
export const TestCaseSchema = z.object({
  id: TestCaseIdSchema,
  name: z.string().min(1),
  description: z.string().optional(),
  tags: z.array(z.string()).default([]),
  priority: z.enum(['low', 'medium', 'high', 'critical']).default('medium'),
  // Linear steps (traditional approach)
  steps: z.array(StepSchema).default([]),
  // Visual flow (modern approach)
  nodes: z.array(FlowNodeSchema).default([]),
  edges: z.array(FlowEdgeSchema).default([]),
  // Variables and data
  variables: z.array(VariableSchema).default([]),
  dataTables: z.array(DataTableSchema).default([]),
  // Configuration
  settings: z.object({
    timeout: z.number().positive().default(300000), // 5 minutes
    retryCount: z.number().min(0).default(0),
    parallel: z.boolean().default(false),
    screenshots: z.object({
      onFailure: z.boolean().default(true),
      onSuccess: z.boolean().default(false),
      onStep: z.boolean().default(false)
    }).default({}),
    reports: z.object({
      generateHtml: z.boolean().default(true),
      generateJson: z.boolean().default(true),
      includeScreenshots: z.boolean().default(true)
    }).default({})
  }).default({}),
  // Metadata
  metadata: z.object({
    createdAt: z.date(),
    updatedAt: z.date(),
    createdBy: z.string().optional(),
    version: z.string().default('1.0.0'),
    category: z.string().optional(),
    requirements: z.array(z.string()).default([])
  })
});

// Test Suite definition
export const TestSuiteSchema = z.object({
  id: TestSuiteIdSchema,
  name: z.string().min(1),
  description: z.string().optional(),
  tags: z.array(z.string()).default([]),
  // Test cases in the suite
  testCases: z.array(z.union([
    TestCaseIdSchema, // Reference to existing test case
    TestCaseSchema    // Inline test case definition
  ])).default([]),
  // Suite-level configuration
  settings: z.object({
    parallel: z.boolean().default(false),
    maxConcurrency: z.number().positive().default(1),
    timeout: z.number().positive().default(3600000), // 1 hour
    continueOnFailure: z.boolean().default(false),
    setupSuite: TestCaseIdSchema.optional(), // Setup test case
    teardownSuite: TestCaseIdSchema.optional(), // Teardown test case
    setupTest: TestCaseIdSchema.optional(), // Before each test
    teardownTest: TestCaseIdSchema.optional() // After each test
  }).default({}),
  // Suite-level variables and data
  variables: z.array(VariableSchema).default([]),
  dataTables: z.array(DataTableSchema).default([]),
  // Execution order and dependencies
  execution: z.object({
    order: z.enum(['sequential', 'parallel', 'dependency']).default('sequential'),
    dependencies: z.array(z.object({
      testCase: TestCaseIdSchema,
      dependsOn: z.array(TestCaseIdSchema)
    })).default([])
  }).default({}),
  // Metadata
  metadata: z.object({
    createdAt: z.date(),
    updatedAt: z.date(),
    createdBy: z.string().optional(),
    version: z.string().default('1.0.0'),
    category: z.string().optional(),
    environment: z.string().optional()
  })
});

// Execution plan (compiled from DSL)
export const ExecutionPlanSchema = z.object({
  id: z.string().uuid(),
  name: z.string(),
  type: z.enum(['testcase', 'testsuite']),
  // Execution strategy
  strategy: z.enum(['sequential', 'parallel', 'optimized']).default('sequential'),
  maxConcurrency: z.number().positive().default(1),
  // Resolved steps in execution order
  steps: z.array(z.object({
    id: z.string(),
    step: StepSchema,
    dependencies: z.array(z.string()).default([]),
    parallelGroup: z.string().optional(),
    retryPolicy: z.object({
      maxRetries: z.number().min(0).default(0),
      backoffStrategy: z.enum(['fixed', 'exponential', 'linear']).default('fixed'),
      backoffDelay: z.number().min(0).default(1000)
    }).optional()
  })),
  // Environment and context
  environment: z.record(z.any()).default({}),
  variables: z.record(z.any()).default({}),
  // Validation and checks
  preChecks: z.array(z.string()).default([]),
  postChecks: z.array(z.string()).default([]),
  // Metadata
  compiledAt: z.date(),
  compiledFrom: z.string(), // Original DSL source
  version: z.string()
});

// Export types
export type FlowNodeType = z.infer<typeof FlowNodeTypeSchema>;
export type FlowNode = z.infer<typeof FlowNodeSchema>;
export type FlowEdge = z.infer<typeof FlowEdgeSchema>;
export type TestCase = z.infer<typeof TestCaseSchema>;
export type TestSuite = z.infer<typeof TestSuiteSchema>;
export type ExecutionPlan = z.infer<typeof ExecutionPlanSchema>; 