import { z } from 'zod';

// Core identifiers
export const TestSuiteIdSchema = z.string().uuid();
export const TestCaseIdSchema = z.string().uuid();
export const StepIdSchema = z.string().uuid();
export const FlowNodeIdSchema = z.string().uuid();
export const FlowEdgeIdSchema = z.string().uuid();

export type TestSuiteId = z.infer<typeof TestSuiteIdSchema>;
export type TestCaseId = z.infer<typeof TestCaseIdSchema>;
export type StepId = z.infer<typeof StepIdSchema>;
export type FlowNodeId = z.infer<typeof FlowNodeIdSchema>;
export type FlowEdgeId = z.infer<typeof FlowEdgeIdSchema>;

// Variable definitions
export const VariableTypeSchema = z.enum([
  'string',
  'number', 
  'boolean',
  'array',
  'object',
  'secret'
]);

export const VariableSchema = z.object({
  name: z.string().min(1),
  type: VariableTypeSchema,
  value: z.any(),
  description: z.string().optional(),
  required: z.boolean().default(false),
  sensitive: z.boolean().default(false)
});

// Data table for parameterized testing
export const DataTableSchema = z.object({
  id: z.string(),
  name: z.string().min(1),
  description: z.string().optional(),
  columns: z.array(z.object({
    name: z.string().min(1),
    type: VariableTypeSchema.default('string'),
    required: z.boolean().default(true)
  })),
  rows: z.array(z.array(z.any())),
  metadata: z.record(z.any()).default({})
});

// Multi-strategy locator system
export const LocatorStrategySchema = z.enum([
  // Web strategies
  'css',
  'xpath', 
  'text',
  'partial-text',
  'role',
  'test-id',
  'placeholder',
  'alt-text',
  'label',
  'title',
  // Desktop strategies
  'uia-name',
  'uia-automation-id',
  'uia-class-name',
  'uia-control-type',
  'win32-class',
  'win32-control-id',
  // Mainframe strategies
  'screen-position',
  'screen-text',
  'field-name',
  // Universal strategies
  'coordinates',
  'image',
  'ai-description'
]);

export const LocatorSchema = z.object({
  strategy: LocatorStrategySchema,
  value: z.string(),
  confidence: z.number().min(0).max(1).default(1.0),
  timeout: z.number().positive().default(30000),
  description: z.string().optional(),
  metadata: z.record(z.any()).default({})
});

export const MultiLocatorSchema = z.object({
  primary: LocatorSchema,
  fallbacks: z.array(LocatorSchema).default([]),
  selfHealing: z.boolean().default(true),
  description: z.string().optional()
});

// Assertion system
export const AssertionTypeSchema = z.enum([
  'exists',
  'not-exists', 
  'visible',
  'not-visible',
  'enabled',
  'disabled',
  'text-equals',
  'text-contains',
  'text-matches',
  'value-equals',
  'value-contains',
  'attribute-equals',
  'attribute-contains',
  'count-equals',
  'count-greater-than',
  'count-less-than',
  'response-status',
  'response-body-contains',
  'response-header-equals',
  'custom'
]);

export const AssertionSchema = z.object({
  type: AssertionTypeSchema,
  locator: MultiLocatorSchema.optional(),
  expected: z.any(),
  actual: z.any().optional(),
  message: z.string().optional(),
  timeout: z.number().positive().default(30000),
  retryInterval: z.number().positive().default(1000),
  continueOnFailure: z.boolean().default(false)
});

export type Variable = z.infer<typeof VariableSchema>;
export type DataTable = z.infer<typeof DataTableSchema>;
export type LocatorStrategy = z.infer<typeof LocatorStrategySchema>;
export type Locator = z.infer<typeof LocatorSchema>;
export type MultiLocator = z.infer<typeof MultiLocatorSchema>;
export type AssertionType = z.infer<typeof AssertionTypeSchema>;
export type Assertion = z.infer<typeof AssertionSchema>; 