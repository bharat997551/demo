import { z } from 'zod';
import { StepIdSchema, MultiLocatorSchema, AssertionSchema, VariableSchema } from './core';

// Base step schema
export const BaseStepSchema = z.object({
  id: StepIdSchema,
  name: z.string().min(1),
  description: z.string().optional(),
  enabled: z.boolean().default(true),
  timeout: z.number().positive().default(30000),
  retryCount: z.number().min(0).default(0),
  retryDelay: z.number().min(0).default(1000),
  continueOnFailure: z.boolean().default(false),
  tags: z.array(z.string()).default([]),
  metadata: z.record(z.any()).default({})
});

// Web automation steps
export const WebStepKindSchema = z.enum([
  'web.navigate',
  'web.click',
  'web.double-click',
  'web.right-click',
  'web.hover',
  'web.type',
  'web.clear',
  'web.select',
  'web.check',
  'web.uncheck',
  'web.upload',
  'web.drag-drop',
  'web.scroll',
  'web.wait',
  'web.screenshot',
  'web.extract',
  'web.execute-js',
  'web.switch-frame',
  'web.switch-tab',
  'web.refresh',
  'web.back',
  'web.forward'
]);

export const WebStepSchema = BaseStepSchema.extend({
  kind: WebStepKindSchema,
  engine: z.literal('web'),
  locator: MultiLocatorSchema.optional(),
  value: z.string().optional(),
  options: z.object({
    url: z.string().url().optional(),
    text: z.string().optional(),
    key: z.string().optional(),
    button: z.enum(['left', 'right', 'middle']).optional(),
    modifiers: z.array(z.enum(['ctrl', 'shift', 'alt', 'meta'])).optional(),
    force: z.boolean().optional(),
    waitForNavigation: z.boolean().optional(),
    viewport: z.object({
      width: z.number(),
      height: z.number()
    }).optional(),
    screenshot: z.object({
      fullPage: z.boolean().optional(),
      quality: z.number().min(0).max(100).optional()
    }).optional()
  }).default({})
});

// Desktop automation steps  
export const DesktopStepKindSchema = z.enum([
  'desktop.click',
  'desktop.double-click',
  'desktop.right-click',
  'desktop.type',
  'desktop.key-press',
  'desktop.hotkey',
  'desktop.drag-drop',
  'desktop.scroll',
  'desktop.wait',
  'desktop.screenshot',
  'desktop.extract',
  'desktop.window-focus',
  'desktop.window-close',
  'desktop.window-maximize',
  'desktop.window-minimize'
]);

export const DesktopStepSchema = BaseStepSchema.extend({
  kind: DesktopStepKindSchema,
  engine: z.literal('desktop'),
  locator: MultiLocatorSchema.optional(),
  value: z.string().optional(),
  options: z.object({
    text: z.string().optional(),
    key: z.string().optional(),
    button: z.enum(['left', 'right', 'middle']).optional(),
    windowTitle: z.string().optional(),
    processName: z.string().optional(),
    coordinates: z.object({
      x: z.number(),
      y: z.number()
    }).optional(),
    offset: z.object({
      x: z.number().default(0),
      y: z.number().default(0)
    }).optional()
  }).default({})
});

// Mainframe automation steps
export const MainframeStepKindSchema = z.enum([
  'mainframe.connect',
  'mainframe.disconnect',
  'mainframe.send',
  'mainframe.send-key',
  'mainframe.wait',
  'mainframe.screenshot',
  'mainframe.extract',
  'mainframe.clear-field',
  'mainframe.set-cursor',
  'mainframe.execute-command'
]);

export const MainframeStepSchema = BaseStepSchema.extend({
  kind: MainframeStepKindSchema,
  engine: z.literal('mainframe'),
  options: z.object({
    host: z.string().optional(),
    port: z.number().min(1).max(65535).optional(),
    row: z.number().min(1).max(24).optional(),
    col: z.number().min(1).max(80).optional(),
    text: z.string().optional(),
    key: z.string().optional(),
    command: z.string().optional(),
    waitForText: z.string().optional(),
    timeout: z.number().positive().optional()
  }).default({})
});

// API testing steps
export const ApiStepKindSchema = z.enum([
  'api.request',
  'api.graphql',
  'api.grpc',
  'api.websocket-connect',
  'api.websocket-send',
  'api.websocket-disconnect',
  'api.wait'
]);

export const ApiStepSchema = BaseStepSchema.extend({
  kind: ApiStepKindSchema,
  engine: z.literal('api'),
  options: z.object({
    method: z.enum(['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS']).optional(),
    url: z.string().optional(),
    headers: z.record(z.string()).optional(),
    body: z.any().optional(),
    query: z.record(z.any()).optional(),
    auth: z.object({
      type: z.enum(['basic', 'bearer', 'api-key', 'oauth2']),
      credentials: z.record(z.string())
    }).optional(),
    timeout: z.number().positive().optional(),
    followRedirects: z.boolean().optional(),
    validateSSL: z.boolean().optional()
  }).default({})
});

// Flow control steps
export const FlowStepKindSchema = z.enum([
  'flow.call',
  'flow.if',
  'flow.loop',
  'flow.parallel',
  'flow.wait',
  'flow.break',
  'flow.continue'
]);

export const FlowStepSchema = BaseStepSchema.extend({
  kind: FlowStepKindSchema,
  engine: z.literal('flow'),
  options: z.object({
    target: z.string().optional(), // Target test case or flow
    condition: z.string().optional(), // JavaScript expression
    iterations: z.number().min(1).optional(),
    dataTable: z.string().optional(), // Data table reference
    parallel: z.boolean().optional(),
    waitTime: z.number().min(0).optional()
  }).default({})
});

// Variable manipulation steps
export const VarStepKindSchema = z.enum([
  'var.set',
  'var.get',
  'var.increment',
  'var.decrement',
  'var.append',
  'var.clear'
]);

export const VarStepSchema = BaseStepSchema.extend({
  kind: VarStepKindSchema,
  engine: z.literal('variable'),
  options: z.object({
    name: z.string().optional(),
    value: z.any().optional(),
    expression: z.string().optional(), // JavaScript expression
    scope: z.enum(['local', 'global', 'session']).optional()
  }).default({})
});

// Utility steps
export const UtilityStepKindSchema = z.enum([
  'wait',
  'screenshot',
  'log',
  'assert'
]);

export const UtilityStepSchema = BaseStepSchema.extend({
  kind: UtilityStepKindSchema,
  engine: z.literal('utility'),
  locator: MultiLocatorSchema.optional(),
  assertions: z.array(AssertionSchema).default([]),
  options: z.object({
    duration: z.number().min(0).optional(),
    message: z.string().optional(),
    level: z.enum(['debug', 'info', 'warn', 'error']).optional(),
    fullPage: z.boolean().optional(),
    filename: z.string().optional()
  }).default({})
});

// Discriminated union of all step types
export const StepSchema = z.discriminatedUnion('engine', [
  WebStepSchema,
  DesktopStepSchema,
  MainframeStepSchema,
  ApiStepSchema,
  FlowStepSchema,
  VarStepSchema,
  UtilityStepSchema
]);

// Export types
export type WebStepKind = z.infer<typeof WebStepKindSchema>;
export type WebStep = z.infer<typeof WebStepSchema>;
export type DesktopStepKind = z.infer<typeof DesktopStepKindSchema>;
export type DesktopStep = z.infer<typeof DesktopStepSchema>;
export type MainframeStepKind = z.infer<typeof MainframeStepKindSchema>;
export type MainframeStep = z.infer<typeof MainframeStepSchema>;
export type ApiStepKind = z.infer<typeof ApiStepKindSchema>;
export type ApiStep = z.infer<typeof ApiStepSchema>;
export type FlowStepKind = z.infer<typeof FlowStepKindSchema>;
export type FlowStep = z.infer<typeof FlowStepSchema>;
export type VarStepKind = z.infer<typeof VarStepKindSchema>;
export type VarStep = z.infer<typeof VarStepSchema>;
export type UtilityStepKind = z.infer<typeof UtilityStepKindSchema>;
export type UtilityStep = z.infer<typeof UtilityStepSchema>;
export type Step = z.infer<typeof StepSchema>; 