import { z } from 'zod';

// Selector types for self-healing
export const SelectorTypeSchema = z.enum([
  'css',
  'xpath',
  'text',
  'role',
  'testid',
  'placeholder',
  'alttext',
  'label',
  'title',
  'uia', // Windows UIA
  'wincontrol', // Win32 control
  'coordinates', // Fallback coordinates
]);

export const SelectorSchema = z.object({
  type: SelectorTypeSchema,
  value: z.string(),
  confidence: z.number().min(0).max(1).default(1.0),
  isGenerated: z.boolean().default(false),
  lastVerified: z.date().optional(),
});

export const SelectorGroupSchema = z.object({
  primary: SelectorSchema,
  alternatives: z.array(SelectorSchema).default([]),
  history: z.array(SelectorSchema).default([]),
});

export type SelectorType = z.infer<typeof SelectorTypeSchema>;
export type Selector = z.infer<typeof SelectorSchema>;
export type SelectorGroup = z.infer<typeof SelectorGroupSchema>;