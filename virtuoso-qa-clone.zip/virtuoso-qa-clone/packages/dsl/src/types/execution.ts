import { z } from 'zod';
import { FlowIdSchema, StepIdSchema } from './base';

export const ExecutionStatusSchema = z.enum([
  'pending',
  'running', 
  'completed',
  'failed',
  'cancelled',
  'paused',
]);

export const StepResultSchema = z.object({
  stepId: StepIdSchema,
  status: ExecutionStatusSchema,
  startTime: z.date(),
  endTime: z.date().optional(),
  duration: z.number().optional(),
  error: z.string().optional(),
  output: z.any().optional(),
  screenshots: z.array(z.string()).default([]),
  logs: z.array(z.object({
    level: z.enum(['debug', 'info', 'warn', 'error']),
    message: z.string(),
    timestamp: z.date(),
  })).default([]),
});

export const ExecutionResultSchema = z.object({
  id: z.string().uuid(),
  flowId: FlowIdSchema,
  status: ExecutionStatusSchema,
  startTime: z.date(),
  endTime: z.date().optional(),
  duration: z.number().optional(),
  stepResults: z.array(StepResultSchema),
  artifacts: z.object({
    screenshots: z.array(z.string()).default([]),
    videos: z.array(z.string()).default([]),
    logs: z.array(z.string()).default([]),
    reports: z.array(z.string()).default([]),
  }).default({}),
  metadata: z.record(z.any()).default({}),
});

export type ExecutionStatus = z.infer<typeof ExecutionStatusSchema>;
export type StepResult = z.infer<typeof StepResultSchema>;
export type ExecutionResult = z.infer<typeof ExecutionResultSchema>;