#!/usr/bin/env python3
"""
Mainframe automation engine using s3270 for TN3270 connections.
"""

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Dict, Any, Optional, List, Tuple
import uvicorn
import logging
import asyncio
import subprocess
import tempfile
import os
import re
import json
import base64
from datetime import datetime
from pathlib import Path
import aiofiles

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="Hybrid QA Mainframe Engine",
    description="Mainframe automation engine using s3270",
    version="1.0.0"
)

# Pydantic models
class ConnectRequest(BaseModel):
    host: str
    port: int = 23
    model: str = "3279-2"
    timeout: int = 30

class SendRequest(BaseModel):
    text: str
    row: Optional[int] = None
    col: Optional[int] = None

class ExpectRequest(BaseModel):
    text: str
    timeout: int = 10
    row: Optional[int] = None
    col: Optional[int] = None

class KeyRequest(BaseModel):
    key: str  # e.g., "Enter", "PF1", "Clear", "Tab", etc.

class ScreenField(BaseModel):
    row: int
    col: int
    length: int
    content: str
    protected: bool = True
    highlighted: bool = False

class ScreenGrid(BaseModel):
    rows: int = 24
    cols: int = 80
    content: List[List[str]]
    fields: List[ScreenField] = []
    cursor_row: int = 0
    cursor_col: int = 0

class CaptureResponse(BaseModel):
    session_id: str
    screen_text: str
    screen_grid: ScreenGrid
    image_path: Optional[str] = None
    timestamp: datetime

# Global state
sessions: Dict[str, 'S3270Manager'] = {}
artifacts_dir = Path("artifacts")
artifacts_dir.mkdir(exist_ok=True)

class S3270Manager:
    """Manages a single s3270 subprocess instance."""
    
    def __init__(self, session_id: str):
        self.session_id = session_id
        self.process: Optional[subprocess.Popen] = None
        self.host = ""
        self.port = 23
        self.model = "3279-2"
        self.connected = False
        
    async def start(self, host: str, port: int = 23, model: str = "3279-2") -> bool:
        """Start s3270 process and connect to mainframe."""
        try:
            # Start s3270 in scriptable mode
            cmd = [
                "s3270",
                "-script",
                "-model", model,
                f"{host}:{port}"
            ]
            
            logger.info(f"Starting s3270: {' '.join(cmd)}")
            
            self.process = subprocess.Popen(
                cmd,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                bufsize=0
            )
            
            self.host = host
            self.port = port
            self.model = model
            
            # Wait for connection
            await asyncio.sleep(2)
            
            # Check if connection is successful
            status = await self._send_command("Status")
            if "Not Connected" not in status:
                self.connected = True
                logger.info(f"Connected to {host}:{port}")
                return True
            else:
                logger.error(f"Failed to connect to {host}:{port}")
                return False
                
        except Exception as e:
            logger.error(f"Error starting s3270: {str(e)}")
            return False
    
    async def disconnect(self):
        """Disconnect from mainframe and close s3270."""
        try:
            if self.process:
                await self._send_command("Quit")
                self.process.terminate()
                try:
                    self.process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    self.process.kill()
                    self.process.wait()
                self.process = None
            self.connected = False
            logger.info(f"Disconnected session {self.session_id}")
        except Exception as e:
            logger.error(f"Error disconnecting: {str(e)}")
    
    async def _send_command(self, command: str) -> str:
        """Send a command to s3270 and return response."""
        if not self.process:
            raise Exception("s3270 process not started")
        
        try:
            self.process.stdin.write(command + "\n")
            self.process.stdin.flush()
            
            # Read response until we get the completion marker
            response_lines = []
            while True:
                line = self.process.stdout.readline()
                if not line:
                    break
                line = line.strip()
                if line == "ok":
                    break
                elif line.startswith("error"):
                    raise Exception(f"s3270 error: {line}")
                response_lines.append(line)
            
            return "\n".join(response_lines)
            
        except Exception as e:
            logger.error(f"Error sending command '{command}': {str(e)}")
            raise
    
    async def send_text(self, text: str, row: Optional[int] = None, col: Optional[int] = None):
        """Send text to the mainframe screen."""
        try:
            if row is not None and col is not None:
                # Move cursor to position first
                await self._send_command(f"MoveCursor({row},{col})")
            
            # Send the text
            await self._send_command(f'String("{text}")')
            
        except Exception as e:
            logger.error(f"Error sending text: {str(e)}")
            raise
    
    async def send_key(self, key: str):
        """Send a key sequence to the mainframe."""
        try:
            # Map common keys
            key_map = {
                "enter": "Enter",
                "tab": "Tab",
                "clear": "Clear",
                "backspace": "BackSpace",
                "delete": "Delete",
                "home": "Home",
                "end": "End"
            }
            
            # Handle PF keys
            if key.upper().startswith("PF"):
                key = key.upper()  # PF1, PF2, etc.
            elif key.upper().startswith("PA"):
                key = key.upper()  # PA1, PA2, etc.
            else:
                key = key_map.get(key.lower(), key)
            
            await self._send_command(f"Key({key})")
            
        except Exception as e:
            logger.error(f"Error sending key '{key}': {str(e)}")
            raise
    
    async def get_screen_text(self) -> str:
        """Get the complete screen content as text."""
        try:
            response = await self._send_command("Ascii")
            return response
        except Exception as e:
            logger.error(f"Error getting screen text: {str(e)}")
            raise
    
    async def get_screen_grid(self) -> ScreenGrid:
        """Parse screen content into structured grid."""
        try:
            # Get screen in different formats
            ascii_response = await self._send_command("Ascii")
            status_response = await self._send_command("Status")
            
            # Parse cursor position from status
            cursor_row, cursor_col = self._parse_cursor_position(status_response)
            
            # Create 24x80 grid
            lines = ascii_response.split('\n')
            content = []
            
            for i in range(24):  # Standard 3270 terminal is 24 rows
                if i < len(lines):
                    line = lines[i].ljust(80)[:80]  # Ensure exactly 80 chars
                else:
                    line = ' ' * 80
                content.append(list(line))
            
            # Detect fields (simplified - in real implementation would parse field attributes)
            fields = self._detect_fields(content)
            
            return ScreenGrid(
                rows=24,
                cols=80,
                content=content,
                fields=fields,
                cursor_row=cursor_row,
                cursor_col=cursor_col
            )
            
        except Exception as e:
            logger.error(f"Error parsing screen grid: {str(e)}")
            raise
    
    def _parse_cursor_position(self, status: str) -> Tuple[int, int]:
        """Parse cursor position from status response."""
        # Look for cursor position in status (format varies)
        cursor_match = re.search(r'(\d+)/(\d+)', status)
        if cursor_match:
            return int(cursor_match.group(1)) - 1, int(cursor_match.group(2)) - 1
        return 0, 0
    
    def _detect_fields(self, content: List[List[str]]) -> List[ScreenField]:
        """Detect input fields on the screen (simplified implementation)."""
        fields = []
        
        for row_idx, row in enumerate(content):
            col_idx = 0
            while col_idx < len(row):
                # Look for sequences of underscores or dots (common field markers)
                if row[col_idx] in ['_', '.'] or (row[col_idx] == ' ' and col_idx > 0 and row[col_idx-1] == '_'):
                    start_col = col_idx
                    field_content = []
                    
                    # Find end of field
                    while col_idx < len(row) and (row[col_idx] in ['_', '.', ' '] or row[col_idx].isalnum()):
                        field_content.append(row[col_idx])
                        col_idx += 1
                    
                    if len(field_content) > 0:
                        fields.append(ScreenField(
                            row=row_idx,
                            col=start_col,
                            length=len(field_content),
                            content=''.join(field_content).strip(),
                            protected=False  # Assume unprotected if we found it as a field
                        ))
                else:
                    col_idx += 1
        
        return fields
    
    async def capture_screenshot(self) -> str:
        """Capture screen as PNG image."""
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            image_path = artifacts_dir / f"mainframe_{self.session_id}_{timestamp}.png"
            
            # Use s3270's built-in screenshot capability
            await self._send_command(f'PrintWindow("{image_path}")')
            
            # If s3270 screenshot doesn't work, try alternative method
            if not image_path.exists():
                # Fallback: create a text-based "screenshot"
                screen_text = await self.get_screen_text()
                self._create_text_image(screen_text, str(image_path))
            
            return str(image_path)
            
        except Exception as e:
            logger.error(f"Error capturing screenshot: {str(e)}")
            # Return a placeholder or create a simple text image
            return await self._create_fallback_image()
    
    def _create_text_image(self, text: str, output_path: str):
        """Create a PNG image from text content."""
        try:
            from PIL import Image, ImageDraw, ImageFont
            
            # Create image with monospace font
            width, height = 800, 600
            image = Image.new('RGB', (width, height), color='black')
            draw = ImageDraw.Draw(image)
            
            # Try to use a monospace font
            try:
                font = ImageFont.truetype("consola.ttf", 10)  # Windows
            except:
                try:
                    font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf", 10)  # Linux
                except:
                    font = ImageFont.load_default()
            
            # Draw text
            lines = text.split('\n')
            y_offset = 10
            for line in lines[:24]:  # Max 24 lines
                draw.text((10, y_offset), line[:80], fill='green', font=font)
                y_offset += 20
            
            image.save(output_path)
            
        except Exception as e:
            logger.error(f"Error creating text image: {str(e)}")
    
    async def _create_fallback_image(self) -> str:
        """Create a fallback image when screenshot fails."""
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            image_path = artifacts_dir / f"mainframe_{self.session_id}_{timestamp}_fallback.png"
            
            screen_text = await self.get_screen_text()
            self._create_text_image(screen_text, str(image_path))
            
            return str(image_path)
            
        except Exception as e:
            logger.error(f"Error creating fallback image: {str(e)}")
            return ""
    
    async def expect_text(self, text: str, timeout: int = 10, row: Optional[int] = None, col: Optional[int] = None) -> bool:
        """Wait for expected text to appear on screen."""
        try:
            start_time = datetime.now()
            
            while (datetime.now() - start_time).seconds < timeout:
                screen_grid = await self.get_screen_grid()
                
                if row is not None and col is not None:
                    # Check specific position
                    if (row < len(screen_grid.content) and 
                        col < len(screen_grid.content[row])):
                        screen_text = ''.join(screen_grid.content[row][col:])
                        if text in screen_text:
                            return True
                else:
                    # Check entire screen
                    full_text = '\n'.join([''.join(row) for row in screen_grid.content])
                    if text in full_text:
                        return True
                
                await asyncio.sleep(0.5)
            
            return False
            
        except Exception as e:
            logger.error(f"Error waiting for text '{text}': {str(e)}")
            return False

# Utility functions for field location
def find_fields_by_regex(screen_grid: ScreenGrid, pattern: str) -> List[ScreenField]:
    """Find fields matching a regex pattern."""
    matching_fields = []
    regex = re.compile(pattern)
    
    for field in screen_grid.fields:
        if regex.search(field.content):
            matching_fields.append(field)
    
    return matching_fields

def find_text_on_screen(screen_grid: ScreenGrid, text: str) -> List[Tuple[int, int]]:
    """Find all occurrences of text on screen and return positions."""
    positions = []
    
    for row_idx, row in enumerate(screen_grid.content):
        row_text = ''.join(row)
        start_pos = 0
        
        while True:
            pos = row_text.find(text, start_pos)
            if pos == -1:
                break
            positions.append((row_idx, pos))
            start_pos = pos + 1
    
    return positions

# FastAPI endpoints
@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "service": "mainframe-engine",
        "version": "1.0.0",
        "timestamp": datetime.now().isoformat(),
        "active_sessions": len(sessions)
    }

@app.post("/connect/{session_id}")
async def connect(session_id: str, request: ConnectRequest):
    """Connect to a mainframe host."""
    try:
        if session_id in sessions:
            raise HTTPException(status_code=400, detail="Session already exists")
        
        manager = S3270Manager(session_id)
        success = await manager.start(request.host, request.port, request.model)
        
        if success:
            sessions[session_id] = manager
            return {
                "message": f"Connected to {request.host}:{request.port}",
                "session_id": session_id,
                "model": request.model
            }
        else:
            raise HTTPException(status_code=500, detail="Failed to connect to mainframe")
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/disconnect/{session_id}")
async def disconnect(session_id: str):
    """Disconnect from mainframe."""
    try:
        if session_id not in sessions:
            raise HTTPException(status_code=404, detail="Session not found")
        
        manager = sessions[session_id]
        await manager.disconnect()
        del sessions[session_id]
        
        return {"message": f"Disconnected session {session_id}"}
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/send/{session_id}")
async def send_text(session_id: str, request: SendRequest):
    """Send text to mainframe screen."""
    try:
        if session_id not in sessions:
            raise HTTPException(status_code=404, detail="Session not found")
        
        manager = sessions[session_id]
        await manager.send_text(request.text, request.row, request.col)
        
        return {
            "message": "Text sent successfully",
            "text": request.text,
            "row": request.row,
            "col": request.col
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/send_key/{session_id}")
async def send_key(session_id: str, request: KeyRequest):
    """Send key sequence to mainframe."""
    try:
        if session_id not in sessions:
            raise HTTPException(status_code=404, detail="Session not found")
        
        manager = sessions[session_id]
        await manager.send_key(request.key)
        
        return {
            "message": "Key sent successfully",
            "key": request.key
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/expect/{session_id}")
async def expect_text_endpoint(session_id: str, request: ExpectRequest):
    """Wait for expected text to appear on screen."""
    try:
        if session_id not in sessions:
            raise HTTPException(status_code=404, detail="Session not found")
        
        manager = sessions[session_id]
        found = await manager.expect_text(request.text, request.timeout, request.row, request.col)
        
        return {
            "found": found,
            "text": request.text,
            "timeout": request.timeout
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/capture/{session_id}", response_model=CaptureResponse)
async def capture_screen(session_id: str):
    """Capture current screen state."""
    try:
        if session_id not in sessions:
            raise HTTPException(status_code=404, detail="Session not found")
        
        manager = sessions[session_id]
        
        # Get screen data
        screen_text = await manager.get_screen_text()
        screen_grid = await manager.get_screen_grid()
        image_path = await manager.capture_screenshot()
        
        return CaptureResponse(
            session_id=session_id,
            screen_text=screen_text,
            screen_grid=screen_grid,
            image_path=image_path,
            timestamp=datetime.now()
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/sessions")
async def get_sessions():
    """Get all active sessions."""
    return {
        "active_sessions": list(sessions.keys()),
        "total_count": len(sessions)
    }

@app.get("/screen/{session_id}")
async def get_screen(session_id: str):
    """Get current screen content."""
    try:
        if session_id not in sessions:
            raise HTTPException(status_code=404, detail="Session not found")
        
        manager = sessions[session_id]
        screen_grid = await manager.get_screen_grid()
        
        return {
            "session_id": session_id,
            "screen_grid": screen_grid,
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    uvicorn.run(
        "main:app", 
        host="127.0.0.1",
        port=8003,
        reload=True,
        log_level="info"
    ) 