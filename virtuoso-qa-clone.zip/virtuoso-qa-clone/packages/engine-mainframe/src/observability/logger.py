"""
Structured logging configuration for mainframe engine using structlog
"""

import logging
import sys
import json
import time
import uuid
from typing import Any, Dict, Optional, List
from datetime import datetime
from functools import wraps

import structlog
from structlog.processors import JSONRenderer, TimeStamper, add_log_level
from structlog.stdlib import BoundLogger, LoggerFactory


class MainframeLoggerConfig:
    """Configuration for mainframe engine logging"""
    
    def __init__(
        self,
        log_level: str = "INFO",
        log_format: str = "json",
        correlation_id: Optional[str] = None,
        session_id: Optional[str] = None,
        redact_fields: Optional[List[str]] = None,
        mask_screen_data: bool = True
    ):
        self.log_level = log_level
        self.log_format = log_format
        self.correlation_id = correlation_id or str(uuid.uuid4())
        self.session_id = session_id
        self.redact_fields = redact_fields or [
            "password", "token", "key", "secret", "pin", 
            "account_number", "ssn", "userid", "pwd"
        ]
        self.mask_screen_data = mask_screen_data


def setup_mainframe_logging(config: MainframeLoggerConfig) -> BoundLogger:
    """Setup structured logging for mainframe engine"""
    
    # Configure Python stdlib logging
    logging.basicConfig(
        format="%(message)s",
        stream=sys.stdout,
        level=getattr(logging, config.log_level.upper())
    )
    
    # Processors for structlog
    processors = [
        structlog.stdlib.filter_by_level,
        structlog.stdlib.add_logger_name,
        add_log_level,
        structlog.stdlib.PositionalArgumentsFormatter(),
        TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        add_mainframe_context,
        redact_mainframe_data(config.redact_fields, config.mask_screen_data),
    ]
    
    # Add appropriate renderer
    if config.log_format == "json":
        processors.append(JSONRenderer())
    else:
        processors.append(structlog.dev.ConsoleRenderer())
    
    # Configure structlog
    structlog.configure(
        processors=processors,
        context_class=dict,
        logger_factory=LoggerFactory(),
        cache_logger_on_first_use=True,
    )
    
    # Create logger with initial context
    logger = structlog.get_logger()
    logger = logger.bind(
        correlation_id=config.correlation_id,
        session_id=config.session_id,
        service="engine-mainframe",
        engine_type="tn3270"
    )
    
    return logger


def add_mainframe_context(logger: Any, method_name: str, event_dict: Dict[str, Any]) -> Dict[str, Any]:
    """Add mainframe-specific context to log entries"""
    
    # Add connection info if available
    if hasattr(logger, "_mainframe_connection"):
        event_dict["connection"] = {
            "host": logger._mainframe_connection.get("host"),
            "port": logger._mainframe_connection.get("port"),
            "connected": logger._mainframe_connection.get("connected", False)
        }
    
    return event_dict


def redact_mainframe_data(redact_fields: List[str], mask_screen_data: bool):
    """Processor to redact sensitive mainframe data"""
    
    def processor(logger: Any, method_name: str, event_dict: Dict[str, Any]) -> Dict[str, Any]:
        # Redact screen data if present
        if mask_screen_data and "screen_data" in event_dict:
            event_dict["screen_data"] = mask_sensitive_screen_data(
                event_dict["screen_data"], 
                redact_fields
            )
        
        # Redact field values
        if "field_value" in event_dict:
            field_name = event_dict.get("field_name", "").lower()
            if any(sensitive in field_name for sensitive in redact_fields):
                event_dict["field_value"] = "[REDACTED]"
        
        # General redaction
        def redact_value(obj: Any) -> Any:
            if isinstance(obj, dict):
                return {
                    k: "[REDACTED]" if any(field in k.lower() for field in redact_fields) else redact_value(v)
                    for k, v in obj.items()
                }
            elif isinstance(obj, list):
                return [redact_value(item) for item in obj]
            return obj
        
        return redact_value(event_dict)
    
    return processor


def mask_sensitive_screen_data(screen_data: str, sensitive_fields: List[str]) -> str:
    """Mask sensitive data in 3270 screen captures"""
    lines = screen_data.split('\n')
    masked_lines = []
    
    for line in lines:
        lower_line = line.lower()
        # Check if line contains sensitive field labels
        if any(field in lower_line for field in sensitive_fields):
            # Mask the value part (simple heuristic - after colon or specific positions)
            if ':' in line:
                label, value = line.split(':', 1)
                masked_lines.append(f"{label}: {'*' * len(value.strip())}")
            else:
                # Mask latter half of the line
                mid = len(line) // 2
                masked_lines.append(line[:mid] + '*' * (len(line) - mid))
        else:
            masked_lines.append(line)
    
    return '\n'.join(masked_lines)


class MainframeLogger:
    """Logger for mainframe operations"""
    
    def __init__(self, logger: BoundLogger, context: Optional[Dict[str, Any]] = None):
        self.logger = logger
        self.context = context or {}
        self._mainframe_connection = {}
    
    def bind(self, **kwargs) -> "MainframeLogger":
        """Create a new logger with additional context"""
        new_logger = self.logger.bind(**kwargs)
        return MainframeLogger(new_logger, {**self.context, **kwargs})
    
    def set_connection_info(self, host: str, port: int, connected: bool = False):
        """Set mainframe connection information"""
        self._mainframe_connection = {
            "host": host,
            "port": port,
            "connected": connected
        }
    
    def debug(self, message: str, **kwargs):
        self.logger.debug(message, **kwargs)
    
    def info(self, message: str, **kwargs):
        self.logger.info(message, **kwargs)
    
    def warning(self, message: str, **kwargs):
        self.logger.warning(message, **kwargs)
    
    def error(self, message: str, exc_info: bool = False, **kwargs):
        self.logger.error(message, exc_info=exc_info, **kwargs)
    
    def log_connection(self, action: str, host: str, port: int, success: bool, **kwargs):
        """Log mainframe connection events"""
        level = "info" if success else "error"
        getattr(self, level)(
            f"Mainframe connection {action}",
            action=action,
            host=host,
            port=port,
            success=success,
            connection_event=True,
            **kwargs
        )
    
    def log_screen_action(self, action: str, row: int, col: int, success: bool, **kwargs):
        """Log screen interactions"""
        self.debug(
            f"Screen action: {action}",
            action=action,
            row=row,
            col=col,
            success=success,
            screen_action=True,
            **kwargs
        )
    
    def log_field_action(self, action: str, field_name: str, row: int, col: int, **kwargs):
        """Log field interactions"""
        self.debug(
            f"Field action: {action}",
            action=action,
            field_name=field_name,
            row=row,
            col=col,
            field_action=True,
            **kwargs
        )
    
    def log_transaction(self, transaction_code: str, status: str, duration: float, **kwargs):
        """Log transaction execution"""
        level = "error" if status == "failed" else "info"
        getattr(self, level)(
            f"Transaction {transaction_code} {status}",
            transaction_code=transaction_code,
            status=status,
            duration_ms=duration,
            transaction=True,
            **kwargs
        )
    
    def log_screen_capture(self, format: str, size: int, **kwargs):
        """Log screen capture events"""
        self.debug(
            "Screen captured",
            format=format,
            size_bytes=size,
            screen_capture=True,
            **kwargs
        )


def get_mainframe_logger(name: Optional[str] = None, **context) -> MainframeLogger:
    """Get a mainframe logger instance"""
    logger = structlog.get_logger(name)
    if context:
        logger = logger.bind(**context)
    return MainframeLogger(logger, context)


# Metrics collection for mainframe operations
class MainframeMetrics:
    """Collect metrics for mainframe operations"""
    
    def __init__(self, logger: MainframeLogger):
        self.logger = logger
        self.metrics = {
            "connections_total": 0,
            "connections_failed": 0,
            "transactions_total": 0,
            "transactions_failed": 0,
            "screen_actions_total": 0,
            "average_response_time": 0,
            "total_response_time": 0,
            "response_count": 0
        }
    
    def record_connection(self, success: bool):
        """Record connection attempt"""
        self.metrics["connections_total"] += 1
        if not success:
            self.metrics["connections_failed"] += 1
    
    def record_transaction(self, success: bool, duration: float):
        """Record transaction execution"""
        self.metrics["transactions_total"] += 1
        if not success:
            self.metrics["transactions_failed"] += 1
        
        # Update response time metrics
        self.metrics["total_response_time"] += duration
        self.metrics["response_count"] += 1
        self.metrics["average_response_time"] = (
            self.metrics["total_response_time"] / self.metrics["response_count"]
        )
    
    def record_screen_action(self):
        """Record screen action"""
        self.metrics["screen_actions_total"] += 1
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get current metrics"""
        return self.metrics.copy()
    
    def log_metrics(self):
        """Log current metrics"""
        self.logger.info("Mainframe metrics", metrics=self.metrics)


# Global logger instance
_global_mainframe_logger: Optional[MainframeLogger] = None


def initialize_mainframe_logging(config: MainframeLoggerConfig) -> MainframeLogger:
    """Initialize global mainframe logging"""
    global _global_mainframe_logger
    base_logger = setup_mainframe_logging(config)
    _global_mainframe_logger = MainframeLogger(base_logger)
    return _global_mainframe_logger


def get_global_mainframe_logger() -> MainframeLogger:
    """Get the global mainframe logger"""
    global _global_mainframe_logger
    if _global_mainframe_logger is None:
        _global_mainframe_logger = initialize_mainframe_logging(MainframeLoggerConfig())
    return _global_mainframe_logger 