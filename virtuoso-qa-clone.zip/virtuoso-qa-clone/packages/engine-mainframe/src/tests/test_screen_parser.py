#!/usr/bin/env python3
"""
Unit tests for mainframe screen parsing functionality.

Tests cover:
- Screen grid parsing
- Field detection
- Text location utilities  
- Screen capture functionality
- Mock screen scenarios
"""

import pytest
import sys
from pathlib import Path

# Add parent directory to path to import main module
sys.path.append(str(Path(__file__).parent.parent))

from main import ScreenGrid, ScreenField, S3270Manager, find_fields_by_regex, find_text_on_screen

class TestScreenParsing:
    """Test screen parsing and grid functionality."""
    
    def test_screen_grid_creation(self):
        """Test basic screen grid creation."""
        content = [['T', 'e', 's', 't'] + [' '] * 76 for _ in range(24)]
        
        grid = ScreenGrid(
            rows=24,
            cols=80,
            content=content,
            cursor_row=0,
            cursor_col=0
        )
        
        assert grid.rows == 24
        assert grid.cols == 80
        assert len(grid.content) == 24
        assert len(grid.content[0]) == 80
        assert grid.cursor_row == 0
        assert grid.cursor_col == 0
    
    def test_field_detection_underscores(self):
        """Test field detection with underscore markers."""
        # Create a mock screen with underscore fields
        content = []
        for i in range(24):
            if i == 5:  # Row with fields
                row = list("USERID   ___________     PASSWORD   ___________" + " " * 31)
            elif i == 10:
                row = list("NAME: ________________    AGE: ___" + " " * 43)
            else:
                row = [' '] * 80
            content.append(row[:80])  # Ensure exactly 80 chars
        
        # Mock the S3270Manager field detection
        manager = S3270Manager("test")
        fields = manager._detect_fields(content)
        
        # Should detect underscore sequences as fields
        assert len(fields) >= 2  # At least USERID and PASSWORD fields
        
        # Check first field (USERID)
        userid_fields = [f for f in fields if f.row == 5 and f.col >= 9 and f.col <= 15]
        assert len(userid_fields) > 0
        
        # Check field properties
        field = userid_fields[0]
        assert not field.protected  # Should be unprotected input field
        assert field.length > 5  # Should have reasonable length
    
    def test_field_detection_dots(self):
        """Test field detection with dot markers."""
        content = []
        for i in range(24):
            if i == 8:  # Row with dot fields
                row = list("ENTER DATA: ........    VALUE: ....." + " " * 41)
            else:
                row = [' '] * 80
            content.append(row)
        
        manager = S3270Manager("test")
        fields = manager._detect_fields(content)
        
        # Should detect dot sequences as fields
        dot_fields = [f for f in fields if f.row == 8]
        assert len(dot_fields) >= 1
    
    def test_find_text_on_screen(self):
        """Test finding text locations on screen."""
        content = []
        for i in range(24):
            if i == 0:
                row = list("WELCOME TO MAINFRAME SYSTEM" + " " * 53)
            elif i == 5:
                row = list("USERID: ________    PASSWORD: ________" + " " * 42)
            elif i == 10:
                row = list("ISPF Primary Option Menu" + " " * 56)
            else:
                row = [' '] * 80
            content.append(row)
        
        grid = ScreenGrid(rows=24, cols=80, content=content)
        
        # Find "WELCOME"
        positions = find_text_on_screen(grid, "WELCOME")
        assert len(positions) == 1
        assert positions[0] == (0, 0)
        
        # Find "USERID"
        positions = find_text_on_screen(grid, "USERID")
        assert len(positions) == 1
        assert positions[0] == (5, 0)
        
        # Find "PASSWORD"
        positions = find_text_on_screen(grid, "PASSWORD")
        assert len(positions) == 1
        assert positions[0] == (5, 20)
        
        # Find non-existent text
        positions = find_text_on_screen(grid, "NOTFOUND")
        assert len(positions) == 0
    
    def test_find_fields_by_regex(self):
        """Test regex-based field finding."""
        fields = [
            ScreenField(row=5, col=8, length=10, content="TESTUSER01", protected=False),
            ScreenField(row=5, col=25, length=8, content="PASSWORD", protected=True),
            ScreenField(row=8, col=15, length=15, content="SYS1.PROCLIB", protected=False),
            ScreenField(row=10, col=5, length=20, content="TEST.DATA.SET", protected=False),
        ]
        
        grid = ScreenGrid(rows=24, cols=80, content=[[' ']*80 for _ in range(24)], fields=fields)
        
        # Find fields containing "TEST"
        test_fields = find_fields_by_regex(grid, r".*TEST.*")
        assert len(test_fields) == 2  # TESTUSER01 and TEST.DATA.SET
        
        # Find fields with dataset pattern
        dataset_fields = find_fields_by_regex(grid, r".*\..*\..*")  # Pattern with dots
        assert len(dataset_fields) == 2  # SYS1.PROCLIB and TEST.DATA.SET
        
        # Find user ID pattern
        userid_fields = find_fields_by_regex(grid, r"[A-Z]+\d+")
        assert len(userid_fields) == 1  # TESTUSER01
        
        # Find non-matching pattern
        no_match = find_fields_by_regex(grid, r"NOMATCH")
        assert len(no_match) == 0

class TestScreenScenarios:
    """Test realistic mainframe screen scenarios."""
    
    def test_tso_login_screen(self):
        """Test parsing TSO login screen."""
        screen_text = """


                        TSO/E LOGON




                 USERID   ===>
                 PASSWORD ===>
                 PROCEDURE===> ISPF
                 ACCT     ===>


                 NEW PASSWORD ===> (IF CHANGING PASSWORD)
                 GROUP IDENT  ===> TSO     (IF DIFFERENT FROM USERID)
                 REGION SIZE  ===> 6144    (IF DIFFERENT FROM DEFAULT)


"""
        
        # Convert text to grid format
        lines = screen_text.split('\n')
        content = []
        for i in range(24):
            if i < len(lines):
                line = lines[i].ljust(80)[:80]
            else:
                line = ' ' * 80
            content.append(list(line))
        
        grid = ScreenGrid(rows=24, cols=80, content=content)
        
        # Find login fields
        userid_pos = find_text_on_screen(grid, "USERID")
        password_pos = find_text_on_screen(grid, "PASSWORD")
        
        assert len(userid_pos) == 1
        assert len(password_pos) == 1
        
        # Verify positions are reasonable
        assert userid_pos[0][0] > 5  # Should be below header
        assert password_pos[0][0] > userid_pos[0][0]  # Password after USERID
    
    def test_ispf_menu_screen(self):
        """Test parsing ISPF Primary Option Menu."""
        screen_text = """  ISPF Primary Option Menu                                                     
                                                                                
     0  Settings       Terminal and user parameters                             
     1  View           Display source data or listings                          
     2  Edit           Create or change source data                             
     3  Utilities      Perform utility functions                                
     4  Foreground     Interactive language processing                          
     5  Batch          Submit job for language processing                       
     6  Command        Enter TSO command or CLIST                               
     7  Dialog         Dialog Test                                              
     8  LM Utilities   Library administrator functions                          
     9  IBM Products   Additional IBM program products                          
    10  SCLM           Software Configuration and Library Manager               
    11  Workplace      ISPF Object/Action Workplace                            
                                                                                
 Option ===>                                                                    
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
 F1=Help      F2=Split     F3=Exit      F9=Swap list  F10=Actions   F12=Cancel
                                                                                """
        
        lines = screen_text.split('\n')
        content = []
        for i in range(24):
            if i < len(lines):
                line = lines[i].ljust(80)[:80]
            else:
                line = ' ' * 80
            content.append(list(line))
        
        grid = ScreenGrid(rows=24, cols=80, content=content)
        
        # Find menu items
        ispf_pos = find_text_on_screen(grid, "ISPF Primary")
        option_pos = find_text_on_screen(grid, "Option ===>")
        utilities_pos = find_text_on_screen(grid, "Utilities")
        
        assert len(ispf_pos) == 1  # Title
        assert len(option_pos) == 1  # Input field
        assert len(utilities_pos) == 1  # Menu option
        
        # Check for function keys
        f1_pos = find_text_on_screen(grid, "F1=Help")
        assert len(f1_pos) == 1
    
    def test_job_submission_confirmation(self):
        """Test parsing job submission confirmation screen."""
        screen_text = """



                    JOB TESTJOB(J0001234) SUBMITTED



            JOB TESTJOB WAS ASSIGNED JOB NUMBER 1234
            
            TOTAL LINES READ: 15
            CARDS IMAGES CREATED: 15
            
            
            JCL SUBMITTED TO INTERNAL READER
            
            
            PRESS ENTER TO CONTINUE




"""
        
        lines = screen_text.split('\n')
        content = []
        for i in range(24):
            if i < len(lines):
                line = lines[i].ljust(80)[:80]
            else:
                line = ' ' * 80
            content.append(list(line))
        
        grid = ScreenGrid(rows=24, cols=80, content=content)
        
        # Find job information
        submitted_pos = find_text_on_screen(grid, "SUBMITTED")
        job_pos = find_text_on_screen(grid, "TESTJOB")
        
        assert len(submitted_pos) >= 1
        assert len(job_pos) >= 1
        
        # Test regex patterns for job extraction
        import re
        screen_full_text = '\n'.join([''.join(row) for row in grid.content])
        
        # Test job ID pattern
        job_match = re.search(r'JOB\s+(\w+)\(J(\d+)\)', screen_full_text)
        assert job_match is not None
        assert job_match.group(1) == "TESTJOB"
        assert job_match.group(2) == "0001234"

class TestS3270ManagerMocking:
    """Test S3270Manager with mocked responses."""
    
    def test_cursor_position_parsing(self):
        """Test cursor position parsing from status."""
        manager = S3270Manager("test")
        
        # Test different status formats
        status1 = "4A 24 80 12 15 0x0 0x0"  # Format: row 12, col 15
        cursor_row, cursor_col = manager._parse_cursor_position(status1)
        assert cursor_row == 11  # 0-indexed
        assert cursor_col == 14  # 0-indexed
        
        status2 = "Connected 10/25"  # Format: row 10, col 25
        cursor_row, cursor_col = manager._parse_cursor_position(status2)
        assert cursor_row == 9  # 0-indexed  
        assert cursor_col == 24  # 0-indexed
        
        # Test invalid format
        status3 = "No cursor info"
        cursor_row, cursor_col = manager._parse_cursor_position(status3)
        assert cursor_row == 0  # Default
        assert cursor_col == 0  # Default

class TestUtilityFunctions:
    """Test utility functions for screen manipulation."""
    
    def test_screen_text_conversion(self):
        """Test conversion between screen grid and text."""
        content = []
        content.append(list("LINE ONE" + " " * 72))
        content.append(list("LINE TWO" + " " * 72))
        content.append([' '] * 80)  # Empty line
        content.append(list("LINE FOUR" + " " * 71))
        
        # Pad to 24 lines
        while len(content) < 24:
            content.append([' '] * 80)
        
        grid = ScreenGrid(rows=24, cols=80, content=content)
        
        # Convert back to text
        text_lines = []
        for row in grid.content:
            text_lines.append(''.join(row).rstrip())
        
        full_text = '\n'.join(text_lines)
        
        assert "LINE ONE" in full_text
        assert "LINE TWO" in full_text
        assert "LINE FOUR" in full_text
    
    def test_field_positioning(self):
        """Test field positioning and overlap detection."""
        fields = [
            ScreenField(row=5, col=10, length=15, content="FIRST_FIELD", protected=False),
            ScreenField(row=5, col=30, length=10, content="SECOND", protected=False),
            ScreenField(row=7, col=10, length=20, content="THIRD_FIELD_LONG", protected=True),
        ]
        
        # Test field boundaries
        first_field = fields[0]
        assert first_field.col == 10
        assert first_field.col + first_field.length == 25  # Ends at col 25
        
        second_field = fields[1]
        assert second_field.col == 30
        assert second_field.col + second_field.length == 40
        
        # Fields on same row shouldn't overlap
        assert first_field.col + first_field.length <= second_field.col
    
    def test_special_characters_handling(self):
        """Test handling of special 3270 characters."""
        # Test with various 3270 special characters and attributes
        special_content = []
        
        # Line with protected/unprotected field markers (simplified)
        special_content.append(list("USERID") + [' '] * 3 + ['_'] * 8 + [' '] * 65)
        special_content.append(list("PASSW") + [' '] * 2 + ['.'] * 8 + [' '] * 65)
        
        # Fill remaining rows
        while len(special_content) < 24:
            special_content.append([' '] * 80)
        
        manager = S3270Manager("test")
        fields = manager._detect_fields(special_content)
        
        # Should detect both underscore and dot fields
        underscore_fields = [f for f in fields if '_' in f.content]
        dot_fields = [f for f in fields if '.' in f.content]
        
        assert len(underscore_fields) > 0
        assert len(dot_fields) > 0

# Mock data for testing
MOCK_SCREENS = {
    "login": """


                        TSO/E LOGON




                 USERID   ===>
                 PASSWORD ===>
                 PROCEDURE===> ISPF
                 ACCT     ===>


                 NEW PASSWORD ===> (IF CHANGING PASSWORD)
                 GROUP IDENT  ===> TSO     (IF DIFFERENT FROM USERID)
                 REGION SIZE  ===> 6144    (IF DIFFERENT FROM DEFAULT)


""",
    
    "ispf_menu": """  ISPF Primary Option Menu                                                     
                                                                                
     0  Settings       Terminal and user parameters                             
     1  View           Display source data or listings                          
     2  Edit           Create or change source data                             
     3  Utilities      Perform utility functions                                
     4  Foreground     Interactive language processing                          
     5  Batch          Submit job for language processing                       
     6  Command        Enter TSO command or CLIST                               
     7  Dialog         Dialog Test                                              
     8  LM Utilities   Library administrator functions                          
     9  IBM Products   Additional IBM program products                          
    10  SCLM           Software Configuration and Library Manager               
    11  Workplace      ISPF Object/Action Workplace                            
                                                                                
 Option ===>                                                                    
                                                                                
 F1=Help      F2=Split     F3=Exit      F9=Swap list  F10=Actions   F12=Cancel
""",
    
    "job_status": """
SDSF OUTPUT DISPLAY TESTJOB  JOB01234  DSID   104 LINE 1       COLUMNS 02- 81 
COMMAND INPUT ===>                                            SCROLL ===> PAGE 
********************************* TOP OF DATA ********************************
JOB TESTJOB(J0001234) SUBMITTED                                               
01.00.01 JOB01234  ---- FRIDAY,    15 DEC 2023 ----                          
01.00.01 JOB01234  IRR010I  USERID TESTUSER  IS ASSIGNED TO THIS JOB.         
01.00.01 JOB01234  ICH70001I TESTUSER  LAST ACCESS AT 14:30:15 ON FRIDAY      
01.00.01 JOB01234  $HASP373 TESTJOB  STARTED - INIT  1 - CLASS A - SYS PROD   
01.00.01 JOB01234  IEF403I TESTJOB - STARTED - TIME=14.30.15                  
01.00.01 JOB01234  -                                       --TIMINGS (MINS.)--
01.00.01 JOB01234  -STEPNAME PROCSTEP    RC      EXCP   CPU  ELAP  ELAP  TOT   
01.00.01 JOB01234  -STEP1              0000      52   .00    .00    .01   .01  
01.00.01 JOB01234  IEF404I TESTJOB - ENDED - TIME=14.30.15                    
01.00.01 JOB01234  -TESTJOB  ENDED.  NAME-TESTUSER                           
01.00.01 JOB01234  $HASP395 TESTJOB  ENDED                                    
******************************** BOTTOM OF DATA ******************************
"""
}

def create_mock_grid(screen_name: str) -> ScreenGrid:
    """Create a mock screen grid from predefined screens."""
    if screen_name not in MOCK_SCREENS:
        raise ValueError(f"Unknown mock screen: {screen_name}")
    
    screen_text = MOCK_SCREENS[screen_name]
    lines = screen_text.split('\n')
    content = []
    
    for i in range(24):
        if i < len(lines):
            line = lines[i].ljust(80)[:80]
        else:
            line = ' ' * 80
        content.append(list(line))
    
    # Detect fields (simplified)
    manager = S3270Manager("mock")
    fields = manager._detect_fields(content)
    
    return ScreenGrid(rows=24, cols=80, content=content, fields=fields)

# Integration tests using mock screens
class TestMockScreens:
    """Integration tests using predefined mock screens."""
    
    def test_login_screen_parsing(self):
        """Test complete login screen parsing."""
        grid = create_mock_grid("login")
        
        # Find key elements
        userid_pos = find_text_on_screen(grid, "USERID")
        password_pos = find_text_on_screen(grid, "PASSWORD")
        
        assert len(userid_pos) == 1
        assert len(password_pos) == 1
        
        # Should detect input fields
        input_fields = [f for f in grid.fields if not f.protected]
        assert len(input_fields) >= 2  # At least USERID and PASSWORD fields
    
    def test_ispf_menu_navigation(self):
        """Test ISPF menu screen parsing and navigation targets."""
        grid = create_mock_grid("ispf_menu")
        
        # Find menu options
        utilities_pos = find_text_on_screen(grid, "Utilities")
        batch_pos = find_text_on_screen(grid, "Batch")
        option_pos = find_text_on_screen(grid, "Option ===>")
        
        assert len(utilities_pos) == 1
        assert len(batch_pos) == 1
        assert len(option_pos) == 1
        
        # Check function key line
        f3_pos = find_text_on_screen(grid, "F3=Exit")
        assert len(f3_pos) == 1
    
    def test_job_status_parsing(self):
        """Test job status screen parsing."""
        grid = create_mock_grid("job_status")
        
        # Find job completion indicators
        ended_pos = find_text_on_screen(grid, "ENDED")
        rc_pos = find_text_on_screen(grid, "RC")
        
        assert len(ended_pos) >= 1  # Should find "ENDED" indicators
        assert len(rc_pos) >= 1     # Should find return codes
        
        # Test job ID extraction
        screen_text = '\n'.join([''.join(row) for row in grid.content])
        import re
        job_match = re.search(r'JOB(\d+)', screen_text)
        assert job_match is not None

if __name__ == "__main__":
    pytest.main([__file__, "-v"]) 