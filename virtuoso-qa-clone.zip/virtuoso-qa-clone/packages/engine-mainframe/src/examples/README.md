# Mainframe Engine Examples

This directory contains examples demonstrating the capabilities of the mainframe automation engine.

## Examples Included

### 1. Login Flow (`login_flow.py`)

Demonstrates a complete mainframe login sequence:
- Connect to mainframe host  
- Handle login screens (TSO/ISPF)
- Navigate through menu systems
- Capture screen states at each step

**Usage:**
```bash
cd packages/engine-mainframe/src/examples
python login_flow.py
```

**Features demonstrated:**
- Connection management
- Text input and key sequences  
- Screen text expectation
- Screen capture and artifact storage
- Error handling and cleanup

### 2. JCL Job Submission (`jcl_submit.py`)

Shows how to submit and monitor mainframe batch jobs:
- Login to mainframe
- Navigate to job submission facility (ISPF/TSO)  
- Submit JCL job
- Monitor job status
- Retrieve job output

**Usage:**
```bash
cd packages/engine-mainframe/src/examples
python jcl_submit.py
```

**Features demonstrated:**
- JCL creation and submission
- Job status monitoring
- Output retrieval
- SDSF integration
- Regex patterns for job information extraction

## Configuration

Both examples can be configured by modifying the connection parameters:

```python
# For real mainframe testing
await example.run_login_flow(
    host="your.mainframe.host",
    username="YOUR_USERID", 
    password="YOUR_PASSWORD"
)
```

## Mock Mode

The examples include mock/simulation support for testing without a real mainframe:

- Mock screens simulate TSO login, ISPF menus, and job submission
- Realistic screen layouts and field positioning
- Suitable for development and CI/CD testing

## Prerequisites

1. **s3270 installed** - The examples require the s3270 terminal emulator:
   ```bash
   # Ubuntu/Debian
   sudo apt-get install s3270
   
   # RHEL/CentOS
   sudo yum install s3270
   
   # Windows
   # Download from http://x3270.bgp.nu/download.html
   ```

2. **Python dependencies** installed:
   ```bash
   pip install -r ../requirements.txt
   ```

3. **Mainframe engine running**:
   ```bash
   cd packages/engine-mainframe/src
   python main.py
   ```

## Output Artifacts

Both examples generate artifacts in the `artifacts/` directory:

- **Screen captures**: Text files containing screen content at each step
- **Screenshots**: PNG images of screen states (when available)
- **Job output**: Retrieved JCL job output and logs

Example artifacts:
```
artifacts/
├── 01_initial_connection_login_demo_session.txt
├── 02_after_login_login_demo_session.txt  
├── 03_final_state_login_demo_session.txt
├── mainframe_login_demo_session_20231215_143015.png
└── job_output_TESTJOB_1234.txt
```

## Customization

### Adding New Screens

To handle additional screen types, extend the examples:

1. Add screen detection logic:
```python
custom_found = await self._expect_text("CUSTOM_SCREEN", timeout=5)
if custom_found:
    await self._handle_custom_screen()
```

2. Implement screen-specific logic:
```python
async def _handle_custom_screen(self):
    """Handle custom mainframe screen."""
    # Navigation and data entry logic
    pass
```

### Field Detection

Customize field detection for specific screen layouts:

```python
def _detect_custom_fields(self, content):
    """Detect fields using custom patterns."""
    fields = []
    # Custom field detection logic
    return fields
```

### Error Recovery

Add robust error handling:

```python
try:
    await self._risky_operation()
except Exception as e:
    await self._capture_screen("error_recovery")
    await self._perform_recovery_action()
```

## Integration with Test Automation

The examples serve as templates for integrating mainframe testing into broader test automation frameworks:

### Pytest Integration

```python
import pytest
from examples.login_flow import MainframeLoginExample

@pytest.fixture
async def mainframe_session():
    example = MainframeLoginExample()
    await example._connect("test.mainframe.host")
    yield example
    await example._disconnect()

async def test_mainframe_login(mainframe_session):
    success = await mainframe_session._login("TESTUSER", "TESTPASS")
    assert success
```

### CI/CD Pipeline

```yaml
# .github/workflows/mainframe-tests.yml
name: Mainframe Tests
on: [push, pull_request]

jobs:
  mainframe-tests:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Install s3270
        run: sudo apt-get install s3270
      - name: Run mainframe tests
        run: |
          cd packages/engine-mainframe
          python -m pytest src/tests/
```

## Troubleshooting

### Common Issues

1. **s3270 not found**
   - Ensure s3270 is installed and in PATH
   - Test with: `s3270 --version`

2. **Connection timeout**
   - Verify mainframe host is accessible
   - Check firewall rules for port 23 (telnet)
   - Try with increased timeout values

3. **Screen parsing issues**
   - Enable debug logging to see raw screen content
   - Verify screen dimensions (24x80 is standard)
   - Check for unexpected characters or formatting

4. **Authentication failures**
   - Verify credentials are correct
   - Check if password change is required
   - Ensure account is not locked

### Debug Mode

Enable detailed logging:

```python
import logging
logging.basicConfig(level=logging.DEBUG)

# The examples will show detailed s3270 communication
```

### Screen Analysis

Use the capture functionality to analyze screen layouts:

```python
# Capture and analyze any screen
response = requests.post("http://127.0.0.1:8003/capture/debug_session")
screen_data = response.json()

print("Screen content:")
print(screen_data["screen_text"])

print("Detected fields:")
for field in screen_data["screen_grid"]["fields"]:
    print(f"Row {field['row']}, Col {field['col']}: '{field['content']}'")
```

## Contributing

When adding new examples:

1. Follow the existing pattern of step-by-step execution
2. Include comprehensive error handling
3. Add screen captures at key points
4. Document configuration options
5. Provide both real and mock modes
6. Add corresponding unit tests

## License

These examples are part of the Hybrid QA project and follow the same MIT license. 