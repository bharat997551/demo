#!/usr/bin/env python3
"""
Example: JCL Job Submission

This example demonstrates how to:
1. Connect to a mainframe system
2. Navigate to job submission facility
3. Submit a JCL job
4. Monitor job status
5. Retrieve job output

Note: This example includes mock JCL for testing when real z/OS is not available.
"""

import asyncio
import sys
import requests
import json
import time
from pathlib import Path

# Add parent directory to path to import main module
sys.path.append(str(Path(__file__).parent.parent))

class JCLSubmitExample:
    def __init__(self, base_url="http://127.0.0.1:8003"):
        self.base_url = base_url
        self.session_id = "jcl_submit_session"
        self.job_name = ""
        self.job_id = ""
    
    async def run_jcl_submit_flow(self, host="mock.mainframe.local", username="TESTUSER", password="PASSWORD"):
        """Execute complete JCL submission flow."""
        try:
            print("=== JCL Job Submission Example ===")
            
            # Step 1: Connect and login
            print("1. Connecting to mainframe...")
            await self._connect(host)
            await self._login(username, password)
            
            # Step 2: Navigate to job submission facility
            print("2. Navigating to job submission facility...")
            await self._navigate_to_job_submission()
            
            # Step 3: Prepare and submit JCL
            print("3. Submitting JCL job...")
            jcl_content = self._get_sample_jcl(username)
            await self._submit_jcl(jcl_content)
            
            # Step 4: Monitor job status
            print("4. Monitoring job status...")
            await self._monitor_job_status()
            
            # Step 5: Retrieve job output
            print("5. Retrieving job output...")
            await self._retrieve_job_output()
            
            print("6. JCL submission flow completed successfully!")
            
        except Exception as e:
            print(f"Error in JCL submission flow: {str(e)}")
            await self._capture_screen("jcl_error_state")
        finally:
            # Cleanup
            print("7. Disconnecting...")
            await self._disconnect()
    
    def _get_sample_jcl(self, username):
        """Generate sample JCL for testing."""
        return f"""//TESTJOB  JOB ({username}),'{username} TEST JOB',
//             CLASS=A,MSGCLASS=X,MSGLEVEL=(1,1),
//             NOTIFY=&SYSUID,TIME=(0,5)
//*
//* SAMPLE JCL JOB FOR TESTING AUTOMATION
//*
//STEP1    EXEC PGM=IDCAMS
//SYSPRINT DD SYSOUT=*
//SYSIN    DD *
  LISTCAT ENTRIES(SYS1.PARMLIB) ALL
/*
//STEP2    EXEC PGM=IEBGENER
//SYSPRINT DD SYSOUT=*
//SYSUT1   DD *
This is a test message from automated JCL submission.
Job submitted at: {time.strftime('%Y-%m-%d %H:%M:%S')}
User: {username}
/*
//SYSUT2   DD SYSOUT=*
//SYSIN    DD DUMMY
//"""
    
    async def _connect(self, host, port=23, model="3279-2"):
        """Connect to mainframe."""
        response = requests.post(
            f"{self.base_url}/connect/{self.session_id}",
            json={"host": host, "port": port, "model": model}
        )
        
        if response.status_code != 200:
            raise Exception(f"Failed to connect: {response.text}")
        
        print(f"   Connected successfully to {host}:{port}")
    
    async def _login(self, username, password):
        """Handle login process."""
        print(f"   Logging in as {username}...")
        
        # Wait for login screen
        await self._expect_text("USERID", timeout=10)
        
        # Enter credentials
        await self._send_text(username, row=6, col=20)
        await self._send_key("Tab")
        await self._send_text(password)
        await self._send_key("Enter")
        
        # Wait for login to complete
        await asyncio.sleep(3)
        await self._capture_screen("01_after_login")
        
        print("   Login completed")
    
    async def _navigate_to_job_submission(self):
        """Navigate to job submission facility (ISPF or TSO)."""
        # Look for ISPF menu
        ispf_found = await self._expect_text("ISPF", timeout=5)
        
        if ispf_found:
            print("   Using ISPF job submission...")
            await self._navigate_ispf_job_submission()
        else:
            print("   Using TSO job submission...")
            await self._navigate_tso_job_submission()
    
    async def _navigate_ispf_job_submission(self):
        """Navigate to ISPF job submission (Option 5 - Batch)."""
        # Go to Batch option (5)
        await self._send_text("5", row=6, col=2)
        await self._send_key("Enter")
        
        await asyncio.sleep(2)
        await self._capture_screen("02_batch_menu")
        
        # Look for job submission options
        await self._expect_text("SUBMIT", timeout=5)
        print("   Reached ISPF batch submission facility")
    
    async def _navigate_tso_job_submission(self):
        """Navigate to TSO job submission using SUBMIT command."""
        # Wait for TSO READY prompt
        await self._expect_text("READY", timeout=10)
        print("   At TSO READY prompt, using SUBMIT command")
    
    async def _submit_jcl(self, jcl_content):
        """Submit JCL job to the system."""
        # Create temporary dataset for JCL
        dataset_name = f"{self.session_id.upper()}.TEST.JCL"
        
        print(f"   Creating JCL dataset: {dataset_name}")
        
        # For ISPF: Use edit facility to create JCL
        ispf_found = await self._expect_text("ISPF", timeout=2)
        
        if ispf_found:
            await self._submit_jcl_via_ispf(dataset_name, jcl_content)
        else:
            await self._submit_jcl_via_tso(jcl_content)
    
    async def _submit_jcl_via_ispf(self, dataset_name, jcl_content):
        """Submit JCL using ISPF facilities."""
        # Go to Edit option (2)
        await self._send_text("2", row=6, col=2)
        await self._send_key("Enter")
        
        await asyncio.sleep(2)
        
        # Enter dataset name
        await self._send_text(dataset_name, row=6, col=15)
        await self._send_key("Enter")
        
        await asyncio.sleep(2)
        await self._capture_screen("03_editing_jcl")
        
        # Enter JCL content (simplified - in real scenario would need line-by-line)
        lines = jcl_content.strip().split('\n')
        for i, line in enumerate(lines[:10]):  # Limit for demo
            await self._send_text(line[:72], row=7+i, col=1)  # JCL line limit
            await self._send_key("Enter")
        
        # Save and submit
        await self._send_key("PF3")  # Save and exit
        await asyncio.sleep(1)
        
        # Submit the job
        await self._send_text("SUB", row=6, col=1)  # ISPF line command
        await self._send_key("Enter")
        
        await self._capture_screen("04_job_submitted")
        
        # Extract job information from submission message
        await self._extract_job_info()
    
    async def _submit_jcl_via_tso(self, jcl_content):
        """Submit JCL using TSO SUBMIT command."""
        print("   Creating inline JCL submission...")
        
        # Use TSO SUBMIT with inline data
        await self._send_text("SUBMIT * END($$)")
        await self._send_key("Enter")
        
        await asyncio.sleep(1)
        
        # Send JCL lines
        lines = jcl_content.strip().split('\n')
        for line in lines[:15]:  # Limit for demo
            await self._send_text(line[:72])
            await self._send_key("Enter")
            await asyncio.sleep(0.1)
        
        # End the submission
        await self._send_text("$$")
        await self._send_key("Enter")
        
        await asyncio.sleep(2)
        await self._capture_screen("04_tso_job_submitted")
        
        # Extract job information
        await self._extract_job_info()
    
    async def _extract_job_info(self):
        """Extract job name and job ID from submission response."""
        # Capture current screen to analyze
        response = requests.post(f"{self.base_url}/capture/{self.session_id}")
        
        if response.status_code == 200:
            screen_text = response.json()["screen_text"]
            
            # Look for job submission patterns
            job_patterns = [
                r'JOB\s+(\w+)\(J(\d+)\)',  # JOB TESTJOB(J0001234)
                r'(\w+)\s+JOB\s+(\d+)',    # TESTJOB JOB 1234
                r'JOB\s+(\w+)\s+SUBMITTED.*?(\d+)'  # JOB TESTJOB SUBMITTED AS 1234
            ]
            
            import re
            for pattern in job_patterns:
                match = re.search(pattern, screen_text)
                if match:
                    self.job_name = match.group(1)
                    self.job_id = match.group(2)
                    print(f"   Job submitted: {self.job_name} (ID: {self.job_id})")
                    return
            
            # Fallback - use mock data
            self.job_name = "TESTJOB"
            self.job_id = "1234"
            print(f"   Job submitted (mock): {self.job_name} (ID: {self.job_id})")
    
    async def _monitor_job_status(self):
        """Monitor job execution status."""
        print(f"   Monitoring job {self.job_name} ({self.job_id})...")
        
        # Use SDSF (System Display and Search Facility) or TSO STATUS
        tso_ready = await self._expect_text("READY", timeout=5)
        
        if tso_ready:
            await self._monitor_via_tso()
        else:
            await self._monitor_via_sdsf()
    
    async def _monitor_via_tso(self):
        """Monitor job status using TSO commands."""
        for attempt in range(5):  # Check status 5 times
            print(f"   Status check {attempt + 1}/5...")
            
            # Use TSO STATUS command
            await self._send_text(f"STATUS {self.job_name}")
            await self._send_key("Enter")
            
            await asyncio.sleep(2)
            await self._capture_screen(f"05_status_check_{attempt + 1}")
            
            # Check if job completed
            response = requests.post(f"{self.base_url}/capture/{self.session_id}")
            if response.status_code == 200:
                screen_text = response.json()["screen_text"]
                if "COMPLETED" in screen_text or "CC 0000" in screen_text:
                    print("   Job completed successfully!")
                    return
                elif "ABENDED" in screen_text or "FAILED" in screen_text:
                    print("   Job failed or abended!")
                    return
            
            await asyncio.sleep(5)  # Wait before next check
        
        print("   Job monitoring completed (timeout)")
    
    async def _monitor_via_sdsf(self):
        """Monitor job status using SDSF."""
        # Navigate to SDSF (typically ISPF option S or command SDSF)
        await self._send_text("S", row=6, col=2)
        await self._send_key("Enter")
        
        await asyncio.sleep(2)
        await self._capture_screen("05_sdsf_main")
        
        # Look for our job in the active job list
        await self._send_text(f"/{self.job_name}", row=6, col=1)  # Filter by job name
        await self._send_key("Enter")
        
        await asyncio.sleep(2)
        await self._capture_screen("05_sdsf_job_list")
        
        print("   Job status checked via SDSF")
    
    async def _retrieve_job_output(self):
        """Retrieve and save job output."""
        print(f"   Retrieving output for job {self.job_name}...")
        
        # Method varies by interface (SDSF, TSO OUTPUT command, etc.)
        tso_ready = await self._expect_text("READY", timeout=5)
        
        if tso_ready:
            await self._retrieve_output_via_tso()
        else:
            await self._retrieve_output_via_sdsf()
    
    async def _retrieve_output_via_tso(self):
        """Retrieve job output using TSO OUTPUT command."""
        # Use TSO OUTPUT command to view job output
        await self._send_text(f"OUTPUT {self.job_name}")
        await self._send_key("Enter")
        
        await asyncio.sleep(3)
        await self._capture_screen("06_job_output")
        
        # Save output to file
        response = requests.post(f"{self.base_url}/capture/{self.session_id}")
        if response.status_code == 200:
            screen_text = response.json()["screen_text"]
            
            output_file = f"artifacts/job_output_{self.job_name}_{self.job_id}.txt"
            with open(output_file, 'w') as f:
                f.write(f"Job Output for {self.job_name} (ID: {self.job_id})\n")
                f.write("=" * 50 + "\n")
                f.write(screen_text)
            
            print(f"   Job output saved to: {output_file}")
    
    async def _retrieve_output_via_sdsf(self):
        """Retrieve job output using SDSF."""
        # In SDSF, use 'S' line command next to job to view output
        await self._send_text("S", row=8, col=2)  # Line command
        await self._send_key("Enter")
        
        await asyncio.sleep(2)
        await self._capture_screen("06_sdsf_output_list")
        
        # Select JESMSGLG (job log)
        await self._send_text("S", row=8, col=2)
        await self._send_key("Enter")
        
        await asyncio.sleep(2)
        await self._capture_screen("06_sdsf_job_log")
        
        print("   Job output viewed via SDSF")
    
    async def _send_text(self, text, row=None, col=None):
        """Send text to mainframe screen."""
        response = requests.post(
            f"{self.base_url}/send/{self.session_id}",
            json={"text": text, "row": row, "col": col}
        )
        
        if response.status_code != 200:
            raise Exception(f"Failed to send text: {response.text}")
    
    async def _send_key(self, key):
        """Send key to mainframe."""
        response = requests.post(
            f"{self.base_url}/send_key/{self.session_id}",
            json={"key": key}
        )
        
        if response.status_code != 200:
            raise Exception(f"Failed to send key: {response.text}")
    
    async def _expect_text(self, text, timeout=10, row=None, col=None):
        """Wait for text to appear on screen."""
        response = requests.post(
            f"{self.base_url}/expect/{self.session_id}",
            json={"text": text, "timeout": timeout, "row": row, "col": col}
        )
        
        if response.status_code != 200:
            return False
        
        return response.json()["found"]
    
    async def _capture_screen(self, filename_prefix):
        """Capture current screen state."""
        response = requests.post(f"{self.base_url}/capture/{self.session_id}")
        
        if response.status_code == 200:
            result = response.json()
            
            # Save screen text to file
            text_filename = f"artifacts/{filename_prefix}_{self.session_id}.txt"
            Path(text_filename).parent.mkdir(exist_ok=True)
            
            with open(text_filename, 'w') as f:
                f.write(result["screen_text"])
    
    async def _disconnect(self):
        """Disconnect from mainframe."""
        try:
            response = requests.post(f"{self.base_url}/disconnect/{self.session_id}")
            if response.status_code == 200:
                print(f"   Disconnected successfully")
        except Exception as e:
            print(f"   Error disconnecting: {str(e)}")

async def main():
    """Main function to run the JCL submission example."""
    example = JCLSubmitExample()
    
    # You can modify these parameters for real mainframe testing
    await example.run_jcl_submit_flow(
        host="mock.mainframe.local",  # Change to real mainframe host
        username="TESTUSER",          # Change to real username
        password="TESTPASS"           # Change to real password
    )

if __name__ == "__main__":
    asyncio.run(main()) 