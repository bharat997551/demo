#!/usr/bin/env python3
"""
Example: Mainframe Login Flow

This example demonstrates how to:
1. Connect to a mainframe system
2. Handle login screens
3. Navigate through menus
4. Capture screens at each step

Note: This example can work with mock/simulated mainframe or real z/OS systems.
"""

import asyncio
import sys
import requests
import json
from pathlib import Path

# Add parent directory to path to import main module
sys.path.append(str(Path(__file__).parent.parent))

class MainframeLoginExample:
    def __init__(self, base_url="http://127.0.0.1:8003"):
        self.base_url = base_url
        self.session_id = "login_demo_session"
    
    async def run_login_flow(self, host="mock.mainframe.local", username="TESTUSER", password="PASSWORD"):
        """Execute complete login flow."""
        try:
            print("=== Mainframe Login Flow Example ===")
            
            # Step 1: Connect to mainframe
            print(f"1. Connecting to {host}...")
            await self._connect(host)
            
            # Step 2: Capture initial screen
            print("2. Capturing initial connection screen...")
            await self._capture_screen("01_initial_connection")
            
            # Step 3: Handle login prompt
            print("3. Waiting for login prompt...")
            login_found = await self._expect_text("USERID", timeout=10)
            if not login_found:
                print("   Warning: Login prompt not found, continuing anyway...")
            
            # Step 4: Enter username
            print(f"4. Entering username: {username}")
            await self._send_text(username, row=6, col=20)  # Typical TSO login position
            await self._send_key("Tab")  # Move to password field
            
            # Step 5: Enter password
            print("5. Entering password...")
            await self._send_text(password)
            await self._send_key("Enter")
            
            # Step 6: Wait for login to complete
            print("6. Waiting for login to complete...")
            await asyncio.sleep(3)  # Allow time for login processing
            await self._capture_screen("02_after_login")
            
            # Step 7: Handle potential menu systems
            print("7. Looking for menu system...")
            menu_found = await self._expect_text("ISPF", timeout=5)
            if menu_found:
                print("   ISPF menu found!")
                await self._handle_ispf_menu()
            else:
                tso_found = await self._expect_text("READY", timeout=5)
                if tso_found:
                    print("   TSO READY prompt found!")
                    await self._handle_tso_ready()
                else:
                    print("   Unknown screen after login")
            
            # Step 8: Final screen capture
            await self._capture_screen("03_final_state")
            
            print("8. Login flow completed successfully!")
            
        except Exception as e:
            print(f"Error in login flow: {str(e)}")
            await self._capture_screen("error_state")
        finally:
            # Cleanup
            print("9. Disconnecting...")
            await self._disconnect()
    
    async def _connect(self, host, port=23, model="3279-2"):
        """Connect to mainframe."""
        response = requests.post(
            f"{self.base_url}/connect/{self.session_id}",
            json={"host": host, "port": port, "model": model}
        )
        
        if response.status_code != 200:
            raise Exception(f"Failed to connect: {response.text}")
        
        print(f"   Connected successfully: {response.json()['message']}")
    
    async def _disconnect(self):
        """Disconnect from mainframe."""
        try:
            response = requests.post(f"{self.base_url}/disconnect/{self.session_id}")
            if response.status_code == 200:
                print(f"   Disconnected: {response.json()['message']}")
        except Exception as e:
            print(f"   Error disconnecting: {str(e)}")
    
    async def _send_text(self, text, row=None, col=None):
        """Send text to mainframe screen."""
        response = requests.post(
            f"{self.base_url}/send/{self.session_id}",
            json={"text": text, "row": row, "col": col}
        )
        
        if response.status_code != 200:
            raise Exception(f"Failed to send text: {response.text}")
        
        print(f"   Sent text: '{text}' at position ({row}, {col})")
    
    async def _send_key(self, key):
        """Send key to mainframe."""
        response = requests.post(
            f"{self.base_url}/send_key/{self.session_id}",
            json={"key": key}
        )
        
        if response.status_code != 200:
            raise Exception(f"Failed to send key: {response.text}")
        
        print(f"   Sent key: {key}")
    
    async def _expect_text(self, text, timeout=10, row=None, col=None):
        """Wait for text to appear on screen."""
        response = requests.post(
            f"{self.base_url}/expect/{self.session_id}",
            json={"text": text, "timeout": timeout, "row": row, "col": col}
        )
        
        if response.status_code != 200:
            print(f"   Warning: Error checking for text '{text}': {response.text}")
            return False
        
        result = response.json()
        if result["found"]:
            print(f"   Found expected text: '{text}'")
        else:
            print(f"   Text not found within {timeout}s: '{text}'")
        
        return result["found"]
    
    async def _capture_screen(self, filename_prefix):
        """Capture current screen state."""
        response = requests.post(f"{self.base_url}/capture/{self.session_id}")
        
        if response.status_code != 200:
            print(f"   Warning: Failed to capture screen: {response.text}")
            return
        
        result = response.json()
        
        # Save screen text to file
        text_filename = f"artifacts/{filename_prefix}_{self.session_id}.txt"
        Path(text_filename).parent.mkdir(exist_ok=True)
        
        with open(text_filename, 'w') as f:
            f.write(result["screen_text"])
        
        print(f"   Screen captured: {text_filename}")
        
        if result.get("image_path"):
            print(f"   Screenshot saved: {result['image_path']}")
    
    async def _handle_ispf_menu(self):
        """Handle ISPF Primary Option Menu."""
        print("   Navigating ISPF menu...")
        
        # Typical ISPF navigation - go to Data Set utilities (Option 3)
        await self._send_text("3", row=6, col=2)  # Typical menu option position
        await self._send_key("Enter")
        
        # Wait for next screen
        await asyncio.sleep(2)
        await self._capture_screen("02a_ispf_dataset_utilities")
        
        # Go back to main menu
        await self._send_key("PF3")  # Exit
        await asyncio.sleep(1)
    
    async def _handle_tso_ready(self):
        """Handle TSO READY prompt."""
        print("   At TSO READY prompt...")
        
        # Execute a simple TSO command
        await self._send_text("TIME")
        await self._send_key("Enter")
        
        # Wait for command output
        await asyncio.sleep(2)
        await self._capture_screen("02a_tso_time_command")
        
        # Wait for next READY prompt
        await self._expect_text("READY", timeout=5)

# Mock mainframe simulator for testing
class MockMainframeSession:
    """A simple mock that simulates mainframe responses for testing."""
    
    def __init__(self):
        self.state = "disconnected"
        self.screen_content = self._get_initial_screen()
        self.login_attempts = 0
    
    def _get_initial_screen(self):
        return """




                        MOCK MAINFRAME SYSTEM
                        
                        USERID   ===>
                        PASSWORD ===>
                        
                        
                        ENTER USERID AND PASSWORD TO CONTINUE




"""
    
    def _get_ispf_menu(self):
        return """
  ISPF Primary Option Menu                                                      
                                                                                
     0  Settings       Terminal and user parameters                             
     1  View           Display source data or listings                          
     2  Edit           Create or change source data                             
     3  Utilities      Perform utility functions                                
     4  Foreground     Interactive language processing                          
     5  Batch          Submit job for language processing                       
     6  Command        Enter TSO command or CLIST                               
     7  Dialog         Dialog Test                                              
     8  LM Utilities   Library administrator functions                          
     9  IBM Products   Additional IBM program products                          
    10  SCLM           Software Configuration and Library Manager               
    11  Workplace      ISPF Object/Action Workplace                            
                                                                                
 Option ===>                                                                    
"""

async def main():
    """Main function to run the login flow example."""
    example = MainframeLoginExample()
    
    # You can modify these parameters for real mainframe testing
    await example.run_login_flow(
        host="mock.mainframe.local",  # Change to real mainframe host
        username="TESTUSER",          # Change to real username
        password="TESTPASS"           # Change to real password
    )

if __name__ == "__main__":
    asyncio.run(main()) 