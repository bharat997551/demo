@echo off
REM Windows batch script to set up Python virtual environment for mainframe engine

echo Setting up Python virtual environment for Mainframe Engine...
echo.

REM Check if Python is available
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo ERROR: Python is not installed or not in PATH
    echo Please install Python 3.11 or higher
    pause
    exit /b 1
)

REM Check Python version
for /f "tokens=2" %%i in ('python --version 2^>^&1') do set python_version=%%i
echo Found Python %python_version%

REM Create virtual environment
echo Creating virtual environment...
python -m venv venv
if %errorlevel% neq 0 (
    echo ERROR: Failed to create virtual environment
    pause
    exit /b 1
)

REM Activate virtual environment
echo Activating virtual environment...
call venv\Scripts\activate.bat

REM Upgrade pip
echo Upgrading pip...
python -m pip install --upgrade pip

REM Install dependencies
echo Installing dependencies...
pip install -r requirements.txt
if %errorlevel% neq 0 (
    echo ERROR: Failed to install dependencies
    pause
    exit /b 1
)

REM Install development dependencies
echo Installing development dependencies...
pip install pytest-asyncio black flake8 mypy
if %errorlevel% neq 0 (
    echo WARNING: Failed to install development dependencies (optional)
)

echo.
echo Virtual environment setup complete!
echo.
echo To activate the environment in future sessions, run:
echo   venv\Scripts\activate.bat
echo.
echo To run the mainframe engine:
echo   cd src
echo   python main.py
echo.
echo To run tests:
echo   python -m pytest src/tests/
echo.

pause 