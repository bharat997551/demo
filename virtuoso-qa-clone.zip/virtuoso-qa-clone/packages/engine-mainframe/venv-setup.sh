#!/bin/bash
# Shell script to set up Python virtual environment for mainframe engine

set -e  # Exit on any error

echo "Setting up Python virtual environment for Mainframe Engine..."
echo

# Check if Python is available
if ! command -v python3 &> /dev/null; then
    if ! command -v python &> /dev/null; then
        echo "ERROR: Python is not installed or not in PATH"
        echo "Please install Python 3.11 or higher"
        exit 1
    else
        PYTHON_CMD="python"
    fi
else
    PYTHON_CMD="python3"
fi

# Check Python version
PYTHON_VERSION=$($PYTHON_CMD --version 2>&1 | cut -d' ' -f2)
echo "Found Python $PYTHON_VERSION"

# Verify Python version is 3.11 or higher
PYTHON_MAJOR=$(echo $PYTHON_VERSION | cut -d'.' -f1)
PYTHON_MINOR=$(echo $PYTHON_VERSION | cut -d'.' -f2)

if [[ $PYTHON_MAJOR -lt 3 ]] || [[ $PYTHON_MAJOR -eq 3 && $PYTHON_MINOR -lt 11 ]]; then
    echo "WARNING: Python $PYTHON_VERSION detected. Python 3.11 or higher is recommended."
    echo "Continuing anyway..."
fi

# Check if s3270 is available (optional but recommended)
if command -v s3270 &> /dev/null; then
    S3270_VERSION=$(s3270 --version 2>&1 | head -n1)
    echo "Found s3270: $S3270_VERSION"
else
    echo "WARNING: s3270 not found in PATH"
    echo "Install s3270 for full mainframe connectivity:"
    echo "  Ubuntu/Debian: sudo apt-get install s3270"
    echo "  RHEL/CentOS: sudo yum install s3270"
    echo "  macOS: brew install s3270"
fi

# Create virtual environment
echo "Creating virtual environment..."
$PYTHON_CMD -m venv venv

# Activate virtual environment
echo "Activating virtual environment..."
source venv/bin/activate

# Upgrade pip
echo "Upgrading pip..."
python -m pip install --upgrade pip

# Install dependencies
echo "Installing dependencies..."
pip install -r requirements.txt

# Install development dependencies
echo "Installing development dependencies..."
pip install pytest-asyncio black flake8 mypy || {
    echo "WARNING: Failed to install development dependencies (optional)"
}

echo
echo "Virtual environment setup complete!"
echo
echo "To activate the environment in future sessions, run:"
echo "  source venv/bin/activate"
echo
echo "To run the mainframe engine:"
echo "  cd src"
echo "  python main.py"
echo
echo "To run tests:"
echo "  python -m pytest src/tests/"
echo
echo "To run examples:"
echo "  cd src/examples"
echo "  python login_flow.py"
echo "  python jcl_submit.py"
echo 