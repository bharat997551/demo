/**
 * Base error class for the application
 */
export class AppError extends Error {
  public readonly statusCode: number;
  public readonly code: string;
  public readonly isOperational: boolean;

  constructor(
    message: string,
    statusCode: number = 500,
    code: string = 'INTERNAL_ERROR',
    isOperational: boolean = true
  ) {
    super(message);
    this.statusCode = statusCode;
    this.code = code;
    this.isOperational = isOperational;
    
    // Maintains proper stack trace for where error was thrown (Node.js only)
    if ((Error as any).captureStackTrace) {
      (Error as any).captureStackTrace(this, this.constructor);
    }
  }
}

/**
 * Validation error
 */
export class ValidationError extends AppError {
  constructor(message: string, field?: string) {
    super(message, 400, 'VALIDATION_ERROR');
    this.name = 'ValidationError';
    if (field) {
      this.message = `${field}: ${message}`;
    }
  }
}

/**
 * Not found error
 */
export class NotFoundError extends AppError {
  constructor(resource: string, id?: string) {
    const message = id ? `${resource} with id ${id} not found` : `${resource} not found`;
    super(message, 404, 'NOT_FOUND');
    this.name = 'NotFoundError';
  }
}

/**
 * Unauthorized error
 */
export class UnauthorizedError extends AppError {
  constructor(message: string = 'Unauthorized') {
    super(message, 401, 'UNAUTHORIZED');
    this.name = 'UnauthorizedError';
  }
}

/**
 * Forbidden error
 */
export class ForbiddenError extends AppError {
  constructor(message: string = 'Forbidden') {
    super(message, 403, 'FORBIDDEN');
    this.name = 'ForbiddenError';
  }
}

/**
 * Engine error
 */
export class EngineError extends AppError {
  public readonly engine: string;

  constructor(message: string, engine: string, statusCode: number = 500) {
    super(message, statusCode, 'ENGINE_ERROR');
    this.name = 'EngineError';
    this.engine = engine;
  }
}

/**
 * Execution error
 */
export class ExecutionError extends AppError {
  public readonly stepId?: string;
  public readonly flowId?: string;

  constructor(
    message: string, 
    stepId?: string, 
    flowId?: string,
    statusCode: number = 500
  ) {
    super(message, statusCode, 'EXECUTION_ERROR');
    this.name = 'ExecutionError';
    this.stepId = stepId;
    this.flowId = flowId;
  }
}

/**
 * Type for error response
 */
export interface ErrorResponse {
  success: false;
  error: {
    message: string;
    code: string;
    statusCode: number;
    details?: any;
  };
}

/**
 * Success response type
 */
export interface SuccessResponse<T = any> {
  success: true;
  data: T;
  message?: string;
} 