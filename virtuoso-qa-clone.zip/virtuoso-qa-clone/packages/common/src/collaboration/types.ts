/**
 * Collaboration Types and Interfaces
 * Foundation for multi-user projects, RBAC, and version control
 */

export type UserRole = 'owner' | 'admin' | 'developer' | 'tester' | 'viewer';
export type Permission = 
  | 'project.create' | 'project.read' | 'project.update' | 'project.delete'
  | 'test.create' | 'test.read' | 'test.update' | 'test.delete' | 'test.execute'
  | 'result.read' | 'result.delete' | 'result.export'
  | 'user.invite' | 'user.remove' | 'user.manage'
  | 'settings.read' | 'settings.update'
  | 'git.push' | 'git.pull' | 'git.merge';

export interface User {
  id: string;
  email: string;
  name: string;
  avatarUrl?: string;
  createdAt: Date;
  lastActiveAt: Date;
  preferences: UserPreferences;
  ssoProvider?: 'github' | 'gitlab' | 'bitbucket' | 'azure' | 'google';
  ssoId?: string;
}

export interface UserPreferences {
  theme: 'light' | 'dark' | 'system';
  language: string;
  notifications: {
    email: boolean;
    desktop: boolean;
    testResults: boolean;
    projectUpdates: boolean;
    mentions: boolean;
  };
  defaultView?: 'visual' | 'code';
  keyboardShortcuts?: Record<string, string>;
}

export interface Project {
  id: string;
  name: string;
  description?: string;
  createdBy: string;
  createdAt: Date;
  updatedAt: Date;
  settings: ProjectSettings;
  gitRepository?: GitRepository;
  teamId?: string;
  tags: string[];
  isPublic: boolean;
}

export interface ProjectSettings {
  defaultEngine?: string;
  defaultTimeout?: number;
  parallelExecution?: boolean;
  maxConcurrentTests?: number;
  artifactRetention?: number; // days
  environmentVariables?: Record<string, string>;
  secretsVault?: string;
  notificationChannels?: NotificationChannel[];
}

export interface Team {
  id: string;
  name: string;
  description?: string;
  organizationId?: string;
  createdAt: Date;
  members: TeamMember[];
  projects: string[]; // Project IDs
  settings: TeamSettings;
}

export interface TeamMember {
  userId: string;
  role: UserRole;
  joinedAt: Date;
  permissions: Permission[];
  customPermissions?: Permission[];
}

export interface TeamSettings {
  requireTwoFactorAuth?: boolean;
  allowGuestAccess?: boolean;
  defaultUserRole?: UserRole;
  ssoRequired?: boolean;
  ipWhitelist?: string[];
}

export interface Organization {
  id: string;
  name: string;
  domain?: string;
  plan: 'free' | 'team' | 'enterprise';
  teams: string[]; // Team IDs
  billing?: BillingInfo;
  settings: OrganizationSettings;
}

export interface OrganizationSettings {
  ssoProvider?: string;
  ssoConfig?: Record<string, any>;
  dataRetentionDays?: number;
  auditLogEnabled?: boolean;
  customBranding?: {
    logo?: string;
    primaryColor?: string;
    favicon?: string;
  };
}

export interface BillingInfo {
  customerId: string;
  subscriptionId: string;
  plan: string;
  status: 'active' | 'past_due' | 'cancelled';
  currentPeriodEnd: Date;
  seats: number;
  usage: {
    testRuns: number;
    storageGB: number;
    apiCalls: number;
  };
}

// Git Integration Types
export interface GitRepository {
  url: string;
  branch: string;
  provider: 'github' | 'gitlab' | 'bitbucket' | 'azure';
  authentication: GitAuth;
  syncEnabled: boolean;
  lastSyncAt?: Date;
  webhook?: {
    url: string;
    secret: string;
    events: string[];
  };
}

export interface GitAuth {
  type: 'ssh' | 'https' | 'token';
  username?: string;
  token?: string;
  sshKey?: string;
  sshKeyPassphrase?: string;
}

export interface GitCommit {
  sha: string;
  message: string;
  author: {
    name: string;
    email: string;
    date: Date;
  };
  files: GitFile[];
  testResults?: TestResultSummary;
}

export interface GitFile {
  path: string;
  status: 'added' | 'modified' | 'deleted' | 'renamed';
  additions: number;
  deletions: number;
  patch?: string;
}

export interface TestResultSummary {
  runId: string;
  status: 'passed' | 'failed' | 'skipped';
  totalTests: number;
  passedTests: number;
  failedTests: number;
  duration: number;
  coverage?: number;
}

// Version Control for Tests
export interface TestVersion {
  id: string;
  testId: string;
  version: number;
  commitSha?: string;
  createdBy: string;
  createdAt: Date;
  message: string;
  changes: TestChange[];
  snapshot: any; // Full test definition at this version
  tags?: string[];
}

export interface TestChange {
  type: 'added' | 'modified' | 'deleted';
  path: string; // JSONPath to the changed field
  oldValue?: any;
  newValue?: any;
  description?: string;
}

// Collaboration Activities
export interface Activity {
  id: string;
  type: ActivityType;
  userId: string;
  projectId?: string;
  testId?: string;
  timestamp: Date;
  details: Record<string, any>;
  metadata?: {
    ip?: string;
    userAgent?: string;
    sessionId?: string;
  };
}

export type ActivityType = 
  | 'project.created' | 'project.updated' | 'project.deleted'
  | 'test.created' | 'test.updated' | 'test.deleted' | 'test.executed'
  | 'user.joined' | 'user.left' | 'user.role_changed'
  | 'comment.added' | 'comment.updated' | 'comment.deleted'
  | 'file.uploaded' | 'file.deleted'
  | 'git.pushed' | 'git.pulled' | 'git.merged';

// Real-time Collaboration
export interface CollaborationSession {
  id: string;
  projectId: string;
  testId?: string;
  participants: SessionParticipant[];
  startedAt: Date;
  type: 'editing' | 'debugging' | 'reviewing';
  state: CollaborationState;
}

export interface SessionParticipant {
  userId: string;
  joinedAt: Date;
  cursor?: CursorPosition;
  selection?: SelectionRange;
  isActive: boolean;
  permissions: Permission[];
}

export interface CursorPosition {
  line: number;
  column: number;
  file?: string;
}

export interface SelectionRange {
  start: CursorPosition;
  end: CursorPosition;
}

export interface CollaborationState {
  locks: Record<string, string>; // path -> userId
  changes: PendingChange[];
  comments: InlineComment[];
}

export interface PendingChange {
  id: string;
  userId: string;
  path: string;
  operation: 'insert' | 'delete' | 'update';
  value: any;
  timestamp: Date;
}

export interface InlineComment {
  id: string;
  userId: string;
  path: string;
  line?: number;
  text: string;
  timestamp: Date;
  resolved: boolean;
  replies: CommentReply[];
}

export interface CommentReply {
  id: string;
  userId: string;
  text: string;
  timestamp: Date;
}

// Notification Types
export interface NotificationChannel {
  type: 'email' | 'slack' | 'teams' | 'webhook';
  config: Record<string, any>;
  events: NotificationEvent[];
  enabled: boolean;
}

export type NotificationEvent = 
  | 'test.failed' | 'test.passed' | 'test.completed'
  | 'project.updated' | 'user.mentioned'
  | 'comment.added' | 'review.requested';

// Access Control
export interface AccessPolicy {
  id: string;
  name: string;
  description?: string;
  rules: AccessRule[];
  priority: number;
}

export interface AccessRule {
  resource: string; // e.g., 'project:*', 'test:123', 'user:*'
  actions: Permission[];
  conditions?: AccessCondition[];
  effect: 'allow' | 'deny';
}

export interface AccessCondition {
  type: 'time' | 'ip' | 'attribute' | 'custom';
  operator: 'equals' | 'not_equals' | 'contains' | 'in' | 'between';
  value: any;
}

// Audit Log
export interface AuditLog {
  id: string;
  timestamp: Date;
  userId: string;
  action: string;
  resource: string;
  resourceId: string;
  changes?: Record<string, { old: any; new: any }>;
  result: 'success' | 'failure';
  errorMessage?: string;
  metadata: {
    ip: string;
    userAgent: string;
    sessionId: string;
    traceId: string;
  };
}

// Role-Based Access Control
export interface RoleDefinition {
  name: UserRole;
  description: string;
  permissions: Permission[];
  inherits?: UserRole[];
  isCustom: boolean;
  createdBy?: string;
  createdAt?: Date;
}

// Default role definitions
export const DEFAULT_ROLES: Record<UserRole, RoleDefinition> = {
  owner: {
    name: 'owner',
    description: 'Full access to all project resources',
    permissions: [
      'project.create', 'project.read', 'project.update', 'project.delete',
      'test.create', 'test.read', 'test.update', 'test.delete', 'test.execute',
      'result.read', 'result.delete', 'result.export',
      'user.invite', 'user.remove', 'user.manage',
      'settings.read', 'settings.update',
      'git.push', 'git.pull', 'git.merge'
    ],
    isCustom: false
  },
  admin: {
    name: 'admin',
    description: 'Administrative access without ownership transfer',
    permissions: [
      'project.read', 'project.update',
      'test.create', 'test.read', 'test.update', 'test.delete', 'test.execute',
      'result.read', 'result.delete', 'result.export',
      'user.invite', 'user.remove',
      'settings.read', 'settings.update',
      'git.push', 'git.pull', 'git.merge'
    ],
    isCustom: false
  },
  developer: {
    name: 'developer',
    description: 'Create and modify tests, execute and view results',
    permissions: [
      'project.read',
      'test.create', 'test.read', 'test.update', 'test.execute',
      'result.read', 'result.export',
      'git.push', 'git.pull'
    ],
    isCustom: false
  },
  tester: {
    name: 'tester',
    description: 'Execute tests and view results',
    permissions: [
      'project.read',
      'test.read', 'test.execute',
      'result.read', 'result.export'
    ],
    isCustom: false
  },
  viewer: {
    name: 'viewer',
    description: 'Read-only access to project resources',
    permissions: [
      'project.read',
      'test.read',
      'result.read'
    ],
    isCustom: false
  }
}; 