/**
 * Collaboration Types and Constants Export
 */

export * from './types';

// Convenience re-exports
export type {
  User,
  UserRole,
  Permission,
  Project,
  Team,
  TeamMember,
  GitRepository,
  Activity,
  ActivityType,
  CollaborationSession,
  AuditLog,
  RoleDefinition
} from './types';

export { DEFAULT_ROLES } from './types'; 