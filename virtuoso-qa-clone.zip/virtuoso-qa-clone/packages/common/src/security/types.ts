export interface SecureVariable {
  id: string;
  name: string;
  value: string;  // Always encrypted when stored
  projectId: string;
  environmentId?: string;
  isMasked: boolean;
  maskInExports: boolean;
  description?: string;
  tags?: string[];
  createdAt: Date;
  updatedAt: Date;
  lastAccessedAt?: Date;
  createdBy: string;
}

export interface EnvironmentProfile {
  id: string;
  name: string;
  projectId: string;
  type: 'DEV' | 'UAT' | 'PROD' | 'CUSTOM';
  isDefault?: boolean;
  variables: Array<{
    key: string;
    value: string;  // Encrypted
    isMasked: boolean;
  }>;
  endpoints: {
    baseUrl?: string;
    apiUrl?: string;
    webUrl?: string;
    mainframeHost?: string;
    [key: string]: string | undefined;
  };
  credentials: Array<{
    id: string;
    type: 'basic' | 'bearer' | 'oauth2' | 'apikey' | 'custom';
    name: string;
    data: string;  // Encrypted JSON
  }>;
  metadata?: Record<string, any>;
  createdAt: Date;
  updatedAt: Date;
}

export interface SecureStorageConfig {
  provider: 'dpapi' | 'file' | 'memory';
  encryptionKey?: string;  // For file-based encryption
  storagePath?: string;
  inMemoryOnly?: boolean;
}

export interface EncryptedData {
  iv: string;
  authTag: string;
  data: string;
  algorithm: string;
  timestamp: number;
}

export interface SecretAccess {
  secretId: string;
  projectId: string;
  environmentId?: string;
  accessedBy: string;
  accessedAt: Date;
  purpose: string;
  success: boolean;
}

export interface MaskingConfig {
  enabled: boolean;
  maskPattern: string;  // Default: '****'
  showFirstChars?: number;
  showLastChars?: number;
  excludePatterns?: RegExp[];  // Patterns that should never be masked
  alwaysMaskPatterns?: RegExp[];  // Patterns that should always be masked
}

export interface ProjectSecurityPolicy {
  projectId: string;
  allowedEnvironments: string[];
  secretRotationDays?: number;
  requireMFA?: boolean;
  allowExportSecrets: boolean;
  auditAccess: boolean;
  ipWhitelist?: string[];
  masking: MaskingConfig;
}

export interface SecretValidation {
  pattern?: RegExp;
  minLength?: number;
  maxLength?: number;
  requireUppercase?: boolean;
  requireLowercase?: boolean;
  requireNumbers?: boolean;
  requireSpecialChars?: boolean;
  customValidator?: (value: string) => boolean | string;
}

export interface SecureContext {
  projectId: string;
  environmentId: string;
  userId: string;
  sessionId: string;
  ipAddress?: string;
  userAgent?: string;
}

export class SecurityError extends Error {
  constructor(
    message: string,
    public code: 'ENCRYPTION_FAILED' | 'DECRYPTION_FAILED' | 'ACCESS_DENIED' | 
           'INVALID_CONTEXT' | 'SECRET_NOT_FOUND' | 'POLICY_VIOLATION',
    public context?: any
  ) {
    super(message);
    this.name = 'SecurityError';
  }
} 