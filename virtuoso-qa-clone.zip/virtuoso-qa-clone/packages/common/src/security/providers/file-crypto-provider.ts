import * as crypto from 'crypto';
import * as fs from 'fs/promises';
import * as path from 'path';
import { EncryptedData, SecurityError } from '../types';
import { logger } from '../../logger';

/**
 * File-based encryption provider using AES-256-GCM
 * Fallback when DPAPI is not available
 */
export class FileCryptoProvider {
  private algorithm = 'aes-256-gcm';
  private keyDerivationIterations = 100000;
  private saltLength = 32;
  private ivLength = 16;
  private tagLength = 16;
  private keyPath: string;
  private masterKey?: Buffer;

  constructor(private storagePath: string) {
    this.keyPath = path.join(storagePath, '.master.key');
  }

  async initialize(passphrase?: string): Promise<void> {
    try {
      await fs.mkdir(this.storagePath, { recursive: true });
      
      if (await this.masterKeyExists()) {
        await this.loadMasterKey(passphrase);
      } else {
        await this.createMasterKey(passphrase);
      }
    } catch (error) {
      logger.error('Failed to initialize file crypto provider', { error });
      throw new SecurityError(
        'Failed to initialize encryption',
        'ENCRYPTION_FAILED',
        { error }
      );
    }
  }

  private async masterKeyExists(): Promise<boolean> {
    try {
      await fs.access(this.keyPath);
      return true;
    } catch {
      return false;
    }
  }

  private async createMasterKey(passphrase?: string): Promise<void> {
    // Generate a random master key
    const masterKey = crypto.randomBytes(32);
    
    if (passphrase) {
      // Encrypt master key with passphrase
      const salt = crypto.randomBytes(this.saltLength);
      const derivedKey = crypto.pbkdf2Sync(
        passphrase,
        salt,
        this.keyDerivationIterations,
        32,
        'sha256'
      );
      
      const iv = crypto.randomBytes(this.ivLength);
      const cipher = crypto.createCipheriv(this.algorithm, derivedKey, iv);
      
      const encrypted = Buffer.concat([
        cipher.update(masterKey),
        cipher.final()
      ]);
      
      const authTag = cipher.getAuthTag();
      
      const keyData = {
        salt: salt.toString('base64'),
        iv: iv.toString('base64'),
        authTag: authTag.toString('base64'),
        encrypted: encrypted.toString('base64'),
        iterations: this.keyDerivationIterations
      };
      
      await fs.writeFile(this.keyPath, JSON.stringify(keyData, null, 2), 'utf-8');
    } else {
      // Store master key in plain (less secure, but no passphrase required)
      const keyData = {
        key: masterKey.toString('base64'),
        warning: 'This key is not encrypted. Use a passphrase for better security.'
      };
      
      await fs.writeFile(this.keyPath, JSON.stringify(keyData, null, 2), 'utf-8');
    }
    
    this.masterKey = masterKey;
  }

  private async loadMasterKey(passphrase?: string): Promise<void> {
    try {
      const keyDataStr = await fs.readFile(this.keyPath, 'utf-8');
      const keyData = JSON.parse(keyDataStr);
      
      if (keyData.key) {
        // Unencrypted master key
        this.masterKey = Buffer.from(keyData.key, 'base64');
      } else if (keyData.encrypted && passphrase) {
        // Encrypted master key
        const salt = Buffer.from(keyData.salt, 'base64');
        const derivedKey = crypto.pbkdf2Sync(
          passphrase,
          salt,
          keyData.iterations,
          32,
          'sha256'
        );
        
        const iv = Buffer.from(keyData.iv, 'base64');
        const authTag = Buffer.from(keyData.authTag, 'base64');
        const encrypted = Buffer.from(keyData.encrypted, 'base64');
        
        const decipher = crypto.createDecipheriv(this.algorithm, derivedKey, iv);
        decipher.setAuthTag(authTag);
        
        this.masterKey = Buffer.concat([
          decipher.update(encrypted),
          decipher.final()
        ]);
      } else {
        throw new Error('Passphrase required for encrypted master key');
      }
    } catch (error) {
      logger.error('Failed to load master key', { error });
      throw new SecurityError(
        'Failed to load encryption key',
        'DECRYPTION_FAILED',
        { error }
      );
    }
  }

  async encrypt(data: string): Promise<EncryptedData> {
    if (!this.masterKey) {
      throw new SecurityError('Encryption not initialized', 'ENCRYPTION_FAILED');
    }

    try {
      const iv = crypto.randomBytes(this.ivLength);
      const cipher = crypto.createCipheriv(this.algorithm, this.masterKey, iv);
      
      const encrypted = Buffer.concat([
        cipher.update(data, 'utf8'),
        cipher.final()
      ]);
      
      const authTag = cipher.getAuthTag();
      
      return {
        iv: iv.toString('base64'),
        authTag: authTag.toString('base64'),
        data: encrypted.toString('base64'),
        algorithm: this.algorithm,
        timestamp: Date.now()
      };
    } catch (error) {
      logger.error('Encryption failed', { error });
      throw new SecurityError(
        'Failed to encrypt data',
        'ENCRYPTION_FAILED',
        { error }
      );
    }
  }

  async decrypt(encryptedData: EncryptedData): Promise<string> {
    if (!this.masterKey) {
      throw new SecurityError('Encryption not initialized', 'DECRYPTION_FAILED');
    }

    if (encryptedData.algorithm !== this.algorithm) {
      throw new SecurityError(
        `Invalid algorithm: ${encryptedData.algorithm}`,
        'DECRYPTION_FAILED'
      );
    }

    try {
      const iv = Buffer.from(encryptedData.iv, 'base64');
      const authTag = Buffer.from(encryptedData.authTag, 'base64');
      const encrypted = Buffer.from(encryptedData.data, 'base64');
      
      const decipher = crypto.createDecipheriv(this.algorithm, this.masterKey, iv);
      decipher.setAuthTag(authTag);
      
      const decrypted = Buffer.concat([
        decipher.update(encrypted),
        decipher.final()
      ]);
      
      return decrypted.toString('utf8');
    } catch (error) {
      logger.error('Decryption failed', { error });
      throw new SecurityError(
        'Failed to decrypt data',
        'DECRYPTION_FAILED',
        { error }
      );
    }
  }

  /**
   * Encrypt a file on disk
   */
  async encryptFile(inputPath: string, outputPath: string): Promise<void> {
    if (!this.masterKey) {
      throw new SecurityError('Encryption not initialized', 'ENCRYPTION_FAILED');
    }

    try {
      const data = await fs.readFile(inputPath);
      const iv = crypto.randomBytes(this.ivLength);
      const cipher = crypto.createCipheriv(this.algorithm, this.masterKey, iv);
      
      const encrypted = Buffer.concat([
        cipher.update(data),
        cipher.final()
      ]);
      
      const authTag = cipher.getAuthTag();
      
      // Write IV, auth tag, and encrypted data
      const output = Buffer.concat([
        iv,
        authTag,
        encrypted
      ]);
      
      await fs.writeFile(outputPath, output);
    } catch (error) {
      logger.error('File encryption failed', { error });
      throw new SecurityError(
        'Failed to encrypt file',
        'ENCRYPTION_FAILED',
        { error }
      );
    }
  }

  /**
   * Decrypt a file on disk
   */
  async decryptFile(inputPath: string, outputPath: string): Promise<void> {
    if (!this.masterKey) {
      throw new SecurityError('Encryption not initialized', 'DECRYPTION_FAILED');
    }

    try {
      const data = await fs.readFile(inputPath);
      
      // Extract IV, auth tag, and encrypted data
      const iv = data.subarray(0, this.ivLength);
      const authTag = data.subarray(this.ivLength, this.ivLength + this.tagLength);
      const encrypted = data.subarray(this.ivLength + this.tagLength);
      
      const decipher = crypto.createDecipheriv(this.algorithm, this.masterKey, iv);
      decipher.setAuthTag(authTag);
      
      const decrypted = Buffer.concat([
        decipher.update(encrypted),
        decipher.final()
      ]);
      
      await fs.writeFile(outputPath, decrypted);
    } catch (error) {
      logger.error('File decryption failed', { error });
      throw new SecurityError(
        'Failed to decrypt file',
        'DECRYPTION_FAILED',
        { error }
      );
    }
  }

  /**
   * Change the master key passphrase
   */
  async changePassphrase(oldPassphrase?: string, newPassphrase?: string): Promise<void> {
    // Load with old passphrase
    await this.loadMasterKey(oldPassphrase);
    
    // Save with new passphrase
    const masterKey = this.masterKey;
    if (!masterKey) {
      throw new SecurityError('No master key loaded', 'ENCRYPTION_FAILED');
    }
    
    // Temporarily clear master key to force recreation
    this.masterKey = undefined;
    await fs.unlink(this.keyPath);
    
    // Set master key back and create with new passphrase
    this.masterKey = masterKey;
    await this.createMasterKey(newPassphrase);
  }
} 