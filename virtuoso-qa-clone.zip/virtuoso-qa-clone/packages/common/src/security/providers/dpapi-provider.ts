import { EncryptedData, SecurityError } from '../types';
import { logger } from '../../logger';
import * as os from 'os';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

/**
 * Windows DPAPI provider for secure encryption
 * Uses PowerShell to access Windows Data Protection API
 */
export class DPAPIProvider {
  private isWindows: boolean;

  constructor() {
    this.isWindows = os.platform() === 'win32';
  }

  async isAvailable(): Promise<boolean> {
    if (!this.isWindows) {
      return false;
    }

    try {
      // Test if PowerShell and DPAPI are available
      await execAsync('powershell -Command "Get-Command ConvertTo-SecureString"');
      return true;
    } catch {
      return false;
    }
  }

  async encrypt(data: string, scope: 'CurrentUser' | 'LocalMachine' = 'CurrentUser'): Promise<EncryptedData> {
    if (!this.isWindows) {
      throw new SecurityError('DPAPI is only available on Windows', 'ENCRYPTION_FAILED');
    }

    try {
      // Convert string to base64
      const base64Data = Buffer.from(data, 'utf-8').toString('base64');
      
      // PowerShell script to encrypt using DPAPI
      const script = `
        $plainText = "${base64Data}"
        $secureString = ConvertTo-SecureString $plainText -AsPlainText -Force
        $encrypted = ConvertFrom-SecureString $secureString -Key $null
        Write-Output $encrypted
      `;

      const { stdout } = await execAsync(`powershell -Command "${script.replace(/"/g, '\\"')}"`);
      const encryptedData = stdout.trim();

      return {
        iv: '', // DPAPI handles this internally
        authTag: '', // DPAPI handles this internally
        data: encryptedData,
        algorithm: 'DPAPI',
        timestamp: Date.now()
      };
    } catch (error) {
      logger.error('DPAPI encryption failed', { error });
      throw new SecurityError(
        'Failed to encrypt data using DPAPI',
        'ENCRYPTION_FAILED',
        { error }
      );
    }
  }

  async decrypt(encryptedData: EncryptedData): Promise<string> {
    if (!this.isWindows) {
      throw new SecurityError('DPAPI is only available on Windows', 'DECRYPTION_FAILED');
    }

    if (encryptedData.algorithm !== 'DPAPI') {
      throw new SecurityError(
        `Invalid algorithm: ${encryptedData.algorithm}`,
        'DECRYPTION_FAILED'
      );
    }

    try {
      // PowerShell script to decrypt using DPAPI
      const script = `
        $encrypted = "${encryptedData.data}"
        $secureString = ConvertTo-SecureString $encrypted
        $plainText = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto([System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureString))
        Write-Output $plainText
      `;

      const { stdout } = await execAsync(`powershell -Command "${script.replace(/"/g, '\\"')}"`);
      const base64Data = stdout.trim();
      
      // Convert from base64 back to string
      return Buffer.from(base64Data, 'base64').toString('utf-8');
    } catch (error) {
      logger.error('DPAPI decryption failed', { error });
      throw new SecurityError(
        'Failed to decrypt data using DPAPI',
        'DECRYPTION_FAILED',
        { error }
      );
    }
  }

  /**
   * Encrypt with additional entropy for extra security
   */
  async encryptWithEntropy(
    data: string,
    entropy: string,
    scope: 'CurrentUser' | 'LocalMachine' = 'CurrentUser'
  ): Promise<EncryptedData> {
    if (!this.isWindows) {
      throw new SecurityError('DPAPI is only available on Windows', 'ENCRYPTION_FAILED');
    }

    try {
      const base64Data = Buffer.from(data, 'utf-8').toString('base64');
      const base64Entropy = Buffer.from(entropy, 'utf-8').toString('base64');
      
      // PowerShell script with entropy
      const script = `
        Add-Type -AssemblyName System.Security
        $plainBytes = [System.Convert]::FromBase64String("${base64Data}")
        $entropyBytes = [System.Convert]::FromBase64String("${base64Entropy}")
        $scope = [System.Security.Cryptography.DataProtectionScope]::${scope}
        $encryptedBytes = [System.Security.Cryptography.ProtectedData]::Protect($plainBytes, $entropyBytes, $scope)
        $encrypted = [System.Convert]::ToBase64String($encryptedBytes)
        Write-Output $encrypted
      `;

      const { stdout } = await execAsync(`powershell -Command "${script.replace(/"/g, '\\"')}"`);
      const encryptedData = stdout.trim();

      return {
        iv: base64Entropy, // Store entropy as IV for decryption
        authTag: '',
        data: encryptedData,
        algorithm: 'DPAPI_ENTROPY',
        timestamp: Date.now()
      };
    } catch (error) {
      logger.error('DPAPI encryption with entropy failed', { error });
      throw new SecurityError(
        'Failed to encrypt data using DPAPI with entropy',
        'ENCRYPTION_FAILED',
        { error }
      );
    }
  }

  async decryptWithEntropy(encryptedData: EncryptedData): Promise<string> {
    if (!this.isWindows) {
      throw new SecurityError('DPAPI is only available on Windows', 'DECRYPTION_FAILED');
    }

    if (encryptedData.algorithm !== 'DPAPI_ENTROPY') {
      throw new SecurityError(
        `Invalid algorithm: ${encryptedData.algorithm}`,
        'DECRYPTION_FAILED'
      );
    }

    try {
      const script = `
        Add-Type -AssemblyName System.Security
        $encryptedBytes = [System.Convert]::FromBase64String("${encryptedData.data}")
        $entropyBytes = [System.Convert]::FromBase64String("${encryptedData.iv}")
        $decryptedBytes = [System.Security.Cryptography.ProtectedData]::Unprotect($encryptedBytes, $entropyBytes, [System.Security.Cryptography.DataProtectionScope]::CurrentUser)
        $decrypted = [System.Convert]::ToBase64String($decryptedBytes)
        Write-Output $decrypted
      `;

      const { stdout } = await execAsync(`powershell -Command "${script.replace(/"/g, '\\"')}"`);
      const base64Data = stdout.trim();
      
      return Buffer.from(base64Data, 'base64').toString('utf-8');
    } catch (error) {
      logger.error('DPAPI decryption with entropy failed', { error });
      throw new SecurityError(
        'Failed to decrypt data using DPAPI with entropy',
        'DECRYPTION_FAILED',
        { error }
      );
    }
  }
} 