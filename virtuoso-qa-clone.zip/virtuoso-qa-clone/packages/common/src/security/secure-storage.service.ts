import { EventEmitter } from 'events';
import * as path from 'path';
import * as fs from 'fs/promises';
import { v4 as uuidv4 } from 'uuid';
import {
  SecureVariable,
  EnvironmentProfile,
  SecureStorageConfig,
  EncryptedData,
  SecretAccess,
  ProjectSecurityPolicy,
  SecureContext,
  SecurityError,
  MaskingConfig
} from './types';
import { DPAPIProvider } from './providers/dpapi-provider';
import { FileCryptoProvider } from './providers/file-crypto-provider';
import { logger } from '../logger';

export class SecureStorageService extends EventEmitter {
  private dpapi?: DPAPIProvider;
  private fileCrypto?: FileCryptoProvider;
  private provider: 'dpapi' | 'file' | 'memory';
  private memoryStore: Map<string, EncryptedData> = new Map();
  private decryptedCache: Map<string, { value: string; expires: number }> = new Map();
  private accessLog: SecretAccess[] = [];
  private config: SecureStorageConfig;
  private storagePath: string;
  private initialized = false;

  constructor(config: SecureStorageConfig) {
    super();
    this.config = config;
    this.provider = config.provider;
    this.storagePath = config.storagePath || path.join(process.cwd(), '.hybrid-qa', 'secure');
  }

  async initialize(passphrase?: string): Promise<void> {
    if (this.initialized) return;

    try {
      await fs.mkdir(this.storagePath, { recursive: true });

      if (this.provider === 'dpapi' || this.provider === 'file') {
        // Try DPAPI first on Windows
        if (this.provider === 'dpapi' || (process.platform === 'win32' && this.provider !== 'file')) {
          this.dpapi = new DPAPIProvider();
          const dpapiAvailable = await this.dpapi.isAvailable();
          
          if (dpapiAvailable) {
            this.provider = 'dpapi';
            logger.info('Using Windows DPAPI for encryption');
          } else if (this.provider === 'dpapi') {
            logger.warn('DPAPI requested but not available, falling back to file encryption');
            this.provider = 'file';
          }
        }

        // Use file crypto as fallback or if explicitly requested
        if (this.provider === 'file') {
          this.fileCrypto = new FileCryptoProvider(this.storagePath);
          await this.fileCrypto.initialize(passphrase || this.config.encryptionKey);
          logger.info('Using file-based encryption');
        }
      }

      this.initialized = true;
      this.emit('initialized', { provider: this.provider });
    } catch (error) {
      logger.error('Failed to initialize secure storage', { error });
      throw new SecurityError(
        'Failed to initialize secure storage',
        'ENCRYPTION_FAILED',
        { error }
      );
    }
  }

  /**
   * Store a secure variable
   */
  async storeVariable(
    variable: Omit<SecureVariable, 'id' | 'createdAt' | 'updatedAt'>,
    context: SecureContext
  ): Promise<SecureVariable> {
    await this.ensureInitialized();
    await this.validateAccess(context, variable.projectId);

    const id = uuidv4();
    const now = new Date();

    // Encrypt the value
    const encrypted = await this.encrypt(variable.value);
    
    const secureVar: SecureVariable = {
      ...variable,
      id,
      value: JSON.stringify(encrypted), // Store as JSON string
      createdAt: now,
      updatedAt: now,
      createdBy: context.userId
    };

    // Store to disk
    const varPath = this.getVariablePath(variable.projectId, id);
    await fs.writeFile(varPath, JSON.stringify(secureVar, null, 2), 'utf-8');

    // Log access
    await this.logAccess({
      secretId: id,
      projectId: variable.projectId,
      environmentId: variable.environmentId,
      accessedBy: context.userId,
      accessedAt: now,
      purpose: 'create',
      success: true
    });

    this.emit('variableStored', { variable: secureVar, context });
    return secureVar;
  }

  /**
   * Retrieve a secure variable
   */
  async getVariable(
    variableId: string,
    projectId: string,
    context: SecureContext,
    decrypt = false
  ): Promise<SecureVariable | null> {
    await this.ensureInitialized();
    await this.validateAccess(context, projectId);

    try {
      const varPath = this.getVariablePath(projectId, variableId);
      const data = await fs.readFile(varPath, 'utf-8');
      const variable = JSON.parse(data) as SecureVariable;

      if (decrypt) {
        // Check cache first
        const cached = this.getCachedValue(variableId);
        if (cached) {
          variable.value = cached;
        } else {
          // Decrypt the value
          const encrypted = JSON.parse(variable.value) as EncryptedData;
          const decrypted = await this.decrypt(encrypted);
          variable.value = decrypted;
          
          // Cache for 5 minutes
          this.cacheValue(variableId, decrypted, 5 * 60 * 1000);
        }

        // Update last accessed
        variable.lastAccessedAt = new Date();
        await fs.writeFile(varPath, JSON.stringify(variable, null, 2), 'utf-8');
      }

      // Log access
      await this.logAccess({
        secretId: variableId,
        projectId,
        environmentId: context.environmentId,
        accessedBy: context.userId,
        accessedAt: new Date(),
        purpose: decrypt ? 'decrypt' : 'read',
        success: true
      });

      return variable;
    } catch (error) {
      logger.error('Failed to get variable', { error, variableId, projectId });
      return null;
    }
  }

  /**
   * List variables for a project
   */
  async listVariables(
    projectId: string,
    context: SecureContext,
    environmentId?: string
  ): Promise<SecureVariable[]> {
    await this.ensureInitialized();
    await this.validateAccess(context, projectId);

    const projectPath = path.join(this.storagePath, 'projects', projectId, 'variables');
    
    try {
      const files = await fs.readdir(projectPath);
      const variables: SecureVariable[] = [];

      for (const file of files) {
        if (file.endsWith('.json')) {
          const data = await fs.readFile(path.join(projectPath, file), 'utf-8');
          const variable = JSON.parse(data) as SecureVariable;
          
          if (!environmentId || variable.environmentId === environmentId) {
            // Don't decrypt values when listing
            variables.push(variable);
          }
        }
      }

      return variables;
    } catch (error) {
      if ((error as any).code === 'ENOENT') {
        return [];
      }
      throw error;
    }
  }

  /**
   * Store an environment profile
   */
  async storeEnvironmentProfile(
    profile: Omit<EnvironmentProfile, 'id' | 'createdAt' | 'updatedAt'>,
    context: SecureContext
  ): Promise<EnvironmentProfile> {
    await this.ensureInitialized();
    await this.validateAccess(context, profile.projectId);

    const id = uuidv4();
    const now = new Date();

    // Encrypt all sensitive values
    const encryptedProfile: EnvironmentProfile = {
      ...profile,
      id,
      variables: await Promise.all(
        profile.variables.map(async (v) => ({
          ...v,
          value: JSON.stringify(await this.encrypt(v.value))
        }))
      ),
      credentials: await Promise.all(
        profile.credentials.map(async (c) => ({
          ...c,
          data: JSON.stringify(await this.encrypt(c.data))
        }))
      ),
      createdAt: now,
      updatedAt: now
    };

    // Store to disk
    const profilePath = this.getProfilePath(profile.projectId, id);
    await fs.writeFile(profilePath, JSON.stringify(encryptedProfile, null, 2), 'utf-8');

    this.emit('profileStored', { profile: encryptedProfile, context });
    return encryptedProfile;
  }

  /**
   * Get an environment profile
   */
  async getEnvironmentProfile(
    profileId: string,
    projectId: string,
    context: SecureContext,
    decrypt = false
  ): Promise<EnvironmentProfile | null> {
    await this.ensureInitialized();
    await this.validateAccess(context, projectId);

    try {
      const profilePath = this.getProfilePath(projectId, profileId);
      const data = await fs.readFile(profilePath, 'utf-8');
      const profile = JSON.parse(data) as EnvironmentProfile;

      if (decrypt) {
        // Decrypt variables
        profile.variables = await Promise.all(
          profile.variables.map(async (v) => ({
            ...v,
            value: await this.decrypt(JSON.parse(v.value))
          }))
        );

        // Decrypt credentials
        profile.credentials = await Promise.all(
          profile.credentials.map(async (c) => ({
            ...c,
            data: await this.decrypt(JSON.parse(c.data))
          }))
        );
      }

      return profile;
    } catch (error) {
      logger.error('Failed to get environment profile', { error, profileId, projectId });
      return null;
    }
  }

  /**
   * Apply masking to a value
   */
  maskValue(
    value: string,
    config: MaskingConfig = {
      enabled: true,
      maskPattern: '****',
      showFirstChars: 2,
      showLastChars: 2
    }
  ): string {
    if (!config.enabled || !value) return value;

    // Check if value should always be masked
    if (config.alwaysMaskPatterns) {
      for (const pattern of config.alwaysMaskPatterns) {
        if (pattern.test(value)) {
          return config.maskPattern;
        }
      }
    }

    // Check if value should never be masked
    if (config.excludePatterns) {
      for (const pattern of config.excludePatterns) {
        if (pattern.test(value)) {
          return value;
        }
      }
    }

    const length = value.length;
    const showFirst = config.showFirstChars || 0;
    const showLast = config.showLastChars || 0;

    if (length <= showFirst + showLast) {
      return config.maskPattern;
    }

    const firstPart = value.substring(0, showFirst);
    const lastPart = value.substring(length - showLast);
    
    return `${firstPart}${config.maskPattern}${lastPart}`;
  }

  /**
   * Export variables with masking
   */
  async exportVariables(
    projectId: string,
    context: SecureContext,
    policy: ProjectSecurityPolicy
  ): Promise<Record<string, any>> {
    await this.ensureInitialized();
    await this.validateAccess(context, projectId);

    if (!policy.allowExportSecrets) {
      throw new SecurityError(
        'Export of secrets is not allowed by security policy',
        'POLICY_VIOLATION'
      );
    }

    const variables = await this.listVariables(projectId, context);
    const exported: Record<string, any> = {};

    for (const variable of variables) {
      if (variable.maskInExports) {
        exported[variable.name] = this.maskValue(variable.value, policy.masking);
      } else {
        // Still decrypt but may apply masking based on policy
        const decrypted = await this.decrypt(JSON.parse(variable.value));
        exported[variable.name] = policy.masking.enabled 
          ? this.maskValue(decrypted, policy.masking)
          : decrypted;
      }
    }

    // Log export
    await this.logAccess({
      secretId: 'export',
      projectId,
      environmentId: context.environmentId,
      accessedBy: context.userId,
      accessedAt: new Date(),
      purpose: 'export',
      success: true
    });

    return exported;
  }

  /**
   * Get access logs
   */
  async getAccessLogs(
    projectId: string,
    context: SecureContext,
    filter?: {
      startDate?: Date;
      endDate?: Date;
      userId?: string;
      purpose?: string;
    }
  ): Promise<SecretAccess[]> {
    await this.validateAccess(context, projectId);

    let logs = this.accessLog.filter(log => log.projectId === projectId);

    if (filter) {
      if (filter.startDate) {
        logs = logs.filter(log => log.accessedAt >= filter.startDate!);
      }
      if (filter.endDate) {
        logs = logs.filter(log => log.accessedAt <= filter.endDate!);
      }
      if (filter.userId) {
        logs = logs.filter(log => log.accessedBy === filter.userId);
      }
      if (filter.purpose) {
        logs = logs.filter(log => log.purpose === filter.purpose);
      }
    }

    return logs;
  }

  // Private methods

  private async ensureInitialized(): Promise<void> {
    if (!this.initialized) {
      throw new SecurityError('Secure storage not initialized', 'INVALID_CONTEXT');
    }
  }

  private async validateAccess(context: SecureContext, projectId: string): Promise<void> {
    if (context.projectId !== projectId) {
      throw new SecurityError(
        'Access denied: context project does not match',
        'ACCESS_DENIED',
        { contextProject: context.projectId, requestedProject: projectId }
      );
    }

    // Additional validation can be added here (IP whitelist, MFA, etc.)
  }

  private async encrypt(data: string): Promise<EncryptedData> {
    if (this.provider === 'dpapi' && this.dpapi) {
      // Use project ID as entropy for additional security
      return this.dpapi.encryptWithEntropy(data, this.storagePath);
    } else if (this.provider === 'file' && this.fileCrypto) {
      return this.fileCrypto.encrypt(data);
    } else if (this.provider === 'memory') {
      // Simple in-memory encryption (not secure, for testing only)
      const id = uuidv4();
      const encrypted: EncryptedData = {
        iv: '',
        authTag: '',
        data: Buffer.from(data).toString('base64'),
        algorithm: 'memory',
        timestamp: Date.now()
      };
      this.memoryStore.set(id, encrypted);
      encrypted.data = id; // Store ID as data
      return encrypted;
    }

    throw new SecurityError('No encryption provider available', 'ENCRYPTION_FAILED');
  }

  private async decrypt(encrypted: EncryptedData): Promise<string> {
    if (encrypted.algorithm === 'DPAPI_ENTROPY' && this.dpapi) {
      return this.dpapi.decryptWithEntropy(encrypted);
    } else if (encrypted.algorithm === 'DPAPI' && this.dpapi) {
      return this.dpapi.decrypt(encrypted);
    } else if (encrypted.algorithm === 'aes-256-gcm' && this.fileCrypto) {
      return this.fileCrypto.decrypt(encrypted);
    } else if (encrypted.algorithm === 'memory') {
      const stored = this.memoryStore.get(encrypted.data);
      if (stored) {
        return Buffer.from(stored.data, 'base64').toString('utf-8');
      }
    }

    throw new SecurityError(
      `No decryption provider for algorithm: ${encrypted.algorithm}`,
      'DECRYPTION_FAILED'
    );
  }

  private getCachedValue(id: string): string | null {
    const cached = this.decryptedCache.get(id);
    if (cached && cached.expires > Date.now()) {
      return cached.value;
    }
    this.decryptedCache.delete(id);
    return null;
  }

  private cacheValue(id: string, value: string, ttl: number): void {
    this.decryptedCache.set(id, {
      value,
      expires: Date.now() + ttl
    });

    // Clean up expired entries periodically
    if (this.decryptedCache.size > 100) {
      const now = Date.now();
      for (const [key, cached] of this.decryptedCache) {
        if (cached.expires < now) {
          this.decryptedCache.delete(key);
        }
      }
    }
  }

  private async logAccess(access: SecretAccess): Promise<void> {
    this.accessLog.push(access);
    
    // Keep only last 10000 entries in memory
    if (this.accessLog.length > 10000) {
      this.accessLog = this.accessLog.slice(-10000);
    }

    // Also persist to disk for audit trail
    const logPath = path.join(
      this.storagePath,
      'projects',
      access.projectId,
      'access.log'
    );
    
    try {
      await fs.appendFile(
        logPath,
        JSON.stringify(access) + '\n',
        'utf-8'
      );
    } catch (error) {
      logger.error('Failed to write access log', { error });
    }
  }

  private getVariablePath(projectId: string, variableId: string): string {
    return path.join(
      this.storagePath,
      'projects',
      projectId,
      'variables',
      `${variableId}.json`
    );
  }

  private getProfilePath(projectId: string, profileId: string): string {
    return path.join(
      this.storagePath,
      'projects',
      projectId,
      'profiles',
      `${profileId}.json`
    );
  }

  /**
   * Clear all cached decrypted values
   */
  clearCache(): void {
    this.decryptedCache.clear();
  }

  /**
   * Destroy the service and clear sensitive data
   */
  async destroy(): Promise<void> {
    this.clearCache();
    this.memoryStore.clear();
    this.accessLog = [];
    this.initialized = false;
  }
} 