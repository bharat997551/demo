import { z } from 'zod';

/**
 * Application configuration schema
 */
export const ConfigSchema = z.object({
  // Server configuration
  port: z.coerce.number().default(3001),
  host: z.string().default('localhost'),
  nodeEnv: z.enum(['development', 'production', 'test']).default('development'),
  
  // Database configuration
  databaseUrl: z.string().default('file:./dev.db'),
  
  // Logging configuration
  logLevel: z.enum(['debug', 'info', 'warn', 'error']).default('info'),
  
  // Engine endpoints
  engines: z.object({
    web: z.string().url().default('http://localhost:8001'),
    desktop: z.string().url().default('http://localhost:8002'), 
    mainframe: z.string().url().default('http://localhost:8003'),
    api: z.string().url().default('http://localhost:8004'),
  }).default({}),
  
  // Security settings
  corsOrigin: z.string().or(z.array(z.string())).default('http://localhost:5173'),
  
  // Application settings
  maxConcurrentRuns: z.coerce.number().default(5),
  artifactRetentionDays: z.coerce.number().default(30),
  screenshotQuality: z.coerce.number().min(1).max(100).default(80),
});

export type Config = z.infer<typeof ConfigSchema>;

/**
 * Load and validate configuration from environment variables
 */
export function loadConfig(): Config {
  const rawConfig = {
    port: process.env.PORT,
    host: process.env.HOST,
    nodeEnv: process.env.NODE_ENV,
    databaseUrl: process.env.DATABASE_URL,
    logLevel: process.env.LOG_LEVEL,
    engines: {
      web: process.env.ENGINE_WEB_URL,
      desktop: process.env.ENGINE_DESKTOP_URL,
      mainframe: process.env.ENGINE_MAINFRAME_URL,
      api: process.env.ENGINE_API_URL,
    },
    corsOrigin: process.env.CORS_ORIGIN,
    maxConcurrentRuns: process.env.MAX_CONCURRENT_RUNS,
    artifactRetentionDays: process.env.ARTIFACT_RETENTION_DAYS,
    screenshotQuality: process.env.SCREENSHOT_QUALITY,
  };
  
  try {
    return ConfigSchema.parse(rawConfig);
  } catch (error) {
    console.error('Configuration validation failed:', error);
    throw new Error('Invalid configuration');
  }
}

/**
 * Get configuration value by key
 */
export function getConfig<K extends keyof Config>(key: K): Config[K] {
  const config = loadConfig();
  return config[key];
}

/**
 * Check if running in development mode
 */
export function isDevelopment(): boolean {
  return getConfig('nodeEnv') === 'development';
}

/**
 * Check if running in production mode
 */
export function isProduction(): boolean {
  return getConfig('nodeEnv') === 'production';
}

/**
 * Check if running in test mode
 */
export function isTest(): boolean {
  return getConfig('nodeEnv') === 'test';
} 