import { EventEmitter } from 'events';
import { performance } from 'perf_hooks';

export interface MetricLabels {
  [key: string]: string | number;
}

export interface MetricValue {
  value: number;
  labels?: MetricLabels;
  timestamp?: number;
}

export type MetricType = 'counter' | 'gauge' | 'histogram' | 'summary';

export interface Metric {
  name: string;
  type: MetricType;
  help: string;
  values: MetricValue[];
}

export interface HistogramBuckets {
  le: number;
  count: number;
}

export class MetricsCollector extends EventEmitter {
  private metrics: Map<string, Metric> = new Map();
  private timers: Map<string, number> = new Map();
  private histogramBuckets = [0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10];

  constructor() {
    super();
    this.initializeDefaultMetrics();
  }

  private initializeDefaultMetrics(): void {
    // Test execution metrics
    this.registerMetric('test_runs_total', 'counter', 'Total number of test runs');
    this.registerMetric('test_runs_passed', 'counter', 'Number of passed test runs');
    this.registerMetric('test_runs_failed', 'counter', 'Number of failed test runs');
    this.registerMetric('test_duration_seconds', 'histogram', 'Test execution duration in seconds');
    
    // Step execution metrics
    this.registerMetric('step_executions_total', 'counter', 'Total number of step executions');
    this.registerMetric('step_executions_failed', 'counter', 'Number of failed step executions');
    this.registerMetric('step_duration_seconds', 'histogram', 'Step execution duration in seconds');
    
    // Engine metrics
    this.registerMetric('engine_requests_total', 'counter', 'Total requests to automation engines');
    this.registerMetric('engine_request_duration_seconds', 'histogram', 'Engine request duration in seconds');
    this.registerMetric('engine_errors_total', 'counter', 'Total engine errors');
    
    // Resource metrics
    this.registerMetric('active_sessions', 'gauge', 'Number of active test sessions');
    this.registerMetric('memory_usage_bytes', 'gauge', 'Memory usage in bytes');
    this.registerMetric('cpu_usage_percent', 'gauge', 'CPU usage percentage');
    
    // Start collecting system metrics
    this.startSystemMetricsCollection();
  }

  private registerMetric(name: string, type: MetricType, help: string): void {
    this.metrics.set(name, {
      name,
      type,
      help,
      values: []
    });
  }

  // Counter methods
  increment(name: string, labels?: MetricLabels, value: number = 1): void {
    const metric = this.metrics.get(name);
    if (!metric || metric.type !== 'counter') {
      throw new Error(`Metric ${name} is not a counter`);
    }

    const existing = this.findMetricValue(metric, labels);
    if (existing) {
      existing.value += value;
    } else {
      metric.values.push({
        value,
        labels,
        timestamp: Date.now()
      });
    }

    this.emit('metric:updated', { name, labels, value });
  }

  // Gauge methods
  set(name: string, value: number, labels?: MetricLabels): void {
    const metric = this.metrics.get(name);
    if (!metric || metric.type !== 'gauge') {
      throw new Error(`Metric ${name} is not a gauge`);
    }

    const existing = this.findMetricValue(metric, labels);
    if (existing) {
      existing.value = value;
      existing.timestamp = Date.now();
    } else {
      metric.values.push({
        value,
        labels,
        timestamp: Date.now()
      });
    }

    this.emit('metric:updated', { name, labels, value });
  }

  // Histogram methods
  observe(name: string, value: number, labels?: MetricLabels): void {
    const metric = this.metrics.get(name);
    if (!metric || (metric.type !== 'histogram' && metric.type !== 'summary')) {
      throw new Error(`Metric ${name} is not a histogram or summary`);
    }

    metric.values.push({
      value,
      labels,
      timestamp: Date.now()
    });

    this.emit('metric:updated', { name, labels, value });
  }

  // Timer methods
  startTimer(name: string, labels?: MetricLabels): () => void {
    const key = this.getTimerKey(name, labels);
    this.timers.set(key, performance.now());

    return () => {
      const start = this.timers.get(key);
      if (start) {
        const duration = (performance.now() - start) / 1000; // Convert to seconds
        this.observe(name, duration, labels);
        this.timers.delete(key);
      }
    };
  }

  // Test execution metrics
  recordTestRun(testName: string, status: 'passed' | 'failed', duration: number): void {
    this.increment('test_runs_total', { test: testName });
    if (status === 'passed') {
      this.increment('test_runs_passed', { test: testName });
    } else {
      this.increment('test_runs_failed', { test: testName });
    }
    this.observe('test_duration_seconds', duration / 1000, { test: testName });
  }

  recordStepExecution(stepName: string, status: 'passed' | 'failed', duration: number, engine: string): void {
    this.increment('step_executions_total', { step: stepName, engine });
    if (status === 'failed') {
      this.increment('step_executions_failed', { step: stepName, engine });
    }
    this.observe('step_duration_seconds', duration / 1000, { step: stepName, engine });
  }

  recordEngineRequest(engine: string, status: 'success' | 'error', duration: number): void {
    this.increment('engine_requests_total', { engine, status });
    if (status === 'error') {
      this.increment('engine_errors_total', { engine });
    }
    this.observe('engine_request_duration_seconds', duration / 1000, { engine });
  }

  // Get metrics in Prometheus format
  getPrometheusMetrics(): string {
    const lines: string[] = [];

    for (const metric of this.metrics.values()) {
      // Add help text
      lines.push(`# HELP ${metric.name} ${metric.help}`);
      lines.push(`# TYPE ${metric.name} ${metric.type}`);

      if (metric.type === 'histogram') {
        // Calculate histogram buckets
        const bucketCounts = this.calculateHistogramBuckets(metric);
        const sum = metric.values.reduce((acc, v) => acc + v.value, 0);
        const count = metric.values.length;

        for (const bucket of bucketCounts) {
          const labels = this.formatLabels({ ...bucket.labels, le: bucket.le });
          lines.push(`${metric.name}_bucket${labels} ${bucket.count}`);
        }

        const labels = metric.values[0]?.labels ? this.formatLabels(metric.values[0].labels) : '';
        lines.push(`${metric.name}_sum${labels} ${sum}`);
        lines.push(`${metric.name}_count${labels} ${count}`);
      } else {
        // Counter or gauge
        for (const value of metric.values) {
          const labels = value.labels ? this.formatLabels(value.labels) : '';
          lines.push(`${metric.name}${labels} ${value.value}`);
        }
      }

      lines.push(''); // Empty line between metrics
    }

    return lines.join('\n');
  }

  // Get metrics in JSON format
  getJsonMetrics(): object {
    const result: any = {};

    for (const metric of this.metrics.values()) {
      result[metric.name] = {
        type: metric.type,
        help: metric.help,
        values: metric.values
      };

      if (metric.type === 'histogram') {
        result[metric.name].buckets = this.calculateHistogramBuckets(metric);
        result[metric.name].sum = metric.values.reduce((acc, v) => acc + v.value, 0);
        result[metric.name].count = metric.values.length;
      }
    }

    return result;
  }

  // Reset all metrics
  reset(): void {
    for (const metric of this.metrics.values()) {
      metric.values = [];
    }
    this.timers.clear();
  }

  // Private helper methods
  private findMetricValue(metric: Metric, labels?: MetricLabels): MetricValue | undefined {
    return metric.values.find(v => this.labelsMatch(v.labels, labels));
  }

  private labelsMatch(labels1?: MetricLabels, labels2?: MetricLabels): boolean {
    if (!labels1 && !labels2) return true;
    if (!labels1 || !labels2) return false;

    const keys1 = Object.keys(labels1);
    const keys2 = Object.keys(labels2);
    if (keys1.length !== keys2.length) return false;

    return keys1.every(key => labels1[key] === labels2[key]);
  }

  private formatLabels(labels: MetricLabels): string {
    const pairs = Object.entries(labels)
      .map(([key, value]) => `${key}="${value}"`)
      .join(',');
    return pairs ? `{${pairs}}` : '';
  }

  private getTimerKey(name: string, labels?: MetricLabels): string {
    const labelStr = labels ? JSON.stringify(labels) : '';
    return `${name}:${labelStr}`;
  }

  private calculateHistogramBuckets(metric: Metric): HistogramBuckets[] {
    const buckets: HistogramBuckets[] = [];
    const values = metric.values.map(v => v.value).sort((a, b) => a - b);

    for (const bucket of this.histogramBuckets) {
      const count = values.filter(v => v <= bucket).length;
      buckets.push({ le: bucket, count });
    }

    // Add +Inf bucket
    buckets.push({ le: Infinity, count: values.length });

    return buckets;
  }

  private startSystemMetricsCollection(): void {
    // Collect system metrics every 10 seconds
    setInterval(() => {
      const memoryUsage = process.memoryUsage();
      this.set('memory_usage_bytes', memoryUsage.heapUsed, { type: 'heap' });
      this.set('memory_usage_bytes', memoryUsage.rss, { type: 'rss' });
      this.set('memory_usage_bytes', memoryUsage.external, { type: 'external' });

      // CPU usage (simplified - in production use proper CPU monitoring)
      const cpuUsage = process.cpuUsage();
      const totalCpu = cpuUsage.user + cpuUsage.system;
      this.set('cpu_usage_percent', totalCpu / 1000000); // Convert to percentage
    }, 10000);
  }
}

// Global metrics instance
let globalMetrics: MetricsCollector;

export function initializeMetrics(): MetricsCollector {
  if (!globalMetrics) {
    globalMetrics = new MetricsCollector();
  }
  return globalMetrics;
}

export function getMetrics(): MetricsCollector {
  if (!globalMetrics) {
    globalMetrics = new MetricsCollector();
  }
  return globalMetrics;
}

// Express middleware for metrics endpoint
export function metricsEndpoint(format: 'prometheus' | 'json' = 'prometheus') {
  return (req: any, res: any) => {
    const metrics = getMetrics();
    
    if (format === 'prometheus' || req.query.format === 'prometheus') {
      res.set('Content-Type', 'text/plain; version=0.0.4');
      res.send(metrics.getPrometheusMetrics());
    } else {
      res.json(metrics.getJsonMetrics());
    }
  };
} 