import pino from 'pino';
import { IncomingMessage } from 'http';
import { v4 as uuidv4 } from 'uuid';

export type LogLevel = 'trace' | 'debug' | 'info' | 'warn' | 'error' | 'fatal';

export interface LoggerConfig {
  level: LogLevel;
  pretty?: boolean;
  redact?: string[];
  name?: string;
  correlationId?: string;
}

export interface LogContext {
  correlationId?: string;
  sessionId?: string;
  userId?: string;
  testRunId?: string;
  engine?: string;
  [key: string]: any;
}

// Default redaction paths for sensitive data
const DEFAULT_REDACT_PATHS = [
  'password',
  'token',
  'apiKey',
  'secret',
  'authorization',
  'cookie',
  'ssn',
  'creditCard',
  '*.password',
  '*.token',
  '*.apiKey',
  'headers.authorization',
  'headers.cookie',
  'body.password',
  'body.token'
];

// Create base logger configuration
export function createLogger(config: LoggerConfig): pino.Logger {
  const { level, pretty, redact, name, correlationId } = config;

  const options: pino.LoggerOptions = {
    level: level || 'info',
    name: name || 'hybrid-qa',
    messageKey: 'message',
    errorKey: 'error',
    timestamp: () => `,"timestamp":"${new Date().toISOString()}"`,
    base: {
      pid: process.pid,
      hostname: process.env.HOSTNAME || require('os').hostname(),
      correlationId: correlationId || uuidv4()
    },
    redact: {
      paths: [...DEFAULT_REDACT_PATHS, ...(redact || [])],
      censor: '[REDACTED]'
    },
    serializers: {
      req: pino.stdSerializers.req,
      res: pino.stdSerializers.res,
      err: pino.stdSerializers.err,
      error: pino.stdSerializers.err
    },
    formatters: {
      level: (label: string) => {
        return { level: label.toUpperCase() };
      }
    }
  };

  // Add pretty printing for development
  if (pretty && process.env.NODE_ENV !== 'production') {
    return pino({
      ...options,
      transport: {
        target: 'pino-pretty',
        options: {
          colorize: true,
          translateTime: 'SYS:standard',
          ignore: 'pid,hostname',
          singleLine: false
        }
      }
    });
  }

  return pino(options);
}

// Logger factory with context
export class ContextLogger {
  private logger: pino.Logger;
  private context: LogContext;

  constructor(config: LoggerConfig, context?: LogContext) {
    this.logger = createLogger(config);
    this.context = context || {};
  }

  private formatMessage(message: string, extra?: object): object {
    return {
      ...this.context,
      ...extra,
      message
    };
  }

  trace(message: string, extra?: object): void {
    this.logger.trace(this.formatMessage(message, extra));
  }

  debug(message: string, extra?: object): void {
    this.logger.debug(this.formatMessage(message, extra));
  }

  info(message: string, extra?: object): void {
    this.logger.info(this.formatMessage(message, extra));
  }

  warn(message: string, extra?: object): void {
    this.logger.warn(this.formatMessage(message, extra));
  }

  error(message: string, error?: Error | object, extra?: object): void {
    const logData = this.formatMessage(message, extra);
    if (error instanceof Error) {
      this.logger.error({ ...logData, error, stack: error.stack });
    } else if (error) {
      this.logger.error({ ...logData, ...error });
    } else {
      this.logger.error(logData);
    }
  }

  fatal(message: string, error?: Error | object, extra?: object): void {
    const logData = this.formatMessage(message, extra);
    if (error instanceof Error) {
      this.logger.fatal({ ...logData, error, stack: error.stack });
    } else if (error) {
      this.logger.fatal({ ...logData, ...error });
    } else {
      this.logger.fatal(logData);
    }
  }

  child(context: LogContext): ContextLogger {
    return new ContextLogger(
      { level: this.logger.level as LogLevel },
      { ...this.context, ...context }
    );
  }

  // HTTP request logging
  logRequest(req: IncomingMessage, extra?: object): void {
    this.info('HTTP Request', {
      method: req.method,
      url: req.url,
      headers: req.headers,
      ...extra
    });
  }

  // Performance logging
  logPerformance(operation: string, duration: number, extra?: object): void {
    this.info('Performance metric', {
      operation,
      duration,
      durationUnit: 'ms',
      ...extra
    });
  }

  // Test execution logging
  logTestStart(testName: string, extra?: object): void {
    this.info('Test started', {
      testName,
      event: 'test_start',
      ...extra
    });
  }

  logTestEnd(testName: string, status: 'passed' | 'failed' | 'skipped', duration: number, extra?: object): void {
    const level = status === 'failed' ? 'error' : 'info';
    this[level]('Test completed', {
      testName,
      event: 'test_end',
      status,
      duration,
      durationUnit: 'ms',
      ...extra
    });
  }

  // Step execution logging
  logStepStart(stepName: string, stepIndex: number, extra?: object): void {
    this.debug('Step started', {
      stepName,
      stepIndex,
      event: 'step_start',
      ...extra
    });
  }

  logStepEnd(stepName: string, stepIndex: number, status: 'passed' | 'failed', duration: number, extra?: object): void {
    const level = status === 'failed' ? 'warn' : 'debug';
    this[level]('Step completed', {
      stepName,
      stepIndex,
      event: 'step_end',
      status,
      duration,
      durationUnit: 'ms',
      ...extra
    });
  }
}

// Global logger instance
let globalLogger: ContextLogger;

export function initializeLogger(config: LoggerConfig, context?: LogContext): ContextLogger {
  globalLogger = new ContextLogger(config, context);
  return globalLogger;
}

export function getLogger(): ContextLogger {
  if (!globalLogger) {
    globalLogger = new ContextLogger({ level: 'info' });
  }
  return globalLogger;
}

// Express middleware for request logging
export function requestLoggingMiddleware() {
  return (req: any, res: any, next: any) => {
    const start = Date.now();
    const logger = getLogger().child({
      requestId: uuidv4(),
      method: req.method,
      path: req.path
    });

    // Log request
    logger.logRequest(req);

    // Log response
    const originalSend = res.send;
    res.send = function (data: any) {
      const duration = Date.now() - start;
      logger.info('HTTP Response', {
        statusCode: res.statusCode,
        duration,
        durationUnit: 'ms'
      });
      originalSend.call(this, data);
    };

    // Attach logger to request for use in routes
    req.logger = logger;
    next();
  };
} 