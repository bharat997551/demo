import { EventEmitter } from 'events';
import { createHash } from 'crypto';
import { v4 as uuidv4 } from 'uuid';
import { getLogger } from './logger';
import os from 'os';

export interface TelemetryConfig {
  enabled: boolean;
  endpoint?: string;
  apiKey?: string;
  batchSize?: number;
  flushInterval?: number;
  anonymizeIp?: boolean;
  excludeFields?: string[];
}

export interface TelemetryEvent {
  eventId: string;
  eventType: string;
  timestamp: string;
  properties: Record<string, any>;
  context: TelemetryContext;
}

export interface TelemetryContext {
  sessionId: string;
  userId: string; // Anonymized
  appVersion: string;
  platform: string;
  osVersion: string;
  nodeVersion: string;
  environment: string;
}

export interface ConsentSettings {
  telemetryEnabled: boolean;
  errorReporting: boolean;
  performanceMetrics: boolean;
  usageAnalytics: boolean;
  consentedAt?: string;
  consentVersion: string;
}

export class TelemetryService extends EventEmitter {
  private config: TelemetryConfig;
  private consent: ConsentSettings;
  private queue: TelemetryEvent[] = [];
  private sessionId: string;
  private userId: string;
  private flushTimer?: NodeJS.Timeout;
  private logger = getLogger().child({ module: 'telemetry' });

  constructor(config: TelemetryConfig) {
    super();
    this.config = config;
    this.sessionId = uuidv4();
    this.userId = this.generateAnonymousUserId();
    this.consent = this.loadConsent();

    if (this.consent.telemetryEnabled && config.enabled) {
      this.startBatching();
    }
  }

  // Consent management
  updateConsent(settings: Partial<ConsentSettings>): void {
    this.consent = {
      ...this.consent,
      ...settings,
      consentedAt: new Date().toISOString(),
      consentVersion: '1.0'
    };
    
    this.saveConsent();
    this.emit('consent:updated', this.consent);
    
    if (this.consent.telemetryEnabled && this.config.enabled) {
      this.startBatching();
    } else {
      this.stopBatching();
      this.clearQueue();
    }
  }

  getConsent(): ConsentSettings {
    return { ...this.consent };
  }

  isEnabled(): boolean {
    return this.config.enabled && this.consent.telemetryEnabled;
  }

  // Event tracking
  trackEvent(eventType: string, properties: Record<string, any>): void {
    if (!this.isEnabled()) return;

    const event: TelemetryEvent = {
      eventId: uuidv4(),
      eventType,
      timestamp: new Date().toISOString(),
      properties: this.anonymizeProperties(properties),
      context: this.getContext()
    };

    this.queue.push(event);
    this.logger.debug('Telemetry event queued', { eventType, queueSize: this.queue.length });

    if (this.queue.length >= (this.config.batchSize || 100)) {
      this.flush();
    }
  }

  // Error tracking
  trackError(error: Error, properties?: Record<string, any>): void {
    if (!this.isEnabled() || !this.consent.errorReporting) return;

    const errorEvent = {
      message: error.message,
      stack: this.anonymizeStackTrace(error.stack || ''),
      type: error.name,
      ...this.anonymizeProperties(properties || {})
    };

    this.trackEvent('error', errorEvent);
  }

  // Performance tracking
  trackPerformance(operation: string, duration: number, properties?: Record<string, any>): void {
    if (!this.isEnabled() || !this.consent.performanceMetrics) return;

    this.trackEvent('performance', {
      operation,
      duration,
      durationUnit: 'ms',
      ...this.anonymizeProperties(properties || {})
    });
  }

  // Usage analytics
  trackUsage(feature: string, properties?: Record<string, any>): void {
    if (!this.isEnabled() || !this.consent.usageAnalytics) return;

    this.trackEvent('usage', {
      feature,
      ...this.anonymizeProperties(properties || {})
    });
  }

  // Test execution tracking
  trackTestExecution(testName: string, status: 'passed' | 'failed', duration: number, engine: string): void {
    if (!this.isEnabled()) return;

    this.trackEvent('test_execution', {
      testName: this.hashValue(testName), // Anonymize test names
      status,
      duration,
      engine
    });
  }

  // Flush events to endpoint
  async flush(): Promise<void> {
    if (this.queue.length === 0) return;

    const events = [...this.queue];
    this.queue = [];

    try {
      await this.sendEvents(events);
      this.logger.debug('Telemetry events sent', { count: events.length });
    } catch (error) {
      this.logger.error('Failed to send telemetry', error);
      // Re-queue events if sending failed
      this.queue.unshift(...events);
    }
  }

  // Shutdown telemetry
  async shutdown(): Promise<void> {
    this.stopBatching();
    await this.flush();
  }

  // Private methods
  private loadConsent(): ConsentSettings {
    // Load from persistent storage (implement based on platform)
    // For now, return default (all disabled)
    return {
      telemetryEnabled: false,
      errorReporting: false,
      performanceMetrics: false,
      usageAnalytics: false,
      consentVersion: '1.0'
    };
  }

  private saveConsent(): void {
    // Save to persistent storage (implement based on platform)
    // Could use electron-store for Electron app
    this.logger.info('Consent settings saved', { consent: this.consent });
  }

  private generateAnonymousUserId(): string {
    // Generate anonymous user ID based on machine characteristics
    const machineId = [
      os.platform(),
      os.arch(),
      os.hostname(),
      os.totalmem()
    ].join('-');
    
    return this.hashValue(machineId);
  }

  private getContext(): TelemetryContext {
    return {
      sessionId: this.sessionId,
      userId: this.userId,
      appVersion: process.env.APP_VERSION || 'unknown',
      platform: os.platform(),
      osVersion: os.release(),
      nodeVersion: process.version,
      environment: process.env.NODE_ENV || 'production'
    };
  }

  private anonymizeProperties(properties: Record<string, any>): Record<string, any> {
    const anonymized: Record<string, any> = {};
    const sensitiveFields = [
      'password', 'token', 'key', 'secret', 'email', 
      'username', 'ip', 'host', 'url', 'path',
      ...(this.config.excludeFields || [])
    ];

    for (const [key, value] of Object.entries(properties)) {
      const lowerKey = key.toLowerCase();
      const isSensitive = sensitiveFields.some(field => lowerKey.includes(field));

      if (isSensitive) {
        anonymized[key] = this.hashValue(String(value));
      } else if (typeof value === 'object' && value !== null) {
        anonymized[key] = this.anonymizeProperties(value);
      } else {
        anonymized[key] = value;
      }
    }

    return anonymized;
  }

  private anonymizeStackTrace(stack: string): string {
    // Remove file paths and potentially sensitive information
    return stack
      .split('\n')
      .map(line => {
        // Remove absolute paths
        line = line.replace(/[A-Z]:\\[^:]+/gi, '<path>');
        line = line.replace(/\/[^:]+/g, '<path>');
        // Remove potential usernames in paths
        line = line.replace(/Users\/[^\/]+/g, 'Users/<user>');
        line = line.replace(/home\/[^\/]+/g, 'home/<user>');
        return line;
      })
      .join('\n');
  }

  private hashValue(value: string): string {
    return createHash('sha256').update(value).digest('hex').substring(0, 16);
  }

  private startBatching(): void {
    if (this.flushTimer) return;

    const interval = this.config.flushInterval || 60000; // Default 1 minute
    this.flushTimer = setInterval(() => {
      this.flush();
    }, interval);
  }

  private stopBatching(): void {
    if (this.flushTimer) {
      clearInterval(this.flushTimer);
      this.flushTimer = undefined;
    }
  }

  private clearQueue(): void {
    this.queue = [];
  }

  private async sendEvents(events: TelemetryEvent[]): Promise<void> {
    if (!this.config.endpoint) {
      this.logger.warn('No telemetry endpoint configured');
      return;
    }

    const payload = {
      events,
      apiKey: this.config.apiKey
    };

    // In production, implement actual HTTP request
    // For now, just log
    this.logger.debug('Would send telemetry to endpoint', {
      endpoint: this.config.endpoint,
      eventCount: events.length
    });

    // Example implementation:
    // const response = await fetch(this.config.endpoint, {
    //   method: 'POST',
    //   headers: {
    //     'Content-Type': 'application/json',
    //     'X-API-Key': this.config.apiKey || ''
    //   },
    //   body: JSON.stringify(payload)
    // });
    // 
    // if (!response.ok) {
    //   throw new Error(`Telemetry request failed: ${response.statusText}`);
    // }
  }
}

// Global telemetry instance
let globalTelemetry: TelemetryService;

export function initializeTelemetry(config: TelemetryConfig): TelemetryService {
  if (!globalTelemetry) {
    globalTelemetry = new TelemetryService(config);
  }
  return globalTelemetry;
}

export function getTelemetry(): TelemetryService {
  if (!globalTelemetry) {
    globalTelemetry = new TelemetryService({ enabled: false });
  }
  return globalTelemetry;
}

// Consent dialog helper for UI
export interface ConsentDialogOptions {
  title: string;
  message: string;
  options: {
    telemetry: boolean;
    errorReporting: boolean;
    performanceMetrics: boolean;
    usageAnalytics: boolean;
  };
}

export function getConsentDialogOptions(): ConsentDialogOptions {
  return {
    title: 'Help Improve Hybrid QA',
    message: `
      We'd like to collect anonymous usage data to improve Hybrid QA.
      This data helps us understand how the application is used and identify issues.
      
      All data is anonymized and no personal information is collected.
      You can change these settings at any time in Preferences.
    `,
    options: {
      telemetry: true,
      errorReporting: true,
      performanceMetrics: true,
      usageAnalytics: true
    }
  };
} 