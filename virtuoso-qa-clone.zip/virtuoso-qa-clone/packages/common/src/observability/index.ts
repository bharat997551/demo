// Export logging functionality
export {
  LogLevel,
  LoggerConfig,
  LogContext,
  createLogger,
  ContextLogger,
  initializeLogger,
  getLogger,
  requestLoggingMiddleware
} from './logger';

// Export metrics functionality
export {
  MetricLabels,
  MetricValue,
  MetricType,
  Metric,
  MetricsCollector,
  initializeMetrics,
  getMetrics,
  metricsEndpoint
} from './metrics';

// Export telemetry functionality
export {
  TelemetryConfig,
  TelemetryEvent,
  TelemetryContext,
  ConsentSettings,
  TelemetryService,
  initializeTelemetry,
  getTelemetry,
  ConsentDialogOptions,
  getConsentDialogOptions
} from './telemetry';

// Combined initialization
export interface ObservabilityConfig {
  logging: {
    level: LogLevel;
    pretty?: boolean;
    redact?: string[];
  };
  metrics: {
    enabled: boolean;
    endpoint?: string;
  };
  telemetry: {
    enabled: boolean;
    endpoint?: string;
    apiKey?: string;
    consent?: ConsentSettings;
  };
}

export function initializeObservability(config: ObservabilityConfig) {
  // Initialize logging
  const logger = initializeLogger({
    level: config.logging.level,
    pretty: config.logging.pretty,
    redact: config.logging.redact
  });

  // Initialize metrics
  const metrics = initializeMetrics();

  // Initialize telemetry
  const telemetry = initializeTelemetry({
    enabled: config.telemetry.enabled,
    endpoint: config.telemetry.endpoint,
    apiKey: config.telemetry.apiKey
  });

  // Set consent if provided
  if (config.telemetry.consent) {
    telemetry.updateConsent(config.telemetry.consent);
  }

  logger.info('Observability initialized', {
    logging: { level: config.logging.level },
    metrics: { enabled: config.metrics.enabled },
    telemetry: { enabled: config.telemetry.enabled }
  });

  return { logger, metrics, telemetry };
} 