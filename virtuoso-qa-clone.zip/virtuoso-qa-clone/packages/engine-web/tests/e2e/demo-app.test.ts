import { test, expect, Page } from '@playwright/test';
import { PlaywrightEngine } from '../../src/engine/playwright-engine';
import { WebRecorder } from '../../src/recorder/web-recorder';
import { CodeGenerator } from '../../src/codegen/code-generator';
import { WebEngineServer } from '../../src/server/web-engine-server';
import path from 'path';
import fs from 'fs/promises';

const DEMO_APP_URL = 'http://localhost:3001';
const WEB_ENGINE_PORT = 3002;
const WS_PORT = 3003;

let webEngineServer: WebEngineServer;

test.describe('Web Engine E2E Tests', () => {
  test.beforeAll(async () => {
    // Start the web engine server
    webEngineServer = new WebEngineServer({
      port: WEB_ENGINE_PORT,
      wsPort: WS_PORT,
      corsOrigin: '*',
      webEngineConfig: {
        headless: false, // Set to true for CI
        browser: 'chromium',
      },
    });
    
    await webEngineServer.start();
    
    // Start demo app server (simple static file server)
    await startDemoApp();
  });

  test.afterAll(async () => {
    if (webEngineServer) {
      await webEngineServer.stop();
    }
  });

  test('should execute full e-commerce workflow', async ({ page }) => {
    const engine = new PlaywrightEngine({
      headless: false,
      browser: 'chromium',
    });

    await engine.initialize();

    try {
      // Navigate to demo app
      await page.goto(DEMO_APP_URL);
      
      // Verify initial state
      await expect(page.getByTestId('logo')).toBeVisible();
      await expect(page.getByTestId('login-btn')).toBeVisible();
      await expect(page.getByTestId('cart-count')).toHaveText('0');

      // Test login flow
      await page.getByTestId('login-btn').click();
      await expect(page.getByTestId('login-form')).toBeVisible();

      // Fill demo credentials
      await page.getByTestId('demo-fill').click();
      await expect(page.getByTestId('username-input')).toHaveValue('demo');
      await expect(page.getByTestId('password-input')).toHaveValue('demo');

      // Submit login
      await page.getByTestId('login-submit').click();
      
      // Verify successful login
      await expect(page.getByTestId('user-name')).toBeVisible();
      await expect(page.getByTestId('logout-btn')).toBeVisible();
      await expect(page.getByTestId('login-btn')).not.toBeVisible();

      // Test product filtering
      await page.getByTestId('category-filter').selectOption('electronics');
      await expect(page.getByTestId('product-1')).toBeVisible(); // Laptop Pro
      await expect(page.getByTestId('product-4')).not.toBeVisible(); // T-Shirt should be hidden

      // Reset filter
      await page.getByTestId('category-filter').selectOption('');
      await expect(page.getByTestId('product-4')).toBeVisible();

      // Add products to cart
      await page.getByTestId('increase-qty-1').click(); // Increase Laptop Pro quantity
      await page.getByTestId('increase-qty-1').click(); 
      await page.getByTestId('add-to-cart-1').click();
      
      // Verify cart count updated
      await expect(page.getByTestId('cart-count')).toHaveText('2');

      // Add another product
      await page.getByTestId('add-to-cart-2').click(); // Wireless Headphones (qty 1)
      await expect(page.getByTestId('cart-count')).toHaveText('3');

      // Open cart dropdown
      await page.getByTestId('cart-btn').click();
      await expect(page.getByTestId('cart-dropdown')).toBeVisible();

      // Go to cart page
      await page.getByTestId('view-cart-btn').click();
      await expect(page.getByTestId('cart-items')).toBeVisible();
      await expect(page.getByTestId('cart-item-1')).toBeVisible();
      await expect(page.getByTestId('cart-item-2')).toBeVisible();

      // Test cart item quantity changes
      await page.getByTestId('increase-cart-qty-1').click();
      await expect(page.getByTestId('cart-count')).toHaveText('4');

      // Proceed to checkout
      await page.getByTestId('checkout-btn').click();
      
      // Verify checkout form pre-filled with user info
      await expect(page.getByTestId('shipping-name')).toHaveValue('Demo User');
      await expect(page.getByTestId('shipping-email')).toHaveValue('demo@example.com');

      // Fill remaining checkout info
      await page.getByTestId('shipping-address').fill('123 Demo Street\nDemo City, DC 12345');
      await page.getByTestId('shipping-method').selectOption('express');
      await page.getByTestId('card-number').fill('4111 1111 1111 1111');
      await page.getByTestId('card-expiry').fill('12/25');
      await page.getByTestId('card-cvv').fill('123');

      // Verify order total is calculated correctly
      const orderTotal = await page.getByTestId('order-total').textContent();
      expect(parseFloat(orderTotal || '0')).toBeGreaterThan(0);

      // Place order
      await page.getByTestId('place-order-btn').click();

      // Verify order confirmation
      await expect(page.getByTestId('order-id')).toBeVisible();
      await expect(page.getByTestId('confirmation-total')).toBeVisible();
      
      // Verify cart is cleared
      await page.getByTestId('continue-shopping-btn').click();
      await expect(page.getByTestId('cart-count')).toHaveText('0');

      // Test logout
      await page.getByTestId('logout-btn').click();
      await expect(page.getByTestId('login-btn')).toBeVisible();
      await expect(page.getByTestId('user-name')).not.toBeVisible();

    } finally {
      await engine.cleanup();
    }
  });

  test('should record and replay user interactions', async ({ page }) => {
    const recorder = new WebRecorder({
      headless: false,
      browser: 'chromium',
    });

    await recorder.initialize();

    try {
      // Start recording session
      const sessionId = await recorder.startRecording({
        baseUrl: DEMO_APP_URL,
        recordNetwork: false,
        recordConsole: false,
        excludeActions: [],
        ignoreSelectors: ['.notification'],
      });

      // Get the recording session page
      const session = recorder.getSessionStatus(sessionId);
      expect(session).toBeTruthy();

      // Perform some interactions on the demo page
      const recordingPage = session!.page;
      
      // Navigate and perform login
      await recordingPage.getByTestId('login-btn').click();
      await recordingPage.getByTestId('username-input').fill('demo');
      await recordingPage.getByTestId('password-input').fill('demo');
      await recordingPage.getByTestId('login-submit').click();

      // Add product to cart
      await recordingPage.getByTestId('add-to-cart-1').click();

      // Wait for interactions to be recorded
      await recordingPage.waitForTimeout(1000);

      // Stop recording
      const interactions = await recorder.stopRecording(sessionId);
      
      expect(interactions.length).toBeGreaterThan(0);
      
      // Verify recorded interactions contain expected steps
      const stepKinds = interactions.map(i => i.dslStep.kind);
      expect(stepKinds).toContain('web.click');
      expect(stepKinds).toContain('web.type');

      // Generate code from recorded interactions
      const codeGenerator = new CodeGenerator();
      const generatedCode = await codeGenerator.generateFromInteractions(interactions, {
        language: 'typescript',
        includeComments: true,
      });

      expect(generatedCode.code).toContain('page.getByTestId');
      expect(generatedCode.code).toContain('.click()');
      expect(generatedCode.code).toContain('.fill(');

      // Save generated test file
      const testFile = await codeGenerator.generateTestFile(interactions, {
        testName: 'recordedLoginTest',
      });

      const outputPath = path.join(__dirname, '../../artifacts/generated-test.ts');
      await fs.mkdir(path.dirname(outputPath), { recursive: true });
      await fs.writeFile(outputPath, testFile);

      expect(await fs.stat(outputPath)).toBeTruthy();

    } finally {
      await recorder.cleanup();
    }
  });

  test('should handle step execution with PlaywrightEngine', async ({ page }) => {
    const engine = new PlaywrightEngine({
      headless: false,
      browser: 'chromium',
      screenshots: {
        onFailure: true,
        onSuccess: false,
        onStep: true,
        quality: 90,
      },
    });

    await engine.initialize();

    const artifactDir = path.join(__dirname, '../../artifacts/step-execution');
    await fs.mkdir(artifactDir, { recursive: true });

    try {
      // Test navigation step
      const navigateStep = {
        id: 'step-1',
        name: 'Navigate to demo app',
        kind: 'web.navigate',
        engine: 'web',
        options: { url: DEMO_APP_URL },
        retryCount: 0,
        retryDelay: 1000,
      };

      const navigateResult = await engine.runStep(navigateStep, {
        runId: 'test-run',
        testCaseId: 'test-case',
        stepId: 'step-1',
        variables: {},
        environment: {},
        artifactDir,
        timeout: 30000,
        screenshots: { onFailure: true, onSuccess: false, onStep: true },
        previousResults: [],
        healing: { enabled: false, maxRetries: 0, learnFromSuccess: false },
      });

      expect(navigateResult.status).toBe('completed');
      expect(navigateResult.duration).toBeGreaterThan(0);

      // Test click step
      const clickStep = {
        id: 'step-2',
        name: 'Click login button',
        kind: 'web.click',
        engine: 'web',
        locator: {
          primary: { strategy: 'testid', value: 'login-btn' },
          fallbacks: [
            { strategy: 'css', value: '[data-testid="login-btn"]' },
            { strategy: 'text', value: 'Login' }
          ],
        },
        retryCount: 2,
        retryDelay: 1000,
      };

      const clickResult = await engine.runStep(clickStep, {
        runId: 'test-run',
        testCaseId: 'test-case',
        stepId: 'step-2',
        variables: {},
        environment: {},
        artifactDir,
        timeout: 30000,
        screenshots: { onFailure: true, onSuccess: false, onStep: true },
        previousResults: [navigateResult],
        healing: { enabled: false, maxRetries: 0, learnFromSuccess: false },
      });

      expect(clickResult.status).toBe('completed');

      // Test type step with variable substitution
      const typeStep = {
        id: 'step-3',
        name: 'Enter username',
        kind: 'web.type',
        engine: 'web',
        locator: {
          primary: { strategy: 'testid', value: 'username-input' },
        },
        options: { text: '${username}' },
        retryCount: 0,
        retryDelay: 1000,
      };

      const typeResult = await engine.runStep(typeStep, {
        runId: 'test-run',
        testCaseId: 'test-case',
        stepId: 'step-3',
        variables: { username: 'demo' },
        environment: {},
        artifactDir,
        timeout: 30000,
        screenshots: { onFailure: true, onSuccess: false, onStep: true },
        previousResults: [navigateResult, clickResult],
        healing: { enabled: false, maxRetries: 0, learnFromSuccess: false },
      });

      expect(typeResult.status).toBe('completed');

      // Test element existence check
      const existsStep = {
        id: 'step-4',
        name: 'Check login form exists',
        kind: 'web.exists',
        engine: 'web',
        locator: {
          primary: { strategy: 'testid', value: 'login-form' },
        },
        retryCount: 0,
        retryDelay: 1000,
      };

      const existsResult = await engine.runStep(existsStep, {
        runId: 'test-run',
        testCaseId: 'test-case',
        stepId: 'step-4',
        variables: {},
        environment: {},
        artifactDir,
        timeout: 30000,
        screenshots: { onFailure: true, onSuccess: false, onStep: true },
        previousResults: [navigateResult, clickResult, typeResult],
        healing: { enabled: false, maxRetries: 0, learnFromSuccess: false },
      });

      expect(existsResult.status).toBe('completed');
      expect(existsResult.extractedData).toBe(true);

      // Verify artifacts were created
      const artifactFiles = await fs.readdir(artifactDir);
      const screenshots = artifactFiles.filter(f => f.endsWith('.png'));
      expect(screenshots.length).toBeGreaterThan(0);

    } finally {
      await engine.cleanup();
    }
  });

  test('should generate Page Object Model code', async () => {
    const codeGenerator = new CodeGenerator();

    // Create sample recorded interactions
    const interactions = [
      {
        timestamp: Date.now(),
        type: 'click' as const,
        selector: { css: '[data-testid="login-btn"]', testId: 'login-btn' },
        url: DEMO_APP_URL,
        dslStep: {
          id: 'step-1',
          name: 'Click login button',
          kind: 'web.click',
          engine: 'web',
          locator: {
            primary: { strategy: 'testid', value: 'login-btn' },
          },
          retryCount: 0,
          retryDelay: 1000,
        },
      },
      {
        timestamp: Date.now() + 1000,
        type: 'type' as const,
        selector: { css: '[data-testid="username-input"]', testId: 'username-input' },
        value: 'demo',
        url: DEMO_APP_URL,
        dslStep: {
          id: 'step-2',
          name: 'Type username',
          kind: 'web.type',
          engine: 'web',
          locator: {
            primary: { strategy: 'testid', value: 'username-input' },
          },
          options: { text: 'demo' },
          retryCount: 0,
          retryDelay: 1000,
        },
      },
    ];

    const pageObjectCode = await codeGenerator.generatePageObjectModel(interactions, {
      className: 'LoginPage',
      language: 'typescript',
    });

    expect(pageObjectCode.code).toContain('export class LoginPage');
    expect(pageObjectCode.code).toContain('performClick');
    expect(pageObjectCode.code).toContain('performType');
    expect(pageObjectCode.code).toContain('page.getByTestId');

    // Save generated page object
    const outputPath = path.join(__dirname, '../../artifacts/LoginPage.ts');
    await fs.mkdir(path.dirname(outputPath), { recursive: true });
    await fs.writeFile(outputPath, pageObjectCode.code);
  });

  test('should validate step configurations', async () => {
    const engine = new PlaywrightEngine();

    // Test valid steps
    const validNavigateStep = {
      id: 'step-1',
      name: 'Navigate',
      kind: 'web.navigate',
      engine: 'web',
      options: { url: 'https://example.com' },
      retryCount: 0,
      retryDelay: 1000,
    };

    const navigateValidation = engine.validateStep(validNavigateStep);
    expect(navigateValidation.valid).toBe(true);
    expect(navigateValidation.errors).toBeUndefined();

    const validClickStep = {
      id: 'step-2',
      name: 'Click button',
      kind: 'web.click',
      engine: 'web',
      locator: {
        primary: { strategy: 'css', value: '#button' },
      },
      retryCount: 0,
      retryDelay: 1000,
    };

    const clickValidation = engine.validateStep(validClickStep);
    expect(clickValidation.valid).toBe(true);

    // Test invalid steps
    const invalidNavigateStep = {
      id: 'step-3',
      name: 'Invalid navigate',
      kind: 'web.navigate',
      engine: 'web',
      // Missing options.url
      retryCount: 0,
      retryDelay: 1000,
    };

    const invalidNavValidation = engine.validateStep(invalidNavigateStep);
    expect(invalidNavValidation.valid).toBe(false);
    expect(invalidNavValidation.errors).toContain('web.navigate requires options.url');

    const invalidClickStep = {
      id: 'step-4',
      name: 'Invalid click',
      kind: 'web.click',
      engine: 'web',
      // Missing locator
      retryCount: 0,
      retryDelay: 1000,
    };

    const invalidClickValidation = engine.validateStep(invalidClickStep);
    expect(invalidClickValidation.valid).toBe(false);
    expect(invalidClickValidation.errors).toContain('web.click requires a locator');
  });
});

// Helper function to start demo app
async function startDemoApp(): Promise<void> {
  const express = require('express');
  const path = require('path');
  
  const app = express();
  const demoPath = path.join(__dirname, '../../demo/public');
  
  app.use(express.static(demoPath));
  
  return new Promise((resolve) => {
    app.listen(3001, () => {
      console.log('Demo app started on http://localhost:3001');
      resolve();
    });
  });
} 