# Hybrid QA Web Engine (Playwright)

A comprehensive Playwright-based web automation engine with integrated recording capabilities, resilient locator resolution, and code generation utilities.

## 🚀 Features

### ✅ Playwright Engine
- **Universal Step Support**: Implements all `web.*` DSL steps with Playwright API mapping
- **Resilient Locator Resolution**: Auto-fallback strategy using role, text, testId, CSS, and XPath
- **Auto-Wait**: Built-in element waiting with configurable timeouts
- **Variable Interpolation**: Dynamic variable substitution in step parameters
- **Comprehensive Step Library**: Navigate, click, type, select, check, hover, scroll, and more

### ✅ Integrated Recorder
- **Real-time Recording**: Capture user interactions and convert to DSL steps
- **WebSocket Streaming**: Live broadcast of recorded steps to orchestrator
- **Smart Selector Generation**: Automatic generation of multiple locator strategies
- **Session Management**: Multiple concurrent recording sessions
- **Event Filtering**: Configurable ignore patterns for unwanted elements

### ✅ Artifact Management
- **Screenshot Capture**: Configurable screenshots on failure/success/step
- **Video Recording**: Full session video recording with Playwright
- **Organized Storage**: Structured artifact storage by run and step ID
- **Multiple Formats**: Support for PNG screenshots and MP4 videos

### ✅ Code Generation
- **TypeScript/JavaScript**: Generate clean Playwright test code
- **Page Object Model**: Auto-generate POM classes from recorded interactions
- **Multiple Strategies**: Support for different coding patterns and styles
- **Configurable Output**: Customizable indentation, comments, and structure

### ✅ REST API & WebSocket
- **Complete REST API**: Engine control, recording management, code generation
- **Real-time WebSocket**: Live streaming of recorded interactions
- **Health Monitoring**: Engine status and capability reporting
- **CORS Support**: Cross-origin requests for web-based clients

## 📦 Installation

```bash
# Install dependencies
pnpm install

# Install Playwright browsers
pnpm run install:browsers
```

## 🏗️ Architecture

```mermaid
graph TB
    subgraph "Web Engine Core"
        PlaywrightEngine[PlaywrightEngine]
        LocatorResolver[LocatorResolver]
        WebRecorder[WebRecorder]
        CodeGenerator[CodeGenerator]
    end
    
    subgraph "Server Layer"
        WebEngineServer[WebEngineServer]
        RestAPI[REST API]
        WebSocketAPI[WebSocket API]
    end
    
    subgraph "Playwright Integration"
        Browser[Browser Instance]
        Page[Page Context]
        Locators[Playwright Locators]
    end
    
    subgraph "Artifacts"
        Screenshots[Screenshots]
        Videos[Videos]
        GeneratedCode[Generated Code]
    end
    
    WebEngineServer --> PlaywrightEngine
    WebEngineServer --> WebRecorder
    WebEngineServer --> CodeGenerator
    
    PlaywrightEngine --> LocatorResolver
    PlaywrightEngine --> Browser
    WebRecorder --> Browser
    
    PlaywrightEngine --> Screenshots
    WebRecorder --> Videos
    CodeGenerator --> GeneratedCode
```

## 🚀 Quick Start

### Start Web Engine Server

```bash
# Development mode
pnpm start:dev

# Production mode
pnpm build
pnpm start

# With demo app
pnpm start:demo
```

### Environment Variables

```bash
# Server Configuration
WEB_ENGINE_PORT=3000
WEB_ENGINE_WS_PORT=3001
WEB_ENGINE_CORS_ORIGIN="*"

# Browser Configuration  
WEB_ENGINE_BROWSER=chromium  # chromium | firefox | webkit
WEB_ENGINE_HEADLESS=false
WEB_ENGINE_VIEWPORT_WIDTH=1280
WEB_ENGINE_VIEWPORT_HEIGHT=720

# Timeouts
WEB_ENGINE_ACTION_TIMEOUT=30000
WEB_ENGINE_NAVIGATION_TIMEOUT=60000
WEB_ENGINE_ELEMENT_TIMEOUT=30000

# Screenshots
WEB_ENGINE_SCREENSHOTS_ON_FAILURE=true
WEB_ENGINE_SCREENSHOTS_ON_SUCCESS=false
WEB_ENGINE_SCREENSHOTS_ON_STEP=false
WEB_ENGINE_SCREENSHOT_QUALITY=90

# Video Recording
WEB_ENGINE_VIDEO_ENABLED=false
WEB_ENGINE_VIDEO_DIR="./artifacts/videos"
WEB_ENGINE_VIDEO_WIDTH=1280
WEB_ENGINE_VIDEO_HEIGHT=720
```

## 🎯 Usage Examples

### Basic Engine Usage

```typescript
import { PlaywrightEngine } from '@hybrid-qa/engine-web';

const engine = new PlaywrightEngine({
  browser: 'chromium',
  headless: false,
  screenshots: { onFailure: true },
});

await engine.initialize();

// Execute a step
const result = await engine.runStep({
  id: 'step-1',
  kind: 'web.navigate',
  engine: 'web',
  options: { url: 'https://example.com' },
}, context);

console.log(result.status); // 'completed' | 'failed'
```

### Recording User Interactions

```typescript
import { WebRecorder } from '@hybrid-qa/engine-web';

const recorder = new WebRecorder();
await recorder.initialize();

// Start recording
const sessionId = await recorder.startRecording({
  baseUrl: 'https://app.example.com',
  recordNetwork: false,
  ignoreSelectors: ['.ads', '.tracking'],
});

// Interactions are automatically recorded...

// Stop and get results
const interactions = await recorder.stopRecording(sessionId);
console.log('Recorded steps:', interactions.length);
```

### Code Generation

```typescript
import { CodeGenerator } from '@hybrid-qa/engine-web';

const generator = new CodeGenerator();

// Generate test from recorded interactions
const testCode = await generator.generateFromInteractions(interactions, {
  language: 'typescript',
  includeComments: true,
});

console.log(testCode.code);

// Generate Page Object Model
const pageObject = await generator.generatePageObjectModel(interactions, {
  className: 'LoginPage',
});
```

## 🔌 API Endpoints

### Engine Management

- `POST /engine/initialize` - Initialize the Playwright engine
- `POST /engine/cleanup` - Cleanup engine resources
- `GET /engine/health` - Get engine health status
- `POST /engine/run-step` - Execute a single DSL step

### Recording Management

- `POST /recorder/start` - Start new recording session
- `POST /recorder/stop/:sessionId` - Stop recording session
- `GET /recorder/session/:sessionId` - Get session status
- `GET /recorder/sessions` - List active sessions

### Code Generation

- `POST /codegen/generate` - Generate code from interactions
- `POST /codegen/generate-from-dsl` - Generate code from DSL steps

### WebSocket Events

- `interaction` - New recorded interaction
- `connected` - Connection established
- `sessions` - Active session list

## 🧪 Testing

### Unit Tests

```bash
pnpm test
```

### E2E Tests

```bash
pnpm test:e2e
```

### Demo Application

The package includes a complete demo e-commerce application for testing:

- Login/logout functionality
- Product catalog with filtering
- Shopping cart management
- Checkout process with form validation
- Order confirmation

Access the demo at `http://localhost:3001` when running `pnpm start:demo`.

**Demo Credentials:**
- Username: `demo` / Password: `demo`
- Username: `test@example.com` / Password: `password123`

## 📝 DSL Step Support

### Navigation Steps
- `web.navigate` - Navigate to URL with configurable wait conditions
- `web.refresh` - Reload current page
- `web.goBack` - Navigate back in history
- `web.goForward` - Navigate forward in history

### Interaction Steps
- `web.click` - Click element with auto-wait
- `web.type` - Type text with clearing and filling
- `web.clear` - Clear input field
- `web.hover` - Hover over element
- `web.scroll` - Scroll element or page

### Form Steps
- `web.select` - Select option by value or text
- `web.check` - Check checkbox/radio button
- `web.uncheck` - Uncheck checkbox/radio button

### Verification Steps
- `web.exists` - Check element existence
- `web.getText` - Extract element text content
- `web.getAttribute` - Get element attribute value

### Utility Steps
- `web.wait` - Wait for specified duration
- `web.screenshot` - Capture screenshot

## 🎛️ Locator Resolution Strategy

The engine uses a sophisticated multi-fallback locator resolution:

1. **Primary Strategy**: Use specified locator first
2. **Fallback Strategies**: Try alternative locators if primary fails
3. **Auto-Detection**: Automatic role/text/testId detection
4. **Confidence Scoring**: Rate locator reliability
5. **Self-Healing**: Learn and adapt locators over time

### Supported Locator Types
- `role` - ARIA role-based (highest reliability)
- `testid` - Test ID attributes (high reliability) 
- `text` - Visible text content (medium reliability)
- `css` - CSS selectors (medium reliability)
- `xpath` - XPath expressions (low reliability)

## 🔧 Configuration

### Engine Configuration

```typescript
interface WebEngineConfig {
  browser: 'chromium' | 'firefox' | 'webkit';
  headless: boolean;
  viewport: { width: number; height: number };
  timeouts: {
    action: number;
    navigation: number; 
    element: number;
  };
  screenshots: {
    onFailure: boolean;
    onSuccess: boolean;
    onStep: boolean;
    quality: number;
  };
  video: {
    enabled: boolean;
    dir: string;
    size: { width: number; height: number };
  };
}
```

### Recording Configuration

```typescript
interface RecordingConfig {
  baseUrl?: string;
  recordNetwork: boolean;
  recordConsole: boolean;
  excludeActions: string[];
  ignoreSelectors: string[];
}
```

## 🤝 Integration

### With Orchestrator

The Web Engine integrates seamlessly with the Hybrid QA Orchestrator:

```typescript
// Register with orchestrator
orchestrator.registerEngine('web', new PlaywrightEngine(config));

// Engine will be available for web.* DSL steps
```

### With Other Engines

The Web Engine follows the universal `IEngine` interface, making it compatible with:
- Desktop engines for hybrid workflows
- API engines for comprehensive testing
- Mainframe engines for legacy system integration

## 📊 Performance & Monitoring

- **Health Checks**: Automatic browser connectivity monitoring
- **Performance Metrics**: Step execution timing and success rates
- **Resource Management**: Automatic cleanup of browser contexts
- **Artifact Management**: Organized storage with retention policies

## 🔄 Future Enhancements

- [ ] **Visual Testing**: Screenshot comparison and visual regression testing
- [ ] **Network Mocking**: Request/response interception and mocking
- [ ] **Accessibility Testing**: Built-in a11y checks with axe-core
- [ ] **Mobile Testing**: Device emulation and mobile-specific gestures
- [ ] **Advanced Selectors**: CSS-in-JS and Shadow DOM support
- [ ] **Performance Testing**: Web vitals and lighthouse integration

---

**🚀 Ready to automate your web testing with the power of Playwright!** 