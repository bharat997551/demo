import express from 'express';
import { createServer } from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import cors from 'cors';
import { logger } from '@hybrid-qa/common';
import { PlaywrightEngine } from '../engine/playwright-engine';
import { WebRecorder } from '../recorder/web-recorder';
import { CodeGenerator } from '../codegen/code-generator';
import { WebEngineConfig, RecordingConfig, CodeGenOptions } from '../types/web-engine.types';

export class WebEngineServer {
  private app: express.Application;
  private httpServer: any;
  private wsServer: WebSocketServer | null = null;
  private engine: PlaywrightEngine;
  private recorder: WebRecorder;
  private codeGenerator: CodeGenerator;

  constructor(
    private config: {
      port: number;
      wsPort: number;
      corsOrigin?: string | string[];
      webEngineConfig?: Partial<WebEngineConfig>;
    }
  ) {
    this.app = express();
    this.httpServer = createServer(this.app);
    
    // Initialize components
    this.engine = new PlaywrightEngine(config.webEngineConfig);
    this.recorder = new WebRecorder(config.webEngineConfig);
    this.codeGenerator = new CodeGenerator();

    this.setupMiddleware();
    this.setupRoutes();
    this.setupWebSocket();
  }

  private setupMiddleware(): void {
    // CORS
    this.app.use(cors({
      origin: this.config.corsOrigin || '*',
      methods: ['GET', 'POST', 'PUT', 'DELETE'],
      allowedHeaders: ['Content-Type', 'Authorization'],
    }));

    // Body parsing
    this.app.use(express.json({ limit: '10mb' }));
    this.app.use(express.urlencoded({ extended: true, limit: '10mb' }));

    // Request logging
    this.app.use((req, res, next) => {
      logger.info('HTTP Request', {
        method: req.method,
        path: req.path,
        userAgent: req.get('User-Agent'),
      });
      next();
    });
  }

  private setupRoutes(): void {
    // Health check
    this.app.get('/health', (req, res) => {
      res.json({
        status: 'healthy',
        timestamp: new Date().toISOString(),
        version: '1.0.0',
      });
    });

    // Engine endpoints
    this.app.post('/engine/initialize', async (req, res) => {
      try {
        await this.engine.initialize();
        res.json({ success: true, message: 'Engine initialized' });
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error instanceof Error ? error.message : 'Unknown error',
        });
      }
    });

    this.app.post('/engine/cleanup', async (req, res) => {
      try {
        await this.engine.cleanup();
        res.json({ success: true, message: 'Engine cleaned up' });
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error instanceof Error ? error.message : 'Unknown error',
        });
      }
    });

    this.app.get('/engine/health', async (req, res) => {
      try {
        const health = await this.engine.healthCheck();
        res.json(health);
      } catch (error) {
        res.status(500).json({
          status: 'unhealthy',
          message: error instanceof Error ? error.message : 'Unknown error',
          lastCheck: new Date(),
        });
      }
    });

    this.app.post('/engine/run-step', async (req, res) => {
      try {
        const { step, context } = req.body;
        if (!step || !context) {
          return res.status(400).json({
            success: false,
            error: 'Missing step or context',
          });
        }

        const result = await this.engine.runStep(step, context);
        res.json({ success: true, result });
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error instanceof Error ? error.message : 'Unknown error',
        });
      }
    });

    // Recording endpoints
    this.app.post('/recorder/start', async (req, res) => {
      try {
        const config: RecordingConfig = req.body;
        const sessionId = await this.recorder.startRecording(config);
        res.json({ success: true, sessionId });
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error instanceof Error ? error.message : 'Unknown error',
        });
      }
    });

    this.app.post('/recorder/stop/:sessionId', async (req, res) => {
      try {
        const { sessionId } = req.params;
        const interactions = await this.recorder.stopRecording(sessionId);
        res.json({ success: true, interactions });
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error instanceof Error ? error.message : 'Unknown error',
        });
      }
    });

    this.app.get('/recorder/session/:sessionId', (req, res) => {
      try {
        const { sessionId } = req.params;
        const session = this.recorder.getSessionStatus(sessionId);
        if (!session) {
          return res.status(404).json({
            success: false,
            error: 'Session not found',
          });
        }
        res.json({ success: true, session: {
          id: session.id,
          startTime: session.startTime,
          currentUrl: session.currentUrl,
          interactionCount: session.interactions.length,
        }});
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error instanceof Error ? error.message : 'Unknown error',
        });
      }
    });

    this.app.get('/recorder/sessions', (req, res) => {
      try {
        const sessions = this.recorder.getActiveSessions().map(session => ({
          id: session.id,
          startTime: session.startTime,
          currentUrl: session.currentUrl,
          interactionCount: session.interactions.length,
        }));
        res.json({ success: true, sessions });
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error instanceof Error ? error.message : 'Unknown error',
        });
      }
    });

    // Code generation endpoints
    this.app.post('/codegen/generate', async (req, res) => {
      try {
        const { interactions, options }: { interactions: any[]; options?: CodeGenOptions } = req.body;
        if (!interactions) {
          return res.status(400).json({
            success: false,
            error: 'Missing interactions',
          });
        }

        const code = await this.codeGenerator.generateFromInteractions(interactions, options);
        res.json({ success: true, code });
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error instanceof Error ? error.message : 'Unknown error',
        });
      }
    });

    this.app.post('/codegen/generate-from-dsl', async (req, res) => {
      try {
        const { steps, options }: { steps: any[]; options?: CodeGenOptions } = req.body;
        if (!steps) {
          return res.status(400).json({
            success: false,
            error: 'Missing steps',
          });
        }

        const code = await this.codeGenerator.generateFromDslSteps(steps, options);
        res.json({ success: true, code });
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error instanceof Error ? error.message : 'Unknown error',
        });
      }
    });

    // Error handling
    this.app.use((error: Error, req: express.Request, res: express.Response, next: express.NextFunction) => {
      logger.error('Express error', { error, path: req.path });
      res.status(500).json({
        success: false,
        error: 'Internal server error',
      });
    });
  }

  private setupWebSocket(): void {
    this.wsServer = new WebSocketServer({ port: this.config.wsPort });

    this.wsServer.on('connection', (ws: WebSocket, req) => {
      logger.info('WebSocket connection established', {
        userAgent: req.headers['user-agent'],
        origin: req.headers.origin,
      });

      // Add to recorder for streaming
      this.recorder.addWebSocketConnection(ws);

      ws.on('message', (data) => {
        try {
          const message = JSON.parse(data.toString());
          this.handleWebSocketMessage(ws, message);
        } catch (error) {
          logger.error('Invalid WebSocket message', { error });
          ws.send(JSON.stringify({
            type: 'error',
            error: 'Invalid message format',
          }));
        }
      });

      ws.on('close', () => {
        logger.info('WebSocket connection closed');
      });

      // Send welcome message
      ws.send(JSON.stringify({
        type: 'connected',
        message: 'WebSocket connection established',
        timestamp: new Date().toISOString(),
      }));
    });

    this.wsServer.on('error', (error) => {
      logger.error('WebSocket server error', { error });
    });
  }

  private handleWebSocketMessage(ws: WebSocket, message: any): void {
    switch (message.type) {
      case 'ping':
        ws.send(JSON.stringify({ type: 'pong', timestamp: new Date().toISOString() }));
        break;

      case 'subscribe':
        // Handle subscription to specific events
        logger.info('Client subscribed to events', { events: message.events });
        break;

      case 'get-sessions':
        const sessions = this.recorder.getActiveSessions().map(session => ({
          id: session.id,
          startTime: session.startTime,
          currentUrl: session.currentUrl,
          interactionCount: session.interactions.length,
        }));
        ws.send(JSON.stringify({
          type: 'sessions',
          data: sessions,
        }));
        break;

      default:
        ws.send(JSON.stringify({
          type: 'error',
          error: `Unknown message type: ${message.type}`,
        }));
    }
  }

  async start(): Promise<void> {
    try {
      // Initialize components
      await this.engine.initialize();
      await this.recorder.initialize();

      // Start HTTP server
      await new Promise<void>((resolve, reject) => {
        this.httpServer.listen(this.config.port, (error?: Error) => {
          if (error) {
            reject(error);
          } else {
            resolve();
          }
        });
      });

      logger.info('Web Engine Server started', {
        httpPort: this.config.port,
        wsPort: this.config.wsPort,
      });
    } catch (error) {
      logger.error('Failed to start Web Engine Server', { error });
      throw error;
    }
  }

  async stop(): Promise<void> {
    try {
      // Stop components
      await this.engine.cleanup();
      await this.recorder.cleanup();

      // Close WebSocket server
      if (this.wsServer) {
        this.wsServer.close();
        this.wsServer = null;
      }

      // Close HTTP server
      if (this.httpServer) {
        await new Promise<void>((resolve) => {
          this.httpServer.close(() => resolve());
        });
      }

      logger.info('Web Engine Server stopped');
    } catch (error) {
      logger.error('Error stopping Web Engine Server', { error });
      throw error;
    }
  }
} 