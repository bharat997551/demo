import { Browser, BrowserContext, Page, chromium, firefox, webkit } from 'playwright';
import { IEngine, RunContext, StepExecutionResult, EngineConfig, EngineHealth } from '@hybrid-qa/orchestrator/src/interfaces/engine.interface';
import { Step, ExecutionStatus } from '@hybrid-qa/dsl';
import { logger } from '@hybrid-qa/common';
import { LocatorResolver } from '../utils/locator-resolver';
import { WebEngineConfig, WebStepContext } from '../types/web-engine.types';
import * as path from 'path';
import * as fs from 'fs';

export class PlaywrightEngine implements IEngine {
  public readonly config: EngineConfig;
  private webConfig: WebEngineConfig;
  private browser: Browser | null = null;
  private context: BrowserContext | null = null;
  private page: Page | null = null;
  private locatorResolver: LocatorResolver | null = null;

  constructor(config: Partial<WebEngineConfig> = {}) {
    this.webConfig = {
      browser: 'chromium',
      headless: true,
      viewport: { width: 1280, height: 720 },
      timeouts: {
        action: 30000,
        navigation: 60000,
        element: 30000,
      },
      screenshots: {
        onFailure: true,
        onSuccess: false,
        onStep: false,
        quality: 90,
      },
      video: {
        enabled: false,
        dir: './artifacts/videos',
        size: { width: 1280, height: 720 },
      },
      locatorStrategy: {
        timeout: 30000,
        retries: 3,
        autoWait: true,
      },
      ...config,
    };

    this.config = {
      id: 'playwright-web-engine',
      name: 'Playwright Web Engine',
      type: 'web',
      version: '1.0.0',
      enabled: true,
      settings: this.webConfig,
      healthCheck: {
        enabled: true,
        interval: 30000,
        timeout: 5000,
        retries: 3,
      },
    };
  }

  async initialize(): Promise<void> {
    try {
      logger.info('Initializing Playwright Web Engine');

      // Launch browser
      const browserType = this.getBrowserType();
      this.browser = await browserType.launch({
        headless: this.webConfig.headless,
      });

      // Create context
      this.context = await this.browser.newContext({
        viewport: this.webConfig.viewport,
        recordVideo: this.webConfig.video.enabled
          ? {
              dir: this.webConfig.video.dir,
              size: this.webConfig.video.size,
            }
          : undefined,
      });

      // Create page
      this.page = await this.context.newPage();
      this.locatorResolver = new LocatorResolver(this.page, this.webConfig.locatorStrategy.timeout);

      logger.info('Playwright Web Engine initialized successfully');
    } catch (error) {
      logger.error('Failed to initialize Playwright Web Engine', { error });
      throw error;
    }
  }

  async cleanup(): Promise<void> {
    try {
      if (this.context) {
        await this.context.close();
        this.context = null;
      }
      if (this.browser) {
        await this.browser.close();
        this.browser = null;
      }
      this.page = null;
      this.locatorResolver = null;
      logger.info('Playwright Web Engine cleaned up successfully');
    } catch (error) {
      logger.error('Error during Playwright Web Engine cleanup', { error });
    }
  }

  async healthCheck(): Promise<EngineHealth> {
    try {
      if (!this.browser || !this.browser.isConnected()) {
        return {
          status: 'unhealthy',
          message: 'Browser not connected',
          lastCheck: new Date(),
        };
      }

      // Test navigation to check engine health
      if (this.page) {
        await this.page.evaluate('navigator.userAgent');
      }

      return {
        status: 'healthy',
        lastCheck: new Date(),
        responseTime: 50,
        version: this.config.version,
        capabilities: this.getSupportedStepKinds(),
      };
    } catch (error) {
      return {
        status: 'unhealthy',
        message: error instanceof Error ? error.message : 'Unknown error',
        lastCheck: new Date(),
      };
    }
  }

  supports(stepKind: string): boolean {
    return stepKind.startsWith('web.');
  }

  getSupportedStepKinds(): string[] {
    return [
      'web.navigate',
      'web.click',
      'web.type',
      'web.clear',
      'web.select',
      'web.check',
      'web.uncheck',
      'web.hover',
      'web.scroll',
      'web.wait',
      'web.exists',
      'web.getText',
      'web.getAttribute',
      'web.screenshot',
      'web.refresh',
      'web.goBack',
      'web.goForward',
    ];
  }

  validateStep(step: Step): { valid: boolean; errors?: string[] } {
    const errors: string[] = [];

    if (!this.supports(step.kind)) {
      errors.push(`Unsupported step kind: ${step.kind}`);
    }

    // Validate step-specific requirements
    switch (step.kind) {
      case 'web.navigate':
        if (!step.options?.url) {
          errors.push('web.navigate requires options.url');
        }
        break;

      case 'web.type':
        if (!step.locator) {
          errors.push('web.type requires a locator');
        }
        if (!step.options?.text) {
          errors.push('web.type requires options.text');
        }
        break;

      case 'web.click':
      case 'web.hover':
      case 'web.check':
      case 'web.uncheck':
        if (!step.locator) {
          errors.push(`${step.kind} requires a locator`);
        }
        break;

      case 'web.select':
        if (!step.locator) {
          errors.push('web.select requires a locator');
        }
        if (!step.options?.value && !step.options?.text) {
          errors.push('web.select requires options.value or options.text');
        }
        break;
    }

    return {
      valid: errors.length === 0,
      errors: errors.length > 0 ? errors : undefined,
    };
  }

  async runStep(step: Step, context: RunContext): Promise<StepExecutionResult> {
    if (!this.page || !this.locatorResolver) {
      throw new Error('Engine not initialized');
    }

    const startTime = new Date();
    const stepContext: WebStepContext = {
      page: this.page,
      context: this.context!,
      artifactDir: context.artifactDir,
      screenshots: context.screenshots,
      timeout: context.timeout || this.webConfig.timeouts.action,
      variables: context.variables,
    };

    try {
      logger.info('Executing web step', { stepId: step.id, kind: step.kind });

      // Take screenshot before step if configured
      if (stepContext.screenshots.onStep) {
        await this.takeScreenshot(stepContext, `${step.id}_before`);
      }

      let result: any;
      switch (step.kind) {
        case 'web.navigate':
          result = await this.executeNavigate(step, stepContext);
          break;
        case 'web.click':
          result = await this.executeClick(step, stepContext);
          break;
        case 'web.type':
          result = await this.executeType(step, stepContext);
          break;
        case 'web.clear':
          result = await this.executeClear(step, stepContext);
          break;
        case 'web.select':
          result = await this.executeSelect(step, stepContext);
          break;
        case 'web.check':
          result = await this.executeCheck(step, stepContext);
          break;
        case 'web.uncheck':
          result = await this.executeUncheck(step, stepContext);
          break;
        case 'web.hover':
          result = await this.executeHover(step, stepContext);
          break;
        case 'web.scroll':
          result = await this.executeScroll(step, stepContext);
          break;
        case 'web.wait':
          result = await this.executeWait(step, stepContext);
          break;
        case 'web.exists':
          result = await this.executeExists(step, stepContext);
          break;
        case 'web.getText':
          result = await this.executeGetText(step, stepContext);
          break;
        case 'web.getAttribute':
          result = await this.executeGetAttribute(step, stepContext);
          break;
        case 'web.screenshot':
          result = await this.executeScreenshot(step, stepContext);
          break;
        case 'web.refresh':
          result = await this.executeRefresh(step, stepContext);
          break;
        case 'web.goBack':
          result = await this.executeGoBack(step, stepContext);
          break;
        case 'web.goForward':
          result = await this.executeGoForward(step, stepContext);
          break;
        default:
          throw new Error(`Unsupported step kind: ${step.kind}`);
      }

      const endTime = new Date();

      // Take screenshot after successful step if configured
      if (stepContext.screenshots.onSuccess || stepContext.screenshots.onStep) {
        await this.takeScreenshot(stepContext, `${step.id}_after_success`);
      }

      return {
        stepId: step.id,
        status: 'completed',
        startTime,
        endTime,
        duration: endTime.getTime() - startTime.getTime(),
        extractedData: result,
        screenshots: [], // Will be populated by screenshot methods
        logs: [`Successfully executed ${step.kind}`],
      };

    } catch (error) {
      const endTime = new Date();

      // Take screenshot on failure if configured
      if (stepContext.screenshots.onFailure) {
        await this.takeScreenshot(stepContext, `${step.id}_failure`);
      }

      logger.error('Web step execution failed', { stepId: step.id, error });

      return {
        stepId: step.id,
        status: 'failed',
        startTime,
        endTime,
        duration: endTime.getTime() - startTime.getTime(),
        error: error instanceof Error ? error.message : String(error),
        screenshots: [],
        logs: [`Failed to execute ${step.kind}: ${error}`],
      };
    }
  }

  private getBrowserType() {
    switch (this.webConfig.browser) {
      case 'firefox':
        return firefox;
      case 'webkit':
        return webkit;
      default:
        return chromium;
    }
  }

  private async takeScreenshot(context: WebStepContext, name: string): Promise<string> {
    const screenshotPath = path.join(context.artifactDir, `${name}.png`);
    
    // Ensure directory exists
    await fs.promises.mkdir(path.dirname(screenshotPath), { recursive: true });
    
    await context.page.screenshot({
      path: screenshotPath,
      quality: this.webConfig.screenshots.quality,
    });
    
    return screenshotPath;
  }

  // Step execution methods
  private async executeNavigate(step: Step, context: WebStepContext): Promise<void> {
    const url = this.interpolateVariables(step.options?.url, context.variables);
    await context.page.goto(url, {
      timeout: this.webConfig.timeouts.navigation,
      waitUntil: 'domcontentloaded',
    });
  }

  private async executeClick(step: Step, context: WebStepContext): Promise<void> {
    if (!step.locator) throw new Error('Click step requires a locator');
    
    const resolution = await this.locatorResolver!.resolveLocator(step.locator);
    if (!resolution.found) {
      throw new Error(`Element not found using locator: ${JSON.stringify(step.locator)}`);
    }

    await this.locatorResolver!.waitForReady(resolution.locator);
    await resolution.locator.click({ timeout: context.timeout });
  }

  private async executeType(step: Step, context: WebStepContext): Promise<void> {
    if (!step.locator) throw new Error('Type step requires a locator');
    if (!step.options?.text) throw new Error('Type step requires options.text');

    const resolution = await this.locatorResolver!.resolveLocator(step.locator);
    if (!resolution.found) {
      throw new Error(`Element not found using locator: ${JSON.stringify(step.locator)}`);
    }

    const text = this.interpolateVariables(step.options.text, context.variables);
    
    await this.locatorResolver!.waitForReady(resolution.locator);
    await resolution.locator.fill(text);
  }

  private async executeClear(step: Step, context: WebStepContext): Promise<void> {
    if (!step.locator) throw new Error('Clear step requires a locator');

    const resolution = await this.locatorResolver!.resolveLocator(step.locator);
    if (!resolution.found) {
      throw new Error(`Element not found using locator: ${JSON.stringify(step.locator)}`);
    }

    await this.locatorResolver!.waitForReady(resolution.locator);
    await resolution.locator.clear();
  }

  private async executeSelect(step: Step, context: WebStepContext): Promise<void> {
    if (!step.locator) throw new Error('Select step requires a locator');

    const resolution = await this.locatorResolver!.resolveLocator(step.locator);
    if (!resolution.found) {
      throw new Error(`Element not found using locator: ${JSON.stringify(step.locator)}`);
    }

    await this.locatorResolver!.waitForReady(resolution.locator);

    if (step.options?.value) {
      const value = this.interpolateVariables(step.options.value, context.variables);
      await resolution.locator.selectOption({ value });
    } else if (step.options?.text) {
      const text = this.interpolateVariables(step.options.text, context.variables);
      await resolution.locator.selectOption({ label: text });
    }
  }

  private async executeCheck(step: Step, context: WebStepContext): Promise<void> {
    if (!step.locator) throw new Error('Check step requires a locator');

    const resolution = await this.locatorResolver!.resolveLocator(step.locator);
    if (!resolution.found) {
      throw new Error(`Element not found using locator: ${JSON.stringify(step.locator)}`);
    }

    await this.locatorResolver!.waitForReady(resolution.locator);
    await resolution.locator.check();
  }

  private async executeUncheck(step: Step, context: WebStepContext): Promise<void> {
    if (!step.locator) throw new Error('Uncheck step requires a locator');

    const resolution = await this.locatorResolver!.resolveLocator(step.locator);
    if (!resolution.found) {
      throw new Error(`Element not found using locator: ${JSON.stringify(step.locator)}`);
    }

    await this.locatorResolver!.waitForReady(resolution.locator);
    await resolution.locator.uncheck();
  }

  private async executeHover(step: Step, context: WebStepContext): Promise<void> {
    if (!step.locator) throw new Error('Hover step requires a locator');

    const resolution = await this.locatorResolver!.resolveLocator(step.locator);
    if (!resolution.found) {
      throw new Error(`Element not found using locator: ${JSON.stringify(step.locator)}`);
    }

    await this.locatorResolver!.waitForReady(resolution.locator);
    await resolution.locator.hover();
  }

  private async executeScroll(step: Step, context: WebStepContext): Promise<void> {
    if (step.locator) {
      const resolution = await this.locatorResolver!.resolveLocator(step.locator);
      if (!resolution.found) {
        throw new Error(`Element not found using locator: ${JSON.stringify(step.locator)}`);
      }
      await resolution.locator.scrollIntoViewIfNeeded();
    } else {
      // Scroll page
      const x = step.options?.x || 0;
      const y = step.options?.y || 0;
      await context.page.evaluate(([x, y]) => window.scrollTo(x, y), [x, y]);
    }
  }

  private async executeWait(step: Step, context: WebStepContext): Promise<void> {
    const duration = step.options?.duration || 1000;
    await context.page.waitForTimeout(duration);
  }

  private async executeExists(step: Step, context: WebStepContext): Promise<boolean> {
    if (!step.locator) throw new Error('Exists step requires a locator');

    const resolution = await this.locatorResolver!.resolveLocator(step.locator);
    return resolution.found;
  }

  private async executeGetText(step: Step, context: WebStepContext): Promise<string> {
    if (!step.locator) throw new Error('GetText step requires a locator');

    const resolution = await this.locatorResolver!.resolveLocator(step.locator);
    if (!resolution.found) {
      throw new Error(`Element not found using locator: ${JSON.stringify(step.locator)}`);
    }

    return await resolution.locator.textContent() || '';
  }

  private async executeGetAttribute(step: Step, context: WebStepContext): Promise<string | null> {
    if (!step.locator) throw new Error('GetAttribute step requires a locator');
    if (!step.options?.attribute) throw new Error('GetAttribute step requires options.attribute');

    const resolution = await this.locatorResolver!.resolveLocator(step.locator);
    if (!resolution.found) {
      throw new Error(`Element not found using locator: ${JSON.stringify(step.locator)}`);
    }

    return await resolution.locator.getAttribute(step.options.attribute);
  }

  private async executeScreenshot(step: Step, context: WebStepContext): Promise<string> {
    const name = step.options?.name || `screenshot_${Date.now()}`;
    return await this.takeScreenshot(context, name);
  }

  private async executeRefresh(step: Step, context: WebStepContext): Promise<void> {
    await context.page.reload({
      timeout: this.webConfig.timeouts.navigation,
      waitUntil: 'domcontentloaded',
    });
  }

  private async executeGoBack(step: Step, context: WebStepContext): Promise<void> {
    await context.page.goBack({
      timeout: this.webConfig.timeouts.navigation,
      waitUntil: 'domcontentloaded',
    });
  }

  private async executeGoForward(step: Step, context: WebStepContext): Promise<void> {
    await context.page.goForward({
      timeout: this.webConfig.timeouts.navigation,
      waitUntil: 'domcontentloaded',
    });
  }

  private interpolateVariables(text: string, variables: Record<string, any>): string {
    return text.replace(/\$\{(\w+)\}/g, (match, varName) => {
      return variables[varName] !== undefined ? String(variables[varName]) : match;
    });
  }
} 