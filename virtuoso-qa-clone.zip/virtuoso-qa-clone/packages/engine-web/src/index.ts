// Main exports for the Web Engine package
export { PlaywrightEngine } from './engine/playwright-engine';
export { WebRecorder } from './recorder/web-recorder';
export { CodeGenerator } from './codegen/code-generator';
export { WebEngineServer } from './server/web-engine-server';
export { LocatorResolver } from './utils/locator-resolver';

// Type exports
export type {
  WebEngineConfig,
  RecordingConfig,
  RecordedInteraction,
  RecordingSession,
  LocatorResolution,
  WebStepContext,
  CodeGenOptions,
  GeneratedCode,
} from './types/web-engine.types'; 