import { Page, Locator, ElementHandle } from 'playwright';
import { logger } from '@hybrid-qa/common';

export interface WebLocatorVariant {
  selector: string;
  type: 'css' | 'xpath' | 'text' | 'id' | 'class' | 'data-testid' | 'aria-label' | 'role' | 'placeholder';
  score: number;
  metadata?: {
    visibility?: boolean;
    boundingBox?: { x: number; y: number; width: number; height: number };
    attributes?: Record<string, string>;
    textContent?: string;
    tagName?: string;
  };
}

export class WebLocatorHealer {
  constructor(private page: Page) {}

  /**
   * Capture DOM snapshot and element metadata
   */
  async captureContext(locator: Locator | ElementHandle): Promise<{
    domSnapshot: string;
    elementMetadata: WebLocatorVariant['metadata'];
  }> {
    try {
      // Get element handle
      let element: ElementHandle;
      if ('elementHandle' in locator) {
        element = await locator.elementHandle();
        if (!element) throw new Error('Could not get element handle');
      } else {
        element = locator as ElementHandle;
      }

      // Capture element metadata
      const elementMetadata = await element.evaluate((el) => {
        const rect = el.getBoundingClientRect();
        const computedStyle = window.getComputedStyle(el);
        
        // Get all attributes
        const attributes: Record<string, string> = {};
        for (const attr of el.attributes) {
          attributes[attr.name] = attr.value;
        }

        return {
          visibility: computedStyle.display !== 'none' && computedStyle.visibility !== 'hidden',
          boundingBox: {
            x: rect.x,
            y: rect.y,
            width: rect.width,
            height: rect.height
          },
          attributes,
          textContent: el.textContent?.trim() || '',
          tagName: el.tagName.toLowerCase()
        };
      });

      // Capture DOM snapshot
      const domSnapshot = await this.page.content();

      return { domSnapshot, elementMetadata };
    } catch (error) {
      logger.error('Failed to capture context', { error });
      throw error;
    }
  }

  /**
   * Generate alternative locators for an element
   */
  async generateAlternativeLocators(
    originalSelector: string,
    originalType: WebLocatorVariant['type']
  ): Promise<WebLocatorVariant[]> {
    const alternatives: WebLocatorVariant[] = [];

    try {
      // Try to find the element with original selector
      const element = await this.findElementBySelector(originalSelector, originalType);
      if (!element) {
        return alternatives;
      }

      // Generate alternatives based on element properties
      const elementData = await element.evaluate((el) => {
        const attributes: Record<string, string> = {};
        for (const attr of el.attributes) {
          attributes[attr.name] = attr.value;
        }
        
        return {
          id: el.id,
          className: el.className,
          tagName: el.tagName.toLowerCase(),
          textContent: el.textContent?.trim() || '',
          attributes,
          parent: {
            tagName: el.parentElement?.tagName.toLowerCase(),
            id: el.parentElement?.id,
            className: el.parentElement?.className
          }
        };
      });

      // ID selector (highest priority)
      if (elementData.id) {
        alternatives.push({
          selector: elementData.id,
          type: 'id',
          score: 1.0
        });
      }

      // Data-testid selector
      if (elementData.attributes['data-testid']) {
        alternatives.push({
          selector: elementData.attributes['data-testid'],
          type: 'data-testid',
          score: 0.95
        });
      }

      // Aria-label selector
      if (elementData.attributes['aria-label']) {
        alternatives.push({
          selector: elementData.attributes['aria-label'],
          type: 'aria-label',
          score: 0.85
        });
      }

      // Role selector
      if (elementData.attributes['role']) {
        alternatives.push({
          selector: elementData.attributes['role'],
          type: 'role',
          score: 0.75
        });
      }

      // Placeholder selector
      if (elementData.attributes['placeholder']) {
        alternatives.push({
          selector: elementData.attributes['placeholder'],
          type: 'placeholder',
          score: 0.7
        });
      }

      // Class selector
      if (elementData.className) {
        const classes = elementData.className.split(' ').filter(c => c.trim());
        if (classes.length > 0) {
          alternatives.push({
            selector: classes[0],
            type: 'class',
            score: 0.6
          });
        }
      }

      // Text selector
      if (elementData.textContent && elementData.textContent.length < 100) {
        alternatives.push({
          selector: elementData.textContent,
          type: 'text',
          score: 0.7
        });
      }

      // CSS selector with context
      const cssSelector = await this.buildContextualCssSelector(element);
      if (cssSelector) {
        alternatives.push({
          selector: cssSelector,
          type: 'css',
          score: 0.5
        });
      }

      // XPath selector as fallback
      const xpathSelector = await this.buildXPathSelector(element);
      if (xpathSelector) {
        alternatives.push({
          selector: xpathSelector,
          type: 'xpath',
          score: 0.4
        });
      }

    } catch (error) {
      logger.error('Failed to generate alternative locators', { error });
    }

    return alternatives;
  }

  /**
   * Try a locator variant and return success/failure
   */
  async tryLocator(variant: WebLocatorVariant): Promise<{
    success: boolean;
    element?: ElementHandle;
    error?: string;
  }> {
    try {
      const element = await this.findElementByVariant(variant);
      if (element) {
        // Verify element is visible and interactable
        const isVisible = await element.isVisible();
        const isEnabled = await element.isEnabled();
        
        if (isVisible && isEnabled) {
          return { success: true, element };
        } else {
          return { 
            success: false, 
            error: `Element found but not interactable (visible: ${isVisible}, enabled: ${isEnabled})` 
          };
        }
      }
      
      return { success: false, error: 'Element not found' };
    } catch (error) {
      return { 
        success: false, 
        error: error instanceof Error ? error.message : 'Unknown error' 
      };
    }
  }

  /**
   * Find element by selector and type
   */
  private async findElementBySelector(
    selector: string,
    type: WebLocatorVariant['type']
  ): Promise<ElementHandle | null> {
    try {
      let locator: Locator;

      switch (type) {
        case 'css':
          locator = this.page.locator(selector);
          break;
        case 'xpath':
          locator = this.page.locator(`xpath=${selector}`);
          break;
        case 'text':
          locator = this.page.getByText(selector, { exact: true });
          break;
        case 'id':
          locator = this.page.locator(`#${selector}`);
          break;
        case 'class':
          locator = this.page.locator(`.${selector}`);
          break;
        case 'data-testid':
          locator = this.page.getByTestId(selector);
          break;
        case 'aria-label':
          locator = this.page.getByLabel(selector);
          break;
        case 'role':
          locator = this.page.getByRole(selector as any);
          break;
        case 'placeholder':
          locator = this.page.getByPlaceholder(selector);
          break;
        default:
          return null;
      }

      return await locator.elementHandle();
    } catch {
      return null;
    }
  }

  /**
   * Find element by locator variant
   */
  private async findElementByVariant(variant: WebLocatorVariant): Promise<ElementHandle | null> {
    return this.findElementBySelector(variant.selector, variant.type);
  }

  /**
   * Build a contextual CSS selector
   */
  private async buildContextualCssSelector(element: ElementHandle): Promise<string | null> {
    try {
      return await element.evaluate((el) => {
        const tag = el.tagName.toLowerCase();
        const attributes: string[] = [];

        // Add specific attributes
        if (el.getAttribute('type')) {
          attributes.push(`[type="${el.getAttribute('type')}"]`);
        }
        if (el.getAttribute('name')) {
          attributes.push(`[name="${el.getAttribute('name')}"]`);
        }

        let selector = tag + attributes.join('');

        // Add nth-child if needed
        const parent = el.parentElement;
        if (parent) {
          const siblings = parent.querySelectorAll(selector);
          if (siblings.length > 1) {
            const index = Array.from(siblings).indexOf(el) + 1;
            selector += `:nth-child(${index})`;
          }

          // Add parent context if still ambiguous
          const matches = document.querySelectorAll(selector);
          if (matches.length > 1) {
            const parentTag = parent.tagName.toLowerCase();
            const parentId = parent.id ? `#${parent.id}` : '';
            selector = `${parentTag}${parentId} > ${selector}`;
          }
        }

        return selector;
      });
    } catch {
      return null;
    }
  }

  /**
   * Build an XPath selector
   */
  private async buildXPathSelector(element: ElementHandle): Promise<string | null> {
    try {
      return await element.evaluate((el) => {
        const tag = el.tagName.toLowerCase();
        const text = el.textContent?.trim();

        if (text && text.length < 50) {
          return `//${tag}[contains(text(),'${text.substring(0, 30)}')]`;
        }

        // Build by position
        let path = '';
        let current: Element | null = el;
        
        while (current && current.nodeType === Node.ELEMENT_NODE) {
          const tag = current.tagName.toLowerCase();
          const parent = current.parentElement;
          
          if (parent) {
            const siblings = Array.from(parent.children).filter(
              child => child.tagName.toLowerCase() === tag
            );
            
            if (siblings.length > 1) {
              const index = siblings.indexOf(current) + 1;
              path = `/${tag}[${index}]${path}`;
            } else {
              path = `/${tag}${path}`;
            }
          } else {
            path = `/${tag}${path}`;
          }
          
          current = parent;
        }

        return `//${path}`;
      });
    } catch {
      return null;
    }
  }

  /**
   * Compare two DOM snapshots and identify similar elements
   */
  async findSimilarElements(
    originalSelector: string,
    originalType: WebLocatorVariant['type'],
    oldSnapshot: string,
    newSnapshot: string
  ): Promise<WebLocatorVariant[]> {
    // This would implement more sophisticated similarity matching
    // For now, just generate alternatives
    return this.generateAlternativeLocators(originalSelector, originalType);
  }
} 