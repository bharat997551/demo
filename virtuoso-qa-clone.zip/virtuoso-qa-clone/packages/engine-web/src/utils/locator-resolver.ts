import { Page, Locator } from 'playwright';
import { Locator as DslLocator } from '@hybrid-qa/dsl';
import { LocatorResolution } from '../types/web-engine.types';

/**
 * Resolves DSL locators to Playwright locators using multiple fallback strategies
 */
export class LocatorResolver {
  private page: Page;
  private timeout: number;

  constructor(page: Page, timeout: number = 30000) {
    this.page = page;
    this.timeout = timeout;
  }

  /**
   * Resolve a DSL locator to a Playwright locator with fallback strategies
   */
  async resolveLocator(dslLocator: DslLocator): Promise<LocatorResolution> {
    const strategies = [
      () => this.resolveByRole(dslLocator),
      () => this.resolveByTestId(dslLocator),
      () => this.resolveByText(dslLocator),
      () => this.resolveByCss(dslLocator),
      () => this.resolveByXPath(dslLocator),
    ];

    // Try primary locator first
    if (dslLocator.primary) {
      const primaryResult = await this.resolveStrategy(dslLocator.primary.strategy, dslLocator.primary.value);
      if (primaryResult.found) {
        return primaryResult;
      }
    }

    // Try fallback locators
    if (dslLocator.fallbacks) {
      for (const fallback of dslLocator.fallbacks) {
        const fallbackResult = await this.resolveStrategy(fallback.strategy, fallback.value);
        if (fallbackResult.found) {
          return { ...fallbackResult, confidence: fallbackResult.confidence * 0.8 }; // Lower confidence for fallbacks
        }
      }
    }

    // Try all automatic strategies as last resort
    for (const strategy of strategies) {
      try {
        const result = await strategy();
        if (result && result.found) {
          return { ...result, confidence: result.confidence * 0.6 }; // Lowest confidence for auto-detected
        }
      } catch (error) {
        // Continue to next strategy
      }
    }

    // Return not found result
    return {
      locator: null,
      strategy: 'css',
      confidence: 0,
      found: false,
    };
  }

  /**
   * Resolve using a specific strategy
   */
  private async resolveStrategy(strategy: string, value: string): Promise<LocatorResolution> {
    switch (strategy.toLowerCase()) {
      case 'role':
        return this.resolveByRoleValue(value);
      case 'testid':
      case 'test-id':
        return this.resolveByTestIdValue(value);
      case 'text':
        return this.resolveByTextValue(value);
      case 'css':
        return this.resolveByCssValue(value);
      case 'xpath':
        return this.resolveByXPathValue(value);
      default:
        return this.resolveByCssValue(value); // Default to CSS
    }
  }

  /**
   * Resolve by ARIA role
   */
  private async resolveByRole(dslLocator: DslLocator): Promise<LocatorResolution | null> {
    // Auto-detect common roles
    const commonRoles = ['button', 'link', 'textbox', 'checkbox', 'radio'];
    
    for (const role of commonRoles) {
      const locator = this.page.getByRole(role as any);
      try {
        await locator.first().waitFor({ timeout: 1000 });
        return {
          locator,
          strategy: 'role',
          confidence: 0.9,
          found: true,
        };
      } catch {
        continue;
      }
    }
    return null;
  }

  private async resolveByRoleValue(role: string): Promise<LocatorResolution> {
    try {
      const locator = this.page.getByRole(role as any);
      await locator.first().waitFor({ timeout: this.timeout });
      return {
        locator,
        strategy: 'role',
        confidence: 0.95,
        found: true,
      };
    } catch {
      return {
        locator: null,
        strategy: 'role',
        confidence: 0,
        found: false,
      };
    }
  }

  /**
   * Resolve by test ID
   */
  private async resolveByTestId(dslLocator: DslLocator): Promise<LocatorResolution | null> {
    // Try common test ID attributes
    const testIdAttrs = ['data-testid', 'data-test-id', 'data-cy', 'test-id'];
    
    for (const attr of testIdAttrs) {
      try {
        const locator = this.page.locator(`[${attr}]`).first();
        await locator.waitFor({ timeout: 1000 });
        return {
          locator,
          strategy: 'testId',
          confidence: 0.9,
          found: true,
        };
      } catch {
        continue;
      }
    }
    return null;
  }

  private async resolveByTestIdValue(testId: string): Promise<LocatorResolution> {
    try {
      const locator = this.page.getByTestId(testId);
      await locator.waitFor({ timeout: this.timeout });
      return {
        locator,
        strategy: 'testId',
        confidence: 0.95,
        found: true,
      };
    } catch {
      return {
        locator: null,
        strategy: 'testId',
        confidence: 0,
        found: false,
      };
    }
  }

  /**
   * Resolve by text content
   */
  private async resolveByText(dslLocator: DslLocator): Promise<LocatorResolution | null> {
    // Try to find by visible text
    try {
      const locator = this.page.locator('text=').first();
      await locator.waitFor({ timeout: 1000 });
      return {
        locator,
        strategy: 'text',
        confidence: 0.8,
        found: true,
      };
    } catch {
      return null;
    }
  }

  private async resolveByTextValue(text: string): Promise<LocatorResolution> {
    try {
      // Try exact text first
      let locator = this.page.getByText(text, { exact: true });
      try {
        await locator.waitFor({ timeout: this.timeout / 2 });
        return {
          locator,
          strategy: 'text',
          confidence: 0.95,
          found: true,
        };
      } catch {
        // Try partial text match
        locator = this.page.getByText(text);
        await locator.waitFor({ timeout: this.timeout / 2 });
        return {
          locator,
          strategy: 'text',
          confidence: 0.85,
          found: true,
        };
      }
    } catch {
      return {
        locator: null,
        strategy: 'text',
        confidence: 0,
        found: false,
      };
    }
  }

  /**
   * Resolve by CSS selector
   */
  private async resolveByCss(dslLocator: DslLocator): Promise<LocatorResolution | null> {
    // This is typically handled by primary/fallback locators
    return null;
  }

  private async resolveByCssValue(css: string): Promise<LocatorResolution> {
    try {
      const locator = this.page.locator(css);
      await locator.first().waitFor({ timeout: this.timeout });
      return {
        locator,
        strategy: 'css',
        confidence: 0.8,
        found: true,
      };
    } catch {
      return {
        locator: null,
        strategy: 'css',
        confidence: 0,
        found: false,
      };
    }
  }

  /**
   * Resolve by XPath
   */
  private async resolveByXPath(dslLocator: DslLocator): Promise<LocatorResolution | null> {
    // This is typically handled by primary/fallback locators
    return null;
  }

  private async resolveByXPathValue(xpath: string): Promise<LocatorResolution> {
    try {
      const locator = this.page.locator(`xpath=${xpath}`);
      await locator.first().waitFor({ timeout: this.timeout });
      return {
        locator,
        strategy: 'xpath',
        confidence: 0.7,
        found: true,
      };
    } catch {
      return {
        locator: null,
        strategy: 'xpath',
        confidence: 0,
        found: false,
      };
    }
  }

  /**
   * Wait for element to be ready for interaction
   */
  async waitForReady(locator: Locator): Promise<void> {
    await locator.waitFor({ state: 'visible', timeout: this.timeout });
    await locator.waitFor({ state: 'attached', timeout: this.timeout });
    
    // Additional wait for interactive elements
    try {
      await locator.waitFor({ state: 'enabled', timeout: 1000 });
    } catch {
      // Not all elements are interactive
    }
  }
} 