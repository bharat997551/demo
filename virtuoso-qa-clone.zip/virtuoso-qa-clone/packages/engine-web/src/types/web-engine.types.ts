import { Browser, BrowserContext, Page } from 'playwright';
import { Step } from '@hybrid-qa/dsl';

/**
 * Web engine configuration
 */
export interface WebEngineConfig {
  /** Browser type to use */
  browser: 'chromium' | 'firefox' | 'webkit';
  /** Whether to run in headless mode */
  headless: boolean;
  /** Browser viewport size */
  viewport: {
    width: number;
    height: number;
  };
  /** Default timeouts */
  timeouts: {
    /** Default timeout for actions */
    action: number;
    /** Navigation timeout */
    navigation: number;
    /** Element wait timeout */
    element: number;
  };
  /** Screenshots configuration */
  screenshots: {
    /** Take screenshots on failure */
    onFailure: boolean;
    /** Take screenshots on success */
    onSuccess: boolean;
    /** Take screenshots for each step */
    onStep: boolean;
    /** Screenshot quality (0-100) */
    quality: number;
  };
  /** Video recording configuration */
  video: {
    /** Enable video recording */
    enabled: boolean;
    /** Video directory */
    dir: string;
    /** Video size */
    size: {
      width: number;
      height: number;
    };
  };
  /** Locator resolution strategy */
  locatorStrategy: {
    /** Timeout for locator resolution */
    timeout: number;
    /** Retry attempts */
    retries: number;
    /** Auto-wait for elements */
    autoWait: boolean;
  };
}

/**
 * Recording session configuration
 */
export interface RecordingConfig {
  /** Base URL to start recording from */
  baseUrl?: string;
  /** Whether to record network requests */
  recordNetwork: boolean;
  /** Whether to record console messages */
  recordConsole: boolean;
  /** Actions to exclude from recording */
  excludeActions: string[];
  /** CSS selectors to ignore */
  ignoreSelectors: string[];
}

/**
 * Recorded interaction data
 */
export interface RecordedInteraction {
  /** Timestamp of the interaction */
  timestamp: number;
  /** Type of interaction */
  type: 'click' | 'type' | 'navigate' | 'select' | 'check' | 'uncheck' | 'hover';
  /** Element selector information */
  selector: {
    /** CSS selector */
    css?: string;
    /** XPath selector */
    xpath?: string;
    /** Text content */
    text?: string;
    /** Role-based selector */
    role?: string;
    /** Test ID */
    testId?: string;
  };
  /** Interaction value (for type, select, etc.) */
  value?: string;
  /** Page URL when interaction occurred */
  url: string;
  /** Element attributes */
  attributes?: Record<string, string>;
  /** Generated DSL step */
  dslStep: Step;
}

/**
 * Recording session state
 */
export interface RecordingSession {
  /** Session ID */
  id: string;
  /** Session start time */
  startTime: Date;
  /** Current page URL */
  currentUrl: string;
  /** Recorded interactions */
  interactions: RecordedInteraction[];
  /** Browser context */
  context: BrowserContext;
  /** Current page */
  page: Page;
  /** Recording configuration */
  config: RecordingConfig;
}

/**
 * Locator resolution result
 */
export interface LocatorResolution {
  /** Resolved Playwright locator */
  locator: any;
  /** Strategy used for resolution */
  strategy: 'role' | 'text' | 'testId' | 'css' | 'xpath';
  /** Confidence score (0-1) */
  confidence: number;
  /** Whether element was found */
  found: boolean;
}

/**
 * Step execution context for web engine
 */
export interface WebStepContext {
  /** Current page */
  page: Page;
  /** Browser context */
  context: BrowserContext;
  /** Artifact directory */
  artifactDir: string;
  /** Screenshot settings */
  screenshots: {
    onFailure: boolean;
    onSuccess: boolean;
    onStep: boolean;
  };
  /** Step timeout */
  timeout: number;
  /** Variables for interpolation */
  variables: Record<string, any>;
}

/**
 * Code generation options
 */
export interface CodeGenOptions {
  /** Target language */
  language: 'typescript' | 'javascript';
  /** Whether to include imports */
  includeImports: boolean;
  /** Whether to use async/await */
  useAsync: boolean;
  /** Indentation style */
  indent: 'spaces' | 'tabs';
  /** Number of spaces/tabs for indentation */
  indentSize: number;
  /** Whether to include comments */
  includeComments: boolean;
}

/**
 * Generated code result
 */
export interface GeneratedCode {
  /** Generated code string */
  code: string;
  /** Imports required */
  imports: string[];
  /** Functions/methods generated */
  functions: string[];
} 