#!/usr/bin/env node

import { WebEngineServer } from './server/web-engine-server';
import { logger } from '@hybrid-qa/common';

async function main() {
  const config = {
    port: parseInt(process.env.WEB_ENGINE_PORT || '3000'),
    wsPort: parseInt(process.env.WEB_ENGINE_WS_PORT || '3001'),
    corsOrigin: process.env.WEB_ENGINE_CORS_ORIGIN || '*',
    webEngineConfig: {
      browser: (process.env.WEB_ENGINE_BROWSER || 'chromium') as 'chromium' | 'firefox' | 'webkit',
      headless: process.env.WEB_ENGINE_HEADLESS === 'true',
      viewport: {
        width: parseInt(process.env.WEB_ENGINE_VIEWPORT_WIDTH || '1280'),
        height: parseInt(process.env.WEB_ENGINE_VIEWPORT_HEIGHT || '720'),
      },
      timeouts: {
        action: parseInt(process.env.WEB_ENGINE_ACTION_TIMEOUT || '30000'),
        navigation: parseInt(process.env.WEB_ENGINE_NAVIGATION_TIMEOUT || '60000'),
        element: parseInt(process.env.WEB_ENGINE_ELEMENT_TIMEOUT || '30000'),
      },
      screenshots: {
        onFailure: process.env.WEB_ENGINE_SCREENSHOTS_ON_FAILURE === 'true',
        onSuccess: process.env.WEB_ENGINE_SCREENSHOTS_ON_SUCCESS === 'true',
        onStep: process.env.WEB_ENGINE_SCREENSHOTS_ON_STEP === 'true',
        quality: parseInt(process.env.WEB_ENGINE_SCREENSHOT_QUALITY || '90'),
      },
      video: {
        enabled: process.env.WEB_ENGINE_VIDEO_ENABLED === 'true',
        dir: process.env.WEB_ENGINE_VIDEO_DIR || './artifacts/videos',
        size: {
          width: parseInt(process.env.WEB_ENGINE_VIDEO_WIDTH || '1280'),
          height: parseInt(process.env.WEB_ENGINE_VIDEO_HEIGHT || '720'),
        },
      },
    },
  };

  const server = new WebEngineServer(config);

  // Handle graceful shutdown
  const shutdown = async (signal: string) => {
    logger.info(`Received ${signal}, shutting down gracefully`);
    try {
      await server.stop();
      process.exit(0);
    } catch (error) {
      logger.error('Error during shutdown', { error });
      process.exit(1);
    }
  };

  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));

  try {
    await server.start();
    logger.info('Web Engine Server is running successfully', {
      httpPort: config.port,
      wsPort: config.wsPort,
    });
  } catch (error) {
    logger.error('Failed to start Web Engine Server', { error });
    process.exit(1);
  }
}

// Run if this is the main module
if (require.main === module) {
  main().catch((error) => {
    logger.error('Unhandled error in main', { error });
    process.exit(1);
  });
} 