import { Browser, BrowserContext, Page, chromium } from 'playwright';
import { Step } from '@hybrid-qa/dsl';
import { logger } from '@hybrid-qa/common';
import { EventEmitter } from 'events';
import { v4 as uuidv4 } from 'uuid';
import { WebSocket } from 'ws';
import {
  RecordingConfig,
  RecordedInteraction,
  RecordingSession,
  WebEngineConfig,
} from '../types/web-engine.types';

export class WebRecorder extends EventEmitter {
  private browser: Browser | null = null;
  private sessions = new Map<string, RecordingSession>();
  private webSocketConnections = new Set<WebSocket>();

  constructor(private config: Partial<WebEngineConfig> = {}) {
    super();
    this.config = {
      browser: 'chromium',
      headless: false, // Recording typically needs visible browser
      viewport: { width: 1280, height: 720 },
      timeouts: { action: 30000, navigation: 60000, element: 30000 },
      screenshots: { onFailure: true, onSuccess: false, onStep: false, quality: 90 },
      video: { enabled: true, dir: './artifacts/recordings', size: { width: 1280, height: 720 } },
      locatorStrategy: { timeout: 30000, retries: 3, autoWait: true },
      ...config,
    };
  }

  async initialize(): Promise<void> {
    try {
      logger.info('Initializing Web Recorder');
      
      this.browser = await chromium.launch({
        headless: this.config.headless,
      });

      logger.info('Web Recorder initialized successfully');
    } catch (error) {
      logger.error('Failed to initialize Web Recorder', { error });
      throw error;
    }
  }

  async cleanup(): Promise<void> {
    try {
      // Stop all recording sessions
      for (const [sessionId, session] of this.sessions) {
        await this.stopRecording(sessionId);
      }

      if (this.browser) {
        await this.browser.close();
        this.browser = null;
      }

      // Close all WebSocket connections
      for (const ws of this.webSocketConnections) {
        ws.close();
      }
      this.webSocketConnections.clear();

      logger.info('Web Recorder cleaned up successfully');
    } catch (error) {
      logger.error('Error during Web Recorder cleanup', { error });
    }
  }

  /**
   * Start a new recording session
   */
  async startRecording(config: RecordingConfig): Promise<string> {
    if (!this.browser) {
      throw new Error('Recorder not initialized');
    }

    const sessionId = uuidv4();
    
    try {
      // Create new browser context for isolation
      const context = await this.browser.newContext({
        viewport: this.config.viewport,
        recordVideo: this.config.video?.enabled
          ? {
              dir: this.config.video.dir,
              size: this.config.video.size,
            }
          : undefined,
      });

      const page = await context.newPage();

      const session: RecordingSession = {
        id: sessionId,
        startTime: new Date(),
        currentUrl: '',
        interactions: [],
        context,
        page,
        config,
      };

      // Set up event listeners for recording
      await this.setupRecordingListeners(session);

      // Navigate to base URL if provided
      if (config.baseUrl) {
        await page.goto(config.baseUrl);
        session.currentUrl = config.baseUrl;
      }

      this.sessions.set(sessionId, session);

      logger.info('Recording session started', { sessionId });
      this.emit('recording:started', { sessionId, config });

      return sessionId;
    } catch (error) {
      logger.error('Failed to start recording session', { error });
      throw error;
    }
  }

  /**
   * Stop recording session and return recorded interactions
   */
  async stopRecording(sessionId: string): Promise<RecordedInteraction[]> {
    const session = this.sessions.get(sessionId);
    if (!session) {
      throw new Error(`Recording session not found: ${sessionId}`);
    }

    try {
      // Close browser context
      await session.context.close();

      // Remove session
      this.sessions.delete(sessionId);

      logger.info('Recording session stopped', { sessionId, interactionCount: session.interactions.length });
      this.emit('recording:stopped', { sessionId, interactions: session.interactions });

      return session.interactions;
    } catch (error) {
      logger.error('Failed to stop recording session', { sessionId, error });
      throw error;
    }
  }

  /**
   * Get current recording session status
   */
  getSessionStatus(sessionId: string): RecordingSession | null {
    return this.sessions.get(sessionId) || null;
  }

  /**
   * Get all active recording sessions
   */
  getActiveSessions(): RecordingSession[] {
    return Array.from(this.sessions.values());
  }

  /**
   * Add WebSocket connection for streaming recorded steps
   */
  addWebSocketConnection(ws: WebSocket): void {
    this.webSocketConnections.add(ws);
    
    ws.on('close', () => {
      this.webSocketConnections.delete(ws);
    });

    ws.on('error', (error) => {
      logger.error('WebSocket error', { error });
      this.webSocketConnections.delete(ws);
    });
  }

  /**
   * Broadcast interaction to all connected WebSocket clients
   */
  private broadcastInteraction(interaction: RecordedInteraction): void {
    const message = JSON.stringify({
      type: 'interaction',
      data: interaction,
    });

    for (const ws of this.webSocketConnections) {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(message);
      }
    }
  }

  /**
   * Set up event listeners for recording user interactions
   */
  private async setupRecordingListeners(session: RecordingSession): Promise<void> {
    const { page, config } = session;

    // Record navigation events
    page.on('framenavigated', async (frame) => {
      if (frame === page.mainFrame()) {
        const url = frame.url();
        session.currentUrl = url;

        const interaction = await this.createNavigationInteraction(url, session);
        session.interactions.push(interaction);
        this.broadcastInteraction(interaction);
      }
    });

    // Record click events
    await page.exposeFunction('__recordClick', async (eventData: any) => {
      if (this.shouldIgnoreElement(eventData.selector, config)) return;

      const interaction = await this.createClickInteraction(eventData, session);
      session.interactions.push(interaction);
      this.broadcastInteraction(interaction);
    });

    // Record type events
    await page.exposeFunction('__recordType', async (eventData: any) => {
      if (this.shouldIgnoreElement(eventData.selector, config)) return;

      const interaction = await this.createTypeInteraction(eventData, session);
      session.interactions.push(interaction);
      this.broadcastInteraction(interaction);
    });

    // Record select events
    await page.exposeFunction('__recordSelect', async (eventData: any) => {
      if (this.shouldIgnoreElement(eventData.selector, config)) return;

      const interaction = await this.createSelectInteraction(eventData, session);
      session.interactions.push(interaction);
      this.broadcastInteraction(interaction);
    });

    // Record check/uncheck events
    await page.exposeFunction('__recordCheck', async (eventData: any) => {
      if (this.shouldIgnoreElement(eventData.selector, config)) return;

      const interaction = await this.createCheckInteraction(eventData, session);
      session.interactions.push(interaction);
      this.broadcastInteraction(interaction);
    });

    // Inject recording script into page
    await page.addInitScript(() => {
      // Track clicks
      document.addEventListener('click', (e) => {
        const target = e.target as Element;
        if (!target) return;

        const selector = generateSelector(target);
        const attributes = getElementAttributes(target);

        (window as any).__recordClick({
          selector,
          attributes,
          timestamp: Date.now(),
          elementType: target.tagName.toLowerCase(),
        });
      });

      // Track input changes
      document.addEventListener('input', (e) => {
        const target = e.target as HTMLInputElement | HTMLTextAreaElement;
        if (!target || !target.value) return;

        const selector = generateSelector(target);
        const attributes = getElementAttributes(target);

        (window as any).__recordType({
          selector,
          value: target.value,
          attributes,
          timestamp: Date.now(),
          elementType: target.tagName.toLowerCase(),
        });
      });

      // Track select changes
      document.addEventListener('change', (e) => {
        const target = e.target as HTMLSelectElement;
        if (!target || target.tagName !== 'SELECT') return;

        const selector = generateSelector(target);
        const attributes = getElementAttributes(target);

        (window as any).__recordSelect({
          selector,
          value: target.value,
          text: target.options[target.selectedIndex]?.text,
          attributes,
          timestamp: Date.now(),
        });
      });

      // Track checkbox/radio changes
      document.addEventListener('change', (e) => {
        const target = e.target as HTMLInputElement;
        if (!target || (target.type !== 'checkbox' && target.type !== 'radio')) return;

        const selector = generateSelector(target);
        const attributes = getElementAttributes(target);

        (window as any).__recordCheck({
          selector,
          checked: target.checked,
          type: target.type,
          attributes,
          timestamp: Date.now(),
        });
      });

      // Helper function to generate CSS selectors
      function generateSelector(element: Element): any {
        const selectors: any = {};

        // CSS selector
        selectors.css = generateCssSelector(element);

        // Test ID
        const testId = element.getAttribute('data-testid') || 
                     element.getAttribute('data-test-id') ||
                     element.getAttribute('data-cy') ||
                     element.getAttribute('test-id');
        if (testId) {
          selectors.testId = testId;
        }

        // Text content
        const text = element.textContent?.trim();
        if (text && text.length < 100) {
          selectors.text = text;
        }

        // Role
        const role = element.getAttribute('role') || getImplicitRole(element);
        if (role) {
          selectors.role = role;
        }

        return selectors;
      }

      function generateCssSelector(element: Element): string {
        if (element.id) {
          return `#${element.id}`;
        }

        if (element.className) {
          const classes = element.className.trim().split(/\s+/).join('.');
          if (classes) {
            return `.${classes}`;
          }
        }

        // Generate path-based selector
        const path: string[] = [];
        let current: Element | null = element;

        while (current && current !== document.body) {
          let selector = current.tagName.toLowerCase();
          
          if (current.id) {
            selector += `#${current.id}`;
            path.unshift(selector);
            break;
          }

          const siblings = Array.from(current.parentElement?.children || []);
          const sameTagSiblings = siblings.filter(s => s.tagName === current!.tagName);
          
          if (sameTagSiblings.length > 1) {
            const index = sameTagSiblings.indexOf(current) + 1;
            selector += `:nth-of-type(${index})`;
          }

          path.unshift(selector);
          current = current.parentElement;
        }

        return path.join(' > ');
      }

      function getElementAttributes(element: Element): Record<string, string> {
        const attrs: Record<string, string> = {};
        for (const attr of element.attributes) {
          attrs[attr.name] = attr.value;
        }
        return attrs;
      }

      function getImplicitRole(element: Element): string | null {
        const tagName = element.tagName.toLowerCase();
        const type = element.getAttribute('type');

        switch (tagName) {
          case 'button':
            return 'button';
          case 'a':
            return element.hasAttribute('href') ? 'link' : null;
          case 'input':
            switch (type) {
              case 'button':
              case 'submit':
              case 'reset':
                return 'button';
              case 'checkbox':
                return 'checkbox';
              case 'radio':
                return 'radio';
              case 'text':
              case 'email':
              case 'password':
              case 'search':
              case 'tel':
              case 'url':
                return 'textbox';
              default:
                return null;
            }
          case 'textarea':
            return 'textbox';
          case 'select':
            return 'combobox';
          default:
            return null;
        }
      }
    });
  }

  private shouldIgnoreElement(selector: any, config: RecordingConfig): boolean {
    if (!selector.css) return false;

    // Check if selector matches ignore patterns
    return config.ignoreSelectors.some(pattern => {
      return selector.css.includes(pattern);
    });
  }

  private async createNavigationInteraction(url: string, session: RecordingSession): Promise<RecordedInteraction> {
    const dslStep: Step = {
      id: uuidv4(),
      name: `Navigate to ${url}`,
      kind: 'web.navigate',
      engine: 'web',
      options: { url },
      retryCount: 0,
      retryDelay: 1000,
    };

    return {
      timestamp: Date.now(),
      type: 'navigate',
      selector: {},
      url,
      dslStep,
    };
  }

  private async createClickInteraction(eventData: any, session: RecordingSession): Promise<RecordedInteraction> {
    const dslStep: Step = {
      id: uuidv4(),
      name: `Click ${eventData.elementType}`,
      kind: 'web.click',
      engine: 'web',
      locator: {
        primary: { strategy: 'css', value: eventData.selector.css },
        fallbacks: this.generateFallbackLocators(eventData.selector),
      },
      retryCount: 2,
      retryDelay: 1000,
    };

    return {
      timestamp: eventData.timestamp,
      type: 'click',
      selector: eventData.selector,
      url: session.currentUrl,
      attributes: eventData.attributes,
      dslStep,
    };
  }

  private async createTypeInteraction(eventData: any, session: RecordingSession): Promise<RecordedInteraction> {
    const dslStep: Step = {
      id: uuidv4(),
      name: `Type "${eventData.value}"`,
      kind: 'web.type',
      engine: 'web',
      locator: {
        primary: { strategy: 'css', value: eventData.selector.css },
        fallbacks: this.generateFallbackLocators(eventData.selector),
      },
      options: { text: eventData.value },
      retryCount: 2,
      retryDelay: 1000,
    };

    return {
      timestamp: eventData.timestamp,
      type: 'type',
      selector: eventData.selector,
      value: eventData.value,
      url: session.currentUrl,
      attributes: eventData.attributes,
      dslStep,
    };
  }

  private async createSelectInteraction(eventData: any, session: RecordingSession): Promise<RecordedInteraction> {
    const dslStep: Step = {
      id: uuidv4(),
      name: `Select "${eventData.text || eventData.value}"`,
      kind: 'web.select',
      engine: 'web',
      locator: {
        primary: { strategy: 'css', value: eventData.selector.css },
        fallbacks: this.generateFallbackLocators(eventData.selector),
      },
      options: {
        value: eventData.value,
        text: eventData.text,
      },
      retryCount: 2,
      retryDelay: 1000,
    };

    return {
      timestamp: eventData.timestamp,
      type: 'select',
      selector: eventData.selector,
      value: eventData.value,
      url: session.currentUrl,
      attributes: eventData.attributes,
      dslStep,
    };
  }

  private async createCheckInteraction(eventData: any, session: RecordingSession): Promise<RecordedInteraction> {
    const action = eventData.checked ? 'check' : 'uncheck';
    const dslStep: Step = {
      id: uuidv4(),
      name: `${action} ${eventData.type}`,
      kind: `web.${action}`,
      engine: 'web',
      locator: {
        primary: { strategy: 'css', value: eventData.selector.css },
        fallbacks: this.generateFallbackLocators(eventData.selector),
      },
      retryCount: 2,
      retryDelay: 1000,
    };

    return {
      timestamp: eventData.timestamp,
      type: eventData.checked ? 'check' : 'uncheck',
      selector: eventData.selector,
      url: session.currentUrl,
      attributes: eventData.attributes,
      dslStep,
    };
  }

  private generateFallbackLocators(selector: any): Array<{ strategy: string; value: string }> {
    const fallbacks: Array<{ strategy: string; value: string }> = [];

    if (selector.testId) {
      fallbacks.push({ strategy: 'testid', value: selector.testId });
    }

    if (selector.text && selector.text.length < 50) {
      fallbacks.push({ strategy: 'text', value: selector.text });
    }

    if (selector.role) {
      fallbacks.push({ strategy: 'role', value: selector.role });
    }

    return fallbacks;
  }
} 