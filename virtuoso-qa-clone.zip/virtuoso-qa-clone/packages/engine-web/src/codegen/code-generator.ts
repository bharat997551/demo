import { Step } from '@hybrid-qa/dsl';
import { RecordedInteraction, CodeGenOptions, GeneratedCode } from '../types/web-engine.types';

export class CodeGenerator {
  private readonly defaultOptions: CodeGenOptions = {
    language: 'typescript',
    includeImports: true,
    useAsync: true,
    indent: 'spaces',
    indentSize: 2,
    includeComments: true,
  };

  async generateFromInteractions(
    interactions: RecordedInteraction[],
    options: Partial<CodeGenOptions> = {}
  ): Promise<GeneratedCode> {
    const opts = { ...this.defaultOptions, ...options };
    const steps = interactions.map(interaction => interaction.dslStep);
    return this.generateFromDslSteps(steps, opts);
  }

  async generateFromDslSteps(
    steps: Step[],
    options: Partial<CodeGenOptions> = {}
  ): Promise<GeneratedCode> {
    const opts = { ...this.defaultOptions, ...options };
    const indent = this.getIndentString(opts);

    let code = '';
    const imports: string[] = [];
    const functions: string[] = [];

    // Add imports
    if (opts.includeImports) {
      if (opts.language === 'typescript') {
        imports.push("import { test, expect, Page } from '@playwright/test';");
      } else {
        imports.push("const { test, expect } = require('@playwright/test');");
      }
      code += imports.join('\n') + '\n\n';
    }

    // Generate test function
    const asyncKeyword = opts.useAsync ? 'async ' : '';
    const functionName = 'generatedTest';
    
    if (opts.language === 'typescript') {
      code += `test('${functionName}', ${asyncKeyword}({ page }: { page: Page }) => {\n`;
    } else {
      code += `test('${functionName}', ${asyncKeyword}({ page }) => {\n`;
    }

    functions.push(functionName);

    // Add comments
    if (opts.includeComments) {
      code += `${indent}// Generated test from recorded interactions\n`;
      code += `${indent}// Total steps: ${steps.length}\n\n`;
    }

    // Generate code for each step
    for (let i = 0; i < steps.length; i++) {
      const step = steps[i];
      const stepCode = this.generateStepCode(step, opts);
      
      if (opts.includeComments) {
        code += `${indent}// Step ${i + 1}: ${step.name || step.kind}\n`;
      }
      
      code += stepCode.split('\n').map(line => line ? indent + line : '').join('\n') + '\n';
      
      if (i < steps.length - 1) {
        code += '\n';
      }
    }

    code += '});\n';

    return {
      code,
      imports,
      functions,
    };
  }

  private generateStepCode(step: Step, options: CodeGenOptions): string {
    const awaitKeyword = options.useAsync ? 'await ' : '';
    
    switch (step.kind) {
      case 'web.navigate':
        return this.generateNavigateCode(step, awaitKeyword);
      
      case 'web.click':
        return this.generateClickCode(step, awaitKeyword, options);
      
      case 'web.type':
        return this.generateTypeCode(step, awaitKeyword, options);
      
      case 'web.clear':
        return this.generateClearCode(step, awaitKeyword, options);
      
      case 'web.select':
        return this.generateSelectCode(step, awaitKeyword, options);
      
      case 'web.check':
        return this.generateCheckCode(step, awaitKeyword, options);
      
      case 'web.uncheck':
        return this.generateUncheckCode(step, awaitKeyword, options);
      
      case 'web.hover':
        return this.generateHoverCode(step, awaitKeyword, options);
      
      case 'web.scroll':
        return this.generateScrollCode(step, awaitKeyword, options);
      
      case 'web.wait':
        return this.generateWaitCode(step, awaitKeyword);
      
      case 'web.exists':
        return this.generateExistsCode(step, awaitKeyword, options);
      
      case 'web.getText':
        return this.generateGetTextCode(step, awaitKeyword, options);
      
      case 'web.getAttribute':
        return this.generateGetAttributeCode(step, awaitKeyword, options);
      
      case 'web.screenshot':
        return this.generateScreenshotCode(step, awaitKeyword);
      
      case 'web.refresh':
        return this.generateRefreshCode(step, awaitKeyword);
      
      case 'web.goBack':
        return this.generateGoBackCode(step, awaitKeyword);
      
      case 'web.goForward':
        return this.generateGoForwardCode(step, awaitKeyword);
      
      default:
        return `// Unsupported step kind: ${step.kind}`;
    }
  }

  private generateNavigateCode(step: Step, awaitKeyword: string): string {
    const url = step.options?.url || '';
    return `${awaitKeyword}page.goto('${url}');`;
  }

  private generateClickCode(step: Step, awaitKeyword: string, options: CodeGenOptions): string {
    const locator = this.generateLocatorCode(step, options);
    return `${awaitKeyword}${locator}.click();`;
  }

  private generateTypeCode(step: Step, awaitKeyword: string, options: CodeGenOptions): string {
    const locator = this.generateLocatorCode(step, options);
    const text = step.options?.text || '';
    return `${awaitKeyword}${locator}.fill('${this.escapeString(text)}');`;
  }

  private generateClearCode(step: Step, awaitKeyword: string, options: CodeGenOptions): string {
    const locator = this.generateLocatorCode(step, options);
    return `${awaitKeyword}${locator}.clear();`;
  }

  private generateSelectCode(step: Step, awaitKeyword: string, options: CodeGenOptions): string {
    const locator = this.generateLocatorCode(step, options);
    
    if (step.options?.value) {
      return `${awaitKeyword}${locator}.selectOption({ value: '${this.escapeString(step.options.value)}' });`;
    } else if (step.options?.text) {
      return `${awaitKeyword}${locator}.selectOption({ label: '${this.escapeString(step.options.text)}' });`;
    }
    
    return `${awaitKeyword}${locator}.selectOption();`;
  }

  private generateCheckCode(step: Step, awaitKeyword: string, options: CodeGenOptions): string {
    const locator = this.generateLocatorCode(step, options);
    return `${awaitKeyword}${locator}.check();`;
  }

  private generateUncheckCode(step: Step, awaitKeyword: string, options: CodeGenOptions): string {
    const locator = this.generateLocatorCode(step, options);
    return `${awaitKeyword}${locator}.uncheck();`;
  }

  private generateHoverCode(step: Step, awaitKeyword: string, options: CodeGenOptions): string {
    const locator = this.generateLocatorCode(step, options);
    return `${awaitKeyword}${locator}.hover();`;
  }

  private generateScrollCode(step: Step, awaitKeyword: string, options: CodeGenOptions): string {
    if (step.locator) {
      const locator = this.generateLocatorCode(step, options);
      return `${awaitKeyword}${locator}.scrollIntoViewIfNeeded();`;
    } else {
      const x = step.options?.x || 0;
      const y = step.options?.y || 0;
      return `${awaitKeyword}page.evaluate(() => window.scrollTo(${x}, ${y}));`;
    }
  }

  private generateWaitCode(step: Step, awaitKeyword: string): string {
    const duration = step.options?.duration || 1000;
    return `${awaitKeyword}page.waitForTimeout(${duration});`;
  }

  private generateExistsCode(step: Step, awaitKeyword: string, options: CodeGenOptions): string {
    const locator = this.generateLocatorCode(step, options);
    return `const exists = ${awaitKeyword}${locator}.isVisible();`;
  }

  private generateGetTextCode(step: Step, awaitKeyword: string, options: CodeGenOptions): string {
    const locator = this.generateLocatorCode(step, options);
    return `const text = ${awaitKeyword}${locator}.textContent();`;
  }

  private generateGetAttributeCode(step: Step, awaitKeyword: string, options: CodeGenOptions): string {
    const locator = this.generateLocatorCode(step, options);
    const attribute = step.options?.attribute || '';
    return `const attr = ${awaitKeyword}${locator}.getAttribute('${attribute}');`;
  }

  private generateScreenshotCode(step: Step, awaitKeyword: string): string {
    const name = step.options?.name || 'screenshot';
    return `${awaitKeyword}page.screenshot({ path: '${name}.png' });`;
  }

  private generateRefreshCode(step: Step, awaitKeyword: string): string {
    return `${awaitKeyword}page.reload();`;
  }

  private generateGoBackCode(step: Step, awaitKeyword: string): string {
    return `${awaitKeyword}page.goBack();`;
  }

  private generateGoForwardCode(step: Step, awaitKeyword: string): string {
    return `${awaitKeyword}page.goForward();`;
  }

  private generateLocatorCode(step: Step, options: CodeGenOptions): string {
    if (!step.locator) {
      return 'page.locator("body")'; // Fallback
    }

    const { primary, fallbacks } = step.locator;
    
    if (primary) {
      switch (primary.strategy) {
        case 'role':
          return `page.getByRole('${primary.value}')`;
        
        case 'testid':
        case 'test-id':
          return `page.getByTestId('${primary.value}')`;
        
        case 'text':
          return `page.getByText('${this.escapeString(primary.value)}')`;
        
        case 'css':
          return `page.locator('${this.escapeString(primary.value)}')`;
        
        case 'xpath':
          return `page.locator('xpath=${this.escapeString(primary.value)}')`;
        
        default:
          return `page.locator('${this.escapeString(primary.value)}')`;
      }
    }

    // Fallback to CSS if no primary
    return 'page.locator("body")';
  }

  private getIndentString(options: CodeGenOptions): string {
    if (options.indent === 'tabs') {
      return '\t';
    }
    return ' '.repeat(options.indentSize);
  }

  private escapeString(str: string): string {
    return str
      .replace(/\\/g, '\\\\')
      .replace(/'/g, "\\'")
      .replace(/"/g, '\\"')
      .replace(/\n/g, '\\n')
      .replace(/\r/g, '\\r')
      .replace(/\t/g, '\\t');
  }

  /**
   * Generate a complete Playwright test file
   */
  async generateTestFile(
    interactions: RecordedInteraction[],
    options: Partial<CodeGenOptions> & { testName?: string } = {}
  ): Promise<string> {
    const opts = { ...this.defaultOptions, ...options };
    const code = await this.generateFromInteractions(interactions, opts);
    
    let content = '';
    
    // Add file header comment
    if (opts.includeComments) {
      content += '// Generated by Hybrid QA Web Engine Recorder\n';
      content += `// Generated on: ${new Date().toISOString()}\n`;
      content += `// Total interactions: ${interactions.length}\n\n`;
    }

    content += code.code;
    
    return content;
  }

  /**
   * Generate Page Object Model code
   */
  async generatePageObjectModel(
    interactions: RecordedInteraction[],
    options: Partial<CodeGenOptions> & { className?: string } = {}
  ): Promise<GeneratedCode> {
    const opts = { ...this.defaultOptions, ...options };
    const className = options.className || 'GeneratedPage';
    const indent = this.getIndentString(opts);

    let code = '';
    const imports: string[] = [];
    const functions: string[] = [];

    // Add imports
    if (opts.includeImports) {
      if (opts.language === 'typescript') {
        imports.push("import { Page } from '@playwright/test';");
      } else {
        imports.push("const { Page } = require('@playwright/test');");
      }
      code += imports.join('\n') + '\n\n';
    }

    // Class definition
    if (opts.language === 'typescript') {
      code += `export class ${className} {\n`;
      code += `${indent}constructor(private page: Page) {}\n\n`;
    } else {
      code += `class ${className} {\n`;
      code += `${indent}constructor(page) {\n`;
      code += `${indent}${indent}this.page = page;\n`;
      code += `${indent}}\n\n`;
    }

    // Generate methods for each unique action
    const uniqueActions = this.groupInteractionsByAction(interactions);
    
    for (const [actionName, actionInteractions] of uniqueActions) {
      const methodName = this.generateMethodName(actionName);
      const methodCode = this.generatePageObjectMethod(actionInteractions[0], opts);
      
      functions.push(methodName);
      code += methodCode + '\n\n';
    }

    code += '}\n';

    // Export for CommonJS
    if (opts.language === 'javascript') {
      code += `\nmodule.exports = { ${className} };\n`;
    }

    return {
      code,
      imports,
      functions,
    };
  }

  private groupInteractionsByAction(interactions: RecordedInteraction[]): Map<string, RecordedInteraction[]> {
    const groups = new Map<string, RecordedInteraction[]>();
    
    for (const interaction of interactions) {
      const key = `${interaction.type}_${JSON.stringify(interaction.selector)}`;
      if (!groups.has(key)) {
        groups.set(key, []);
      }
      groups.get(key)!.push(interaction);
    }
    
    return groups;
  }

  private generateMethodName(actionKey: string): string {
    // Extract action type and create method name
    const action = actionKey.split('_')[0];
    return `perform${action.charAt(0).toUpperCase()}${action.slice(1)}`;
  }

  private generatePageObjectMethod(interaction: RecordedInteraction, options: CodeGenOptions): string {
    const step = interaction.dslStep;
    const indent = this.getIndentString(options);
    const awaitKeyword = options.useAsync ? 'await ' : '';
    const asyncKeyword = options.useAsync ? 'async ' : '';
    const methodName = this.generateMethodName(`${interaction.type}_${JSON.stringify(interaction.selector)}`);
    
    let code = `${indent}${asyncKeyword}${methodName}() {\n`;
    
    if (options.includeComments) {
      code += `${indent}${indent}// ${step.name || step.kind}\n`;
    }
    
    const stepCode = this.generateStepCode(step, options);
    code += stepCode.split('\n').map(line => line ? indent + indent + line : '').join('\n') + '\n';
    code += `${indent}}`;
    
    return code;
  }
} 