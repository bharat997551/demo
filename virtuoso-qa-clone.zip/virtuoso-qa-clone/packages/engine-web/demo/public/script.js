// Demo E-Commerce App JavaScript
class DemoApp {
    constructor() {
        this.currentUser = null;
        this.cart = [];
        this.products = [];
        this.currentPage = 'products';
        
        this.initializeProducts();
        this.setupEventListeners();
        this.updateUI();
    }

    initializeProducts() {
        this.products = [
            { id: 1, name: 'Laptop Pro', price: 999.99, category: 'electronics', emoji: '💻' },
            { id: 2, name: 'Wireless Headphones', price: 199.99, category: 'electronics', emoji: '🎧' },
            { id: 3, name: 'Smart Watch', price: 299.99, category: 'electronics', emoji: '⌚' },
            { id: 4, name: 'Cotton T-Shirt', price: 29.99, category: 'clothing', emoji: '👕' },
            { id: 5, name: 'Running Shoes', price: 89.99, category: 'clothing', emoji: '👟' },
            { id: 6, name: 'Winter Jacket', price: 149.99, category: 'clothing', emoji: '🧥' },
            { id: 7, name: 'JavaScript Guide', price: 39.99, category: 'books', emoji: '📚' },
            { id: 8, name: 'Design Patterns', price: 49.99, category: 'books', emoji: '📖' },
            { id: 9, name: 'Web Development', price: 34.99, category: 'books', emoji: '💡' }
        ];
        
        this.renderProducts();
    }

    setupEventListeners() {
        // Navigation
        document.getElementById('login-btn').addEventListener('click', () => this.showPage('login'));
        document.getElementById('logout-btn').addEventListener('click', () => this.logout());
        document.getElementById('cart-btn').addEventListener('click', () => this.toggleCartDropdown());
        
        // Login form
        document.getElementById('login-form').addEventListener('submit', (e) => this.handleLogin(e));
        document.getElementById('demo-fill-btn').addEventListener('click', () => this.fillDemoData());
        
        // Product filtering
        document.getElementById('category-filter').addEventListener('change', (e) => this.filterProducts(e.target.value));
        
        // Cart actions
        document.getElementById('view-cart-btn').addEventListener('click', () => {
            this.hideCartDropdown();
            this.showPage('cart');
        });
        document.getElementById('checkout-btn').addEventListener('click', () => this.showPage('checkout'));
        document.getElementById('clear-cart-btn').addEventListener('click', () => this.clearCart());
        
        // Checkout form
        document.getElementById('checkout-form').addEventListener('submit', (e) => this.handleCheckout(e));
        document.getElementById('back-to-cart-btn').addEventListener('click', () => this.showPage('cart'));
        
        // Order confirmation
        document.getElementById('continue-shopping-btn').addEventListener('click', () => this.showPage('products'));
        
        // Close cart dropdown when clicking outside
        document.addEventListener('click', (e) => {
            if (!e.target.closest('#cart-dropdown') && !e.target.closest('#cart-btn')) {
                this.hideCartDropdown();
            }
        });
    }

    showPage(pageName) {
        // Hide all pages
        document.querySelectorAll('.page').forEach(page => {
            page.classList.remove('active');
        });
        
        // Show selected page
        document.getElementById(`${pageName}-page`).classList.add('active');
        this.currentPage = pageName;
        
        // Update cart display if showing cart page
        if (pageName === 'cart') {
            this.renderCartItems();
        } else if (pageName === 'checkout') {
            this.renderCheckoutSummary();
        }
        
        this.hideCartDropdown();
    }

    handleLogin(event) {
        event.preventDefault();
        
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        
        // Simple demo validation
        if (username && password) {
            if ((username === 'demo' && password === 'demo') || 
                (username === 'test@example.com' && password === 'password123')) {
                
                this.currentUser = {
                    name: username === 'demo' ? 'Demo User' : 'Test User',
                    email: username === 'demo' ? 'demo@example.com' : 'test@example.com'
                };
                
                this.showNotification('Login successful!', 'success');
                this.updateUI();
                this.showPage('products');
            } else {
                this.showNotification('Invalid credentials. Try demo/demo or test@example.com/password123', 'error');
            }
        }
    }

    logout() {
        this.currentUser = null;
        this.cart = [];
        this.updateUI();
        this.showNotification('Logged out successfully', 'success');
        this.showPage('products');
    }

    fillDemoData() {
        document.getElementById('username').value = 'demo';
        document.getElementById('password').value = 'demo';
        document.getElementById('remember-me').checked = true;
    }

    updateUI() {
        const loginBtn = document.getElementById('login-btn');
        const logoutBtn = document.getElementById('logout-btn');
        const userName = document.getElementById('user-name');
        const cartCount = document.getElementById('cart-count');
        
        if (this.currentUser) {
            loginBtn.style.display = 'none';
            logoutBtn.style.display = 'inline-block';
            userName.style.display = 'inline';
            userName.textContent = `Welcome, ${this.currentUser.name}`;
        } else {
            loginBtn.style.display = 'inline-block';
            logoutBtn.style.display = 'none';
            userName.style.display = 'none';
        }
        
        cartCount.textContent = this.cart.reduce((total, item) => total + item.quantity, 0);
        this.updateCartDropdown();
    }

    renderProducts(filteredProducts = this.products) {
        const grid = document.getElementById('products-grid');
        grid.innerHTML = '';
        
        filteredProducts.forEach(product => {
            const productCard = document.createElement('div');
            productCard.className = 'product-card';
            productCard.setAttribute('data-testid', `product-${product.id}`);
            
            productCard.innerHTML = `
                <div class="product-image">${product.emoji}</div>
                <div class="product-name">${product.name}</div>
                <div class="product-price">$${product.price.toFixed(2)}</div>
                <div class="quantity-controls">
                    <button class="quantity-btn" onclick="app.changeQuantity(${product.id}, -1)" data-testid="decrease-qty-${product.id}">−</button>
                    <span class="quantity-display" id="qty-${product.id}">0</span>
                    <button class="quantity-btn" onclick="app.changeQuantity(${product.id}, 1)" data-testid="increase-qty-${product.id}">+</button>
                </div>
                <button class="btn btn-primary" onclick="app.addToCart(${product.id})" data-testid="add-to-cart-${product.id}" style="margin-top: 10px;">
                    Add to Cart
                </button>
            `;
            
            grid.appendChild(productCard);
        });
    }

    filterProducts(category) {
        const filtered = category ? 
            this.products.filter(p => p.category === category) : 
            this.products;
        this.renderProducts(filtered);
    }

    changeQuantity(productId, delta) {
        const qtyDisplay = document.getElementById(`qty-${productId}`);
        let currentQty = parseInt(qtyDisplay.textContent);
        currentQty = Math.max(0, currentQty + delta);
        qtyDisplay.textContent = currentQty;
    }

    addToCart(productId) {
        const product = this.products.find(p => p.id === productId);
        const qtyElement = document.getElementById(`qty-${productId}`);
        const quantity = parseInt(qtyElement.textContent) || 1;
        
        if (!product) return;
        
        const existingItem = this.cart.find(item => item.productId === productId);
        
        if (existingItem) {
            existingItem.quantity += quantity;
        } else {
            this.cart.push({
                productId: productId,
                name: product.name,
                price: product.price,
                quantity: quantity
            });
        }
        
        // Reset quantity display
        qtyElement.textContent = '0';
        
        this.updateUI();
        this.showNotification(`${product.name} added to cart!`, 'success');
    }

    removeFromCart(productId) {
        this.cart = this.cart.filter(item => item.productId !== productId);
        this.updateUI();
        this.renderCartItems();
        this.showNotification('Item removed from cart', 'success');
    }

    updateCartQuantity(productId, newQuantity) {
        const item = this.cart.find(item => item.productId === productId);
        if (item) {
            if (newQuantity <= 0) {
                this.removeFromCart(productId);
            } else {
                item.quantity = newQuantity;
                this.updateUI();
                this.renderCartItems();
            }
        }
    }

    clearCart() {
        this.cart = [];
        this.updateUI();
        this.renderCartItems();
        this.showNotification('Cart cleared', 'success');
    }

    toggleCartDropdown() {
        const dropdown = document.getElementById('cart-dropdown');
        dropdown.classList.toggle('show');
    }

    hideCartDropdown() {
        document.getElementById('cart-dropdown').classList.remove('show');
    }

    updateCartDropdown() {
        const dropdownItems = document.getElementById('cart-dropdown-items');
        const dropdownTotal = document.getElementById('cart-dropdown-total');
        
        if (this.cart.length === 0) {
            dropdownItems.innerHTML = '<p style="text-align: center; color: #666;">Cart is empty</p>';
            dropdownTotal.textContent = '0.00';
            return;
        }
        
        dropdownItems.innerHTML = '';
        let total = 0;
        
        this.cart.forEach(item => {
            const itemElement = document.createElement('div');
            itemElement.className = 'cart-item';
            itemElement.innerHTML = `
                <div>
                    <div style="font-weight: 600;">${item.name}</div>
                    <div style="font-size: 12px; color: #666;">$${item.price.toFixed(2)} x ${item.quantity}</div>
                </div>
                <div style="font-weight: 600;">$${(item.price * item.quantity).toFixed(2)}</div>
            `;
            dropdownItems.appendChild(itemElement);
            total += item.price * item.quantity;
        });
        
        dropdownTotal.textContent = total.toFixed(2);
    }

    renderCartItems() {
        const cartItems = document.getElementById('cart-items');
        const cartTotal = document.getElementById('cart-total-amount');
        
        if (this.cart.length === 0) {
            cartItems.innerHTML = '<p style="text-align: center; color: #666; padding: 40px;">Your cart is empty</p>';
            cartTotal.textContent = '0.00';
            return;
        }
        
        cartItems.innerHTML = '';
        let total = 0;
        
        this.cart.forEach(item => {
            const itemElement = document.createElement('div');
            itemElement.className = 'card';
            itemElement.setAttribute('data-testid', `cart-item-${item.productId}`);
            itemElement.innerHTML = `
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <h4>${item.name}</h4>
                        <p>$${item.price.toFixed(2)} each</p>
                    </div>
                    <div style="display: flex; align-items: center; gap: 15px;">
                        <div class="quantity-controls">
                            <button class="quantity-btn" onclick="app.updateCartQuantity(${item.productId}, ${item.quantity - 1})" data-testid="decrease-cart-qty-${item.productId}">−</button>
                            <span class="quantity-display">${item.quantity}</span>
                            <button class="quantity-btn" onclick="app.updateCartQuantity(${item.productId}, ${item.quantity + 1})" data-testid="increase-cart-qty-${item.productId}">+</button>
                        </div>
                        <div style="font-weight: bold; font-size: 18px;">$${(item.price * item.quantity).toFixed(2)}</div>
                        <button class="btn btn-secondary" onclick="app.removeFromCart(${item.productId})" data-testid="remove-item-${item.productId}">Remove</button>
                    </div>
                </div>
            `;
            cartItems.appendChild(itemElement);
            total += item.price * item.quantity;
        });
        
        cartTotal.textContent = total.toFixed(2);
    }

    renderCheckoutSummary() {
        const total = this.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        document.getElementById('order-total').textContent = total.toFixed(2);
        
        // Pre-fill user info if logged in
        if (this.currentUser) {
            document.getElementById('shipping-name').value = this.currentUser.name;
            document.getElementById('shipping-email').value = this.currentUser.email;
        }
    }

    handleCheckout(event) {
        event.preventDefault();
        
        if (this.cart.length === 0) {
            this.showNotification('Cart is empty!', 'error');
            return;
        }
        
        // Simulate order processing
        const orderId = 'ORD' + Date.now().toString().slice(-6);
        const total = this.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        
        // Add shipping cost
        const shippingMethod = document.getElementById('shipping-method').value;
        let shippingCost = 0;
        switch (shippingMethod) {
            case 'standard': shippingCost = 5.99; break;
            case 'express': shippingCost = 12.99; break;
            case 'overnight': shippingCost = 24.99; break;
        }
        
        const finalTotal = total + shippingCost;
        
        // Show confirmation
        document.getElementById('order-id').textContent = orderId;
        document.getElementById('confirmation-total').textContent = finalTotal.toFixed(2);
        
        // Clear cart
        this.cart = [];
        this.updateUI();
        
        this.showPage('confirmation');
        this.showNotification('Order placed successfully!', 'success');
    }

    showNotification(message, type = 'success') {
        const notification = document.getElementById('notification');
        notification.textContent = message;
        notification.className = `notification ${type}`;
        notification.style.display = 'block';
        
        setTimeout(() => {
            notification.style.display = 'none';
        }, 3000);
    }
}

// Initialize the app
const app = new DemoApp(); 