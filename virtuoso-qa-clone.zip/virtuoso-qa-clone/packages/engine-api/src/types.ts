import { z } from 'zod';

// Base types
export type HttpMethod = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE' | 'HEAD' | 'OPTIONS';
export type ContentType = 'application/json' | 'application/xml' | 'text/plain' | 'application/x-www-form-urlencoded' | 'multipart/form-data';

// Authentication types
export const AuthConfigSchema = z.object({
  type: z.enum(['none', 'basic', 'bearer', 'apikey', 'oauth2', 'custom']),
  basic: z.object({
    username: z.string(),
    password: z.string(),
  }).optional(),
  bearer: z.object({
    token: z.string(),
  }).optional(),
  apikey: z.object({
    key: z.string(),
    value: z.string(),
    location: z.enum(['header', 'query', 'body']),
  }).optional(),
  oauth2: z.object({
    accessToken: z.string(),
    refreshToken: z.string().optional(),
    clientId: z.string().optional(),
    clientSecret: z.string().optional(),
  }).optional(),
  custom: z.object({
    headers: z.record(z.string()).optional(),
    query: z.record(z.string()).optional(),
  }).optional(),
});

export type AuthConfig = z.infer<typeof AuthConfigSchema>;

// Request configuration
export const RequestConfigSchema = z.object({
  url: z.string(),
  method: z.enum(['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS']).default('GET'),
  headers: z.record(z.string()).default({}),
  query: z.record(z.union([z.string(), z.number(), z.boolean()])).default({}),
  body: z.any().optional(),
  timeout: z.number().default(30000),
  followRedirects: z.boolean().default(true),
  validateSSL: z.boolean().default(true),
  auth: AuthConfigSchema.optional(),
});

export type RequestConfig = z.infer<typeof RequestConfigSchema>;

// GraphQL configuration
export const GraphQLConfigSchema = z.object({
  endpoint: z.string(),
  query: z.string(),
  variables: z.record(z.any()).default({}),
  operationName: z.string().optional(),
  headers: z.record(z.string()).default({}),
  auth: AuthConfigSchema.optional(),
});

export type GraphQLConfig = z.infer<typeof GraphQLConfigSchema>;

// gRPC configuration
export const GrpcConfigSchema = z.object({
  service: z.string(),
  method: z.string(),
  host: z.string(),
  port: z.number(),
  protoPath: z.string(),
  packageName: z.string(),
  serviceName: z.string(),
  metadata: z.record(z.string()).default({}),
  data: z.record(z.any()).default({}),
  timeout: z.number().default(30000),
  credentials: z.object({
    cert: z.string().optional(),
    key: z.string().optional(),
    ca: z.string().optional(),
  }).optional(),
});

export type GrpcConfig = z.infer<typeof GrpcConfigSchema>;

// WebSocket configuration
export const WebSocketConfigSchema = z.object({
  url: z.string(),
  protocols: z.array(z.string()).default([]),
  headers: z.record(z.string()).default({}),
  timeout: z.number().default(30000),
});

export type WebSocketConfig = z.infer<typeof WebSocketConfigSchema>;

// Response types
export interface ApiResponse {
  status: number;
  statusText: string;
  headers: Record<string, string>;
  body: any;
  rawBody: string;
  duration: number;
  timestamp: Date;
  url: string;
  method: string;
}

export interface GraphQLResponse {
  data?: any;
  errors?: Array<{
    message: string;
    locations?: Array<{ line: number; column: number }>;
    path?: Array<string | number>;
  }>;
  extensions?: any;
  duration: number;
  timestamp: Date;
}

export interface GrpcResponse {
  data: any;
  metadata: Record<string, string>;
  duration: number;
  timestamp: Date;
  status: {
    code: number;
    details: string;
  };
}

// Extraction configuration
export const ExtractionConfigSchema = z.object({
  type: z.enum(['jsonpath', 'xpath', 'regex', 'header', 'status']),
  expression: z.string(),
  attribute: z.string().optional(), // For XPath attribute extraction
  flags: z.string().optional(), // For regex flags
  multiple: z.boolean().default(false), // Extract all matches vs first match
  defaultValue: z.any().optional(),
});

export type ExtractionConfig = z.infer<typeof ExtractionConfigSchema>;

// Assertion configuration
export const AssertionConfigSchema = z.object({
  type: z.enum(['equals', 'not_equals', 'contains', 'not_contains', 'greater_than', 'less_than', 'regex', 'json_schema', 'status_code', 'response_time']),
  path: z.string().optional(), // JSONPath or XPath for nested assertions
  expected: z.any(),
  actual: z.any().optional(), // Can be set dynamically
  tolerance: z.number().optional(), // For numeric comparisons
  ignoreCase: z.boolean().default(false),
});

export type AssertionConfig = z.infer<typeof AssertionConfigSchema>;

// Template variables
export const VariableSchema = z.object({
  name: z.string(),
  value: z.any(),
  type: z.enum(['string', 'number', 'boolean', 'object', 'array']).default('string'),
  secure: z.boolean().default(false), // Marks sensitive data
});

export type Variable = z.infer<typeof VariableSchema>;

// Template context
export interface TemplateContext {
  variables: Record<string, any>;
  globals: Record<string, any>;
  environment: Record<string, any>;
  iteration?: number;
  request?: {
    url: string;
    method: string;
    timestamp: Date;
  };
  response?: {
    status: number;
    body: any;
    headers: Record<string, string>;
  };
}

// Mock server configuration
export const MockEndpointSchema = z.object({
  path: z.string(),
  method: z.enum(['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS', 'ALL']).default('GET'),
  response: z.object({
    status: z.number().default(200),
    headers: z.record(z.string()).default({}),
    body: z.any(),
    delay: z.number().default(0), // Simulated response delay in ms
  }),
  conditions: z.object({
    headers: z.record(z.string()).optional(),
    query: z.record(z.string()).optional(),
    body: z.any().optional(),
  }).optional(),
});

export type MockEndpoint = z.infer<typeof MockEndpointSchema>;

// OpenAPI import types
export interface OpenAPIImportResult {
  endpoints: Array<{
    path: string;
    method: HttpMethod;
    operationId?: string;
    summary?: string;
    description?: string;
    requestConfig: RequestConfig;
    examples?: Array<{
      name: string;
      config: RequestConfig;
    }>;
  }>;
  baseUrl?: string;
  info: {
    title: string;
    version: string;
    description?: string;
  };
}

// Postman import types
export interface PostmanImportResult {
  requests: Array<{
    name: string;
    description?: string;
    config: RequestConfig;
    folder?: string;
    tests?: string[]; // Pre-request scripts or tests
  }>;
  variables?: Record<string, any>;
  info: {
    name: string;
    description?: string;
  };
}

// Session management
export interface ApiSession {
  id: string;
  name?: string;
  variables: Record<string, any>;
  cookies: Record<string, string>;
  headers: Record<string, string>;
  baseUrl?: string;
  auth?: AuthConfig;
  createdAt: Date;
  lastUsedAt: Date;
}

// Error types
export class ApiEngineError extends Error {
  constructor(
    message: string,
    public code: string,
    public details?: any
  ) {
    super(message);
    this.name = 'ApiEngineError';
  }
}

export class RequestError extends ApiEngineError {
  constructor(
    message: string,
    public statusCode?: number,
    public response?: any
  ) {
    super(message, 'REQUEST_ERROR', { statusCode, response });
    this.name = 'RequestError';
  }
}

export class ValidationError extends ApiEngineError {
  constructor(message: string, public validationErrors: any[]) {
    super(message, 'VALIDATION_ERROR', validationErrors);
    this.name = 'ValidationError';
  }
}

export class TemplateError extends ApiEngineError {
  constructor(message: string, public template: string) {
    super(message, 'TEMPLATE_ERROR', { template });
    this.name = 'TemplateError';
  }
}

// DSL Step types (matching the schema)
export interface ApiRequestStep {
  kind: 'api.request';
  config: RequestConfig;
  extractions?: ExtractionConfig[];
  assertions?: AssertionConfig[];
  timeout?: number;
}

export interface ApiGraphQLStep {
  kind: 'api.graphql';
  config: GraphQLConfig;
  extractions?: ExtractionConfig[];
  assertions?: AssertionConfig[];
  timeout?: number;
}

export interface ApiGrpcStep {
  kind: 'api.grpc';
  config: GrpcConfig;
  extractions?: ExtractionConfig[];
  assertions?: AssertionConfig[];
  timeout?: number;
}

export interface ApiWebSocketConnectStep {
  kind: 'api.websocket-connect';
  config: WebSocketConfig;
  timeout?: number;
}

export interface ApiWebSocketSendStep {
  kind: 'api.websocket-send';
  sessionId: string;
  message: any;
  timeout?: number;
}

export interface ApiWebSocketDisconnectStep {
  kind: 'api.websocket-disconnect';
  sessionId: string;
}

export type ApiStep = 
  | ApiRequestStep 
  | ApiGraphQLStep 
  | ApiGrpcStep 
  | ApiWebSocketConnectStep 
  | ApiWebSocketSendStep 
  | ApiWebSocketDisconnectStep; 