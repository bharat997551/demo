import { DSLExecutor } from '../dsl-executor';
import { MockServer } from '../mock-server';
import { RequestRunner } from '../request-runner';
import { ExtractionEngine } from '../extraction-engine';
import { AssertionEngine } from '../assertion-engine';
import { TemplateEngine } from '../template-engine';
import {
  ApiRequestStep,
  ApiGraphQLStep,
  ExtractionConfig,
  AssertionConfig,
  TemplateContext,
  MockEndpoint
} from '../types';

describe('API Engine Integration Tests', () => {
  let mockServer: MockServer;
  let dslExecutor: DSLExecutor;
  let requestRunner: RequestRunner;
  
  beforeAll(async () => {
    // Start mock server
    mockServer = new MockServer(3998);
    await mockServer.start();
    
    // Add test endpoints
    const testEndpoints: MockEndpoint[] = [
      {
        path: '/api/users',
        method: 'GET',
        response: {
          status: 200,
          headers: { 'Content-Type': 'application/json' },
          body: {
            users: [
              { id: 1, name: 'John Doe', email: 'john@example.com', active: true },
              { id: 2, name: 'Jane Smith', email: 'jane@example.com', active: false }
            ],
            total: 2,
            timestamp: '2023-12-15T10:30:00Z'
          }
        }
      },
      {
        path: '/api/users',
        method: 'POST',
        response: {
          status: 201,
          headers: { 'Content-Type': 'application/json' },
          body: { id: 3, message: 'User created successfully' }
        }
      },
      {
        path: '/api/users/1',
        method: 'GET',
        response: {
          status: 200,
          headers: { 'Content-Type': 'application/json' },
          body: { id: 1, name: 'John Doe', email: 'john@example.com', active: true }
        }
      },
      {
        path: '/api/error',
        method: 'GET',
        response: {
          status: 500,
          headers: { 'Content-Type': 'application/json' },
          body: { error: 'Internal Server Error', code: 500 }
        }
      },
      {
        path: '/api/slow',
        method: 'GET',
        response: {
          status: 200,
          headers: { 'Content-Type': 'application/json' },
          body: { message: 'Slow response' },
          delay: 1000
        }
      }
    ];
    
    mockServer.addEndpoints(testEndpoints);
    
    // Initialize executors
    dslExecutor = new DSLExecutor();
    requestRunner = new RequestRunner();
  });
  
  afterAll(async () => {
    await mockServer.stop();
    await dslExecutor.cleanup();
  });

  describe('REST API DSL Steps', () => {
    test('should execute simple GET request step', async () => {
      const step: ApiRequestStep = {
        kind: 'api.request',
        config: {
          url: 'http://localhost:3998/api/users',
          method: 'GET',
          headers: {},
          query: {},
          timeout: 5000,
          followRedirects: true,
          validateSSL: false
        }
      };
      
      const context = dslExecutor.createContext();
      const result = await dslExecutor.executeStep(step, {
        ...context,
        stepIndex: 0,
        previousResults: [],
        sessionData: {}
      });
      
      expect(result.success).toBe(true);
      expect(result.response).toBeDefined();
      expect(result.response!.status).toBe(200);
      expect(result.response!.body).toEqual({
        users: expect.arrayContaining([
          expect.objectContaining({ id: 1, name: 'John Doe' })
        ]),
        total: 2,
        timestamp: expect.any(String)
      });
    });

    test('should execute POST request with body', async () => {
      const step: ApiRequestStep = {
        kind: 'api.request',
        config: {
          url: 'http://localhost:3998/api/users',
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          query: {},
          body: { name: 'New User', email: 'new@example.com' },
          timeout: 5000,
          followRedirects: true,
          validateSSL: false
        }
      };
      
      const context = dslExecutor.createContext();
      const result = await dslExecutor.executeStep(step, {
        ...context,
        stepIndex: 0,
        previousResults: [],
        sessionData: {}
      });
      
      expect(result.success).toBe(true);
      expect(result.response!.status).toBe(201);
      expect(result.response!.body).toEqual({
        id: 3,
        message: 'User created successfully'
      });
    });

    test('should execute request with template variables', async () => {
      const step: ApiRequestStep = {
        kind: 'api.request',
        config: {
          url: 'http://localhost:3998/api/users/{{variables.userId}}',
          method: 'GET',
          headers: {},
          query: {},
          timeout: 5000,
          followRedirects: true,
          validateSSL: false
        }
      };
      
      const context = dslExecutor.createContext({ userId: '1' });
      const result = await dslExecutor.executeStep(step, {
        ...context,
        stepIndex: 0,
        previousResults: [],
        sessionData: {}
      });
      
      expect(result.success).toBe(true);
      expect(result.response!.status).toBe(200);
      expect(result.response!.body.id).toBe(1);
    });
  });

  describe('Data Extraction', () => {
    test('should extract data using JSONPath', async () => {
      const step: ApiRequestStep = {
        kind: 'api.request',
        config: {
          url: 'http://localhost:3998/api/users',
          method: 'GET',
          headers: {},
          query: {},
          timeout: 5000,
          followRedirects: true,
          validateSSL: false
        },
        extractions: [
          {
            type: 'jsonpath',
            expression: '$.users[0].name',
            multiple: false
          },
          {
            type: 'jsonpath', 
            expression: '$.users[*].id',
            multiple: true
          },
          {
            type: 'jsonpath',
            expression: '$.total',
            multiple: false
          }
        ]
      };
      
      const context = dslExecutor.createContext();
      const result = await dslExecutor.executeStep(step, {
        ...context,
        stepIndex: 0,
        previousResults: [],
        sessionData: {}
      });
      
      expect(result.success).toBe(true);
      expect(result.extractions).toBeDefined();
      expect(result.extractions!['users_0_name']).toBe('John Doe');
      expect(result.extractions!['users_id']).toEqual([1, 2]);
      expect(result.extractions!['total']).toBe(2);
    });

    test('should extract headers and status', async () => {
      const step: ApiRequestStep = {
        kind: 'api.request',
        config: {
          url: 'http://localhost:3998/api/users',
          method: 'GET',
          headers: {},
          query: {},
          timeout: 5000,
          followRedirects: true,
          validateSSL: false
        },
        extractions: [
          {
            type: 'header',
            expression: 'content-type',
            multiple: false
          },
          {
            type: 'status',
            expression: '',
            multiple: false
          }
        ]
      };
      
      const context = dslExecutor.createContext();
      const result = await dslExecutor.executeStep(step, {
        ...context,
        stepIndex: 0,
        previousResults: [],
        sessionData: {}
      });
      
      expect(result.success).toBe(true);
      expect(result.extractions!['content_type']).toBe('application/json');
      expect(result.extractions!['_extraction']).toBe(200);
    });
  });

  describe('Assertions', () => {
    test('should perform status code assertion', async () => {
      const step: ApiRequestStep = {
        kind: 'api.request',
        config: {
          url: 'http://localhost:3998/api/users',
          method: 'GET',
          headers: {},
          query: {},
          timeout: 5000,
          followRedirects: true,
          validateSSL: false
        },
        assertions: [
          {
            type: 'status_code',
            expected: 200,
            path: undefined,
            ignoreCase: false
          }
        ]
      };
      
      const context = dslExecutor.createContext();
      const result = await dslExecutor.executeStep(step, {
        ...context,
        stepIndex: 0,
        previousResults: [],
        sessionData: {}
      });
      
      expect(result.success).toBe(true);
      expect(result.assertions![0].passed).toBe(true);
      expect(result.assertions![0].message).toContain('Status code matches: 200');
    });

    test('should perform JSON content assertions', async () => {
      const step: ApiRequestStep = {
        kind: 'api.request',
        config: {
          url: 'http://localhost:3998/api/users',
          method: 'GET',
          headers: {},
          query: {},
          timeout: 5000,
          followRedirects: true,
          validateSSL: false
        },
        assertions: [
          {
            type: 'equals',
            path: '$.total',
            expected: 2,
            ignoreCase: false
          },
          {
            type: 'contains',
            path: '$.users[0].name',
            expected: 'John',
            ignoreCase: false
          },
          {
            type: 'greater_than',
            path: '$.users.length',
            expected: 1,
            ignoreCase: false
          }
        ]
      };
      
      const context = dslExecutor.createContext();
      const result = await dslExecutor.executeStep(step, {
        ...context,
        stepIndex: 0,
        previousResults: [],
        sessionData: {}
      });
      
      expect(result.success).toBe(true);
      expect(result.assertions![0].passed).toBe(true); // total equals 2
      expect(result.assertions![1].passed).toBe(true); // name contains 'John'
      expect(result.assertions![2].passed).toBe(true); // users.length > 1
    });

    test('should handle failed assertions', async () => {
      const step: ApiRequestStep = {
        kind: 'api.request',
        config: {
          url: 'http://localhost:3998/api/error',
          method: 'GET',
          headers: {},
          query: {},
          timeout: 5000,
          followRedirects: true,
          validateSSL: false
        },
        assertions: [
          {
            type: 'status_code',
            expected: 200, // This will fail since mock returns 500
            path: undefined,
            ignoreCase: false
          }
        ]
      };
      
      const context = dslExecutor.createContext();
      const result = await dslExecutor.executeStep(step, {
        ...context,
        stepIndex: 0,
        previousResults: [],
        sessionData: {}
      });
      
      expect(result.success).toBe(false);
      expect(result.assertions![0].passed).toBe(false);
      expect(result.error).toContain('assertion(s) failed');
    });
  });

  describe('Sequential DSL Steps', () => {
    test('should execute sequence of steps with variable passing', async () => {
      const steps: ApiRequestStep[] = [
        // Step 1: Get user list
        {
          kind: 'api.request',
          config: {
            url: 'http://localhost:3998/api/users',
            method: 'GET',
            headers: {},
            query: {},
            timeout: 5000,
            followRedirects: true,
            validateSSL: false
          },
          extractions: [
            {
              type: 'jsonpath',
              expression: '$.users[0].id',
              multiple: false
            }
          ]
        },
        // Step 2: Get specific user using extracted ID
        {
          kind: 'api.request',
          config: {
            url: 'http://localhost:3998/api/users/{{variables.users_0_id}}',
            method: 'GET',
            headers: {},
            query: {},
            timeout: 5000,
            followRedirects: true,
            validateSSL: false
          },
          assertions: [
            {
              type: 'equals',
              path: '$.name',
              expected: 'John Doe',
              ignoreCase: false
            }
          ]
        }
      ];
      
      const context = dslExecutor.createContext();
      const results = await dslExecutor.executeSequence(steps, context);
      
      expect(results).toHaveLength(2);
      expect(results[0].success).toBe(true);
      expect(results[1].success).toBe(true);
      
      // Check that variable was extracted and used
      expect(results[0].extractions!['users_0_id']).toBe(1);
      expect(results[1].assertions![0].passed).toBe(true);
    });

    test('should execute steps with flow control', async () => {
      const steps: ApiRequestStep[] = [
        {
          kind: 'api.request',
          config: {
            url: 'http://localhost:3998/api/users',
            method: 'GET',
            headers: {},
            query: {},
            timeout: 5000,
            followRedirects: true,
            validateSSL: false
          }
        },
        {
          kind: 'api.request',
          config: {
            url: 'http://localhost:3998/api/error', // This will fail
            method: 'GET',
            headers: {},
            query: {},
            timeout: 5000,
            followRedirects: true,
            validateSSL: false
          }
        },
        {
          kind: 'api.request',
          config: {
            url: 'http://localhost:3998/api/users/1',
            method: 'GET',
            headers: {},
            query: {},
            timeout: 5000,
            followRedirects: true,
            validateSSL: false
          }
        }
      ];
      
      const context = dslExecutor.createContext();
      const results = await dslExecutor.executeWithFlow(steps, context, {
        continueOnFailure: true, // Continue even if a step fails
        maxRetries: 1
      });
      
      expect(results).toHaveLength(3);
      expect(results[0].success).toBe(true);  // First request succeeds
      expect(results[1].success).toBe(true);  // Second request gets 500 but that's not a failure for HTTP
      expect(results[2].success).toBe(true);  // Third request succeeds
    });
  });

  describe('Template Engine', () => {
    test('should render templates with context variables', async () => {
      const templateEngine = new TemplateEngine();
      
      const context: TemplateContext = {
        variables: { userId: 123, userName: 'testUser' },
        globals: { baseUrl: 'http://localhost:3998' },
        environment: { env: 'test' }
      };
      
      const template = '{{globals.baseUrl}}/api/users/{{variables.userId}}?user={{variables.userName}}&env={{environment.env}}';
      const result = await templateEngine.render(template, context);
      
      expect(result).toBe('http://localhost:3998/api/users/123?user=testUser&env=test');
    });

    test('should use template helpers', async () => {
      const templateEngine = new TemplateEngine();
      
      const context: TemplateContext = {
        variables: { name: 'john doe', count: 5 },
        globals: {},
        environment: {}
      };
      
      const template = '{{upper variables.name}} - {{add variables.count 10}} - {{uuid}}';
      const result = await templateEngine.render(template, context);
      
      expect(result).toMatch(/^JOHN DOE - 15 - [0-9a-f-]{36}$/);
    });

    test('should handle response data in templates', async () => {
      const templateEngine = new TemplateEngine();
      
      const context: TemplateContext = {
        variables: {},
        globals: {},
        environment: {},
        response: {
          status: 200,
          body: { userId: 42, token: 'abc123' },
          headers: { 'x-request-id': 'req-456' }
        }
      };
      
      const template = 'User: {{response "userId"}} | Token: {{response "token"}} | RequestId: {{header "x-request-id"}}';
      const result = await templateEngine.render(template, context);
      
      expect(result).toBe('User: 42 | Token: abc123 | RequestId: req-456');
    });
  });

  describe('Performance Tests', () => {
    test('should handle response time assertions', async () => {
      const slowStep: ApiRequestStep = {
        kind: 'api.request',
        config: {
          url: 'http://localhost:3998/api/slow',
          method: 'GET',
          headers: {},
          query: {},
          timeout: 5000,
          followRedirects: true,
          validateSSL: false
        },
        assertions: [
          {
            type: 'response_time',
            expected: 1500, // Expect response within 1500ms
            tolerance: 200, // Allow 200ms tolerance
            ignoreCase: false
          }
        ]
      };
      
      const context = dslExecutor.createContext();
      const result = await dslExecutor.executeStep(slowStep, {
        ...context,
        stepIndex: 0,
        previousResults: [],
        sessionData: {}
      });
      
      expect(result.success).toBe(true);
      expect(result.response!.duration).toBeGreaterThan(900); // Should be around 1000ms + processing time
      expect(result.assertions![0].passed).toBe(true);
    });
  });

  describe('Error Handling', () => {
    test('should handle network errors gracefully', async () => {
      const step: ApiRequestStep = {
        kind: 'api.request',
        config: {
          url: 'http://localhost:9999/nonexistent', // Non-existent server
          method: 'GET',
          headers: {},
          query: {},
          timeout: 1000,
          followRedirects: true,
          validateSSL: false
        }
      };
      
      const context = dslExecutor.createContext();
      const result = await dslExecutor.executeStep(step, {
        ...context,
        stepIndex: 0,
        previousResults: [],
        sessionData: {}
      });
      
      expect(result.success).toBe(false);
      expect(result.error).toBeDefined();
      expect(result.error).toContain('Network error');
    });
  });

  describe('Mock Server', () => {
    test('should validate mock server endpoints', async () => {
      const info = mockServer.getInfo();
      
      expect(info.isRunning).toBe(true);
      expect(info.port).toBe(3998);
      expect(info.endpointCount).toBeGreaterThan(0);
      expect(info.endpoints).toContain('/api/users');
    });

    test('should add and remove endpoints dynamically', () => {
      const newEndpoint: MockEndpoint = {
        path: '/api/test',
        method: 'GET',
        response: {
          status: 200,
          headers: {},
          body: { test: true }
        }
      };
      
      mockServer.addEndpoint(newEndpoint);
      
      const info = mockServer.getInfo();
      expect(info.endpoints).toContain('/api/test');
      
      mockServer.removeEndpoint('/api/test');
      
      const updatedInfo = mockServer.getInfo();
      expect(updatedInfo.endpoints).not.toContain('/api/test');
    });
  });

  describe('Execution Summary', () => {
    test('should generate comprehensive execution summary', async () => {
      const steps: ApiRequestStep[] = [
        {
          kind: 'api.request',
          config: {
            url: 'http://localhost:3998/api/users',
            method: 'GET',
            headers: {},
            query: {},
            timeout: 5000,
            followRedirects: true,
            validateSSL: false
          },
          extractions: [{ type: 'jsonpath', expression: '$.total', multiple: false }],
          assertions: [{ type: 'status_code', expected: 200, ignoreCase: false }]
        },
        {
          kind: 'api.request',
          config: {
            url: 'http://localhost:3998/api/users/1',
            method: 'GET',
            headers: {},
            query: {},
            timeout: 5000,
            followRedirects: true,
            validateSSL: false
          },
          extractions: [{ type: 'jsonpath', expression: '$.name', multiple: false }],
          assertions: [{ type: 'equals', path: '$.id', expected: 1, ignoreCase: false }]
        }
      ];
      
      const context = dslExecutor.createContext();
      const results = await dslExecutor.executeSequence(steps, context);
      const summary = dslExecutor.generateExecutionSummary(results);
      
      expect(summary.totalSteps).toBe(2);
      expect(summary.successfulSteps).toBe(2);
      expect(summary.failedSteps).toBe(0);
      expect(summary.extractionCount).toBe(2);
      expect(summary.assertionCount).toBe(2);
      expect(summary.failedAssertions).toBe(0);
      expect(summary.totalDuration).toBeGreaterThan(0);
      expect(summary.avgDuration).toBeGreaterThan(0);
    });
  });
}); 