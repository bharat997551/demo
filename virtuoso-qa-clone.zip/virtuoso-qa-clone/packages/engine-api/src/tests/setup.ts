// Test setup and global configuration
import { logger } from '@hybrid-qa/common';

// Configure logger for testing
logger.level = 'error'; // Reduce log noise during tests

// Global test configuration
jest.setTimeout(30000); // 30 seconds timeout

// Mock external dependencies that may not be available in test environment
jest.mock('s3270', () => ({}), { virtual: true });
jest.mock('swagger-parser', () => ({
  dereference: jest.fn(),
  validate: jest.fn()
}), { virtual: true });

// Suppress console.warn and console.error during tests unless needed
const originalConsoleWarn = console.warn;
const originalConsoleError = console.error;

beforeAll(() => {
  console.warn = jest.fn();
  console.error = jest.fn();
});

afterAll(() => {
  console.warn = originalConsoleWarn;
  console.error = originalConsoleError;
});

// Helper to wait for async operations
export const waitFor = (ms: number): Promise<void> => {
  return new Promise(resolve => setTimeout(resolve, ms));
};

// Helper to create mock responses
export const createMockResponse = (data: any, status: number = 200) => ({
  status,
  statusText: status === 200 ? 'OK' : 'Error',
  headers: { 'content-type': 'application/json' },
  body: data,
  rawBody: JSON.stringify(data),
  duration: Math.random() * 100 + 50, // Random duration between 50-150ms
  timestamp: new Date(),
  url: 'http://test.example.com/api',
  method: 'GET'
});

// Helper to create template context
export const createTestContext = (variables: Record<string, any> = {}) => ({
  variables,
  globals: { baseUrl: 'http://localhost:3998' },
  environment: { env: 'test' }
});

// Export common test utilities
export { };

// Add custom matchers for API responses
declare global {
  namespace jest {
    interface Matchers<R> {
      toBeValidApiResponse(): R;
      toHaveStatusCode(statusCode: number): R;
    }
  }
}

expect.extend({
  toBeValidApiResponse(received) {
    const pass = received &&
      typeof received.status === 'number' &&
      typeof received.statusText === 'string' &&
      typeof received.headers === 'object' &&
      received.body !== undefined &&
      typeof received.duration === 'number' &&
      received.timestamp instanceof Date;

    if (pass) {
      return {
        message: () => `expected ${JSON.stringify(received)} not to be a valid API response`,
        pass: true,
      };
    } else {
      return {
        message: () => `expected ${JSON.stringify(received)} to be a valid API response`,
        pass: false,
      };
    }
  },

  toHaveStatusCode(received, statusCode) {
    const pass = received && received.status === statusCode;

    if (pass) {
      return {
        message: () => `expected response not to have status code ${statusCode}`,
        pass: true,
      };
    } else {
      return {
        message: () => `expected response to have status code ${statusCode}, but got ${received?.status}`,
        pass: false,
      };
    }
  },
}); 