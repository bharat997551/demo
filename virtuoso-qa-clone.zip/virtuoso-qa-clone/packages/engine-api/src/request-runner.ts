import axios, { AxiosResponse, AxiosRequestConfig } from 'axios';
import { GraphQLClient, RequestOptions } from 'graphql-request';
import * as grpc from '@grpc/grpc-js';
import * as protoLoader from '@grpc/proto-loader';
import WebSocket from 'ws';
import { logger } from '@hybrid-qa/common';
import {
  RequestConfig,
  GraphQLConfig,
  GrpcConfig,
  WebSocketConfig,
  ApiResponse,
  GraphQLResponse,
  GrpcResponse,
  AuthConfig,
  TemplateContext,
  RequestError,
  ApiEngineError,
  TemplateError
} from './types';
import { TemplateEngine } from './template-engine';
import { CredentialManager } from './credential-manager';

/**
 * Main API request runner that handles all types of API calls
 */
export class RequestRunner {
  private templateEngine: TemplateEngine;
  private credentialManager: CredentialManager;
  private webSocketConnections: Map<string, WebSocket> = new Map();

  constructor() {
    this.templateEngine = new TemplateEngine();
    this.credentialManager = new CredentialManager();
  }

  /**
   * Execute REST API request
   */
  async executeRestRequest(
    config: RequestConfig,
    context?: TemplateContext
  ): Promise<ApiResponse> {
    const startTime = Date.now();
    
    try {
      logger.info('Executing REST request', { 
        method: config.method, 
        url: config.url 
      });

      // Apply templating
      const processedConfig = await this.processRequestTemplate(config, context);
      
      // Build axios config
      const axiosConfig: AxiosRequestConfig = {
        method: processedConfig.method,
        url: processedConfig.url,
        headers: processedConfig.headers,
        params: processedConfig.query,
        data: processedConfig.body,
        timeout: processedConfig.timeout,
        maxRedirects: processedConfig.followRedirects ? 5 : 0,
        validateStatus: () => true, // Don't throw on HTTP errors
      };

      // Apply authentication
      if (processedConfig.auth) {
        axiosConfig.headers = await this.applyAuthentication(
          axiosConfig.headers || {},
          processedConfig.auth,
          axiosConfig
        );
      }

      // Handle SSL validation
      if (!processedConfig.validateSSL) {
        process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '0';
      }

      const response: AxiosResponse = await axios(axiosConfig);
      const duration = Date.now() - startTime;

      // Reset SSL validation
      if (!processedConfig.validateSSL) {
        delete process.env['NODE_TLS_REJECT_UNAUTHORIZED'];
      }

      const apiResponse: ApiResponse = {
        status: response.status,
        statusText: response.statusText,
        headers: this.normalizeHeaders(response.headers),
        body: response.data,
        rawBody: typeof response.data === 'string' ? response.data : JSON.stringify(response.data),
        duration,
        timestamp: new Date(),
        url: response.config.url || processedConfig.url,
        method: processedConfig.method,
      };

      logger.info('REST request completed', {
        status: response.status,
        duration,
        url: processedConfig.url
      });

      return apiResponse;

    } catch (error: any) {
      const duration = Date.now() - startTime;
      logger.error('REST request failed', { 
        error: error.message, 
        url: config.url,
        duration 
      });

      if (error.response) {
        // HTTP error response
        throw new RequestError(
          `HTTP ${error.response.status}: ${error.response.statusText}`,
          error.response.status,
          error.response.data
        );
      } else if (error.request) {
        // Network error
        throw new RequestError('Network error: No response received', 0);
      } else {
        // Other error
        throw new ApiEngineError(error.message, 'REQUEST_SETUP_ERROR');
      }
    }
  }

  /**
   * Execute GraphQL request
   */
  async executeGraphQLRequest(
    config: GraphQLConfig,
    context?: TemplateContext
  ): Promise<GraphQLResponse> {
    const startTime = Date.now();

    try {
      logger.info('Executing GraphQL request', { 
        endpoint: config.endpoint,
        operationName: config.operationName
      });

      // Apply templating
      const processedConfig = await this.processGraphQLTemplate(config, context);

      // Create GraphQL client
      const client = new GraphQLClient(processedConfig.endpoint, {
        headers: processedConfig.headers,
      });

      // Apply authentication
      if (processedConfig.auth) {
        const authHeaders = await this.applyAuthentication(
          processedConfig.headers,
          processedConfig.auth
        );
        client.setHeaders(authHeaders);
      }

      // Execute query/mutation
      const requestOptions: RequestOptions = {
        variables: processedConfig.variables,
      };

      if (processedConfig.operationName) {
        requestOptions.operationName = processedConfig.operationName;
      }

      const data = await client.request(
        processedConfig.query,
        processedConfig.variables,
        processedConfig.headers
      );

      const duration = Date.now() - startTime;

      const graphqlResponse: GraphQLResponse = {
        data,
        duration,
        timestamp: new Date(),
      };

      logger.info('GraphQL request completed', {
        duration,
        endpoint: processedConfig.endpoint
      });

      return graphqlResponse;

    } catch (error: any) {
      const duration = Date.now() - startTime;
      logger.error('GraphQL request failed', { 
        error: error.message, 
        endpoint: config.endpoint,
        duration 
      });

      if (error.response?.errors) {
        const graphqlResponse: GraphQLResponse = {
          data: error.response.data,
          errors: error.response.errors,
          extensions: error.response.extensions,
          duration,
          timestamp: new Date(),
        };
        return graphqlResponse;
      }

      throw new RequestError(`GraphQL error: ${error.message}`, 0, error.response);
    }
  }

  /**
   * Execute gRPC request
   */
  async executeGrpcRequest(
    config: GrpcConfig,
    context?: TemplateContext
  ): Promise<GrpcResponse> {
    const startTime = Date.now();

    try {
      logger.info('Executing gRPC request', { 
        service: config.service,
        method: config.method,
        host: config.host,
        port: config.port
      });

      // Apply templating
      const processedConfig = await this.processGrpcTemplate(config, context);

      // Load proto file
      const packageDefinition = await protoLoader.load(processedConfig.protoPath, {
        keepCase: true,
        longs: String,
        enums: String,
        defaults: true,
        oneofs: true,
      });

      const protoDescriptor = grpc.loadPackageDefinition(packageDefinition);

      // Get service constructor
      const servicePackage = this.getNestedProperty(protoDescriptor, processedConfig.packageName);
      const ServiceConstructor = servicePackage[processedConfig.serviceName];

      if (!ServiceConstructor) {
        throw new ApiEngineError(
          `Service ${processedConfig.serviceName} not found in package ${processedConfig.packageName}`,
          'GRPC_SERVICE_NOT_FOUND'
        );
      }

      // Create client
      const credentials = processedConfig.credentials 
        ? this.createGrpcCredentials(processedConfig.credentials)
        : grpc.credentials.createInsecure();

      const client = new ServiceConstructor(
        `${processedConfig.host}:${processedConfig.port}`,
        credentials
      );

      // Prepare metadata
      const metadata = new grpc.Metadata();
      Object.entries(processedConfig.metadata).forEach(([key, value]) => {
        metadata.add(key, value);
      });

      // Execute call
      const response = await this.executeGrpcCall(
        client,
        processedConfig.method,
        processedConfig.data,
        metadata,
        processedConfig.timeout
      );

      const duration = Date.now() - startTime;

      const grpcResponse: GrpcResponse = {
        data: response.data,
        metadata: response.metadata,
        duration,
        timestamp: new Date(),
        status: response.status,
      };

      logger.info('gRPC request completed', {
        duration,
        service: processedConfig.service,
        method: processedConfig.method
      });

      return grpcResponse;

    } catch (error: any) {
      const duration = Date.now() - startTime;
      logger.error('gRPC request failed', { 
        error: error.message, 
        service: config.service,
        method: config.method,
        duration 
      });

      throw new RequestError(`gRPC error: ${error.message}`, error.code || 0, error.details);
    }
  }

  /**
   * Connect to WebSocket
   */
  async connectWebSocket(
    sessionId: string,
    config: WebSocketConfig,
    context?: TemplateContext
  ): Promise<void> {
    try {
      logger.info('Connecting to WebSocket', { sessionId, url: config.url });

      // Apply templating
      const processedConfig = await this.processWebSocketTemplate(config, context);

      const ws = new WebSocket(processedConfig.url, processedConfig.protocols, {
        headers: processedConfig.headers,
        handshakeTimeout: processedConfig.timeout,
      });

      await new Promise<void>((resolve, reject) => {
        ws.on('open', () => {
          logger.info('WebSocket connected', { sessionId, url: processedConfig.url });
          resolve();
        });

        ws.on('error', (error) => {
          logger.error('WebSocket connection failed', { sessionId, error: error.message });
          reject(new RequestError(`WebSocket connection failed: ${error.message}`));
        });

        setTimeout(() => {
          reject(new RequestError('WebSocket connection timeout'));
        }, processedConfig.timeout);
      });

      this.webSocketConnections.set(sessionId, ws);

    } catch (error: any) {
      logger.error('WebSocket connection failed', { 
        sessionId, 
        error: error.message 
      });
      throw error;
    }
  }

  /**
   * Send message to WebSocket
   */
  async sendWebSocketMessage(sessionId: string, message: any): Promise<void> {
    const ws = this.webSocketConnections.get(sessionId);
    if (!ws) {
      throw new ApiEngineError(`WebSocket session ${sessionId} not found`, 'WEBSOCKET_NOT_FOUND');
    }

    if (ws.readyState !== WebSocket.OPEN) {
      throw new ApiEngineError(`WebSocket session ${sessionId} is not open`, 'WEBSOCKET_NOT_OPEN');
    }

    const messageData = typeof message === 'string' ? message : JSON.stringify(message);
    
    return new Promise((resolve, reject) => {
      ws.send(messageData, (error) => {
        if (error) {
          logger.error('WebSocket send failed', { sessionId, error: error.message });
          reject(new RequestError(`WebSocket send failed: ${error.message}`));
        } else {
          logger.info('WebSocket message sent', { sessionId });
          resolve();
        }
      });
    });
  }

  /**
   * Disconnect WebSocket
   */
  async disconnectWebSocket(sessionId: string): Promise<void> {
    const ws = this.webSocketConnections.get(sessionId);
    if (!ws) {
      throw new ApiEngineError(`WebSocket session ${sessionId} not found`, 'WEBSOCKET_NOT_FOUND');
    }

    ws.close();
    this.webSocketConnections.delete(sessionId);
    logger.info('WebSocket disconnected', { sessionId });
  }

  /**
   * Process request template with context
   */
  private async processRequestTemplate(
    config: RequestConfig,
    context?: TemplateContext
  ): Promise<RequestConfig> {
    if (!context) return config;

    return {
      ...config,
      url: await this.templateEngine.render(config.url, context),
      headers: await this.renderObjectTemplate(config.headers, context),
      query: await this.renderObjectTemplate(config.query, context),
      body: config.body ? await this.templateEngine.renderObject(config.body, context) : undefined,
    };
  }

  /**
   * Process GraphQL template with context
   */
  private async processGraphQLTemplate(
    config: GraphQLConfig,
    context?: TemplateContext
  ): Promise<GraphQLConfig> {
    if (!context) return config;

    return {
      ...config,
      endpoint: await this.templateEngine.render(config.endpoint, context),
      query: await this.templateEngine.render(config.query, context),
      variables: await this.templateEngine.renderObject(config.variables, context),
      headers: await this.renderObjectTemplate(config.headers, context),
    };
  }

  /**
   * Process gRPC template with context
   */
  private async processGrpcTemplate(
    config: GrpcConfig,
    context?: TemplateContext
  ): Promise<GrpcConfig> {
    if (!context) return config;

    return {
      ...config,
      host: await this.templateEngine.render(config.host, context),
      data: await this.templateEngine.renderObject(config.data, context),
      metadata: await this.renderObjectTemplate(config.metadata, context),
    };
  }

  /**
   * Process WebSocket template with context
   */
  private async processWebSocketTemplate(
    config: WebSocketConfig,
    context?: TemplateContext
  ): Promise<WebSocketConfig> {
    if (!context) return config;

    return {
      ...config,
      url: await this.templateEngine.render(config.url, context),
      headers: await this.renderObjectTemplate(config.headers, context),
    };
  }

  /**
   * Apply authentication to request
   */
  private async applyAuthentication(
    headers: Record<string, string>,
    auth: AuthConfig,
    axiosConfig?: AxiosRequestConfig
  ): Promise<Record<string, string>> {
    const authHeaders = { ...headers };

    switch (auth.type) {
      case 'basic':
        if (auth.basic) {
          const credentials = Buffer.from(
            `${auth.basic.username}:${auth.basic.password}`
          ).toString('base64');
          authHeaders.Authorization = `Basic ${credentials}`;
        }
        break;

      case 'bearer':
        if (auth.bearer) {
          const token = await this.credentialManager.getSecureValue(auth.bearer.token);
          authHeaders.Authorization = `Bearer ${token}`;
        }
        break;

      case 'apikey':
        if (auth.apikey) {
          const value = await this.credentialManager.getSecureValue(auth.apikey.value);
          
          if (auth.apikey.location === 'header') {
            authHeaders[auth.apikey.key] = value;
          } else if (auth.apikey.location === 'query' && axiosConfig) {
            axiosConfig.params = axiosConfig.params || {};
            axiosConfig.params[auth.apikey.key] = value;
          }
        }
        break;

      case 'oauth2':
        if (auth.oauth2) {
          const token = await this.credentialManager.getSecureValue(auth.oauth2.accessToken);
          authHeaders.Authorization = `Bearer ${token}`;
        }
        break;

      case 'custom':
        if (auth.custom?.headers) {
          Object.assign(authHeaders, auth.custom.headers);
        }
        break;
    }

    return authHeaders;
  }

  /**
   * Execute gRPC call with promise wrapper
   */
  private executeGrpcCall(
    client: any,
    methodName: string,
    data: any,
    metadata: grpc.Metadata,
    timeout: number
  ): Promise<{ data: any; metadata: Record<string, string>; status: { code: number; details: string } }> {
    return new Promise((resolve, reject) => {
      const deadline = new Date(Date.now() + timeout);
      
      client[methodName](data, metadata, { deadline }, (error: any, response: any) => {
        if (error) {
          reject(error);
        } else {
          resolve({
            data: response,
            metadata: this.grpcMetadataToObject(metadata),
            status: { code: 0, details: 'OK' },
          });
        }
      });
    });
  }

  /**
   * Create gRPC credentials
   */
  private createGrpcCredentials(creds: { cert?: string; key?: string; ca?: string }) {
    if (creds.cert && creds.key) {
      return grpc.credentials.createSsl(
        Buffer.from(creds.ca || ''),
        Buffer.from(creds.key),
        Buffer.from(creds.cert)
      );
    }
    return grpc.credentials.createInsecure();
  }

  /**
   * Utility functions
   */
  private normalizeHeaders(headers: any): Record<string, string> {
    const normalized: Record<string, string> = {};
    for (const [key, value] of Object.entries(headers)) {
      normalized[key.toLowerCase()] = String(value);
    }
    return normalized;
  }

  private async renderObjectTemplate(
    obj: Record<string, any>,
    context: TemplateContext
  ): Promise<Record<string, any>> {
    const result: Record<string, any> = {};
    for (const [key, value] of Object.entries(obj)) {
      if (typeof value === 'string') {
        result[key] = await this.templateEngine.render(value, context);
      } else {
        result[key] = value;
      }
    }
    return result;
  }

  private getNestedProperty(obj: any, path: string): any {
    return path.split('.').reduce((current, key) => current?.[key], obj);
  }

  private grpcMetadataToObject(metadata: grpc.Metadata): Record<string, string> {
    const obj: Record<string, string> = {};
    const map = metadata.getMap();
    for (const [key, value] of Object.entries(map)) {
      obj[key] = Array.isArray(value) ? value.join(', ') : String(value);
    }
    return obj;
  }

  /**
   * Cleanup resources
   */
  async cleanup(): Promise<void> {
    // Close all WebSocket connections
    for (const [sessionId, ws] of this.webSocketConnections) {
      try {
        ws.close();
        logger.info('Closed WebSocket connection', { sessionId });
      } catch (error) {
        logger.warn('Error closing WebSocket', { sessionId, error });
      }
    }
    this.webSocketConnections.clear();
  }
} 