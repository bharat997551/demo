import express, { Request, Response } from 'express';
import cors from 'cors';
import { logger } from '@hybrid-qa/common';
import { DSLExecutor } from './dsl-executor';
import { RequestRunner } from './request-runner';
import { ExtractionEngine } from './extraction-engine';
import { AssertionEngine } from './assertion-engine';
import { TemplateEngine } from './template-engine';
import { CredentialManager } from './credential-manager';
import { OpenAPIImporter } from './importers/openapi-importer';
import { PostmanImporter } from './importers/postman-importer';
import { MockServer } from './mock-server';
import { 
  ApiStep, 
  RequestConfig, 
  GraphQLConfig, 
  GrpcConfig,
  ExtractionConfig,
  AssertionConfig,
  TemplateContext,
  ApiEngineError,
  ValidationError
} from './types';

/**
 * Main API Engine server
 */
export class APIEngine {
  private app: express.Application;
  private server: any;
  private port: number;
  private dslExecutor: DSLExecutor;
  private requestRunner: RequestRunner;
  private extractionEngine: ExtractionEngine;
  private assertionEngine: AssertionEngine;
  private templateEngine: TemplateEngine;
  private credentialManager: CredentialManager;
  private openApiImporter: OpenAPIImporter;
  private postmanImporter: PostmanImporter;
  private mockServer?: MockServer;

  constructor(port: number = 8004) {
    this.port = port;
    this.app = express();
    
    // Initialize engines
    this.dslExecutor = new DSLExecutor();
    this.requestRunner = new RequestRunner();
    this.extractionEngine = new ExtractionEngine();
    this.assertionEngine = new AssertionEngine();
    this.templateEngine = new TemplateEngine();
    this.credentialManager = new CredentialManager();
    this.openApiImporter = new OpenAPIImporter();
    this.postmanImporter = new PostmanImporter();
    
    this.setupMiddleware();
    this.setupRoutes();
  }

  /**
   * Setup Express middleware
   */
  private setupMiddleware(): void {
    this.app.use(cors());
    this.app.use(express.json({ limit: '10mb' }));
    this.app.use(express.urlencoded({ extended: true, limit: '10mb' }));
    
    // Request logging
    this.app.use((req, res, next) => {
      logger.info('API request received', {
        method: req.method,
        path: req.path,
        userAgent: req.get('User-Agent')
      });
      next();
    });
    
    // Error handling
    this.app.use((error: any, req: Request, res: Response, next: any) => {
      logger.error('API request error', {
        error: error.message,
        stack: error.stack,
        path: req.path,
        method: req.method
      });
      
      if (error instanceof ApiEngineError) {
        res.status(400).json({
          error: error.message,
          code: error.code,
          details: error.details
        });
      } else if (error instanceof ValidationError) {
        res.status(422).json({
          error: error.message,
          validationErrors: error.validationErrors
        });
      } else {
        res.status(500).json({
          error: 'Internal server error',
          message: error.message
        });
      }
    });
  }

  /**
   * Setup API routes
   */
  private setupRoutes(): void {
    // Health check
    this.app.get('/health', (req, res) => {
      res.json({
        status: 'healthy',
        service: 'api-engine',
        version: '1.0.0',
        port: this.port,
        timestamp: new Date().toISOString()
      });
    });

    // Execute DSL steps
    this.app.post('/execute/step', async (req, res, next) => {
      try {
        const { step, context } = req.body;
        
        if (!step || !step.kind) {
          throw new ValidationError('Step and step.kind are required', []);
        }
        
        const executionContext = {
          variables: context?.variables || {},
          globals: context?.globals || {},
          environment: context?.environment || {},
          stepIndex: 0,
          previousResults: [],
          sessionData: {}
        };
        
        const result = await this.dslExecutor.executeStep(step, executionContext);
        res.json(result);
        
      } catch (error) {
        next(error);
      }
    });

    // Execute sequence of DSL steps
    this.app.post('/execute/sequence', async (req, res, next) => {
      try {
        const { steps, context, options = {} } = req.body;
        
        if (!Array.isArray(steps) || steps.length === 0) {
          throw new ValidationError('Steps array is required and must not be empty', []);
        }
        
        const templateContext = {
          variables: context?.variables || {},
          globals: context?.globals || {},
          environment: context?.environment || {}
        };
        
        let results;
        if (options.flowControl) {
          results = await this.dslExecutor.executeWithFlow(steps, templateContext, options.flowControl);
        } else {
          results = await this.dslExecutor.executeSequence(steps, templateContext);
        }
        
        const summary = this.dslExecutor.generateExecutionSummary(results);
        
        res.json({
          results,
          summary
        });
        
      } catch (error) {
        next(error);
      }
    });

    // Execute REST request
    this.app.post('/request/rest', async (req, res, next) => {
      try {
        const { config, context } = req.body;
        
        if (!config || !config.url) {
          throw new ValidationError('Request config with URL is required', []);
        }
        
        const result = await this.requestRunner.executeRestRequest(config, context);
        res.json(result);
        
      } catch (error) {
        next(error);
      }
    });

    // Execute GraphQL request
    this.app.post('/request/graphql', async (req, res, next) => {
      try {
        const { config, context } = req.body;
        
        if (!config || !config.endpoint || !config.query) {
          throw new ValidationError('GraphQL config with endpoint and query is required', []);
        }
        
        const result = await this.requestRunner.executeGraphQLRequest(config, context);
        res.json(result);
        
      } catch (error) {
        next(error);
      }
    });

    // Execute gRPC request
    this.app.post('/request/grpc', async (req, res, next) => {
      try {
        const { config, context } = req.body;
        
        if (!config || !config.host || !config.port || !config.service || !config.method) {
          throw new ValidationError('gRPC config with host, port, service, and method is required', []);
        }
        
        const result = await this.requestRunner.executeGrpcRequest(config, context);
        res.json(result);
        
      } catch (error) {
        next(error);
      }
    });

    // Extract data from response
    this.app.post('/extract', async (req, res, next) => {
      try {
        const { response, config } = req.body;
        
        if (!response || !config) {
          throw new ValidationError('Response and extraction config are required', []);
        }
        
        const result = await this.extractionEngine.extract(response, config);
        res.json({ result });
        
      } catch (error) {
        next(error);
      }
    });

    // Perform assertion
    this.app.post('/assert', async (req, res, next) => {
      try {
        const { response, config } = req.body;
        
        if (!response || !config) {
          throw new ValidationError('Response and assertion config are required', []);
        }
        
        const result = await this.assertionEngine.assert(response, config);
        res.json(result);
        
      } catch (error) {
        next(error);
      }
    });

    // Render template
    this.app.post('/template/render', async (req, res, next) => {
      try {
        const { template, context } = req.body;
        
        if (!template) {
          throw new ValidationError('Template is required', []);
        }
        
        const result = await this.templateEngine.render(template, context || {});
        res.json({ result });
        
      } catch (error) {
        next(error);
      }
    });

    // Credential management
    this.app.post('/credentials', async (req, res, next) => {
      try {
        const { key, value } = req.body;
        
        if (!key || !value) {
          throw new ValidationError('Key and value are required', []);
        }
        
        await this.credentialManager.setCredential(key, value);
        res.json({ message: 'Credential stored successfully' });
        
      } catch (error) {
        next(error);
      }
    });

    this.app.get('/credentials/:key', async (req, res, next) => {
      try {
        const { key } = req.params;
        const exists = await this.credentialManager.hasCredential(key);
        
        res.json({ exists, key: key.replace(/./g, '*') }); // Masked key
        
      } catch (error) {
        next(error);
      }
    });

    // Import OpenAPI specification
    this.app.post('/import/openapi', async (req, res, next) => {
      try {
        const { url, spec } = req.body;
        
        let result;
        if (url) {
          result = await this.openApiImporter.importFromUrl(url);
        } else if (spec) {
          result = await this.openApiImporter.importFromObject(spec);
        } else {
          throw new ValidationError('Either URL or spec object is required', []);
        }
        
        res.json(result);
        
      } catch (error) {
        next(error);
      }
    });

    // Import Postman collection
    this.app.post('/import/postman', async (req, res, next) => {
      try {
        const { url, collection } = req.body;
        
        let result;
        if (url) {
          result = await this.postmanImporter.importFromUrl(url);
        } else if (collection) {
          result = await this.postmanImporter.importFromObject(collection);
        } else {
          throw new ValidationError('Either URL or collection object is required', []);
        }
        
        res.json(result);
        
      } catch (error) {
        next(error);
      }
    });

    // Validate DSL step
    this.app.post('/validate/step', (req, res, next) => {
      try {
        const { step } = req.body;
        
        if (!step) {
          throw new ValidationError('Step is required', []);
        }
        
        const validation = this.dslExecutor.validateStep(step);
        res.json(validation);
        
      } catch (error) {
        next(error);
      }
    });

    // Mock server management
    this.app.post('/mock/start', async (req, res, next) => {
      try {
        const { port = 3999, endpoints = [] } = req.body;
        
        if (this.mockServer) {
          throw new ApiEngineError('Mock server is already running', 'MOCK_SERVER_RUNNING');
        }
        
        this.mockServer = new MockServer(port);
        
        if (endpoints.length > 0) {
          this.mockServer.addEndpoints(endpoints);
        } else {
          // Add default endpoints
          this.mockServer.addEndpoints(MockServer.createCommonMocks());
        }
        
        await this.mockServer.start();
        
        res.json({
          message: 'Mock server started',
          port,
          info: this.mockServer.getInfo()
        });
        
      } catch (error) {
        next(error);
      }
    });

    this.app.post('/mock/stop', async (req, res, next) => {
      try {
        if (!this.mockServer) {
          throw new ApiEngineError('Mock server is not running', 'MOCK_SERVER_NOT_RUNNING');
        }
        
        await this.mockServer.stop();
        this.mockServer = undefined;
        
        res.json({ message: 'Mock server stopped' });
        
      } catch (error) {
        next(error);
      }
    });

    this.app.get('/mock/info', (req, res) => {
      if (this.mockServer) {
        res.json(this.mockServer.getInfo());
      } else {
        res.json({ isRunning: false });
      }
    });
  }

  /**
   * Start the API engine server
   */
  async start(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.server = this.app.listen(this.port, () => {
        logger.info('API Engine server started', { port: this.port });
        resolve();
      });
      
      this.server.on('error', (error: any) => {
        logger.error('API Engine server failed to start', { error: error.message });
        reject(error);
      });
    });
  }

  /**
   * Stop the API engine server
   */
  async stop(): Promise<void> {
    // Cleanup resources
    await this.dslExecutor.cleanup();
    
    if (this.mockServer) {
      await this.mockServer.stop();
    }
    
    if (this.server) {
      return new Promise((resolve) => {
        this.server.close(() => {
          logger.info('API Engine server stopped');
          resolve();
        });
      });
    }
  }
}

// Export all components for external use
export {
  DSLExecutor,
  RequestRunner,
  ExtractionEngine,
  AssertionEngine,
  TemplateEngine,
  CredentialManager,
  OpenAPIImporter,
  PostmanImporter,
  MockServer
};

// Export types
export * from './types';

// Main entry point
if (require.main === module) {
  const apiEngine = new APIEngine();
  
  // Handle graceful shutdown
  process.on('SIGINT', async () => {
    logger.info('Received SIGINT, shutting down gracefully...');
    await apiEngine.stop();
    process.exit(0);
  });
  
  process.on('SIGTERM', async () => {
    logger.info('Received SIGTERM, shutting down gracefully...');
    await apiEngine.stop();
    process.exit(0);
  });
  
  // Start the server
  apiEngine.start().catch((error) => {
    logger.error('Failed to start API Engine', { error: error.message });
    process.exit(1);
  });
} 