import { logger } from '@hybrid-qa/common';
import { ApiEngineError } from './types';

/**
 * Interface for credential storage backends
 */
interface CredentialStore {
  get(key: string): Promise<string | null>;
  set(key: string, value: string): Promise<void>;
  delete(key: string): Promise<void>;
  has(key: string): Promise<boolean>;
}

/**
 * In-memory credential store (for development/testing)
 */
class MemoryCredentialStore implements CredentialStore {
  private credentials: Map<string, string> = new Map();

  async get(key: string): Promise<string | null> {
    return this.credentials.get(key) || null;
  }

  async set(key: string, value: string): Promise<void> {
    this.credentials.set(key, value);
  }

  async delete(key: string): Promise<void> {
    this.credentials.delete(key);
  }

  async has(key: string): Promise<boolean> {
    return this.credentials.has(key);
  }
}

/**
 * Environment variable credential store
 */
class EnvironmentCredentialStore implements CredentialStore {
  private prefix: string;

  constructor(prefix: string = 'HYBRID_QA_CREDENTIAL_') {
    this.prefix = prefix;
  }

  async get(key: string): Promise<string | null> {
    const envKey = this.prefix + key.toUpperCase();
    return process.env[envKey] || null;
  }

  async set(key: string, value: string): Promise<void> {
    const envKey = this.prefix + key.toUpperCase();
    process.env[envKey] = value;
  }

  async delete(key: string): Promise<void> {
    const envKey = this.prefix + key.toUpperCase();
    delete process.env[envKey];
  }

  async has(key: string): Promise<boolean> {
    const envKey = this.prefix + key.toUpperCase();
    return envKey in process.env;
  }
}

/**
 * File-based credential store (encrypted)
 */
class FileCredentialStore implements CredentialStore {
  private filePath: string;
  private credentials: Map<string, string> = new Map();
  private loaded: boolean = false;

  constructor(filePath: string) {
    this.filePath = filePath;
  }

  private async loadCredentials(): Promise<void> {
    if (this.loaded) return;

    try {
      const fs = require('fs').promises;
      const crypto = require('crypto');
      
      if (await this.fileExists()) {
        const encrypted = await fs.readFile(this.filePath, 'utf8');
        const decrypted = this.decrypt(encrypted);
        const data = JSON.parse(decrypted);
        
        for (const [key, value] of Object.entries(data)) {
          this.credentials.set(key, value as string);
        }
      }
      
      this.loaded = true;
    } catch (error: any) {
      logger.warn('Failed to load credentials file', { error: error.message });
      this.loaded = true; // Continue with empty store
    }
  }

  private async saveCredentials(): Promise<void> {
    try {
      const fs = require('fs').promises;
      const path = require('path');
      
      const data = Object.fromEntries(this.credentials.entries());
      const encrypted = this.encrypt(JSON.stringify(data));
      
      // Ensure directory exists
      await fs.mkdir(path.dirname(this.filePath), { recursive: true });
      await fs.writeFile(this.filePath, encrypted, 'utf8');
    } catch (error: any) {
      logger.error('Failed to save credentials file', { error: error.message });
      throw new ApiEngineError(`Failed to save credentials: ${error.message}`, 'CREDENTIAL_SAVE_ERROR');
    }
  }

  private async fileExists(): Promise<boolean> {
    try {
      const fs = require('fs').promises;
      await fs.access(this.filePath);
      return true;
    } catch {
      return false;
    }
  }

  private encrypt(text: string): string {
    const crypto = require('crypto');
    const key = this.getEncryptionKey();
    const iv = crypto.randomBytes(16);
    const cipher = crypto.createCipher('aes-256-cbc', key);
    
    let encrypted = cipher.update(text, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    
    return iv.toString('hex') + ':' + encrypted;
  }

  private decrypt(encryptedText: string): string {
    const crypto = require('crypto');
    const key = this.getEncryptionKey();
    const parts = encryptedText.split(':');
    const iv = Buffer.from(parts[0], 'hex');
    const encrypted = parts[1];
    
    const decipher = crypto.createDecipher('aes-256-cbc', key);
    let decrypted = decipher.update(encrypted, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    
    return decrypted;
  }

  private getEncryptionKey(): string {
    // In production, this should come from a secure key management system
    return process.env.HYBRID_QA_ENCRYPTION_KEY || 'default-encryption-key-change-in-production';
  }

  async get(key: string): Promise<string | null> {
    await this.loadCredentials();
    return this.credentials.get(key) || null;
  }

  async set(key: string, value: string): Promise<void> {
    await this.loadCredentials();
    this.credentials.set(key, value);
    await this.saveCredentials();
  }

  async delete(key: string): Promise<void> {
    await this.loadCredentials();
    this.credentials.delete(key);
    await this.saveCredentials();
  }

  async has(key: string): Promise<boolean> {
    await this.loadCredentials();
    return this.credentials.has(key);
  }
}

/**
 * Credential manager that handles secure storage and retrieval of sensitive data
 */
export class CredentialManager {
  private stores: CredentialStore[] = [];
  private defaultStore: CredentialStore;

  constructor() {
    // Initialize default stores in order of preference
    this.defaultStore = new MemoryCredentialStore();
    
    // Add environment variable store
    this.stores.push(new EnvironmentCredentialStore());
    
    // Add file store if path is configured
    const credentialFile = process.env.HYBRID_QA_CREDENTIAL_FILE;
    if (credentialFile) {
      this.stores.push(new FileCredentialStore(credentialFile));
    }
    
    // Add memory store as fallback
    this.stores.push(this.defaultStore);
  }

  /**
   * Get a credential value, checking stores in order of preference
   */
  async getSecureValue(keyOrValue: string): Promise<string> {
    // If it doesn't look like a credential key, return as-is
    if (!this.isCredentialKey(keyOrValue)) {
      return keyOrValue;
    }

    const key = this.extractCredentialKey(keyOrValue);

    for (const store of this.stores) {
      try {
        const value = await store.get(key);
        if (value !== null) {
          logger.debug('Retrieved credential from store', { key: this.maskKey(key) });
          return value;
        }
      } catch (error: any) {
        logger.warn('Error retrieving credential from store', { 
          key: this.maskKey(key), 
          error: error.message 
        });
      }
    }

    throw new ApiEngineError(
      `Credential not found: ${this.maskKey(key)}`,
      'CREDENTIAL_NOT_FOUND',
      { key: this.maskKey(key) }
    );
  }

  /**
   * Set a credential value
   */
  async setCredential(key: string, value: string, storeIndex: number = 0): Promise<void> {
    const store = this.stores[storeIndex] || this.defaultStore;
    
    try {
      await store.set(key, value);
      logger.info('Credential stored', { key: this.maskKey(key) });
    } catch (error: any) {
      logger.error('Failed to store credential', { 
        key: this.maskKey(key), 
        error: error.message 
      });
      throw new ApiEngineError(
        `Failed to store credential: ${error.message}`,
        'CREDENTIAL_STORE_ERROR'
      );
    }
  }

  /**
   * Delete a credential
   */
  async deleteCredential(key: string): Promise<void> {
    for (const store of this.stores) {
      try {
        if (await store.has(key)) {
          await store.delete(key);
          logger.info('Credential deleted', { key: this.maskKey(key) });
        }
      } catch (error: any) {
        logger.warn('Error deleting credential from store', { 
          key: this.maskKey(key), 
          error: error.message 
        });
      }
    }
  }

  /**
   * Check if a credential exists
   */
  async hasCredential(key: string): Promise<boolean> {
    for (const store of this.stores) {
      try {
        if (await store.has(key)) {
          return true;
        }
      } catch (error: any) {
        logger.warn('Error checking credential in store', { 
          key: this.maskKey(key), 
          error: error.message 
        });
      }
    }
    return false;
  }

  /**
   * List all available credential keys (masked for security)
   */
  async listCredentials(): Promise<string[]> {
    const keys = new Set<string>();
    
    for (const store of this.stores) {
      try {
        // This is a simplified implementation
        // In a real scenario, stores would need a method to list keys
        // For now, we'll return an empty array
      } catch (error: any) {
        logger.warn('Error listing credentials from store', { error: error.message });
      }
    }
    
    return Array.from(keys).map(key => this.maskKey(key));
  }

  /**
   * Check if a string looks like a credential key
   * Credential keys are expected to be in format: ${credential:key_name}
   */
  private isCredentialKey(value: string): boolean {
    return /^\$\{credential:[\w\-_.]+\}$/i.test(value);
  }

  /**
   * Extract the credential key from a credential reference
   */
  private extractCredentialKey(credentialRef: string): string {
    const match = credentialRef.match(/^\$\{credential:([\w\-_.]+)\}$/i);
    return match ? match[1] : credentialRef;
  }

  /**
   * Mask credential key for logging
   */
  private maskKey(key: string): string {
    if (key.length <= 4) {
      return '*'.repeat(key.length);
    }
    return key.substring(0, 2) + '*'.repeat(key.length - 4) + key.substring(key.length - 2);
  }

  /**
   * Validate credential key format
   */
  validateCredentialKey(key: string): { valid: boolean; errors: string[] } {
    const errors: string[] = [];

    if (!key) {
      errors.push('Credential key cannot be empty');
    }

    if (!/^[\w\-_.]+$/.test(key)) {
      errors.push('Credential key can only contain letters, numbers, hyphens, underscores, and dots');
    }

    if (key.length > 100) {
      errors.push('Credential key cannot be longer than 100 characters');
    }

    return {
      valid: errors.length === 0,
      errors
    };
  }

  /**
   * Bulk import credentials from object
   */
  async importCredentials(credentials: Record<string, string>, storeIndex: number = 0): Promise<void> {
    const store = this.stores[storeIndex] || this.defaultStore;
    
    for (const [key, value] of Object.entries(credentials)) {
      const validation = this.validateCredentialKey(key);
      if (!validation.valid) {
        logger.warn('Skipping invalid credential key', { 
          key: this.maskKey(key), 
          errors: validation.errors 
        });
        continue;
      }
      
      try {
        await store.set(key, value);
        logger.debug('Imported credential', { key: this.maskKey(key) });
      } catch (error: any) {
        logger.error('Failed to import credential', { 
          key: this.maskKey(key), 
          error: error.message 
        });
      }
    }
  }

  /**
   * Create a credential reference string
   */
  createCredentialReference(key: string): string {
    return `\${credential:${key}}`;
  }

  /**
   * Parse template for credential references and return required keys
   */
  extractCredentialReferences(template: string): string[] {
    const references: string[] = [];
    const regex = /\$\{credential:([\w\-_.]+)\}/g;
    let match;

    while ((match = regex.exec(template)) !== null) {
      const key = match[1];
      if (!references.includes(key)) {
        references.push(key);
      }
    }

    return references;
  }
} 