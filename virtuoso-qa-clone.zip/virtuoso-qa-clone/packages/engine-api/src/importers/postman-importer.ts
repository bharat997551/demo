import { Collection } from 'postman-collection';
import { logger } from '@hybrid-qa/common';
import {
  PostmanImportResult,
  RequestConfig,
  HttpMethod,
  ApiEngineError,
  AuthConfig
} from '../types';

/**
 * Postman collection importer
 */
export class PostmanImporter {

  /**
   * Import from Postman collection URL
   */
  async importFromUrl(collectionUrl: string): Promise<PostmanImportResult> {
    try {
      logger.info('Importing Postman collection from URL', { url: collectionUrl });
      
      const response = await fetch(collectionUrl);
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      
      const collectionData = await response.json();
      return this.processCollection(collectionData);
      
    } catch (error: any) {
      logger.error('Failed to import Postman collection from URL', { 
        url: collectionUrl, 
        error: error.message 
      });
      throw new ApiEngineError(
        `Failed to import Postman collection: ${error.message}`,
        'POSTMAN_IMPORT_ERROR'
      );
    }
  }

  /**
   * Import from Postman collection object
   */
  async importFromObject(collectionData: any): Promise<PostmanImportResult> {
    try {
      logger.info('Importing Postman collection from object');
      
      return this.processCollection(collectionData);
      
    } catch (error: any) {
      logger.error('Failed to import Postman collection from object', { 
        error: error.message 
      });
      throw new ApiEngineError(
        `Failed to import Postman collection: ${error.message}`,
        'POSTMAN_IMPORT_ERROR'
      );
    }
  }

  /**
   * Process Postman collection
   */
  private processCollection(collectionData: any): PostmanImportResult {
    const collection = new Collection(collectionData);
    
    const result: PostmanImportResult = {
      requests: [],
      info: {
        name: collection.name || 'Untitled Collection',
        description: collection.description?.content || collection.description
      }
    };

    // Process collection variables
    if (collection.variables && collection.variables.count() > 0) {
      result.variables = {};
      collection.variables.each((variable: any) => {
        result.variables![variable.key] = variable.value;
      });
    }

    // Process all items recursively
    this.processItems(collection.items, result);

    logger.info('Postman collection processed', { 
      requestCount: result.requests.length,
      name: result.info.name 
    });

    return result;
  }

  /**
   * Process collection items recursively
   */
  private processItems(
    items: any, 
    result: PostmanImportResult, 
    folderPath: string[] = []
  ): void {
    
    items.each((item: any) => {
      if (item.items) {
        // This is a folder, process recursively
        const newPath = [...folderPath, item.name];
        this.processItems(item.items, result, newPath);
      } else {
        // This is a request
        const request = this.processRequest(item, folderPath);
        result.requests.push(request);
      }
    });
  }

  /**
   * Process a single Postman request
   */
  private processRequest(
    item: any,
    folderPath: string[]
  ): PostmanImportResult['requests'][0] {
    
    const postmanRequest = item.request;
    
    // Build request configuration
    const config: RequestConfig = {
      url: this.buildUrl(postmanRequest.url),
      method: this.normalizeMethod(postmanRequest.method),
      headers: this.processHeaders(postmanRequest.header),
      query: this.processQuery(postmanRequest.url),
      timeout: 30000,
      followRedirects: true,
      validateSSL: true
    };

    // Process request body
    if (postmanRequest.body) {
      this.processBody(postmanRequest.body, config);
    }

    // Process authentication
    if (postmanRequest.auth) {
      config.auth = this.processAuth(postmanRequest.auth);
    }

    // Extract tests/scripts
    const tests: string[] = [];
    if (item.event) {
      for (const event of item.event) {
        if (event.listen === 'test' && event.script) {
          tests.push(event.script.exec?.join('\n') || '');
        }
      }
    }

    return {
      name: item.name || 'Untitled Request',
      description: item.description?.content || item.description,
      config,
      folder: folderPath.length > 0 ? folderPath.join(' / ') : undefined,
      tests: tests.length > 0 ? tests : undefined
    };
  }

  /**
   * Build URL from Postman URL object
   */
  private buildUrl(url: any): string {
    if (typeof url === 'string') {
      return this.replacePostmanVariables(url);
    }

    if (url.raw) {
      return this.replacePostmanVariables(url.raw);
    }

    // Construct URL from parts
    let constructedUrl = '';
    
    if (url.protocol) {
      constructedUrl += url.protocol + '://';
    } else {
      constructedUrl += 'https://';
    }

    if (url.host) {
      if (Array.isArray(url.host)) {
        constructedUrl += url.host.join('.');
      } else {
        constructedUrl += url.host;
      }
    }

    if (url.port) {
      constructedUrl += ':' + url.port;
    }

    if (url.path) {
      if (Array.isArray(url.path)) {
        constructedUrl += '/' + url.path.join('/');
      } else {
        constructedUrl += '/' + url.path;
      }
    }

    return this.replacePostmanVariables(constructedUrl);
  }

  /**
   * Process headers
   */
  private processHeaders(headers: any): Record<string, string> {
    const result: Record<string, string> = {};
    
    if (!headers) return result;

    if (Array.isArray(headers)) {
      for (const header of headers) {
        if (!header.disabled && header.key && header.value) {
          result[header.key] = this.replacePostmanVariables(header.value);
        }
      }
    } else {
      headers.each((header: any) => {
        if (!header.disabled && header.key && header.value) {
          result[header.key] = this.replacePostmanVariables(header.value);
        }
      });
    }

    return result;
  }

  /**
   * Process query parameters
   */
  private processQuery(url: any): Record<string, string | number | boolean> {
    const result: Record<string, string | number | boolean> = {};
    
    if (!url || !url.query) return result;

    if (Array.isArray(url.query)) {
      for (const param of url.query) {
        if (!param.disabled && param.key && param.value !== undefined) {
          result[param.key] = this.replacePostmanVariables(param.value);
        }
      }
    } else {
      url.query.each((param: any) => {
        if (!param.disabled && param.key && param.value !== undefined) {
          result[param.key] = this.replacePostmanVariables(param.value);
        }
      });
    }

    return result;
  }

  /**
   * Process request body
   */
  private processBody(body: any, config: RequestConfig): void {
    if (!body) return;

    switch (body.mode) {
      case 'raw':
        config.body = this.replacePostmanVariables(body.raw);
        
        // Try to determine content type from options
        if (body.options?.raw?.language === 'json') {
          config.headers['Content-Type'] = 'application/json';
        } else if (body.options?.raw?.language === 'xml') {
          config.headers['Content-Type'] = 'application/xml';
        }
        break;

      case 'urlencoded':
        const formData: Record<string, string> = {};
        if (body.urlencoded) {
          for (const param of body.urlencoded) {
            if (!param.disabled && param.key) {
              formData[param.key] = this.replacePostmanVariables(param.value || '');
            }
          }
        }
        config.body = new URLSearchParams(formData).toString();
        config.headers['Content-Type'] = 'application/x-www-form-urlencoded';
        break;

      case 'formdata':
        // For multipart/form-data, we'll create a simple object representation
        const multipartData: Record<string, any> = {};
        if (body.formdata) {
          for (const param of body.formdata) {
            if (!param.disabled && param.key) {
              if (param.type === 'file') {
                multipartData[param.key] = `<file: ${param.src || 'file.txt'}>`;
              } else {
                multipartData[param.key] = this.replacePostmanVariables(param.value || '');
              }
            }
          }
        }
        config.body = multipartData;
        config.headers['Content-Type'] = 'multipart/form-data';
        break;

      case 'binary':
        config.body = '<binary data>';
        break;

      default:
        if (body.raw) {
          config.body = this.replacePostmanVariables(body.raw);
        }
    }
  }

  /**
   * Process authentication
   */
  private processAuth(auth: any): AuthConfig {
    if (!auth || !auth.type) {
      return { type: 'none' };
    }

    switch (auth.type) {
      case 'basic':
        return {
          type: 'basic',
          basic: {
            username: this.replacePostmanVariables(auth.basic?.username || ''),
            password: this.replacePostmanVariables(auth.basic?.password || '')
          }
        };

      case 'bearer':
        return {
          type: 'bearer',
          bearer: {
            token: this.replacePostmanVariables(auth.bearer?.token || '')
          }
        };

      case 'apikey':
        const keyData = auth.apikey || {};
        return {
          type: 'apikey',
          apikey: {
            key: keyData.key || 'api-key',
            value: this.replacePostmanVariables(keyData.value || ''),
            location: keyData.in === 'header' ? 'header' : 'query'
          }
        };

      case 'oauth1':
      case 'oauth2':
        return {
          type: 'oauth2',
          oauth2: {
            accessToken: this.replacePostmanVariables(auth.oauth2?.accessToken || '')
          }
        };

      default:
        return {
          type: 'custom',
          custom: {
            headers: {
              'Authorization': '{{variables.authorization}}'
            }
          }
        };
    }
  }

  /**
   * Normalize HTTP method
   */
  private normalizeMethod(method: string): HttpMethod {
    const normalized = method.toUpperCase();
    const validMethods: HttpMethod[] = ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS'];
    
    if (validMethods.includes(normalized as HttpMethod)) {
      return normalized as HttpMethod;
    }
    
    return 'GET'; // Default fallback
  }

  /**
   * Replace Postman variables with template syntax
   */
  private replacePostmanVariables(text: string): string {
    if (!text || typeof text !== 'string') {
      return text;
    }

    // Replace {{variable}} with template syntax (already compatible)
    // Replace environment variables {{$variable}}
    return text.replace(/\{\{\$([^}]+)\}\}/g, '{{environment.$1}}');
  }

  /**
   * Extract collection info
   */
  async getCollectionInfo(source: string | any): Promise<{ name: string; description?: string }> {
    try {
      let collectionData: any;
      
      if (typeof source === 'string') {
        // Assume it's a URL
        const response = await fetch(source);
        collectionData = await response.json();
      } else {
        collectionData = source;
      }
      
      const collection = new Collection(collectionData);
      
      return {
        name: collection.name || 'Untitled Collection',
        description: collection.description?.content || collection.description
      };
    } catch (error: any) {
      throw new ApiEngineError(
        `Failed to get collection info: ${error.message}`,
        'POSTMAN_INFO_ERROR'
      );
    }
  }

  /**
   * Validate Postman collection
   */
  validateCollection(collectionData: any): { valid: boolean; errors: string[] } {
    const errors: string[] = [];

    try {
      const collection = new Collection(collectionData);
      
      if (!collection.name) {
        errors.push('Collection name is missing');
      }

      // Basic structure validation
      if (!collectionData.info) {
        errors.push('Collection info is missing');
      }

      if (!collectionData.item && !collectionData.items) {
        errors.push('Collection has no items');
      }

    } catch (error: any) {
      errors.push(`Invalid collection structure: ${error.message}`);
    }

    return {
      valid: errors.length === 0,
      errors
    };
  }

  /**
   * Convert Postman tests to assertion configs
   */
  parsePostmanTests(testScript: string): Array<{ type: string; expression: string; expected: any }> {
    const assertions: Array<{ type: string; expression: string; expected: any }> = [];
    
    // This is a simplified parser for common Postman test patterns
    const lines = testScript.split('\n');
    
    for (const line of lines) {
      const trimmed = line.trim();
      
      // pm.response.to.have.status(200)
      const statusMatch = trimmed.match(/pm\.response\.to\.have\.status\((\d+)\)/);
      if (statusMatch) {
        assertions.push({
          type: 'status_code',
          expression: 'status',
          expected: parseInt(statusMatch[1])
        });
        continue;
      }

      // pm.expect(pm.response.responseTime).to.be.below(1000)
      const responseTimeMatch = trimmed.match(/pm\.expect\(pm\.response\.responseTime\)\.to\.be\.below\((\d+)\)/);
      if (responseTimeMatch) {
        assertions.push({
          type: 'response_time',
          expression: 'responseTime',
          expected: parseInt(responseTimeMatch[1])
        });
        continue;
      }

      // pm.expect(pm.response.text()).to.include("success")
      const includeMatch = trimmed.match(/pm\.expect\(pm\.response\.text\(\)\)\.to\.include\("([^"]+)"\)/);
      if (includeMatch) {
        assertions.push({
          type: 'contains',
          expression: 'body',
          expected: includeMatch[1]
        });
        continue;
      }

      // JSON body expectations
      const jsonMatch = trimmed.match(/pm\.expect\(pm\.response\.json\(\)\.([^)]+)\)\.to\.eql\("?([^"]+)"?\)/);
      if (jsonMatch) {
        assertions.push({
          type: 'equals',
          expression: `$.${jsonMatch[1]}`,
          expected: jsonMatch[2]
        });
        continue;
      }
    }

    return assertions;
  }
} 