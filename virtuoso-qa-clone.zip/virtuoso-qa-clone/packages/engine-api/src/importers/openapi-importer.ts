import SwaggerParser from 'swagger-parser';
import { OpenAPI } from 'openapi-types';
import { logger } from '@hybrid-qa/common';
import { 
  OpenAPIImportResult, 
  RequestConfig, 
  HttpMethod, 
  ApiEngineError,
  AuthConfig 
} from '../types';

/**
 * OpenAPI specification importer
 */
export class OpenAPIImporter {
  
  /**
   * Import OpenAPI specification from URL or file path
   */
  async importFromUrl(specUrl: string): Promise<OpenAPIImportResult> {
    try {
      logger.info('Importing OpenAPI spec from URL', { url: specUrl });
      
      const api = await SwaggerParser.dereference(specUrl) as OpenAPI.Document;
      return this.processOpenAPISpec(api, specUrl);
      
    } catch (error: any) {
      logger.error('Failed to import OpenAPI spec from URL', { 
        url: specUrl, 
        error: error.message 
      });
      throw new ApiEngineError(
        `Failed to import OpenAPI spec: ${error.message}`,
        'OPENAPI_IMPORT_ERROR'
      );
    }
  }

  /**
   * Import OpenAPI specification from JSON object
   */
  async importFromObject(spec: any): Promise<OpenAPIImportResult> {
    try {
      logger.info('Importing OpenAPI spec from object');
      
      const api = await SwaggerParser.dereference(spec) as OpenAPI.Document;
      return this.processOpenAPISpec(api);
      
    } catch (error: any) {
      logger.error('Failed to import OpenAPI spec from object', { 
        error: error.message 
      });
      throw new ApiEngineError(
        `Failed to import OpenAPI spec: ${error.message}`,
        'OPENAPI_IMPORT_ERROR'
      );
    }
  }

  /**
   * Process OpenAPI specification and extract endpoints
   */
  private processOpenAPISpec(api: OpenAPI.Document, sourceUrl?: string): OpenAPIImportResult {
    const result: OpenAPIImportResult = {
      endpoints: [],
      info: {
        title: api.info.title,
        version: api.info.version,
        description: api.info.description
      }
    };

    // Determine base URL
    if (this.isOpenAPI3(api)) {
      const openapi3 = api as OpenAPI.Document3;
      if (openapi3.servers && openapi3.servers.length > 0) {
        result.baseUrl = openapi3.servers[0].url;
      }
    } else {
      const swagger2 = api as OpenAPI.Document2;
      const scheme = swagger2.schemes?.[0] || 'http';
      const host = swagger2.host || 'localhost';
      const basePath = swagger2.basePath || '';
      result.baseUrl = `${scheme}://${host}${basePath}`;
    }

    // Process paths
    if (api.paths) {
      for (const [path, pathItem] of Object.entries(api.paths)) {
        if (pathItem) {
          this.processPathItem(path, pathItem, result, api);
        }
      }
    }

    logger.info('OpenAPI spec processed', { 
      endpointCount: result.endpoints.length,
      title: result.info.title 
    });

    return result;
  }

  /**
   * Process a single path item
   */
  private processPathItem(
    path: string, 
    pathItem: OpenAPI.PathItem, 
    result: OpenAPIImportResult, 
    api: OpenAPI.Document
  ): void {
    const methods: (keyof OpenAPI.PathItem)[] = [
      'get', 'post', 'put', 'patch', 'delete', 'head', 'options'
    ];

    for (const method of methods) {
      const operation = pathItem[method] as OpenAPI.Operation;
      if (operation) {
        const endpoint = this.processOperation(
          path,
          method.toUpperCase() as HttpMethod,
          operation,
          api
        );
        result.endpoints.push(endpoint);
      }
    }
  }

  /**
   * Process a single operation
   */
  private processOperation(
    path: string,
    method: HttpMethod,
    operation: OpenAPI.Operation,
    api: OpenAPI.Document
  ): OpenAPIImportResult['endpoints'][0] {
    
    // Build request configuration
    const requestConfig: RequestConfig = {
      url: this.buildUrl(path),
      method,
      headers: {},
      query: {},
      timeout: 30000,
      followRedirects: true,
      validateSSL: true
    };

    // Process parameters
    if (operation.parameters) {
      this.processParameters(operation.parameters, requestConfig);
    }

    // Process request body
    if (this.isOpenAPI3(api) && 'requestBody' in operation && operation.requestBody) {
      this.processRequestBody(operation.requestBody as OpenAPI.RequestBody, requestConfig);
    }

    // Process security
    const auth = this.processOperationSecurity(operation, api);
    if (auth) {
      requestConfig.auth = auth;
    }

    // Generate examples
    const examples = this.generateExamples(operation, requestConfig);

    return {
      path,
      method,
      operationId: operation.operationId,
      summary: operation.summary,
      description: operation.description,
      requestConfig,
      examples
    };
  }

  /**
   * Process operation parameters
   */
  private processParameters(
    parameters: (OpenAPI.Parameter | OpenAPI.Reference)[],
    requestConfig: RequestConfig
  ): void {
    
    for (const param of parameters) {
      if ('$ref' in param) {
        // Skip references for now (would need to resolve them)
        continue;
      }

      const parameter = param as OpenAPI.Parameter;
      const example = this.getParameterExample(parameter);

      switch (parameter.in) {
        case 'query':
          requestConfig.query[parameter.name] = example;
          break;
        
        case 'header':
          requestConfig.headers[parameter.name] = String(example);
          break;
        
        case 'path':
          // Path parameters are handled in URL templating
          requestConfig.url = requestConfig.url.replace(
            `{${parameter.name}}`, 
            `{{variables.${parameter.name}}}`
          );
          break;
      }
    }
  }

  /**
   * Process request body for OpenAPI 3.x
   */
  private processRequestBody(
    requestBody: OpenAPI.RequestBody,
    requestConfig: RequestConfig
  ): void {
    
    if (!requestBody.content) return;

    // Find the first supported content type
    const contentTypes = Object.keys(requestBody.content);
    const supportedTypes = ['application/json', 'application/xml', 'text/plain', 'application/x-www-form-urlencoded'];
    
    const contentType = supportedTypes.find(type => contentTypes.includes(type)) || contentTypes[0];
    
    if (contentType) {
      const mediaType = requestBody.content[contentType];
      
      // Set content type header
      requestConfig.headers['Content-Type'] = contentType;
      
      // Generate example body
      if (mediaType.schema) {
        requestConfig.body = this.generateSchemaExample(mediaType.schema);
      } else if (mediaType.example) {
        requestConfig.body = mediaType.example;
      } else if (mediaType.examples) {
        const exampleKey = Object.keys(mediaType.examples)[0];
        const example = mediaType.examples[exampleKey];
        requestConfig.body = 'value' in example ? example.value : example;
      }
    }
  }

  /**
   * Process operation security
   */
  private processOperationSecurity(
    operation: OpenAPI.Operation,
    api: OpenAPI.Document
  ): AuthConfig | undefined {
    
    // Use operation-specific security or fall back to global
    const security = operation.security || api.security;
    if (!security || security.length === 0) {
      return undefined;
    }

    // Process first security requirement
    const securityRequirement = security[0];
    const securitySchemeName = Object.keys(securityRequirement)[0];
    
    if (!securitySchemeName) return undefined;

    // Get security scheme definition
    let securityScheme: OpenAPI.SecurityScheme | undefined;
    
    if (this.isOpenAPI3(api)) {
      const openapi3 = api as OpenAPI.Document3;
      securityScheme = openapi3.components?.securitySchemes?.[securitySchemeName] as OpenAPI.SecurityScheme;
    } else {
      const swagger2 = api as OpenAPI.Document2;
      securityScheme = swagger2.securityDefinitions?.[securitySchemeName] as any;
    }

    if (!securityScheme) return undefined;

    return this.convertSecurityScheme(securityScheme);
  }

  /**
   * Convert OpenAPI security scheme to AuthConfig
   */
  private convertSecurityScheme(securityScheme: OpenAPI.SecurityScheme): AuthConfig {
    switch (securityScheme.type) {
      case 'http':
        const httpScheme = securityScheme as OpenAPI.HttpSecurityScheme;
        if (httpScheme.scheme === 'basic') {
          return {
            type: 'basic',
            basic: {
              username: '{{variables.username}}',
              password: '{{variables.password}}'
            }
          };
        } else if (httpScheme.scheme === 'bearer') {
          return {
            type: 'bearer',
            bearer: {
              token: '{{variables.bearerToken}}'
            }
          };
        }
        break;
      
      case 'apiKey':
        const apiKeyScheme = securityScheme as OpenAPI.ApiKeySecurityScheme;
        return {
          type: 'apikey',
          apikey: {
            key: apiKeyScheme.name,
            value: `{{variables.${apiKeyScheme.name}}}`,
            location: apiKeyScheme.in === 'header' ? 'header' : 'query'
          }
        };
      
      case 'oauth2':
        return {
          type: 'oauth2',
          oauth2: {
            accessToken: '{{variables.accessToken}}'
          }
        };
    }

    return {
      type: 'custom',
      custom: {
        headers: {
          'Authorization': '{{variables.authorization}}'
        }
      }
    };
  }

  /**
   * Generate examples for an operation
   */
  private generateExamples(
    operation: OpenAPI.Operation,
    baseConfig: RequestConfig
  ): Array<{ name: string; config: RequestConfig }> {
    
    const examples: Array<{ name: string; config: RequestConfig }> = [];
    
    // Create basic example
    examples.push({
      name: 'Basic Example',
      config: { ...baseConfig }
    });

    // TODO: Generate additional examples based on parameter schemas
    // This could include edge cases, different data types, etc.

    return examples;
  }

  /**
   * Utility methods
   */
  private isOpenAPI3(api: OpenAPI.Document): boolean {
    return 'openapi' in api;
  }

  private buildUrl(path: string): string {
    // Convert OpenAPI path parameters to template variables
    return path.replace(/{([^}]+)}/g, '{{variables.$1}}');
  }

  private getParameterExample(parameter: OpenAPI.Parameter): any {
    if (parameter.example !== undefined) {
      return parameter.example;
    }

    if (parameter.schema) {
      return this.generateSchemaExample(parameter.schema);
    }

    // Fallback based on type
    switch (parameter.type || 'string') {
      case 'integer': return 123;
      case 'number': return 123.45;
      case 'boolean': return true;
      case 'array': return [];
      case 'object': return {};
      default: return `{{variables.${parameter.name}}}`;
    }
  }

  private generateSchemaExample(schema: OpenAPI.Schema | OpenAPI.Reference): any {
    if ('$ref' in schema) {
      return {}; // Skip references
    }

    const s = schema as OpenAPI.Schema;

    if (s.example !== undefined) {
      return s.example;
    }

    switch (s.type) {
      case 'string':
        if (s.enum) return s.enum[0];
        if (s.format === 'email') return 'example@email.com';
        if (s.format === 'date') return '2023-12-15';
        if (s.format === 'date-time') return '2023-12-15T10:30:00Z';
        return 'string';
      
      case 'integer':
      case 'number':
        return s.minimum || 0;
      
      case 'boolean':
        return true;
      
      case 'array':
        if (s.items) {
          const itemExample = this.generateSchemaExample(s.items);
          return [itemExample];
        }
        return [];
      
      case 'object':
        const obj: any = {};
        if (s.properties) {
          for (const [propName, propSchema] of Object.entries(s.properties)) {
            obj[propName] = this.generateSchemaExample(propSchema);
          }
        }
        return obj;
      
      default:
        return null;
    }
  }

  /**
   * Validate OpenAPI specification
   */
  async validateSpec(spec: any): Promise<{ valid: boolean; errors: string[] }> {
    try {
      await SwaggerParser.validate(spec);
      return { valid: true, errors: [] };
    } catch (error: any) {
      return { 
        valid: false, 
        errors: Array.isArray(error) ? error.map((e: any) => e.message) : [error.message]
      };
    }
  }

  /**
   * Get specification info without full processing
   */
  async getSpecInfo(specUrl: string): Promise<{ title: string; version: string; description?: string }> {
    try {
      const api = await SwaggerParser.dereference(specUrl) as OpenAPI.Document;
      return {
        title: api.info.title,
        version: api.info.version,
        description: api.info.description
      };
    } catch (error: any) {
      throw new ApiEngineError(
        `Failed to get spec info: ${error.message}`,
        'OPENAPI_INFO_ERROR'
      );
    }
  }
} 