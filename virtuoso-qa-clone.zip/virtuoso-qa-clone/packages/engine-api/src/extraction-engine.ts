import { logger } from '@hybrid-qa/common';
import { ExtractionConfig, ApiResponse, GraphQLResponse, GrpcResponse, ApiEngineError } from './types';

/**
 * Engine for extracting data from API responses using various strategies
 */
export class ExtractionEngine {
  /**
   * Extract data from API response based on configuration
   */
  async extract(
    response: ApiResponse | GraphQLResponse | GrpcResponse,
    config: ExtractionConfig
  ): Promise<any> {
    try {
      logger.debug('Extracting data from response', { 
        type: config.type,
        expression: config.expression 
      });

      let result: any;

      switch (config.type) {
        case 'jsonpath':
          result = this.extractJsonPath(response, config);
          break;
        
        case 'xpath':
          result = this.extractXPath(response, config);
          break;
        
        case 'regex':
          result = this.extractRegex(response, config);
          break;
        
        case 'header':
          result = this.extractHeader(response, config);
          break;
        
        case 'status':
          result = this.extractStatus(response, config);
          break;
        
        default:
          throw new ApiEngineError(
            `Unsupported extraction type: ${config.type}`,
            'EXTRACTION_TYPE_ERROR'
          );
      }

      // Return default value if extraction yields no results
      if (result === null || result === undefined) {
        result = config.defaultValue;
      }

      logger.debug('Data extraction completed', { 
        type: config.type,
        hasResult: result !== null && result !== undefined,
        isMultiple: Array.isArray(result)
      });

      return result;

    } catch (error: any) {
      logger.error('Data extraction failed', { 
        type: config.type,
        expression: config.expression,
        error: error.message 
      });

      // Return default value on error if specified
      if (config.defaultValue !== undefined) {
        return config.defaultValue;
      }

      throw new ApiEngineError(
        `Extraction failed: ${error.message}`,
        'EXTRACTION_ERROR',
        { config, error: error.message }
      );
    }
  }

  /**
   * Extract data using JSONPath
   */
  private extractJsonPath(
    response: ApiResponse | GraphQLResponse | GrpcResponse,
    config: ExtractionConfig
  ): any {
    const { JSONPath } = require('jsonpath-plus');
    
    // Get the source data based on response type
    let sourceData: any;
    if ('body' in response) {
      // REST API response
      sourceData = response.body;
    } else if ('data' in response && 'errors' in response) {
      // GraphQL response
      sourceData = response.data;
    } else {
      // gRPC response
      sourceData = response.data;
    }

    try {
      const result = JSONPath({
        path: config.expression,
        json: sourceData,
        wrap: false
      });

      if (config.multiple) {
        return Array.isArray(result) ? result : [result].filter(item => item !== undefined);
      } else {
        return Array.isArray(result) && result.length > 0 ? result[0] : result;
      }
    } catch (error: any) {
      throw new Error(`JSONPath extraction failed: ${error.message}`);
    }
  }

  /**
   * Extract data using XPath (for XML responses)
   */
  private extractXPath(
    response: ApiResponse | GraphQLResponse | GrpcResponse,
    config: ExtractionConfig
  ): any {
    const xpath = require('xpath');
    const { DOMParser } = require('xmldom');

    // Get XML content
    let xmlContent: string;
    if ('rawBody' in response) {
      xmlContent = response.rawBody;
    } else {
      throw new Error('XPath extraction requires raw response body (XML content)');
    }

    try {
      const doc = new DOMParser().parseFromString(xmlContent, 'text/xml');
      const nodes = xpath.select(config.expression, doc);

      let result: any;

      if (Array.isArray(nodes)) {
        if (config.attribute) {
          // Extract attribute values
          result = nodes.map(node => {
            if (node.getAttribute) {
              return node.getAttribute(config.attribute);
            }
            return null;
          }).filter(val => val !== null);
        } else {
          // Extract text content
          result = nodes.map(node => {
            if (node.textContent !== undefined) {
              return node.textContent;
            } else if (node.nodeValue) {
              return node.nodeValue;
            } else if (typeof node === 'string') {
              return node;
            }
            return null;
          }).filter(val => val !== null);
        }

        if (!config.multiple && result.length > 0) {
          result = result[0];
        }
      } else {
        // Single node result
        if (config.attribute && nodes.getAttribute) {
          result = nodes.getAttribute(config.attribute);
        } else if (nodes.textContent !== undefined) {
          result = nodes.textContent;
        } else if (nodes.nodeValue) {
          result = nodes.nodeValue;
        } else {
          result = nodes;
        }
      }

      return result;

    } catch (error: any) {
      throw new Error(`XPath extraction failed: ${error.message}`);
    }
  }

  /**
   * Extract data using regular expressions
   */
  private extractRegex(
    response: ApiResponse | GraphQLResponse | GrpcResponse,
    config: ExtractionConfig
  ): any {
    // Get text content to search
    let searchText: string;
    if ('rawBody' in response) {
      searchText = response.rawBody;
    } else if ('body' in response) {
      searchText = typeof response.body === 'string' 
        ? response.body 
        : JSON.stringify(response.body);
    } else {
      searchText = JSON.stringify(response);
    }

    try {
      const flags = config.flags || 'g';
      const regex = new RegExp(config.expression, flags);
      
      if (config.multiple) {
        const matches = Array.from(searchText.matchAll(regex));
        return matches.map(match => {
          // Return capture groups if available, otherwise return full match
          if (match.length > 1) {
            return match.length === 2 ? match[1] : match.slice(1);
          }
          return match[0];
        });
      } else {
        const match = searchText.match(regex);
        if (match) {
          // Return first capture group if available, otherwise return full match
          return match.length > 1 ? match[1] : match[0];
        }
        return null;
      }
    } catch (error: any) {
      throw new Error(`Regex extraction failed: ${error.message}`);
    }
  }

  /**
   * Extract header value
   */
  private extractHeader(
    response: ApiResponse | GraphQLResponse | GrpcResponse,
    config: ExtractionConfig
  ): any {
    if (!('headers' in response)) {
      throw new Error('Header extraction not supported for this response type');
    }

    const headers = response.headers;
    const headerName = config.expression.toLowerCase();
    
    return headers[headerName] || null;
  }

  /**
   * Extract status code
   */
  private extractStatus(
    response: ApiResponse | GraphQLResponse | GrpcResponse,
    config: ExtractionConfig
  ): any {
    if ('status' in response) {
      return response.status;
    } else if ('data' in response && 'errors' in response) {
      // GraphQL response - return 200 if no errors, 400 if errors
      return (response as GraphQLResponse).errors ? 400 : 200;
    } else if ('status' in response) {
      // gRPC response
      return (response as GrpcResponse).status.code;
    }
    
    return null;
  }

  /**
   * Batch extract multiple values from a response
   */
  async extractMultiple(
    response: ApiResponse | GraphQLResponse | GrpcResponse,
    configs: ExtractionConfig[]
  ): Promise<Record<string, any>> {
    const results: Record<string, any> = {};
    
    for (const config of configs) {
      try {
        const key = this.generateExtractionKey(config);
        results[key] = await this.extract(response, config);
      } catch (error: any) {
        logger.warn('Failed to extract value', { 
          type: config.type,
          expression: config.expression,
          error: error.message 
        });
        
        if (config.defaultValue !== undefined) {
          const key = this.generateExtractionKey(config);
          results[key] = config.defaultValue;
        }
      }
    }
    
    return results;
  }

  /**
   * Generate a key for extraction result
   */
  private generateExtractionKey(config: ExtractionConfig): string {
    // Use expression as key, but sanitize it
    let key = config.expression
      .replace(/[^a-zA-Z0-9_$]/g, '_')
      .replace(/_{2,}/g, '_')
      .replace(/^_+|_+$/g, '');
    
    if (!key || key.length === 0) {
      key = `${config.type}_extraction`;
    }
    
    return key;
  }

  /**
   * Validate extraction configuration
   */
  validateConfig(config: ExtractionConfig): { valid: boolean; errors: string[] } {
    const errors: string[] = [];

    if (!config.expression) {
      errors.push('Expression is required');
    }

    switch (config.type) {
      case 'jsonpath':
        if (!config.expression.startsWith('$')) {
          errors.push('JSONPath expression should start with $');
        }
        break;
      
      case 'xpath':
        // Basic XPath validation
        if (config.expression.includes('//') && !config.expression.startsWith('/')) {
          // Allow descendant expressions
        } else if (!config.expression.startsWith('/') && !config.expression.startsWith('.')) {
          errors.push('XPath expression should start with / or .');
        }
        break;
      
      case 'regex':
        try {
          new RegExp(config.expression, config.flags || 'g');
        } catch (error: any) {
          errors.push(`Invalid regex pattern: ${error.message}`);
        }
        break;
      
      case 'header':
        if (!config.expression || config.expression.trim().length === 0) {
          errors.push('Header name cannot be empty');
        }
        break;
      
      case 'status':
        // Status extraction doesn't need expression validation
        break;
    }

    return {
      valid: errors.length === 0,
      errors
    };
  }

  /**
   * Test an extraction configuration against sample data
   */
  async testExtraction(
    sampleData: any,
    config: ExtractionConfig
  ): Promise<{ success: boolean; result?: any; error?: string }> {
    try {
      // Create a mock response for testing
      const mockResponse: any = {
        status: 200,
        statusText: 'OK',
        headers: { 'content-type': 'application/json' },
        body: sampleData,
        rawBody: typeof sampleData === 'string' ? sampleData : JSON.stringify(sampleData),
        duration: 100,
        timestamp: new Date(),
        url: 'http://test.example.com',
        method: 'GET'
      };

      const result = await this.extract(mockResponse, config);
      
      return {
        success: true,
        result
      };
    } catch (error: any) {
      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * Extract and transform data in one step
   */
  async extractAndTransform(
    response: ApiResponse | GraphQLResponse | GrpcResponse,
    config: ExtractionConfig,
    transformer?: (value: any) => any
  ): Promise<any> {
    const extracted = await this.extract(response, config);
    
    if (transformer && extracted !== null && extracted !== undefined) {
      try {
        return transformer(extracted);
      } catch (error: any) {
        logger.warn('Data transformation failed', { error: error.message });
        return extracted; // Return original value if transformation fails
      }
    }
    
    return extracted;
  }

  /**
   * Common transformers
   */
  static transformers = {
    toString: (value: any) => String(value),
    toNumber: (value: any) => Number(value),
    toBoolean: (value: any) => Boolean(value),
    toUpperCase: (value: string) => String(value).toUpperCase(),
    toLowerCase: (value: string) => String(value).toLowerCase(),
    trim: (value: string) => String(value).trim(),
    parseJson: (value: string) => JSON.parse(value),
    toArray: (value: any) => Array.isArray(value) ? value : [value],
    length: (value: any) => value?.length || 0,
    first: (value: any[]) => Array.isArray(value) ? value[0] : value,
    last: (value: any[]) => Array.isArray(value) ? value[value.length - 1] : value,
    unique: (value: any[]) => Array.isArray(value) ? [...new Set(value)] : value,
    sort: (value: any[]) => Array.isArray(value) ? [...value].sort() : value,
    reverse: (value: any[]) => Array.isArray(value) ? [...value].reverse() : value,
  };
} 