import { logger } from '@hybrid-qa/common';
import { AssertionConfig, ApiResponse, GraphQLResponse, GrpcResponse, ApiEngineError } from './types';
import { ExtractionEngine } from './extraction-engine';

/**
 * Result of an assertion
 */
interface AssertionResult {
  passed: boolean;
  message: string;
  actual?: any;
  expected?: any;
}

/**
 * Engine for asserting API response conditions
 */
export class AssertionEngine {
  private extractionEngine: ExtractionEngine;

  constructor() {
    this.extractionEngine = new ExtractionEngine();
  }

  /**
   * Assert a condition against an API response
   */
  async assert(
    response: ApiResponse | GraphQLResponse | GrpcResponse,
    config: AssertionConfig
  ): Promise<AssertionResult> {
    try {
      logger.debug('Performing assertion', { 
        type: config.type,
        expected: this.maskSensitiveValue(config.expected)
      });

      let actual: any;

      // Get actual value based on path or direct response
      if (config.path) {
        // Use extraction to get value from path
        const extractionConfig = {
          type: 'jsonpath' as const,
          expression: config.path,
          multiple: false
        };
        actual = await this.extractionEngine.extract(response, extractionConfig);
      } else if (config.actual !== undefined) {
        // Use provided actual value
        actual = config.actual;
      } else {
        // Use whole response body for assertion
        if ('body' in response) {
          actual = response.body;
        } else if ('data' in response) {
          actual = (response as any).data;
        } else {
          actual = response;
        }
      }

      const result = await this.performAssertion(actual, config);

      logger.debug('Assertion completed', { 
        type: config.type,
        passed: result.passed,
        message: result.message
      });

      return result;

    } catch (error: any) {
      logger.error('Assertion failed', { 
        type: config.type,
        error: error.message 
      });

      return {
        passed: false,
        message: `Assertion error: ${error.message}`,
        actual: undefined,
        expected: config.expected
      };
    }
  }

  /**
   * Perform the actual assertion based on type
   */
  private async performAssertion(
    actual: any,
    config: AssertionConfig
  ): Promise<AssertionResult> {
    const { type, expected, ignoreCase, tolerance } = config;

    switch (type) {
      case 'equals':
        return this.assertEqual(actual, expected, ignoreCase);
      
      case 'not_equals':
        return this.assertNotEqual(actual, expected, ignoreCase);
      
      case 'contains':
        return this.assertContains(actual, expected, ignoreCase);
      
      case 'not_contains':
        return this.assertNotContains(actual, expected, ignoreCase);
      
      case 'greater_than':
        return this.assertGreaterThan(actual, expected, tolerance);
      
      case 'less_than':
        return this.assertLessThan(actual, expected, tolerance);
      
      case 'regex':
        return this.assertRegex(actual, expected);
      
      case 'json_schema':
        return this.assertJsonSchema(actual, expected);
      
      case 'status_code':
        return this.assertStatusCode(actual, expected);
      
      case 'response_time':
        return this.assertResponseTime(actual, expected, tolerance);
      
      default:
        throw new ApiEngineError(
          `Unsupported assertion type: ${type}`,
          'ASSERTION_TYPE_ERROR'
        );
    }
  }

  /**
   * Assert equality
   */
  private assertEqual(actual: any, expected: any, ignoreCase?: boolean): AssertionResult {
    let isEqual: boolean;
    
    if (ignoreCase && typeof actual === 'string' && typeof expected === 'string') {
      isEqual = actual.toLowerCase() === expected.toLowerCase();
    } else {
      isEqual = this.deepEqual(actual, expected);
    }
    
    return {
      passed: isEqual,
      message: isEqual 
        ? `Values are equal: ${this.formatValue(expected)}`
        : `Expected ${this.formatValue(expected)}, but got ${this.formatValue(actual)}`,
      actual,
      expected
    };
  }

  /**
   * Assert not equality
   */
  private assertNotEqual(actual: any, expected: any, ignoreCase?: boolean): AssertionResult {
    const equalResult = this.assertEqual(actual, expected, ignoreCase);
    
    return {
      passed: !equalResult.passed,
      message: equalResult.passed
        ? `Values should not be equal: ${this.formatValue(expected)}`
        : `Values are correctly not equal`,
      actual,
      expected
    };
  }

  /**
   * Assert contains
   */
  private assertContains(actual: any, expected: any, ignoreCase?: boolean): AssertionResult {
    let contains: boolean;
    let actualStr = String(actual);
    let expectedStr = String(expected);
    
    if (ignoreCase) {
      actualStr = actualStr.toLowerCase();
      expectedStr = expectedStr.toLowerCase();
    }
    
    if (Array.isArray(actual)) {
      contains = actual.some(item => 
        ignoreCase 
          ? String(item).toLowerCase() === expectedStr
          : item === expected
      );
    } else if (typeof actual === 'object' && actual !== null) {
      contains = this.objectContains(actual, expected);
    } else {
      contains = actualStr.includes(expectedStr);
    }
    
    return {
      passed: contains,
      message: contains
        ? `Value contains ${this.formatValue(expected)}`
        : `Value does not contain ${this.formatValue(expected)}`,
      actual,
      expected
    };
  }

  /**
   * Assert not contains
   */
  private assertNotContains(actual: any, expected: any, ignoreCase?: boolean): AssertionResult {
    const containsResult = this.assertContains(actual, expected, ignoreCase);
    
    return {
      passed: !containsResult.passed,
      message: containsResult.passed
        ? `Value should not contain ${this.formatValue(expected)}`
        : `Value correctly does not contain ${this.formatValue(expected)}`,
      actual,
      expected
    };
  }

  /**
   * Assert greater than
   */
  private assertGreaterThan(actual: any, expected: any, tolerance?: number): AssertionResult {
    const actualNum = Number(actual);
    const expectedNum = Number(expected);
    
    if (isNaN(actualNum) || isNaN(expectedNum)) {
      return {
        passed: false,
        message: `Cannot compare non-numeric values: ${this.formatValue(actual)} > ${this.formatValue(expected)}`,
        actual,
        expected
      };
    }
    
    const isGreater = tolerance 
      ? actualNum > (expectedNum - tolerance)
      : actualNum > expectedNum;
    
    return {
      passed: isGreater,
      message: isGreater
        ? `${actualNum} is greater than ${expectedNum}${tolerance ? ` (±${tolerance})` : ''}`
        : `${actualNum} is not greater than ${expectedNum}${tolerance ? ` (±${tolerance})` : ''}`,
      actual: actualNum,
      expected: expectedNum
    };
  }

  /**
   * Assert less than
   */
  private assertLessThan(actual: any, expected: any, tolerance?: number): AssertionResult {
    const actualNum = Number(actual);
    const expectedNum = Number(expected);
    
    if (isNaN(actualNum) || isNaN(expectedNum)) {
      return {
        passed: false,
        message: `Cannot compare non-numeric values: ${this.formatValue(actual)} < ${this.formatValue(expected)}`,
        actual,
        expected
      };
    }
    
    const isLess = tolerance 
      ? actualNum < (expectedNum + tolerance)
      : actualNum < expectedNum;
    
    return {
      passed: isLess,
      message: isLess
        ? `${actualNum} is less than ${expectedNum}${tolerance ? ` (±${tolerance})` : ''}`
        : `${actualNum} is not less than ${expectedNum}${tolerance ? ` (±${tolerance})` : ''}`,
      actual: actualNum,
      expected: expectedNum
    };
  }

  /**
   * Assert regex match
   */
  private assertRegex(actual: any, expected: any): AssertionResult {
    try {
      const actualStr = String(actual);
      const regex = new RegExp(expected);
      const matches = regex.test(actualStr);
      
      return {
        passed: matches,
        message: matches
          ? `Value matches regex pattern: ${expected}`
          : `Value does not match regex pattern: ${expected}`,
        actual: actualStr,
        expected
      };
    } catch (error: any) {
      return {
        passed: false,
        message: `Invalid regex pattern: ${expected} - ${error.message}`,
        actual,
        expected
      };
    }
  }

  /**
   * Assert JSON schema compliance
   */
  private assertJsonSchema(actual: any, expected: any): AssertionResult {
    try {
      const Joi = require('joi');
      
      // If expected is a Joi schema object
      if (expected && typeof expected.validate === 'function') {
        const result = expected.validate(actual);
        return {
          passed: !result.error,
          message: result.error 
            ? `Schema validation failed: ${result.error.message}`
            : 'Schema validation passed',
          actual,
          expected: 'Joi schema'
        };
      }
      
      // If expected is a JSON schema object, use a simple validation
      if (typeof expected === 'object' && expected.type) {
        const isValid = this.validateSimpleJsonSchema(actual, expected);
        return {
          passed: isValid,
          message: isValid 
            ? 'JSON schema validation passed'
            : 'JSON schema validation failed',
          actual,
          expected
        };
      }
      
      return {
        passed: false,
        message: 'Invalid schema format provided',
        actual,
        expected
      };
      
    } catch (error: any) {
      return {
        passed: false,
        message: `Schema validation error: ${error.message}`,
        actual,
        expected
      };
    }
  }

  /**
   * Assert status code
   */
  private assertStatusCode(actual: any, expected: any): AssertionResult {
    // actual might be the full response or just the status
    let statusCode: number;
    
    if (typeof actual === 'number') {
      statusCode = actual;
    } else if (actual && typeof actual === 'object' && 'status' in actual) {
      statusCode = actual.status;
    } else {
      return {
        passed: false,
        message: 'Cannot determine status code from response',
        actual,
        expected
      };
    }
    
    const expectedCode = Number(expected);
    const matches = statusCode === expectedCode;
    
    return {
      passed: matches,
      message: matches
        ? `Status code matches: ${statusCode}`
        : `Expected status ${expectedCode}, but got ${statusCode}`,
      actual: statusCode,
      expected: expectedCode
    };
  }

  /**
   * Assert response time
   */
  private assertResponseTime(actual: any, expected: any, tolerance?: number): AssertionResult {
    // actual might be the full response or just the duration
    let responseTime: number;
    
    if (typeof actual === 'number') {
      responseTime = actual;
    } else if (actual && typeof actual === 'object' && 'duration' in actual) {
      responseTime = actual.duration;
    } else {
      return {
        passed: false,
        message: 'Cannot determine response time from response',
        actual,
        expected
      };
    }
    
    const expectedTime = Number(expected);
    const tolerance_value = tolerance || expectedTime * 0.1; // 10% tolerance by default
    const withinTolerance = Math.abs(responseTime - expectedTime) <= tolerance_value;
    
    return {
      passed: withinTolerance,
      message: withinTolerance
        ? `Response time ${responseTime}ms is within expected range (${expectedTime}±${tolerance_value}ms)`
        : `Response time ${responseTime}ms is outside expected range (${expectedTime}±${tolerance_value}ms)`,
      actual: responseTime,
      expected: expectedTime
    };
  }

  /**
   * Validate configuration
   */
  validateConfig(config: AssertionConfig): { valid: boolean; errors: string[] } {
    const errors: string[] = [];

    if (!config.type) {
      errors.push('Assertion type is required');
    }

    if (config.expected === undefined && config.type !== 'status_code' && config.type !== 'response_time') {
      errors.push('Expected value is required for most assertion types');
    }

    // Type-specific validation
    switch (config.type) {
      case 'regex':
        if (typeof config.expected !== 'string') {
          errors.push('Regex pattern must be a string');
        } else {
          try {
            new RegExp(config.expected);
          } catch (error) {
            errors.push('Invalid regex pattern');
          }
        }
        break;
      
      case 'greater_than':
      case 'less_than':
        if (typeof config.expected !== 'number') {
          errors.push('Numeric comparison requires a number as expected value');
        }
        break;
      
      case 'status_code':
        if (config.expected !== undefined && !Number.isInteger(Number(config.expected))) {
          errors.push('Status code must be an integer');
        }
        break;
      
      case 'response_time':
        if (config.expected !== undefined && typeof config.expected !== 'number') {
          errors.push('Response time must be a number (milliseconds)');
        }
        break;
    }

    return {
      valid: errors.length === 0,
      errors
    };
  }

  /**
   * Utility methods
   */
  private deepEqual(a: any, b: any): boolean {
    if (a === b) return true;
    if (a === null || b === null) return false;
    if (typeof a !== typeof b) return false;
    
    if (Array.isArray(a) && Array.isArray(b)) {
      if (a.length !== b.length) return false;
      for (let i = 0; i < a.length; i++) {
        if (!this.deepEqual(a[i], b[i])) return false;
      }
      return true;
    }
    
    if (typeof a === 'object') {
      const keysA = Object.keys(a);
      const keysB = Object.keys(b);
      if (keysA.length !== keysB.length) return false;
      
      for (const key of keysA) {
        if (!keysB.includes(key) || !this.deepEqual(a[key], b[key])) {
          return false;
        }
      }
      return true;
    }
    
    return false;
  }

  private objectContains(obj: any, expected: any): boolean {
    if (typeof expected !== 'object' || expected === null) {
      return Object.values(obj).includes(expected);
    }
    
    // Check if obj contains all properties of expected
    for (const [key, value] of Object.entries(expected)) {
      if (!(key in obj) || !this.deepEqual(obj[key], value)) {
        return false;
      }
    }
    
    return true;
  }

  private validateSimpleJsonSchema(data: any, schema: any): boolean {
    // Very basic JSON schema validation
    if (schema.type) {
      const dataType = Array.isArray(data) ? 'array' : typeof data;
      if (dataType !== schema.type) {
        return false;
      }
    }
    
    if (schema.properties && typeof data === 'object' && data !== null) {
      for (const [prop, propSchema] of Object.entries(schema.properties as any)) {
        if (schema.required?.includes(prop) && !(prop in data)) {
          return false;
        }
        if (prop in data && !this.validateSimpleJsonSchema(data[prop], propSchema)) {
          return false;
        }
      }
    }
    
    return true;
  }

  private formatValue(value: any): string {
    if (value === null) return 'null';
    if (value === undefined) return 'undefined';
    if (typeof value === 'string') return `"${value}"`;
    if (typeof value === 'object') return JSON.stringify(value);
    return String(value);
  }

  private maskSensitiveValue(value: any): any {
    if (typeof value === 'string' && (
      value.toLowerCase().includes('password') ||
      value.toLowerCase().includes('token') ||
      value.toLowerCase().includes('secret') ||
      value.toLowerCase().includes('key')
    )) {
      return '***';
    }
    return value;
  }
}

export { AssertionResult }; 