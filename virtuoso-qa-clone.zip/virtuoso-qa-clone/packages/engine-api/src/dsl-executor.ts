import { logger } from '@hybrid-qa/common';
import { RequestRunner } from './request-runner';
import { ExtractionEngine } from './extraction-engine';
import { AssertionEngine } from './assertion-engine';
import { TemplateEngine } from './template-engine';
import {
  ApiStep,
  ApiRequestStep,
  ApiGraphQLStep,
  ApiGrpcStep,
  ApiWebSocketConnectStep,
  ApiWebSocketSendStep,
  ApiWebSocketDisconnectStep,
  TemplateContext,
  ApiResponse,
  GraphQLResponse,
  GrpcResponse,
  ApiEngineError,
  ExtractionConfig,
  AssertionConfig
} from './types';

/**
 * Result of executing a DSL step
 */
interface StepExecutionResult {
  success: boolean;
  response?: ApiResponse | GraphQLResponse | GrpcResponse;
  extractions?: Record<string, any>;
  assertions?: Array<{ passed: boolean; message: string; config: AssertionConfig }>;
  error?: string;
  duration: number;
  timestamp: Date;
}

/**
 * Context for DSL step execution
 */
interface ExecutionContext extends TemplateContext {
  stepIndex: number;
  previousResults: StepExecutionResult[];
  sessionData: Record<string, any>;
}

/**
 * DSL executor that handles API testing steps
 */
export class DSLExecutor {
  private requestRunner: RequestRunner;
  private extractionEngine: ExtractionEngine;
  private assertionEngine: AssertionEngine;
  private templateEngine: TemplateEngine;

  constructor() {
    this.requestRunner = new RequestRunner();
    this.extractionEngine = new ExtractionEngine();
    this.assertionEngine = new AssertionEngine();
    this.templateEngine = new TemplateEngine();
  }

  /**
   * Execute a single API DSL step
   */
  async executeStep(
    step: ApiStep,
    context: ExecutionContext
  ): Promise<StepExecutionResult> {
    const startTime = Date.now();
    
    try {
      logger.info('Executing DSL step', { 
        kind: step.kind,
        stepIndex: context.stepIndex 
      });

      let response: ApiResponse | GraphQLResponse | GrpcResponse | undefined;

      // Execute the main action based on step kind
      switch (step.kind) {
        case 'api.request':
          response = await this.executeRestRequest(step, context);
          break;
        
        case 'api.graphql':
          response = await this.executeGraphQLRequest(step, context);
          break;
        
        case 'api.grpc':
          response = await this.executeGrpcRequest(step, context);
          break;
        
        case 'api.websocket-connect':
          await this.executeWebSocketConnect(step, context);
          break;
        
        case 'api.websocket-send':
          await this.executeWebSocketSend(step, context);
          break;
        
        case 'api.websocket-disconnect':
          await this.executeWebSocketDisconnect(step, context);
          break;
        
        default:
          throw new ApiEngineError(
            `Unsupported step kind: ${(step as any).kind}`,
            'UNSUPPORTED_STEP_KIND'
          );
      }

      const duration = Date.now() - startTime;

      // Handle extractions
      let extractions: Record<string, any> = {};
      if (response && 'extractions' in step && step.extractions) {
        extractions = await this.extractionEngine.extractMultiple(
          response, 
          step.extractions
        );
        
        // Update context with extracted values
        Object.assign(context.variables, extractions);
      }

      // Handle assertions
      let assertions: Array<{ passed: boolean; message: string; config: AssertionConfig }> = [];
      if (response && 'assertions' in step && step.assertions) {
        for (const assertionConfig of step.assertions) {
          try {
            const result = await this.assertionEngine.assert(response, assertionConfig);
            assertions.push({
              passed: result.passed,
              message: result.message,
              config: assertionConfig
            });
          } catch (error: any) {
            assertions.push({
              passed: false,
              message: `Assertion failed: ${error.message}`,
              config: assertionConfig
            });
          }
        }
      }

      // Check if any assertions failed
      const failedAssertions = assertions.filter(a => !a.passed);
      const success = failedAssertions.length === 0;

      const result: StepExecutionResult = {
        success,
        response,
        extractions,
        assertions,
        duration,
        timestamp: new Date()
      };

      if (!success) {
        result.error = `${failedAssertions.length} assertion(s) failed`;
      }

      logger.info('DSL step execution completed', {
        kind: step.kind,
        success,
        duration,
        extractionCount: Object.keys(extractions).length,
        assertionCount: assertions.length,
        failedAssertions: failedAssertions.length
      });

      return result;

    } catch (error: any) {
      const duration = Date.now() - startTime;
      
      logger.error('DSL step execution failed', { 
        kind: step.kind,
        error: error.message,
        duration 
      });

      return {
        success: false,
        error: error.message,
        duration,
        timestamp: new Date()
      };
    }
  }

  /**
   * Execute REST API request step
   */
  private async executeRestRequest(
    step: ApiRequestStep,
    context: ExecutionContext
  ): Promise<ApiResponse> {
    return await this.requestRunner.executeRestRequest(step.config, context);
  }

  /**
   * Execute GraphQL request step
   */
  private async executeGraphQLRequest(
    step: ApiGraphQLStep,
    context: ExecutionContext
  ): Promise<GraphQLResponse> {
    return await this.requestRunner.executeGraphQLRequest(step.config, context);
  }

  /**
   * Execute gRPC request step
   */
  private async executeGrpcRequest(
    step: ApiGrpcStep,
    context: ExecutionContext
  ): Promise<GrpcResponse> {
    return await this.requestRunner.executeGrpcRequest(step.config, context);
  }

  /**
   * Execute WebSocket connect step
   */
  private async executeWebSocketConnect(
    step: ApiWebSocketConnectStep,
    context: ExecutionContext
  ): Promise<void> {
    const sessionId = `ws_${context.stepIndex}_${Date.now()}`;
    await this.requestRunner.connectWebSocket(sessionId, step.config, context);
    
    // Store session ID for future steps
    context.sessionData[`websocket_session_${context.stepIndex}`] = sessionId;
  }

  /**
   * Execute WebSocket send step
   */
  private async executeWebSocketSend(
    step: ApiWebSocketSendStep,
    context: ExecutionContext
  ): Promise<void> {
    await this.requestRunner.sendWebSocketMessage(step.sessionId, step.message);
  }

  /**
   * Execute WebSocket disconnect step
   */
  private async executeWebSocketDisconnect(
    step: ApiWebSocketDisconnectStep,
    context: ExecutionContext
  ): Promise<void> {
    await this.requestRunner.disconnectWebSocket(step.sessionId);
  }

  /**
   * Execute multiple steps in sequence
   */
  async executeSequence(
    steps: ApiStep[],
    initialContext: TemplateContext
  ): Promise<StepExecutionResult[]> {
    const results: StepExecutionResult[] = [];
    
    const context: ExecutionContext = {
      ...initialContext,
      stepIndex: 0,
      previousResults: [],
      sessionData: {}
    };

    for (let i = 0; i < steps.length; i++) {
      context.stepIndex = i;
      context.previousResults = [...results];
      
      // Update context with results from previous steps
      if (results.length > 0) {
        const lastResult = results[results.length - 1];
        if (lastResult.response) {
          context.response = {
            status: 'status' in lastResult.response ? lastResult.response.status : 200,
            body: 'body' in lastResult.response ? lastResult.response.body : lastResult.response.data,
            headers: 'headers' in lastResult.response ? lastResult.response.headers : {}
          };
        }
        
        // Merge extractions into context variables
        if (lastResult.extractions) {
          Object.assign(context.variables, lastResult.extractions);
        }
      }

      const result = await this.executeStep(steps[i], context);
      results.push(result);

      // Stop execution on failure if configured to do so
      if (!result.success && this.shouldStopOnFailure(steps[i])) {
        logger.warn('Stopping execution due to step failure', { 
          stepIndex: i,
          kind: steps[i].kind 
        });
        break;
      }
    }

    return results;
  }

  /**
   * Execute steps with custom flow control
   */
  async executeWithFlow(
    steps: ApiStep[],
    initialContext: TemplateContext,
    flowOptions: {
      stopOnFailure?: boolean;
      continueOnFailure?: boolean;
      maxRetries?: number;
      retryDelay?: number;
      parallel?: boolean;
    } = {}
  ): Promise<StepExecutionResult[]> {
    
    if (flowOptions.parallel) {
      return this.executeParallel(steps, initialContext);
    }

    const results: StepExecutionResult[] = [];
    const context: ExecutionContext = {
      ...initialContext,
      stepIndex: 0,
      previousResults: [],
      sessionData: {}
    };

    for (let i = 0; i < steps.length; i++) {
      let attempts = 0;
      let result: StepExecutionResult;
      
      do {
        attempts++;
        context.stepIndex = i;
        context.previousResults = [...results];
        
        result = await this.executeStep(steps[i], context);
        
        if (!result.success && attempts < (flowOptions.maxRetries || 1)) {
          logger.info('Retrying step execution', { 
            stepIndex: i,
            attempt: attempts + 1,
            maxRetries: flowOptions.maxRetries 
          });
          
          if (flowOptions.retryDelay) {
            await this.delay(flowOptions.retryDelay);
          }
        }
      } while (!result.success && attempts < (flowOptions.maxRetries || 1));

      results.push(result);

      // Handle failure policies
      if (!result.success) {
        if (flowOptions.stopOnFailure) {
          logger.warn('Stopping execution due to failure policy', { stepIndex: i });
          break;
        }
      }
      
      // Update context for next step
      if (result.response) {
        context.response = {
          status: 'status' in result.response ? result.response.status : 200,
          body: 'body' in result.response ? result.response.body : result.response.data,
          headers: 'headers' in result.response ? result.response.headers : {}
        };
      }
    }

    return results;
  }

  /**
   * Execute steps in parallel
   */
  private async executeParallel(
    steps: ApiStep[],
    initialContext: TemplateContext
  ): Promise<StepExecutionResult[]> {
    const promises = steps.map(async (step, index) => {
      const context: ExecutionContext = {
        ...initialContext,
        stepIndex: index,
        previousResults: [],
        sessionData: {}
      };
      
      return this.executeStep(step, context);
    });

    return Promise.all(promises);
  }

  /**
   * Create execution context from variables and environment
   */
  createContext(
    variables: Record<string, any> = {},
    globals: Record<string, any> = {},
    environment: Record<string, any> = {}
  ): TemplateContext {
    return {
      variables: { ...variables },
      globals: { ...globals },
      environment: { ...environment }
    };
  }

  /**
   * Validate a DSL step configuration
   */
  validateStep(step: ApiStep): { valid: boolean; errors: string[] } {
    const errors: string[] = [];

    // Basic validation
    if (!step.kind) {
      errors.push('Step kind is required');
    }

    // Step-specific validation
    switch (step.kind) {
      case 'api.request':
        if (!step.config.url) {
          errors.push('URL is required for REST requests');
        }
        break;
      
      case 'api.graphql':
        if (!step.config.endpoint) {
          errors.push('Endpoint is required for GraphQL requests');
        }
        if (!step.config.query) {
          errors.push('Query is required for GraphQL requests');
        }
        break;
      
      case 'api.grpc':
        if (!step.config.host || !step.config.port) {
          errors.push('Host and port are required for gRPC requests');
        }
        if (!step.config.service || !step.config.method) {
          errors.push('Service and method are required for gRPC requests');
        }
        break;
      
      case 'api.websocket-connect':
        if (!step.config.url) {
          errors.push('URL is required for WebSocket connection');
        }
        break;
      
      case 'api.websocket-send':
        if (!step.sessionId) {
          errors.push('Session ID is required for WebSocket send');
        }
        break;
      
      case 'api.websocket-disconnect':
        if (!step.sessionId) {
          errors.push('Session ID is required for WebSocket disconnect');
        }
        break;
    }

    // Validate extractions
    if ('extractions' in step && step.extractions) {
      for (const extraction of step.extractions) {
        const validation = this.extractionEngine.validateConfig(extraction);
        if (!validation.valid) {
          errors.push(...validation.errors.map(e => `Extraction error: ${e}`));
        }
      }
    }

    // Validate assertions
    if ('assertions' in step && step.assertions) {
      for (const assertion of step.assertions) {
        const validation = this.assertionEngine.validateConfig(assertion);
        if (!validation.valid) {
          errors.push(...validation.errors.map(e => `Assertion error: ${e}`));
        }
      }
    }

    return {
      valid: errors.length === 0,
      errors
    };
  }

  /**
   * Generate execution summary
   */
  generateExecutionSummary(results: StepExecutionResult[]): {
    totalSteps: number;
    successfulSteps: number;
    failedSteps: number;
    totalDuration: number;
    avgDuration: number;
    extractionCount: number;
    assertionCount: number;
    failedAssertions: number;
  } {
    const totalSteps = results.length;
    const successfulSteps = results.filter(r => r.success).length;
    const failedSteps = totalSteps - successfulSteps;
    const totalDuration = results.reduce((sum, r) => sum + r.duration, 0);
    const avgDuration = totalSteps > 0 ? totalDuration / totalSteps : 0;
    
    let extractionCount = 0;
    let assertionCount = 0;
    let failedAssertions = 0;
    
    for (const result of results) {
      if (result.extractions) {
        extractionCount += Object.keys(result.extractions).length;
      }
      if (result.assertions) {
        assertionCount += result.assertions.length;
        failedAssertions += result.assertions.filter(a => !a.passed).length;
      }
    }

    return {
      totalSteps,
      successfulSteps,
      failedSteps,
      totalDuration,
      avgDuration,
      extractionCount,
      assertionCount,
      failedAssertions
    };
  }

  /**
   * Utility methods
   */
  private shouldStopOnFailure(step: ApiStep): boolean {
    // Could be configured per step or globally
    return true; // Default: stop on failure
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  /**
   * Cleanup resources
   */
  async cleanup(): Promise<void> {
    await this.requestRunner.cleanup();
  }
}

// Export for easier testing
export { StepExecutionResult, ExecutionContext }; 