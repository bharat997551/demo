import * as Handlebars from 'handlebars';
import { logger } from '@hybrid-qa/common';
import { TemplateContext, TemplateError } from './types';

/**
 * Template engine for rendering API requests with dynamic variables
 */
export class TemplateEngine {
  private handlebars: typeof Handlebars;

  constructor() {
    this.handlebars = Handlebars.create();
    this.registerHelpers();
  }

  /**
   * Render a string template with context
   */
  async render(template: string, context: TemplateContext): Promise<string> {
    try {
      if (!this.containsTemplate(template)) {
        return template;
      }

      const compiledTemplate = this.handlebars.compile(template);
      const result = compiledTemplate(context);

      logger.debug('Template rendered', { 
        template: this.maskSensitiveData(template),
        result: this.maskSensitiveData(result)
      });

      return result;
    } catch (error: any) {
      logger.error('Template rendering failed', { 
        template: this.maskSensitiveData(template),
        error: error.message 
      });
      throw new TemplateError(`Template rendering failed: ${error.message}`, template);
    }
  }

  /**
   * Render an object template recursively
   */
  async renderObject(obj: any, context: TemplateContext): Promise<any> {
    if (typeof obj === 'string') {
      return await this.render(obj, context);
    }

    if (Array.isArray(obj)) {
      const results = [];
      for (const item of obj) {
        results.push(await this.renderObject(item, context));
      }
      return results;
    }

    if (obj && typeof obj === 'object') {
      const result: any = {};
      for (const [key, value] of Object.entries(obj)) {
        const renderedKey = await this.render(key, context);
        result[renderedKey] = await this.renderObject(value, context);
      }
      return result;
    }

    return obj;
  }

  /**
   * Check if string contains template syntax
   */
  private containsTemplate(str: string): boolean {
    return str.includes('{{') && str.includes('}}');
  }

  /**
   * Register custom Handlebars helpers
   */
  private registerHelpers(): void {
    // Date/time helpers
    this.handlebars.registerHelper('now', () => new Date().toISOString());
    this.handlebars.registerHelper('timestamp', () => Date.now());
    this.handlebars.registerHelper('date', (format?: string) => {
      const now = new Date();
      if (format === 'iso') return now.toISOString();
      if (format === 'date') return now.toDateString();
      if (format === 'time') return now.toTimeString();
      return now.toString();
    });

    // String helpers
    this.handlebars.registerHelper('upper', (str: string) => str?.toUpperCase());
    this.handlebars.registerHelper('lower', (str: string) => str?.toLowerCase());
    this.handlebars.registerHelper('trim', (str: string) => str?.trim());
    this.handlebars.registerHelper('replace', (str: string, search: string, replace: string) => 
      str?.replace(new RegExp(search, 'g'), replace)
    );

    // Encoding helpers
    this.handlebars.registerHelper('base64', (str: string) => 
      Buffer.from(str).toString('base64')
    );
    this.handlebars.registerHelper('base64decode', (str: string) => 
      Buffer.from(str, 'base64').toString('utf8')
    );
    this.handlebars.registerHelper('urlencode', (str: string) => encodeURIComponent(str));
    this.handlebars.registerHelper('urldecode', (str: string) => decodeURIComponent(str));

    // Math helpers
    this.handlebars.registerHelper('add', (a: number, b: number) => a + b);
    this.handlebars.registerHelper('subtract', (a: number, b: number) => a - b);
    this.handlebars.registerHelper('multiply', (a: number, b: number) => a * b);
    this.handlebars.registerHelper('divide', (a: number, b: number) => a / b);
    this.handlebars.registerHelper('random', (min: number = 0, max: number = 100) => 
      Math.floor(Math.random() * (max - min + 1)) + min
    );

    // UUID helper
    this.handlebars.registerHelper('uuid', () => {
      const { v4: uuidv4 } = require('uuid');
      return uuidv4();
    });

    // JSON helpers
    this.handlebars.registerHelper('json', (obj: any) => JSON.stringify(obj));
    this.handlebars.registerHelper('jsonpath', (obj: any, path: string) => {
      const { JSONPath } = require('jsonpath-plus');
      try {
        const result = JSONPath({ path, json: obj });
        return Array.isArray(result) && result.length === 1 ? result[0] : result;
      } catch {
        return undefined;
      }
    });

    // Conditional helpers
    this.handlebars.registerHelper('eq', (a: any, b: any) => a === b);
    this.handlebars.registerHelper('ne', (a: any, b: any) => a !== b);
    this.handlebars.registerHelper('gt', (a: any, b: any) => a > b);
    this.handlebars.registerHelper('lt', (a: any, b: any) => a < b);
    this.handlebars.registerHelper('gte', (a: any, b: any) => a >= b);
    this.handlebars.registerHelper('lte', (a: any, b: any) => a <= b);

    // Array helpers
    this.handlebars.registerHelper('length', (arr: any[]) => arr?.length || 0);
    this.handlebars.registerHelper('first', (arr: any[]) => arr?.[0]);
    this.handlebars.registerHelper('last', (arr: any[]) => arr?.[arr.length - 1]);
    this.handlebars.registerHelper('join', (arr: any[], separator: string = ',') => 
      arr?.join(separator)
    );

    // Environment helpers
    this.handlebars.registerHelper('env', (key: string, defaultValue?: string) => 
      process.env[key] || defaultValue
    );
    
    // Iteration helper with context
    this.handlebars.registerHelper('iteration', function(this: any) {
      return this.iteration || 0;
    });

    // Response data helpers (for chaining requests)
    this.handlebars.registerHelper('response', function(this: any, path?: string) {
      if (!this.response) return undefined;
      
      if (path) {
        const { JSONPath } = require('jsonpath-plus');
        try {
          const result = JSONPath({ path: `$.${path}`, json: this.response.body });
          return Array.isArray(result) && result.length === 1 ? result[0] : result;
        } catch {
          return undefined;
        }
      }
      
      return this.response;
    });

    // Header helper
    this.handlebars.registerHelper('header', function(this: any, name: string) {
      return this.response?.headers?.[name.toLowerCase()];
    });

    // Status helper
    this.handlebars.registerHelper('status', function(this: any) {
      return this.response?.status;
    });

    // Fake data helpers
    this.handlebars.registerHelper('fake', (type: string) => {
      const faker = require('faker');
      
      switch (type) {
        case 'name': return faker.name.findName();
        case 'email': return faker.internet.email();
        case 'phone': return faker.phone.phoneNumber();
        case 'address': return faker.address.streetAddress();
        case 'city': return faker.address.city();
        case 'country': return faker.address.country();
        case 'company': return faker.company.companyName();
        case 'word': return faker.lorem.word();
        case 'sentence': return faker.lorem.sentence();
        case 'paragraph': return faker.lorem.paragraph();
        case 'number': return faker.datatype.number();
        case 'boolean': return faker.datatype.boolean();
        case 'date': return faker.date.recent().toISOString();
        case 'past_date': return faker.date.past().toISOString();
        case 'future_date': return faker.date.future().toISOString();
        case 'image': return faker.image.imageUrl();
        case 'avatar': return faker.image.avatar();
        case 'color': return faker.commerce.color();
        case 'product': return faker.commerce.productName();
        case 'price': return faker.commerce.price();
        case 'username': return faker.internet.userName();
        case 'password': return faker.internet.password();
        case 'url': return faker.internet.url();
        case 'domain': return faker.internet.domainName();
        case 'ip': return faker.internet.ip();
        case 'mac': return faker.internet.mac();
        case 'useragent': return faker.internet.userAgent();
        case 'creditcard': return faker.finance.creditCardNumber();
        case 'iban': return faker.finance.iban();
        case 'bic': return faker.finance.bic();
        default: return faker.lorem.word();
      }
    });
  }

  /**
   * Mask sensitive data in logs
   */
  private maskSensitiveData(str: string): string {
    // Mask common sensitive patterns
    return str
      .replace(/password['":\s]*['"]\w+['"]/gi, 'password":"***"')
      .replace(/token['":\s]*['"]\w+['"]/gi, 'token":"***"')
      .replace(/key['":\s]*['"]\w+['"]/gi, 'key":"***"')
      .replace(/secret['":\s]*['"]\w+['"]/gi, 'secret":"***"')
      .replace(/authorization['":\s]*['"]\w+['"]/gi, 'authorization":"***"')
      .replace(/bearer\s+\w+/gi, 'bearer ***');
  }

  /**
   * Validate template syntax
   */
  validateTemplate(template: string): { valid: boolean; errors: string[] } {
    const errors: string[] = [];

    try {
      this.handlebars.compile(template);
    } catch (error: any) {
      errors.push(`Syntax error: ${error.message}`);
    }

    // Check for balanced braces
    const openBraces = (template.match(/\{\{/g) || []).length;
    const closeBraces = (template.match(/\}\}/g) || []).length;
    
    if (openBraces !== closeBraces) {
      errors.push('Unbalanced template braces');
    }

    return {
      valid: errors.length === 0,
      errors
    };
  }

  /**
   * Extract variables from template
   */
  extractVariables(template: string): string[] {
    const variables: string[] = [];
    const regex = /\{\{\s*([^}]+)\s*\}\}/g;
    let match;

    while ((match = regex.exec(template)) !== null) {
      const variable = match[1].trim();
      
      // Skip helpers and control structures
      if (!variable.startsWith('#') && 
          !variable.startsWith('/') && 
          !variable.startsWith('else') &&
          !variable.includes(' ')) {
        
        // Extract just the variable name (before any dot notation or array access)
        const varName = variable.split('.')[0].split('[')[0];
        
        if (!variables.includes(varName)) {
          variables.push(varName);
        }
      }
    }

    return variables;
  }

  /**
   * Create a sandbox context with only allowed properties
   */
  createSafeContext(context: TemplateContext): any {
    return {
      variables: context.variables || {},
      globals: context.globals || {},
      environment: context.environment || {},
      iteration: context.iteration,
      request: context.request,
      response: context.response,
      // Add utility functions that are safe to use
      Math: {
        random: Math.random,
        floor: Math.floor,
        ceil: Math.ceil,
        round: Math.round,
        abs: Math.abs,
        min: Math.min,
        max: Math.max
      },
      Date: {
        now: Date.now
      }
    };
  }
} 