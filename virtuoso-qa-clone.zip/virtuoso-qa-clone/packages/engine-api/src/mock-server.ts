import express, { Request, Response, NextFunction } from 'express';
import cors from 'cors';
import { logger } from '@hybrid-qa/common';
import { MockEndpoint, ApiEngineError } from './types';

/**
 * Lightweight mock server for API testing
 */
export class MockServer {
  private app: express.Application;
  private server: any;
  private port: number;
  private endpoints: Map<string, MockEndpoint[]> = new Map();

  constructor(port: number = 3999) {
    this.port = port;
    this.app = express();
    this.setupMiddleware();
    this.setupRoutes();
  }

  /**
   * Setup Express middleware
   */
  private setupMiddleware(): void {
    this.app.use(cors());
    this.app.use(express.json({ limit: '10mb' }));
    this.app.use(express.urlencoded({ extended: true, limit: '10mb' }));
    
    // Request logging
    this.app.use((req: Request, res: Response, next: NextFunction) => {
      logger.info('Mock request received', {
        method: req.method,
        path: req.path,
        query: req.query,
        headers: this.sanitizeHeaders(req.headers)
      });
      next();
    });
  }

  /**
   * Setup routes
   */
  private setupRoutes(): void {
    // Health check
    this.app.get('/_mock/health', (req: Request, res: Response) => {
      res.json({
        status: 'healthy',
        service: 'api-mock-server',
        port: this.port,
        endpointCount: this.getTotalEndpointCount(),
        timestamp: new Date().toISOString()
      });
    });

    // List all mock endpoints
    this.app.get('/_mock/endpoints', (req: Request, res: Response) => {
      const allEndpoints: any[] = [];
      
      for (const [path, endpoints] of this.endpoints) {
        for (const endpoint of endpoints) {
          allEndpoints.push({
            path,
            method: endpoint.method,
            response: {
              status: endpoint.response.status,
              headers: endpoint.response.headers,
              hasBody: endpoint.response.body !== undefined,
              delay: endpoint.response.delay
            },
            conditions: endpoint.conditions
          });
        }
      }
      
      res.json({ endpoints: allEndpoints });
    });

    // Add new mock endpoint
    this.app.post('/_mock/endpoints', (req: Request, res: Response) => {
      try {
        const endpoint: MockEndpoint = req.body;
        this.addEndpoint(endpoint);
        res.json({ message: 'Endpoint added successfully', endpoint });
      } catch (error: any) {
        res.status(400).json({ error: error.message });
      }
    });

    // Remove mock endpoint
    this.app.delete('/_mock/endpoints', (req: Request, res: Response) => {
      const { path, method } = req.body;
      const removed = this.removeEndpoint(path, method);
      
      if (removed) {
        res.json({ message: 'Endpoint removed successfully' });
      } else {
        res.status(404).json({ error: 'Endpoint not found' });
      }
    });

    // Clear all endpoints
    this.app.delete('/_mock/endpoints/all', (req: Request, res: Response) => {
      this.clearAllEndpoints();
      res.json({ message: 'All endpoints cleared' });
    });

    // Catch-all route for mock responses
    this.app.all('*', (req: Request, res: Response) => {
      this.handleMockRequest(req, res);
    });
  }

  /**
   * Handle incoming mock requests
   */
  private async handleMockRequest(req: Request, res: Response): Promise<void> {
    const path = req.path;
    const method = req.method.toUpperCase();
    
    logger.info('Processing mock request', { method, path });

    // Find matching endpoints
    const pathEndpoints = this.endpoints.get(path) || [];
    const matchingEndpoints = pathEndpoints.filter(endpoint => 
      endpoint.method === 'ALL' || endpoint.method === method
    );

    if (matchingEndpoints.length === 0) {
      // No matching endpoint found
      res.status(404).json({
        error: 'Mock endpoint not found',
        path,
        method,
        availableEndpoints: this.getAvailableEndpoints()
      });
      return;
    }

    // Find the best matching endpoint based on conditions
    const bestMatch = this.findBestMatch(req, matchingEndpoints);
    
    if (!bestMatch) {
      res.status(404).json({
        error: 'No endpoint matches the request conditions',
        path,
        method
      });
      return;
    }

    // Apply response delay if configured
    if (bestMatch.response.delay > 0) {
      await this.delay(bestMatch.response.delay);
    }

    // Send mock response
    res.status(bestMatch.response.status);
    
    // Set response headers
    for (const [key, value] of Object.entries(bestMatch.response.headers)) {
      res.set(key, value);
    }

    // Send response body
    if (bestMatch.response.body !== undefined) {
      if (typeof bestMatch.response.body === 'object') {
        res.json(bestMatch.response.body);
      } else {
        res.send(bestMatch.response.body);
      }
    } else {
      res.end();
    }

    logger.info('Mock response sent', {
      status: bestMatch.response.status,
      delay: bestMatch.response.delay,
      hasBody: bestMatch.response.body !== undefined
    });
  }

  /**
   * Find the best matching endpoint based on conditions
   */
  private findBestMatch(req: Request, endpoints: MockEndpoint[]): MockEndpoint | null {
    for (const endpoint of endpoints) {
      if (this.matchesConditions(req, endpoint.conditions)) {
        return endpoint;
      }
    }
    
    // Return first endpoint if no specific conditions match
    return endpoints[0] || null;
  }

  /**
   * Check if request matches endpoint conditions
   */
  private matchesConditions(req: Request, conditions?: MockEndpoint['conditions']): boolean {
    if (!conditions) return true;

    // Check header conditions
    if (conditions.headers) {
      for (const [key, expectedValue] of Object.entries(conditions.headers)) {
        const actualValue = req.get(key);
        if (actualValue !== expectedValue) {
          return false;
        }
      }
    }

    // Check query parameter conditions
    if (conditions.query) {
      for (const [key, expectedValue] of Object.entries(conditions.query)) {
        const actualValue = req.query[key];
        if (actualValue !== expectedValue) {
          return false;
        }
      }
    }

    // Check body conditions (simplified)
    if (conditions.body) {
      if (typeof conditions.body === 'object') {
        // Deep comparison would be needed here
        const bodyMatches = this.deepCompare(req.body, conditions.body);
        if (!bodyMatches) {
          return false;
        }
      } else {
        if (req.body !== conditions.body) {
          return false;
        }
      }
    }

    return true;
  }

  /**
   * Add a new mock endpoint
   */
  addEndpoint(endpoint: MockEndpoint): void {
    const path = endpoint.path;
    
    if (!this.endpoints.has(path)) {
      this.endpoints.set(path, []);
    }
    
    const pathEndpoints = this.endpoints.get(path)!;
    pathEndpoints.push(endpoint);
    
    logger.info('Mock endpoint added', {
      path: endpoint.path,
      method: endpoint.method,
      status: endpoint.response.status
    });
  }

  /**
   * Remove a mock endpoint
   */
  removeEndpoint(path: string, method?: string): boolean {
    const pathEndpoints = this.endpoints.get(path);
    if (!pathEndpoints) return false;

    if (method) {
      // Remove specific method
      const index = pathEndpoints.findIndex(ep => ep.method === method.toUpperCase());
      if (index >= 0) {
        pathEndpoints.splice(index, 1);
        
        // Remove path if no endpoints left
        if (pathEndpoints.length === 0) {
          this.endpoints.delete(path);
        }
        
        logger.info('Mock endpoint removed', { path, method });
        return true;
      }
    } else {
      // Remove all endpoints for path
      this.endpoints.delete(path);
      logger.info('All mock endpoints removed for path', { path });
      return true;
    }
    
    return false;
  }

  /**
   * Clear all endpoints
   */
  clearAllEndpoints(): void {
    this.endpoints.clear();
    logger.info('All mock endpoints cleared');
  }

  /**
   * Bulk add endpoints
   */
  addEndpoints(endpoints: MockEndpoint[]): void {
    for (const endpoint of endpoints) {
      this.addEndpoint(endpoint);
    }
    
    logger.info('Bulk endpoints added', { count: endpoints.length });
  }

  /**
   * Load endpoints from configuration
   */
  loadFromConfig(config: {
    endpoints: MockEndpoint[];
    defaultDelay?: number;
    defaultStatus?: number;
  }): void {
    // Apply defaults to endpoints
    const processedEndpoints = config.endpoints.map(endpoint => ({
      ...endpoint,
      response: {
        status: config.defaultStatus || 200,
        headers: {},
        delay: config.defaultDelay || 0,
        ...endpoint.response
      }
    }));
    
    this.addEndpoints(processedEndpoints);
    
    logger.info('Mock endpoints loaded from config', { 
      count: processedEndpoints.length 
    });
  }

  /**
   * Start the mock server
   */
  async start(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.server = this.app.listen(this.port, () => {
        logger.info('Mock server started', { port: this.port });
        resolve();
      });
      
      this.server.on('error', (error: any) => {
        logger.error('Mock server failed to start', { error: error.message });
        reject(new ApiEngineError(`Failed to start mock server: ${error.message}`, 'MOCK_SERVER_ERROR'));
      });
    });
  }

  /**
   * Stop the mock server
   */
  async stop(): Promise<void> {
    if (this.server) {
      return new Promise((resolve) => {
        this.server.close(() => {
          logger.info('Mock server stopped');
          resolve();
        });
      });
    }
  }

  /**
   * Get server info
   */
  getInfo(): {
    port: number;
    isRunning: boolean;
    endpointCount: number;
    endpoints: string[];
  } {
    return {
      port: this.port,
      isRunning: !!this.server,
      endpointCount: this.getTotalEndpointCount(),
      endpoints: Array.from(this.endpoints.keys())
    };
  }

  /**
   * Create common mock responses
   */
  static createCommonMocks(): MockEndpoint[] {
    return [
      // Success response
      {
        path: '/api/success',
        method: 'GET',
        response: {
          status: 200,
          headers: { 'Content-Type': 'application/json' },
          body: { message: 'Success', timestamp: new Date().toISOString() }
        }
      },
      
      // Error response
      {
        path: '/api/error',
        method: 'GET',
        response: {
          status: 500,
          headers: { 'Content-Type': 'application/json' },
          body: { error: 'Internal Server Error', code: 500 }
        }
      },
      
      // Not found
      {
        path: '/api/notfound',
        method: 'GET',
        response: {
          status: 404,
          headers: { 'Content-Type': 'application/json' },
          body: { error: 'Not Found', code: 404 }
        }
      },
      
      // Slow response
      {
        path: '/api/slow',
        method: 'GET',
        response: {
          status: 200,
          headers: { 'Content-Type': 'application/json' },
          body: { message: 'Slow response' },
          delay: 2000
        }
      },
      
      // JSON data
      {
        path: '/api/users',
        method: 'GET',
        response: {
          status: 200,
          headers: { 'Content-Type': 'application/json' },
          body: {
            users: [
              { id: 1, name: 'John Doe', email: 'john@example.com' },
              { id: 2, name: 'Jane Smith', email: 'jane@example.com' }
            ],
            total: 2
          }
        }
      },
      
      // POST endpoint
      {
        path: '/api/users',
        method: 'POST',
        response: {
          status: 201,
          headers: { 'Content-Type': 'application/json' },
          body: { id: 3, message: 'User created successfully' }
        }
      }
    ];
  }

  /**
   * Utility methods
   */
  private getTotalEndpointCount(): number {
    let count = 0;
    for (const endpoints of this.endpoints.values()) {
      count += endpoints.length;
    }
    return count;
  }

  private getAvailableEndpoints(): string[] {
    const available: string[] = [];
    for (const [path, endpoints] of this.endpoints) {
      for (const endpoint of endpoints) {
        available.push(`${endpoint.method} ${path}`);
      }
    }
    return available;
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  private sanitizeHeaders(headers: any): any {
    const sanitized = { ...headers };
    const sensitiveHeaders = ['authorization', 'x-api-key', 'cookie'];
    
    for (const header of sensitiveHeaders) {
      if (sanitized[header]) {
        sanitized[header] = '***';
      }
    }
    
    return sanitized;
  }

  private deepCompare(obj1: any, obj2: any): boolean {
    if (obj1 === obj2) return true;
    if (obj1 === null || obj2 === null) return false;
    if (typeof obj1 !== typeof obj2) return false;
    
    if (typeof obj1 === 'object') {
      const keys1 = Object.keys(obj1);
      const keys2 = Object.keys(obj2);
      
      if (keys1.length !== keys2.length) return false;
      
      for (const key of keys1) {
        if (!keys2.includes(key) || !this.deepCompare(obj1[key], obj2[key])) {
          return false;
        }
      }
      
      return true;
    }
    
    return false;
  }
} 