# API Testing Engine

A comprehensive API testing engine that supports REST, GraphQL, gRPC, and WebSocket protocols with advanced templating, data extraction, and assertion capabilities.

## 🚀 Features

### Core Functionality
- **Multi-Protocol Support**: REST (HTTP/HTTPS), GraphQL, gRPC, WebSocket
- **Request Templating**: Handlebars-based templating with variables and secure credentials
- **Data Extraction**: JSONPath, XPath, regex, header, and status extraction
- **Powerful Assertions**: Status codes, response times, content validation, schema validation
- **Secure Credential Management**: Encrypted storage with multiple backends
- **Mock Server**: Lightweight mock server for testing and development

### DSL Steps
- `api.request` - Execute REST API requests
- `api.graphql` - Execute GraphQL queries and mutations  
- `api.grpc` - Execute gRPC method calls
- `api.websocket-connect` - Connect to WebSocket endpoints
- `api.websocket-send` - Send messages to WebSocket connections
- `api.websocket-disconnect` - Close WebSocket connections

### Import Capabilities
- **OpenAPI/Swagger**: Import specifications and generate test steps
- **Postman Collections**: Import collections with variables and authentication
- **Auto-generation**: Create example requests and test scenarios

## 📋 Quick Start

### Installation

```bash
cd packages/engine-api
npm install
```

### Basic Usage

```typescript
import { APIEngine } from './src';

// Start the API engine server
const apiEngine = new APIEngine(8004);
await apiEngine.start();

// The server provides REST endpoints for:
// - Executing DSL steps
// - Managing credentials
// - Importing specifications
// - Running mock servers
```

### DSL Step Example

```json
{
  "kind": "api.request",
  "config": {
    "url": "https://api.example.com/users/{{variables.userId}}",
    "method": "GET",
    "headers": {
      "Authorization": "Bearer {{credential:api_token}}"
    },
    "timeout": 5000
  },
  "extractions": [
    {
      "type": "jsonpath",
      "expression": "$.user.name",
      "multiple": false
    }
  ],
  "assertions": [
    {
      "type": "status_code", 
      "expected": 200
    },
    {
      "type": "response_time",
      "expected": 1000,
      "tolerance": 200
    }
  ]
}
```

## 🔧 API Endpoints

### Health & Status
- `GET /health` - Health check and server status

### DSL Execution  
- `POST /execute/step` - Execute a single DSL step
- `POST /execute/sequence` - Execute multiple steps in sequence

### Request Types
- `POST /request/rest` - Execute REST API request
- `POST /request/graphql` - Execute GraphQL query
- `POST /request/grpc` - Execute gRPC call

### Data Operations
- `POST /extract` - Extract data from API responses
- `POST /assert` - Perform assertions on responses
- `POST /template/render` - Render templates with context

### Credential Management
- `POST /credentials` - Store credentials securely
- `GET /credentials/:key` - Check credential existence

### Import Tools
- `POST /import/openapi` - Import OpenAPI specifications
- `POST /import/postman` - Import Postman collections

### Mock Server
- `POST /mock/start` - Start mock server with endpoints
- `POST /mock/stop` - Stop mock server
- `GET /mock/info` - Get mock server status

### Validation
- `POST /validate/step` - Validate DSL step configuration

## 🧪 Testing

```bash
# Run all tests
npm test

# Run tests with coverage
npm run test -- --coverage

# Run tests in watch mode
npm run test:watch
```

### Test Examples

The test suite includes comprehensive examples demonstrating:

- **REST API Testing**: GET, POST, PUT, DELETE requests
- **Template Variables**: Dynamic URL and payload generation  
- **Data Extraction**: JSONPath, regex, header extraction
- **Assertions**: Status codes, content validation, performance checks
- **Sequential Steps**: Multi-step workflows with variable passing
- **Error Handling**: Network errors, timeouts, validation failures
- **Mock Server**: Dynamic endpoint management

## 📖 Detailed Documentation

### Request Configuration

```typescript
interface RequestConfig {
  url: string;                    // Request URL with template support
  method: HttpMethod;             // HTTP method
  headers: Record<string, string>; // Request headers
  query: Record<string, any>;     // Query parameters
  body?: any;                     // Request body
  timeout: number;                // Request timeout in ms
  followRedirects: boolean;       // Follow HTTP redirects
  validateSSL: boolean;           // Validate SSL certificates
  auth?: AuthConfig;              // Authentication configuration
}
```

### Authentication Types

```typescript
// Basic Authentication
{
  "type": "basic",
  "basic": {
    "username": "user",
    "password": "pass"
  }
}

// Bearer Token
{
  "type": "bearer", 
  "bearer": {
    "token": "{{credential:access_token}}"
  }
}

// API Key
{
  "type": "apikey",
  "apikey": {
    "key": "X-API-Key",
    "value": "{{credential:api_key}}",
    "location": "header"
  }
}

// OAuth2
{
  "type": "oauth2",
  "oauth2": {
    "accessToken": "{{credential:oauth_token}}"
  }
}
```

### Extraction Types

#### JSONPath Extraction
```json
{
  "type": "jsonpath",
  "expression": "$.users[*].email",
  "multiple": true,
  "defaultValue": []
}
```

#### XPath Extraction (for XML responses)
```json
{
  "type": "xpath", 
  "expression": "//user/@id",
  "attribute": "id",
  "multiple": true
}
```

#### Regex Extraction
```json
{
  "type": "regex",
  "expression": "token=([a-zA-Z0-9]+)",
  "flags": "g",
  "multiple": false
}
```

#### Header Extraction
```json
{
  "type": "header",
  "expression": "x-request-id"
}
```

#### Status Extraction
```json
{
  "type": "status",
  "expression": ""
}
```

### Assertion Types

#### Status Code
```json
{
  "type": "status_code",
  "expected": 200
}
```

#### Content Assertions
```json
{
  "type": "equals",
  "path": "$.user.name", 
  "expected": "John Doe",
  "ignoreCase": false
}

{
  "type": "contains",
  "path": "$.message",
  "expected": "success"
}

{
  "type": "not_contains", 
  "path": "$.errors",
  "expected": "error"
}
```

#### Numeric Comparisons
```json
{
  "type": "greater_than",
  "path": "$.count",
  "expected": 10,
  "tolerance": 1
}

{
  "type": "less_than",
  "path": "$.response_time", 
  "expected": 1000
}
```

#### Pattern Matching
```json
{
  "type": "regex",
  "expected": "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$"
}
```

#### Schema Validation
```json
{
  "type": "json_schema",
  "expected": {
    "type": "object",
    "properties": {
      "id": {"type": "number"},
      "name": {"type": "string"}
    },
    "required": ["id", "name"]
  }
}
```

#### Performance Testing
```json
{
  "type": "response_time",
  "expected": 500,
  "tolerance": 100
}
```

### Template System

The template engine uses Handlebars with custom helpers:

#### Built-in Helpers

**Date/Time**
- `{{now}}` - Current ISO timestamp
- `{{timestamp}}` - Current Unix timestamp  
- `{{date "iso"}}` - Formatted date

**String Operations**
- `{{upper "hello"}}` → "HELLO"
- `{{lower "WORLD"}}` → "world"
- `{{trim " text "}}` → "text"

**Encoding**
- `{{base64 "text"}}` → Base64 encoded
- `{{urlencode "text with spaces"}}` → URL encoded

**Math**
- `{{add 5 3}}` → 8
- `{{random 1 100}}` → Random number 1-100

**Utilities**
- `{{uuid}}` → UUID v4
- `{{json object}}` → JSON string
- `{{fake "name"}}` → Fake data generation

**Response Data**
- `{{response "user.id"}}` → Extract from previous response
- `{{header "content-type"}}` → Extract response header
- `{{status}}` → Previous response status

#### Context Variables

```handlebars
{{variables.userId}}       # From step variables
{{globals.baseUrl}}        # From global context  
{{environment.apiKey}}     # From environment
{{iteration}}              # Loop iteration number
{{response.data.token}}    # From previous response
```

### GraphQL Support

```json
{
  "kind": "api.graphql",
  "config": {
    "endpoint": "https://api.example.com/graphql",
    "query": "query GetUser($id: ID!) { user(id: $id) { name email } }",
    "variables": {
      "id": "{{variables.userId}}"
    },
    "operationName": "GetUser",
    "headers": {
      "Authorization": "Bearer {{credential:token}}"
    }
  }
}
```

### gRPC Support

```json
{
  "kind": "api.grpc", 
  "config": {
    "host": "localhost",
    "port": 50051,
    "protoPath": "./protos/user.proto",
    "packageName": "user",
    "serviceName": "UserService", 
    "method": "GetUser",
    "data": {
      "id": "{{variables.userId}}"
    },
    "metadata": {
      "authorization": "Bearer {{credential:token}}"
    }
  }
}
```

### WebSocket Support

```json
{
  "kind": "api.websocket-connect",
  "config": {
    "url": "ws://localhost:8080/ws",
    "protocols": ["chat", "v1"],
    "headers": {
      "Authorization": "Bearer {{credential:token}}"
    }
  }
}
```

## 🔒 Security Features

### Credential Management
- Multiple storage backends (memory, environment, encrypted files)
- Automatic credential masking in logs
- Template-based credential references: `{{credential:key_name}}`

### SSL/TLS Support
- Certificate validation (configurable)
- Custom CA certificates for gRPC
- SNI support

### Input Validation
- Comprehensive request validation
- Template syntax validation
- Schema validation for imported specifications

## 🛠 Development

### Project Structure

```
packages/engine-api/
├── src/
│   ├── types.ts                 # TypeScript type definitions
│   ├── request-runner.ts        # Core request execution engine
│   ├── template-engine.ts       # Handlebars template system
│   ├── credential-manager.ts    # Secure credential storage
│   ├── extraction-engine.ts     # Data extraction utilities
│   ├── assertion-engine.ts      # Response assertion validation
│   ├── dsl-executor.ts          # DSL step orchestration
│   ├── mock-server.ts          # Lightweight mock server
│   ├── importers/
│   │   ├── openapi-importer.ts  # OpenAPI specification importer
│   │   └── postman-importer.ts  # Postman collection importer
│   ├── tests/
│   │   ├── setup.ts            # Test configuration
│   │   └── api-engine.test.ts  # Comprehensive integration tests
│   └── index.ts                # Main server and exports
├── package.json
├── tsconfig.json
├── jest.config.js
└── README.md
```

### Building

```bash
# Build TypeScript
npm run build

# Type checking
npm run type-check

# Linting
npm run lint
npm run lint:fix

# Clean build artifacts
npm run clean
```

### Running

```bash
# Development mode with hot reload
npm run start:dev

# Production mode  
npm start

# Mock server only
npm run mock:start
```

## 🌟 Advanced Features

### Flow Control
```typescript
// Execute steps with retry logic and error handling
await dslExecutor.executeWithFlow(steps, context, {
  stopOnFailure: false,
  maxRetries: 3,
  retryDelay: 1000,
  parallel: false
});
```

### Bulk Operations
```typescript
// Import multiple specifications
const openApiResult = await openApiImporter.importFromUrl('https://api.example.com/openapi.json');
const postmanResult = await postmanImporter.importFromUrl('https://api.postman.com/collections/12345');
```

### Performance Monitoring
- Request duration tracking
- Response time assertions with tolerance
- Concurrent request handling
- Memory usage monitoring

### Extensibility
- Plugin architecture for custom authentication methods
- Custom template helpers
- Custom assertion types
- Custom extraction methods

## 🤝 Integration Examples

### With Test Frameworks

```typescript
// Jest integration
import { APIEngine } from '@hybrid-qa/engine-api';

describe('API Tests', () => {
  let apiEngine: APIEngine;
  
  beforeAll(async () => {
    apiEngine = new APIEngine(8004);
    await apiEngine.start();
  });
  
  afterAll(async () => {
    await apiEngine.stop();
  });
  
  test('should execute API workflow', async () => {
    // Test implementation
  });
});
```

### With CI/CD Pipelines

```yaml
# GitHub Actions example
- name: Run API Tests
  run: |
    cd packages/engine-api
    npm install
    npm test
  env:
    API_BASE_URL: ${{ secrets.API_BASE_URL }}
    API_TOKEN: ${{ secrets.API_TOKEN }}
```

## 📊 Monitoring & Observability

### Logging
- Structured JSON logging with Winston
- Request/response logging with sensitive data masking
- Performance metrics tracking
- Error context preservation

### Health Checks
```bash
# Check engine health
curl http://localhost:8004/health

# Check mock server
curl http://localhost:3999/_mock/health
```

### Metrics
- Request success/failure rates
- Response time percentiles  
- Extraction success rates
- Assertion pass/fail rates

## 🚨 Error Handling

The engine provides comprehensive error handling with specific error types:

- `ApiEngineError` - General engine errors
- `RequestError` - HTTP/network request failures
- `ValidationError` - Input validation failures
- `TemplateError` - Template rendering errors

All errors include:
- Descriptive error messages
- Error codes for programmatic handling
- Context information for debugging
- Stack traces in development mode

## 🏆 Best Practices

### Request Design
1. Use meaningful variable names in templates
2. Set appropriate timeouts for different endpoint types
3. Include retry logic for flaky endpoints
4. Validate SSL certificates in production

### Testing Strategy  
1. Start with smoke tests for critical endpoints
2. Add comprehensive data validation
3. Include performance benchmarks
4. Test error conditions and edge cases

### Security
1. Store credentials securely using the credential manager
2. Mask sensitive data in logs and responses
3. Use HTTPS for all production endpoints
4. Rotate credentials regularly

### Performance
1. Set reasonable timeouts
2. Use connection pooling for high-volume testing
3. Monitor response times and set appropriate thresholds
4. Clean up resources (WebSocket connections, etc.)

## 📝 License

This project is part of the Hybrid QA platform and follows the same licensing terms.

## 🆘 Support

For issues, feature requests, or questions:
1. Check the test suite for usage examples
2. Review the API documentation above
3. Submit issues with detailed reproduction steps
4. Include logs and error messages when reporting bugs

---

**Note**: This engine is designed to be used as part of the larger Hybrid QA ecosystem but can also function as a standalone API testing solution. 