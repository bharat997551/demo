# Hybrid QA Desktop Engine

Windows desktop automation engine using pywinauto and Windows UIA (User Interface Automation) for interacting with native Windows applications.

## 🚀 Features

- **Windows UIA Integration**: Native Windows UI automation using pywinauto
- **FastAPI Server**: HTTP API for executing automation steps
- **Recording Capabilities**: Capture user interactions in real-time
- **Screenshot Support**: Automatic screenshot capture during execution
- **Error Handling**: Robust error handling and recovery mechanisms
- **Multiple Backends**: Support for UIA and Win32 backends

## 🛠️ Tech Stack

- **Language**: Python 3.11+
- **Web Framework**: FastAPI + Uvicorn
- **Automation**: pywinauto (UIA backend)
- **Windows API**: pywin32
- **Image Processing**: Pillow (PIL)
- **Testing**: pytest

## 📋 Prerequisites

- **Windows 10/11**: Required for UIA support
- **Python 3.11+**: With pip package manager
- **Windows SDK**: For pywin32 (usually auto-installed)

## 🚀 Setup

### Automatic Setup (Recommended)

Run the setup script for your platform:

**Windows:**
\`\`\`batch
venv-setup.bat
\`\`\`

**Linux/Mac:**
\`\`\`bash
chmod +x venv-setup.sh
./venv-setup.sh
\`\`\`

### Manual Setup

\`\`\`bash
# Create virtual environment
python -m venv venv

# Activate virtual environment (Windows)
venv\Scripts\activate

# Activate virtual environment (Linux/Mac)  
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
\`\`\`

## 🏃‍♂️ Running the Engine

\`\`\`bash
# Activate virtual environment first
venv\Scripts\activate  # Windows
# or
source venv/bin/activate  # Linux/Mac

# Start the FastAPI server
python src/main.py
\`\`\`

The engine will start on http://localhost:8002

## 📡 API Endpoints

### Health Check
\`\`\`
GET /health
\`\`\`

Response:
\`\`\`json
{
  "status": "healthy",
  "service": "desktop-engine",
  "version": "1.0.0",
  "timestamp": "2024-01-01T12:00:00"
}
\`\`\`

### Execute Step
\`\`\`
POST /runStep
\`\`\`

Request body:
\`\`\`json
{
  "action": "click",
  "target": {
    "type": "uia",
    "value": "Name:ButtonName"
  },
  "options": {
    "timeout": 30
  }
}
\`\`\`

Response:
\`\`\`json
{
  "success": true,
  "result": {
    "action": "click",
    "status": "executed"
  },
  "timestamp": "2024-01-01T12:00:00"
}
\`\`\`

### Recording

**Start Recording:**
\`\`\`
POST /record/start/{session_id}
\`\`\`

**Stop Recording:**
\`\`\`
POST /record/stop/{session_id}
\`\`\`

**Get Sessions:**
\`\`\`
GET /record/sessions
\`\`\`

## 🎯 Supported Actions

### Mouse Actions
- **click**: Left click on element
- **doubleclick**: Double click on element  
- **rightclick**: Right click on element
- **drag**: Drag and drop operations

### Keyboard Actions
- **type**: Type text into focused element
- **keypress**: Send individual key presses
- **hotkey**: Send key combinations (Ctrl+C, Alt+Tab, etc.)

### Wait Actions  
- **wait**: Wait for element or condition
- **wait_for_window**: Wait for window to appear

### Utility Actions
- **screenshot**: Capture screenshot
- **extract**: Extract text or properties
- **assert**: Verify element state or properties

## 🎯 Selector Types

### UIA Selectors
\`\`\`json
{
  "type": "uia",
  "value": "Name:ButtonName"
}
\`\`\`

Common UIA properties:
- \`Name:ButtonName\` - Control name
- \`AutomationId:submitButton\` - Automation ID
- \`ClassName:Button\` - Window class name
- \`ControlType:Button\` - Control type

### Win32 Selectors (Legacy)
\`\`\`json
{
  "type": "wincontrol", 
  "value": "#32770>Button2"
}
\`\`\`

### Coordinate Selectors (Fallback)
\`\`\`json
{
  "type": "coordinates",
  "value": "100,200"
}
\`\`\`

## 🏗️ Project Structure

\`\`\`
src/
├── main.py              # FastAPI server entry point
├── automation/          # Automation logic
│   ├── __init__.py
│   ├── uia_handler.py   # UIA automation handler
│   ├── win32_handler.py # Win32 automation handler
│   └── recorder.py      # Interaction recording
├── utils/               # Utility functions  
│   ├── __init__.py
│   ├── screenshot.py    # Screenshot utilities
│   └── selectors.py     # Selector parsing
└── tests/               # Test files
    ├── test_main.py
    └── test_automation.py
\`\`\`

## 🧪 Testing

\`\`\`bash
# Activate virtual environment
venv\Scripts\activate

# Run all tests
pytest

# Run with coverage
pytest --cov=src

# Run specific test file
pytest tests/test_automation.py
\`\`\`

## 🔧 Configuration

Environment variables:
\`\`\`bash
# Server configuration
HOST=127.0.0.1
PORT=8002

# Automation backend
BACKEND=uia  # or 'win32'

# Screenshot settings
SCREENSHOT_DIR=screenshots
SCREENSHOT_FORMAT=png

# Timeouts (seconds)
DEFAULT_TIMEOUT=30
ELEMENT_TIMEOUT=10
\`\`\`

## 🐛 Troubleshooting

### Common Issues

**UIA Not Working:**
- Ensure Windows 10/11 with latest updates
- Check if target application supports UIA
- Try switching to Win32 backend

**Permission Errors:**
- Run as administrator if needed
- Check Windows UAC settings
- Verify antivirus isn't blocking automation

**Element Not Found:**
- Use tools like Inspect.exe or UIA Spy
- Verify selector syntax
- Add appropriate wait conditions
- Check if element is in different window/frame

### Debugging

Enable debug logging:
\`\`\`python
import logging
logging.basicConfig(level=logging.DEBUG)
\`\`\`

Use pywinauto's built-in debugging:
\`\`\`python
from pywinauto import findwindows
findwindows.find_elements()  # List all windows
\`\`\`

## 📝 Examples

### Simple Click Example
\`\`\`python
import requests

response = requests.post('http://localhost:8002/runStep', json={
    'action': 'click',
    'target': {
        'type': 'uia',
        'value': 'Name:OK'
    }
})
\`\`\`

### Type Text Example
\`\`\`python
response = requests.post('http://localhost:8002/runStep', json={
    'action': 'type',
    'target': {
        'type': 'uia', 
        'value': 'AutomationId:textBox1'
    },
    'value': 'Hello World!'
})
\`\`\`

## 🔄 Integration

This engine integrates with:
- **Orchestrator**: Receives step execution requests
- **Desktop App**: Provides recording and step execution
- **Self-healing**: Reports selector success/failure for learning

## 📚 Resources

- [pywinauto Documentation](https://pywinauto.readthedocs.io/)
- [Windows UIA Documentation](https://docs.microsoft.com/en-us/windows/win32/winauto/entry-uiauto-win32)
- [FastAPI Documentation](https://fastapi.tiangolo.com/) 