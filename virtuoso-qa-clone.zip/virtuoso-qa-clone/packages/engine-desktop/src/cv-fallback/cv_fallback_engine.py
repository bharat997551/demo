"""
Computer Vision Fallback Engine
Handles automation when standard methods fail (RDP, Citrix, etc.)
"""

import time
import hashlib
from typing import Optional, List, Dict, Any, Union, Tuple
import numpy as np
import cv2
from PIL import Image
import pytesseract
import logging
from concurrent.futures import ThreadPoolExecutor, Future
from functools import lru_cache

try:
    import torch
    import torchvision
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False

from .types import (
    CVMatchMethod, CVMatch, CVRegion, CVElement, OCRResult, OCRWord,
    CVTemplate, MLModel, CVFallbackStrategy, RemoteDesktopConfig,
    CVCalibration, CVProvider, CVCache, CVPerformanceMetrics, CVConfidence
)


class TesseractOCRProvider:
    """OCR provider using Tesseract"""
    
    def __init__(self, tesseract_cmd: Optional[str] = None):
        if tesseract_cmd:
            pytesseract.pytesseract.tesseract_cmd = tesseract_cmd
        self.logger = logging.getLogger(__name__)
    
    def extract_text(self, 
                    image: np.ndarray,
                    region: Optional[CVRegion] = None,
                    language: str = "eng",
                    config: str = "--psm 3") -> List[OCRResult]:
        """Extract text from image using Tesseract"""
        
        # Crop to region if specified
        if region:
            image = image[region.y:region.y + region.height, 
                         region.x:region.x + region.width]
        
        # Preprocess image for better OCR
        processed = self._preprocess_for_ocr(image)
        
        # Get detailed OCR data
        data = pytesseract.image_to_data(processed, lang=language, 
                                        config=config, output_type=pytesseract.Output.DICT)
        
        # Parse results
        results = []
        current_text = []
        current_region = None
        
        for i in range(len(data['text'])):
            if int(data['conf'][i]) > 0:  # Valid detection
                text = data['text'][i].strip()
                if text:
                    x, y, w, h = data['left'][i], data['top'][i], data['width'][i], data['height'][i]
                    
                    # Adjust coordinates if region was specified
                    if region:
                        x += region.x
                        y += region.y
                    
                    word_region = CVRegion(x, y, w, h)
                    word = OCRWord(text, word_region, float(data['conf'][i]) / 100)
                    
                    # Group words into lines
                    if current_region and self._is_same_line(current_region, word_region):
                        current_text.append(text)
                        current_region = self._merge_regions(current_region, word_region)
                    else:
                        if current_text:
                            results.append(OCRResult(
                                text=' '.join(current_text),
                                region=current_region,
                                confidence=sum(float(data['conf'][j]) / 100 for j in range(i - len(current_text), i)) / len(current_text),
                                language=language
                            ))
                        current_text = [text]
                        current_region = word_region
        
        # Add last group
        if current_text:
            results.append(OCRResult(
                text=' '.join(current_text),
                region=current_region,
                confidence=1.0,  # Simplified
                language=language
            ))
        
        return results
    
    def _preprocess_for_ocr(self, image: np.ndarray) -> np.ndarray:
        """Preprocess image for better OCR results"""
        # Convert to grayscale if needed
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image.copy()
        
        # Apply thresholding
        _, thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        
        # Denoise
        denoised = cv2.fastNlMeansDenoising(thresh)
        
        # Resize if too small
        height, width = denoised.shape
        if height < 50 or width < 50:
            scale = max(50 / height, 50 / width)
            new_size = (int(width * scale), int(height * scale))
            denoised = cv2.resize(denoised, new_size, interpolation=cv2.INTER_CUBIC)
        
        return denoised
    
    def _is_same_line(self, region1: CVRegion, region2: CVRegion) -> bool:
        """Check if two regions are on the same line"""
        # Check vertical overlap
        y_overlap = min(region1.y + region1.height, region2.y + region2.height) - max(region1.y, region2.y)
        min_height = min(region1.height, region2.height)
        return y_overlap > 0.5 * min_height
    
    def _merge_regions(self, region1: CVRegion, region2: CVRegion) -> CVRegion:
        """Merge two regions into one"""
        x = min(region1.x, region2.x)
        y = min(region1.y, region2.y)
        x2 = max(region1.x + region1.width, region2.x + region2.width)
        y2 = max(region1.y + region1.height, region2.y + region2.height)
        return CVRegion(x, y, x2 - x, y2 - y)


class TemplateMatchingProvider:
    """Template matching using OpenCV"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.methods = {
            'TM_CCOEFF_NORMED': cv2.TM_CCOEFF_NORMED,
            'TM_CCORR_NORMED': cv2.TM_CCORR_NORMED,
            'TM_SQDIFF_NORMED': cv2.TM_SQDIFF_NORMED
        }
    
    def find_template(self,
                     screenshot: np.ndarray,
                     template: np.ndarray,
                     confidence: float = 0.8,
                     method: str = 'TM_CCOEFF_NORMED',
                     scale_range: Optional[Tuple[float, float]] = None) -> Optional[CVMatch]:
        """Find template in screenshot"""
        
        if scale_range:
            # Multi-scale template matching
            return self._multi_scale_match(screenshot, template, confidence, method, scale_range)
        
        # Single scale matching
        result = cv2.matchTemplate(screenshot, template, self.methods[method])
        min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(result)
        
        # For SQDIFF, lower values are better
        if method == 'TM_SQDIFF_NORMED':
            match_val = 1 - min_val
            match_loc = min_loc
        else:
            match_val = max_val
            match_loc = max_loc
        
        if match_val >= confidence:
            h, w = template.shape[:2]
            region = CVRegion(match_loc[0], match_loc[1], w, h)
            return CVMatch(
                region=region,
                confidence=match_val,
                method=CVMatchMethod.TEMPLATE_MATCHING,
                metadata={'method': method}
            )
        
        return None
    
    def find_all_templates(self,
                          screenshot: np.ndarray,
                          template: np.ndarray,
                          confidence: float = 0.8,
                          method: str = 'TM_CCOEFF_NORMED') -> List[CVMatch]:
        """Find all occurrences of template in screenshot"""
        
        result = cv2.matchTemplate(screenshot, template, self.methods[method])
        h, w = template.shape[:2]
        
        # Find all locations above threshold
        if method == 'TM_SQDIFF_NORMED':
            locations = np.where(result <= 1 - confidence)
        else:
            locations = np.where(result >= confidence)
        
        matches = []
        for pt in zip(*locations[::-1]):
            region = CVRegion(pt[0], pt[1], w, h)
            match_confidence = result[pt[1], pt[0]]
            if method == 'TM_SQDIFF_NORMED':
                match_confidence = 1 - match_confidence
            
            matches.append(CVMatch(
                region=region,
                confidence=match_confidence,
                method=CVMatchMethod.TEMPLATE_MATCHING,
                metadata={'method': method}
            ))
        
        # Remove overlapping matches
        return self._non_max_suppression(matches)
    
    def _multi_scale_match(self,
                          screenshot: np.ndarray,
                          template: np.ndarray,
                          confidence: float,
                          method: str,
                          scale_range: Tuple[float, float]) -> Optional[CVMatch]:
        """Template matching at multiple scales"""
        
        best_match = None
        best_confidence = 0
        
        for scale in np.linspace(scale_range[0], scale_range[1], 20):
            # Resize template
            scaled_template = cv2.resize(template, None, fx=scale, fy=scale)
            
            # Skip if template is larger than screenshot
            if (scaled_template.shape[0] > screenshot.shape[0] or 
                scaled_template.shape[1] > screenshot.shape[1]):
                continue
            
            match = self.find_template(screenshot, scaled_template, confidence, method)
            if match and match.confidence > best_confidence:
                best_match = match
                best_confidence = match.confidence
                best_match.metadata['scale'] = scale
        
        return best_match
    
    def _non_max_suppression(self, matches: List[CVMatch], overlap_thresh: float = 0.3) -> List[CVMatch]:
        """Remove overlapping matches"""
        if not matches:
            return []
        
        # Sort by confidence
        matches = sorted(matches, key=lambda x: x.confidence, reverse=True)
        
        keep = []
        for match in matches:
            # Check overlap with already kept matches
            overlap = False
            for kept in keep:
                if self._calculate_iou(match.region, kept.region) > overlap_thresh:
                    overlap = True
                    break
            
            if not overlap:
                keep.append(match)
        
        return keep
    
    def _calculate_iou(self, region1: CVRegion, region2: CVRegion) -> float:
        """Calculate Intersection over Union"""
        # Calculate intersection
        x1 = max(region1.x, region2.x)
        y1 = max(region1.y, region2.y)
        x2 = min(region1.x + region1.width, region2.x + region2.width)
        y2 = min(region1.y + region1.height, region2.y + region2.height)
        
        if x2 < x1 or y2 < y1:
            return 0.0
        
        intersection = (x2 - x1) * (y2 - y1)
        
        # Calculate union
        area1 = region1.width * region1.height
        area2 = region2.width * region2.height
        union = area1 + area2 - intersection
        
        return intersection / union if union > 0 else 0.0


class MLObjectDetectionProvider:
    """Machine learning based object detection"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.models: Dict[str, MLModel] = {}
        self.loaded_models: Dict[str, Any] = {}
    
    def register_model(self, model: MLModel):
        """Register an ML model for object detection"""
        self.models[model.id] = model
    
    def load_model(self, model_id: str):
        """Load a registered model"""
        if model_id in self.loaded_models:
            return
        
        model = self.models.get(model_id)
        if not model:
            raise ValueError(f"Model {model_id} not registered")
        
        if model.type == "yolo" and TORCH_AVAILABLE:
            # Load YOLO model
            self.loaded_models[model_id] = torch.hub.load(
                'ultralytics/yolov5', 'custom', path=model.model_path
            )
        elif model.type == "tensorflow":
            # TODO: Load TensorFlow model
            pass
        elif model.type == "custom":
            # Load custom model using provided loader
            if hasattr(model, 'loader'):
                self.loaded_models[model_id] = model.loader(model.model_path)
    
    def detect_objects(self,
                      image: np.ndarray,
                      model_id: str,
                      confidence: float = 0.5,
                      classes: Optional[List[str]] = None) -> List[CVElement]:
        """Detect objects in image using ML model"""
        
        # Load model if not already loaded
        self.load_model(model_id)
        
        model = self.models[model_id]
        loaded_model = self.loaded_models[model_id]
        
        if model.type == "yolo" and TORCH_AVAILABLE:
            return self._detect_yolo(image, loaded_model, confidence, classes)
        elif model.type == "custom":
            # Use custom detection function
            if hasattr(model, 'detect'):
                return model.detect(image, loaded_model, confidence, classes)
        
        return []
    
    def _detect_yolo(self,
                    image: np.ndarray,
                    model: Any,
                    confidence: float,
                    classes: Optional[List[str]]) -> List[CVElement]:
        """Detect objects using YOLO model"""
        
        # Run inference
        results = model(image)
        
        elements = []
        for *box, conf, cls in results.xyxy[0]:
            if conf < confidence:
                continue
            
            class_name = model.names[int(cls)]
            if classes and class_name not in classes:
                continue
            
            x1, y1, x2, y2 = map(int, box)
            region = CVRegion(x1, y1, x2 - x1, y2 - y1)
            
            element = CVElement(
                id=f"{class_name}_{len(elements)}",
                type=class_name,
                region=region,
                confidence=float(conf),
                properties={
                    'class': class_name,
                    'class_id': int(cls)
                }
            )
            elements.append(element)
        
        return elements


class CVFallbackEngine(CVProvider):
    """Main computer vision fallback engine"""
    
    def __init__(self, config: Optional[RemoteDesktopConfig] = None):
        self.config = config or RemoteDesktopConfig(type="rdp")
        self.logger = logging.getLogger(__name__)
        
        # Initialize providers
        self.ocr_provider = TesseractOCRProvider()
        self.template_provider = TemplateMatchingProvider()
        self.ml_provider = MLObjectDetectionProvider()
        
        # Initialize cache
        self.cache = CVCache(max_size_mb=self.config.max_cache_size)
        
        # Strategies
        self.strategies: List[CVFallbackStrategy] = []
        self._init_default_strategies()
        
        # Performance tracking
        self.metrics: List[CVPerformanceMetrics] = []
        
        # Thread pool for parallel operations
        self.executor = ThreadPoolExecutor(max_workers=4)
    
    def _init_default_strategies(self):
        """Initialize default fallback strategies"""
        
        # RDP/Citrix strategy
        rdp_strategy = CVFallbackStrategy(
            name="rdp_citrix",
            methods=[CVMatchMethod.OCR_TEXT, CVMatchMethod.TEMPLATE_MATCHING],
            priority=1
        )
        rdp_strategy.should_use_for = lambda ctx: ctx.get('connection_type') in ['rdp', 'citrix']
        
        # Low quality image strategy
        low_quality_strategy = CVFallbackStrategy(
            name="low_quality",
            methods=[CVMatchMethod.ML_OBJECT_DETECTION, CVMatchMethod.FEATURE_MATCHING],
            priority=2
        )
        
        # Text-heavy UI strategy
        text_ui_strategy = CVFallbackStrategy(
            name="text_ui",
            methods=[CVMatchMethod.OCR_TEXT],
            priority=3
        )
        
        self.strategies.extend([rdp_strategy, low_quality_strategy, text_ui_strategy])
    
    def find_element(self,
                    screenshot: Union[str, np.ndarray, Image.Image],
                    target: Union[str, CVTemplate, Dict[str, Any]],
                    method: CVMatchMethod = CVMatchMethod.TEMPLATE_MATCHING,
                    confidence: float = CVConfidence.MEDIUM.value) -> Optional[CVMatch]:
        """Find an element in screenshot"""
        
        start_time = time.time()
        
        # Convert screenshot to numpy array
        screenshot_np = self._to_numpy(screenshot)
        
        # Check cache
        screenshot_hash = self._hash_image(screenshot_np)
        target_hash = self._hash_target(target)
        cached = self.cache.get_cached_match(screenshot_hash, target_hash)
        if cached:
            self._record_metric("find_element", time.time() - start_time, method, True, cache_hit=True)
            return cached[0] if cached else None
        
        # Try requested method
        match = self._find_by_method(screenshot_np, target, method, confidence)
        
        # If failed, try fallback strategies
        if not match:
            context = self._analyze_context(screenshot_np)
            for strategy in sorted(self.strategies, key=lambda s: s.priority):
                if strategy.should_use_for(context):
                    for fallback_method in strategy.methods:
                        match = self._find_by_method(screenshot_np, target, fallback_method, confidence)
                        if match:
                            break
                if match:
                    break
        
        # Cache result
        if match:
            self.cache.cache_match(screenshot_hash, target_hash, [match])
        
        self._record_metric("find_element", time.time() - start_time, method, match is not None)
        return match
    
    def find_all_elements(self,
                         screenshot: Union[str, np.ndarray, Image.Image],
                         target: Union[str, CVTemplate, Dict[str, Any]],
                         method: CVMatchMethod = CVMatchMethod.TEMPLATE_MATCHING,
                         confidence: float = CVConfidence.MEDIUM.value) -> List[CVMatch]:
        """Find all matching elements in screenshot"""
        
        screenshot_np = self._to_numpy(screenshot)
        
        if method == CVMatchMethod.TEMPLATE_MATCHING:
            template = self._get_template(target)
            if template:
                return self.template_provider.find_all_templates(
                    screenshot_np, template, confidence
                )
        elif method == CVMatchMethod.OCR_TEXT and isinstance(target, str):
            ocr_results = self.extract_text(screenshot_np)
            matches = []
            for result in ocr_results:
                if result.contains_text(target):
                    matches.append(CVMatch(
                        region=result.region,
                        confidence=result.confidence,
                        method=CVMatchMethod.OCR_TEXT,
                        text=result.text
                    ))
            return matches
        
        return []
    
    def extract_text(self,
                    screenshot: Union[str, np.ndarray, Image.Image],
                    region: Optional[CVRegion] = None,
                    language: str = "eng") -> List[OCRResult]:
        """Extract text using OCR"""
        
        screenshot_np = self._to_numpy(screenshot)
        return self.ocr_provider.extract_text(screenshot_np, region, language)
    
    def detect_ui_elements(self,
                          screenshot: Union[str, np.ndarray, Image.Image],
                          element_types: Optional[List[str]] = None) -> List[CVElement]:
        """Detect UI elements using ML models"""
        
        screenshot_np = self._to_numpy(screenshot)
        
        # Use default UI detection model if available
        if "ui_detector" in self.ml_provider.models:
            return self.ml_provider.detect_objects(
                screenshot_np, "ui_detector", classes=element_types
            )
        
        # Fallback to template-based detection
        elements = []
        
        # Detect buttons
        if not element_types or "button" in element_types:
            button_matches = self._detect_buttons(screenshot_np)
            elements.extend(button_matches)
        
        # Detect text fields
        if not element_types or "textbox" in element_types:
            textbox_matches = self._detect_textboxes(screenshot_np)
            elements.extend(textbox_matches)
        
        return elements
    
    def wait_for_element(self,
                        target: Union[str, CVTemplate, Dict[str, Any]],
                        timeout: int = 30,
                        method: CVMatchMethod = CVMatchMethod.TEMPLATE_MATCHING,
                        capture_func: Optional[Callable] = None) -> Optional[CVMatch]:
        """Wait for element to appear"""
        
        start_time = time.time()
        
        while time.time() - start_time < timeout:
            # Capture screenshot
            if capture_func:
                screenshot = capture_func()
            else:
                # Default screenshot capture
                screenshot = self._capture_screenshot()
            
            # Try to find element
            match = self.find_element(screenshot, target, method)
            if match:
                return match
            
            time.sleep(0.5)
        
        return None
    
    def calibrate(self, reference_screenshot: Union[str, np.ndarray, Image.Image]) -> CVCalibration:
        """Calibrate CV for current environment"""
        
        screenshot_np = self._to_numpy(reference_screenshot)
        height, width = screenshot_np.shape[:2]
        
        # Detect known UI elements for calibration
        elements = self.detect_ui_elements(screenshot_np)
        
        # Analyze image properties
        if len(screenshot_np.shape) == 3:
            gray = cv2.cvtColor(screenshot_np, cv2.COLOR_BGR2GRAY)
        else:
            gray = screenshot_np
        
        brightness = np.mean(gray) / 255.0
        contrast = np.std(gray) / 128.0
        
        calibration = CVCalibration(
            screen_resolution=(width, height),
            dpi=96.0,  # Default, would need actual DPI detection
            brightness_adjustment=1.0 / brightness if brightness > 0 else 1.0,
            contrast_adjustment=1.0 / contrast if contrast > 0 else 1.0,
            known_elements=elements,
            reference_screenshot=screenshot_np
        )
        
        return calibration
    
    # Helper methods
    def _to_numpy(self, image: Union[str, np.ndarray, Image.Image]) -> np.ndarray:
        """Convert image to numpy array"""
        if isinstance(image, str):
            return cv2.imread(image)
        elif isinstance(image, Image.Image):
            return np.array(image)
        return image
    
    def _hash_image(self, image: np.ndarray) -> str:
        """Generate hash for image"""
        return hashlib.md5(image.tobytes()).hexdigest()
    
    def _hash_target(self, target: Any) -> str:
        """Generate hash for target"""
        if isinstance(target, str):
            return hashlib.md5(target.encode()).hexdigest()
        elif isinstance(target, CVTemplate):
            return target.id
        else:
            return hashlib.md5(str(target).encode()).hexdigest()
    
    def _find_by_method(self,
                       screenshot: np.ndarray,
                       target: Any,
                       method: CVMatchMethod,
                       confidence: float) -> Optional[CVMatch]:
        """Find element using specific method"""
        
        if method == CVMatchMethod.TEMPLATE_MATCHING:
            template = self._get_template(target)
            if template:
                return self.template_provider.find_template(
                    screenshot, template, confidence
                )
        
        elif method == CVMatchMethod.OCR_TEXT and isinstance(target, str):
            ocr_results = self.extract_text(screenshot)
            for result in ocr_results:
                if result.contains_text(target) and result.confidence >= confidence:
                    return CVMatch(
                        region=result.region,
                        confidence=result.confidence,
                        method=CVMatchMethod.OCR_TEXT,
                        text=result.text
                    )
        
        elif method == CVMatchMethod.ML_OBJECT_DETECTION:
            if isinstance(target, dict) and 'model_id' in target:
                elements = self.ml_provider.detect_objects(
                    screenshot, target['model_id'], confidence
                )
                if elements and 'type' in target:
                    # Filter by type
                    elements = [e for e in elements if e.type == target['type']]
                
                if elements:
                    # Return best match
                    best = max(elements, key=lambda e: e.confidence)
                    return CVMatch(
                        region=best.region,
                        confidence=best.confidence,
                        method=CVMatchMethod.ML_OBJECT_DETECTION,
                        metadata={'element': best}
                    )
        
        return None
    
    def _get_template(self, target: Any) -> Optional[np.ndarray]:
        """Get template image from target"""
        if isinstance(target, CVTemplate):
            if target.image_data is not None:
                return target.image_data
            elif target.image_path:
                return cv2.imread(target.image_path)
        elif isinstance(target, str) and target.endswith(('.png', '.jpg', '.jpeg')):
            return cv2.imread(target)
        elif isinstance(target, dict) and 'image_path' in target:
            return cv2.imread(target['image_path'])
        return None
    
    def _analyze_context(self, screenshot: np.ndarray) -> Dict[str, Any]:
        """Analyze screenshot context for strategy selection"""
        context = {}
        
        # Check if it's a remote desktop window
        # Simple heuristic: look for RDP/Citrix window decorations
        ocr_results = self.extract_text(screenshot, 
                                       CVRegion(0, 0, screenshot.shape[1], 50))
        for result in ocr_results:
            if any(term in result.text.lower() for term in ['remote desktop', 'citrix', 'vmware']):
                context['connection_type'] = 'rdp'
                break
        
        # Analyze image quality
        if len(screenshot.shape) == 3:
            gray = cv2.cvtColor(screenshot, cv2.COLOR_BGR2GRAY)
        else:
            gray = screenshot
        
        # Calculate image metrics
        context['brightness'] = np.mean(gray)
        context['contrast'] = np.std(gray)
        context['sharpness'] = cv2.Laplacian(gray, cv2.CV_64F).var()
        
        # Determine if low quality
        if context['sharpness'] < 100:
            context['quality'] = 'low'
        
        return context
    
    def _detect_buttons(self, screenshot: np.ndarray) -> List[CVElement]:
        """Detect button-like elements"""
        elements = []
        
        # Convert to grayscale
        if len(screenshot.shape) == 3:
            gray = cv2.cvtColor(screenshot, cv2.COLOR_BGR2GRAY)
        else:
            gray = screenshot
        
        # Find contours
        edges = cv2.Canny(gray, 50, 150)
        contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        for i, contour in enumerate(contours):
            x, y, w, h = cv2.boundingRect(contour)
            
            # Filter by size and aspect ratio
            if 20 < w < 300 and 15 < h < 100 and 0.5 < w/h < 8:
                region = CVRegion(x, y, w, h)
                
                # Check if contains text
                roi = screenshot[y:y+h, x:x+w]
                ocr_results = self.extract_text(roi)
                
                if ocr_results:
                    # Likely a button
                    element = CVElement(
                        id=f"button_{i}",
                        type="button",
                        region=region,
                        confidence=0.7,
                        properties={
                            'text': ocr_results[0].text if ocr_results else ""
                        }
                    )
                    elements.append(element)
        
        return elements
    
    def _detect_textboxes(self, screenshot: np.ndarray) -> List[CVElement]:
        """Detect text input fields"""
        elements = []
        
        # Convert to grayscale
        if len(screenshot.shape) == 3:
            gray = cv2.cvtColor(screenshot, cv2.COLOR_BGR2GRAY)
        else:
            gray = screenshot
        
        # Look for rectangular areas with consistent background
        # This is a simplified approach
        edges = cv2.Canny(gray, 30, 100)
        contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        for i, contour in enumerate(contours):
            x, y, w, h = cv2.boundingRect(contour)
            
            # Filter by size and aspect ratio typical for text fields
            if 50 < w < 500 and 15 < h < 50 and w/h > 3:
                region = CVRegion(x, y, w, h)
                
                # Check if it's likely a text field (light background, minimal text)
                roi = gray[y:y+h, x:x+w]
                mean_val = np.mean(roi)
                
                if mean_val > 200:  # Light background
                    element = CVElement(
                        id=f"textbox_{i}",
                        type="textbox",
                        region=region,
                        confidence=0.6,
                        properties={}
                    )
                    elements.append(element)
        
        return elements
    
    def _capture_screenshot(self) -> np.ndarray:
        """Default screenshot capture method"""
        # This would be implemented based on the platform
        # For now, return a placeholder
        import mss
        with mss.mss() as sct:
            monitor = sct.monitors[1]
            img = sct.grab(monitor)
            return np.array(img)
    
    def _record_metric(self, 
                      operation: str,
                      duration_ms: float,
                      method: CVMatchMethod,
                      success: bool,
                      cache_hit: bool = False):
        """Record performance metric"""
        metric = CVPerformanceMetrics(
            operation=operation,
            duration_ms=duration_ms * 1000,
            method=method,
            success=success,
            cache_hit=cache_hit,
            gpu_used=self.config.use_gpu
        )
        self.metrics.append(metric)
        
        # Keep only recent metrics
        if len(self.metrics) > 1000:
            self.metrics = self.metrics[-1000:]
    
    def get_performance_stats(self) -> Dict[str, Any]:
        """Get performance statistics"""
        if not self.metrics:
            return {}
        
        total_ops = len(self.metrics)
        successful_ops = sum(1 for m in self.metrics if m.success)
        cache_hits = sum(1 for m in self.metrics if m.cache_hit)
        avg_duration = sum(m.duration_ms for m in self.metrics) / total_ops
        
        return {
            'total_operations': total_ops,
            'success_rate': successful_ops / total_ops,
            'cache_hit_rate': cache_hits / total_ops,
            'average_duration_ms': avg_duration,
            'by_method': self._get_method_stats()
        }
    
    def _get_method_stats(self) -> Dict[str, Dict[str, float]]:
        """Get statistics by method"""
        method_stats = {}
        
        for method in CVMatchMethod:
            method_metrics = [m for m in self.metrics if m.method == method]
            if method_metrics:
                successful = sum(1 for m in method_metrics if m.success)
                avg_duration = sum(m.duration_ms for m in method_metrics) / len(method_metrics)
                
                method_stats[method.value] = {
                    'count': len(method_metrics),
                    'success_rate': successful / len(method_metrics),
                    'average_duration_ms': avg_duration
                }
        
        return method_stats 