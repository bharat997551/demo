"""
Computer Vision Fallback Package
Provides CV-based automation when standard methods fail
"""

from .types import (
    CVMatchMethod,
    CVConfidence,
    CVRegion,
    CVMatch,
    CVElement,
    OCRResult,
    OCRWord,
    CVTemplate,
    MLModel,
    CVFallbackStrategy,
    RemoteDesktopConfig,
    CVCalibration,
    CVProvider,
    CVCache,
    CVPerformanceMetrics
)

from .cv_fallback_engine import (
    TesseractOCRProvider,
    TemplateMatchingProvider,
    MLObjectDetectionProvider,
    CVFallbackEngine
)

from .integration import (
    CVIntegratedDesktopEngine,
    CVElementWrapper
)

__all__ = [
    # Types
    'CVMatchMethod',
    'CVConfidence', 
    'CVRegion',
    'CVMatch',
    'CVElement',
    'OCRResult',
    'OCRWord',
    'CVTemplate',
    'MLModel',
    'CVFallbackStrategy',
    'RemoteDesktopConfig',
    'CVCalibration',
    'CVProvider',
    'CVCache',
    'CVPerformanceMetrics',
    
    # Providers
    'TesseractOCRProvider',
    'TemplateMatchingProvider',
    'MLObjectDetectionProvider',
    
    # Main Engine
    'CVFallbackEngine',
    
    # Integration
    'CVIntegratedDesktopEngine',
    'CVElementWrapper'
] 