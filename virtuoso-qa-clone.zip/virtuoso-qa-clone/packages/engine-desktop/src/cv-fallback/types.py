"""
Computer Vision Fallback Types and Interfaces
For handling RDP/Citrix and other virtualized environments
"""

from typing import Optional, List, Dict, Any, Tuple, Union, Callable
from dataclasses import dataclass
from enum import Enum
import numpy as np
from PIL import Image


class CVMatchMethod(Enum):
    """Computer vision matching methods"""
    TEMPLATE_MATCHING = "template_matching"
    FEATURE_MATCHING = "feature_matching"
    OCR_TEXT = "ocr_text"
    ML_OBJECT_DETECTION = "ml_object_detection"
    CUSTOM_MODEL = "custom_model"
    HYBRID = "hybrid"


class CVConfidence(Enum):
    """Confidence levels for CV matches"""
    VERY_HIGH = 0.95
    HIGH = 0.85
    MEDIUM = 0.70
    LOW = 0.50
    VERY_LOW = 0.30


@dataclass
class CVRegion:
    """Region of interest in an image"""
    x: int
    y: int
    width: int
    height: int
    
    @property
    def center(self) -> Tuple[int, int]:
        return (self.x + self.width // 2, self.y + self.height // 2)
    
    @property
    def bounds(self) -> Tuple[int, int, int, int]:
        return (self.x, self.y, self.x + self.width, self.y + self.height)
    
    def contains(self, x: int, y: int) -> bool:
        return self.x <= x <= self.x + self.width and self.y <= y <= self.y + self.height
    
    def intersects(self, other: 'CVRegion') -> bool:
        return not (self.x + self.width < other.x or 
                   other.x + other.width < self.x or
                   self.y + self.height < other.y or
                   other.y + other.height < self.y)


@dataclass
class CVMatch:
    """Result of a computer vision match"""
    region: CVRegion
    confidence: float
    method: CVMatchMethod
    template: Optional[str] = None
    text: Optional[str] = None
    features: Optional[Dict[str, Any]] = None
    metadata: Optional[Dict[str, Any]] = None
    
    @property
    def is_high_confidence(self) -> bool:
        return self.confidence >= CVConfidence.HIGH.value
    
    @property
    def center(self) -> Tuple[int, int]:
        return self.region.center


@dataclass
class CVElement:
    """UI element detected by computer vision"""
    id: str
    type: str  # button, textbox, label, etc.
    region: CVRegion
    confidence: float
    properties: Dict[str, Any]
    screenshot: Optional[np.ndarray] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'id': self.id,
            'type': self.type,
            'region': {
                'x': self.region.x,
                'y': self.region.y,
                'width': self.region.width,
                'height': self.region.height
            },
            'confidence': self.confidence,
            'properties': self.properties
        }


@dataclass
class OCRResult:
    """OCR text detection result"""
    text: str
    region: CVRegion
    confidence: float
    language: str = "en"
    words: Optional[List['OCRWord']] = None
    
    def contains_text(self, search_text: str, case_sensitive: bool = False) -> bool:
        if case_sensitive:
            return search_text in self.text
        return search_text.lower() in self.text.lower()


@dataclass
class OCRWord:
    """Individual word from OCR"""
    text: str
    region: CVRegion
    confidence: float


@dataclass
class CVTemplate:
    """Template for computer vision matching"""
    id: str
    name: str
    image_path: Optional[str] = None
    image_data: Optional[np.ndarray] = None
    features: Optional[Dict[str, Any]] = None
    match_threshold: float = 0.8
    use_grayscale: bool = True
    scale_invariant: bool = False
    rotation_invariant: bool = False
    metadata: Optional[Dict[str, Any]] = None


@dataclass
class MLModel:
    """Machine learning model for object detection"""
    id: str
    name: str
    type: str  # yolo, tensorflow, pytorch, custom
    model_path: str
    config_path: Optional[str] = None
    labels: Optional[List[str]] = None
    input_size: Optional[Tuple[int, int]] = None
    preprocessing: Optional[Callable] = None
    postprocessing: Optional[Callable] = None


class CVFallbackStrategy:
    """Strategy for fallback when standard automation fails"""
    
    def __init__(self, name: str, methods: List[CVMatchMethod], priority: int = 0):
        self.name = name
        self.methods = methods
        self.priority = priority
        self.custom_handlers: Dict[str, Callable] = {}
    
    def add_handler(self, element_type: str, handler: Callable):
        """Add custom handler for specific element types"""
        self.custom_handlers[element_type] = handler
    
    def should_use_for(self, context: Dict[str, Any]) -> bool:
        """Determine if this strategy should be used"""
        # Override in subclasses
        return True


@dataclass
class RemoteDesktopConfig:
    """Configuration for remote desktop sessions"""
    type: str  # rdp, citrix, vnc, custom
    compression_quality: int = 85
    color_depth: int = 24
    capture_method: str = "screenshot"  # screenshot, hook, mirror
    optimize_for: str = "accuracy"  # accuracy, speed, balanced
    use_gpu: bool = True
    cache_templates: bool = True
    max_cache_size: int = 100  # MB


@dataclass
class CVCalibration:
    """Calibration data for computer vision accuracy"""
    screen_resolution: Tuple[int, int]
    dpi: float
    color_profile: Optional[str] = None
    brightness_adjustment: float = 1.0
    contrast_adjustment: float = 1.0
    known_elements: Optional[List[CVElement]] = None
    reference_screenshot: Optional[np.ndarray] = None


class CVProvider:
    """Base class for computer vision providers"""
    
    def find_element(self, 
                    screenshot: Union[str, np.ndarray, Image.Image],
                    target: Union[str, CVTemplate, Dict[str, Any]],
                    method: CVMatchMethod = CVMatchMethod.TEMPLATE_MATCHING,
                    confidence: float = CVConfidence.MEDIUM.value) -> Optional[CVMatch]:
        """Find an element in screenshot"""
        raise NotImplementedError
    
    def find_all_elements(self,
                         screenshot: Union[str, np.ndarray, Image.Image],
                         target: Union[str, CVTemplate, Dict[str, Any]],
                         method: CVMatchMethod = CVMatchMethod.TEMPLATE_MATCHING,
                         confidence: float = CVConfidence.MEDIUM.value) -> List[CVMatch]:
        """Find all matching elements in screenshot"""
        raise NotImplementedError
    
    def extract_text(self,
                    screenshot: Union[str, np.ndarray, Image.Image],
                    region: Optional[CVRegion] = None,
                    language: str = "en") -> List[OCRResult]:
        """Extract text using OCR"""
        raise NotImplementedError
    
    def detect_ui_elements(self,
                          screenshot: Union[str, np.ndarray, Image.Image],
                          element_types: Optional[List[str]] = None) -> List[CVElement]:
        """Detect UI elements using ML models"""
        raise NotImplementedError
    
    def wait_for_element(self,
                        target: Union[str, CVTemplate, Dict[str, Any]],
                        timeout: int = 30,
                        method: CVMatchMethod = CVMatchMethod.TEMPLATE_MATCHING) -> Optional[CVMatch]:
        """Wait for element to appear"""
        raise NotImplementedError
    
    def calibrate(self, reference_screenshot: Union[str, np.ndarray, Image.Image]) -> CVCalibration:
        """Calibrate CV for current environment"""
        raise NotImplementedError


class CVCache:
    """Cache for computer vision operations"""
    
    def __init__(self, max_size_mb: int = 100):
        self.max_size_mb = max_size_mb
        self.templates: Dict[str, CVTemplate] = {}
        self.screenshots: Dict[str, np.ndarray] = {}
        self.matches: Dict[str, List[CVMatch]] = {}
        self.ocr_results: Dict[str, List[OCRResult]] = {}
    
    def get_template(self, template_id: str) -> Optional[CVTemplate]:
        return self.templates.get(template_id)
    
    def cache_template(self, template: CVTemplate):
        self.templates[template.id] = template
    
    def get_cached_match(self, screenshot_hash: str, target_hash: str) -> Optional[List[CVMatch]]:
        key = f"{screenshot_hash}:{target_hash}"
        return self.matches.get(key)
    
    def cache_match(self, screenshot_hash: str, target_hash: str, matches: List[CVMatch]):
        key = f"{screenshot_hash}:{target_hash}"
        self.matches[key] = matches
    
    def clear(self):
        self.templates.clear()
        self.screenshots.clear()
        self.matches.clear()
        self.ocr_results.clear()


@dataclass
class CVPerformanceMetrics:
    """Performance metrics for CV operations"""
    operation: str
    duration_ms: float
    method: CVMatchMethod
    success: bool
    confidence: Optional[float] = None
    cache_hit: bool = False
    gpu_used: bool = False
    memory_mb: Optional[float] = None 