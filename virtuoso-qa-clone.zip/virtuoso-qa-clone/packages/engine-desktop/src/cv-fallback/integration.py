"""
Integration layer for computer vision fallback in desktop automation
Automatically switches to CV when standard methods fail
"""

import time
import logging
from typing import Optional, Dict, Any, List, Union
import numpy as np
from pywinauto import Desktop, Application
from pywinauto.findwindows import ElementNotFoundError
from pywinauto.controls.win32_controls import ButtonWrapper
from pywinauto.timings import TimeoutError as PywinautoTimeoutError

from .cv_fallback_engine import CVFallbackEngine
from .types import (
    CVMatchMethod, RemoteDesktopConfig, CVElement, CVMatch,
    CVTemplate, CVConfidence
)


class CVIntegratedDesktopEngine:
    """Desktop automation engine with CV fallback integration"""
    
    def __init__(self, use_cv_fallback: bool = True):
        self.logger = logging.getLogger(__name__)
        self.use_cv_fallback = use_cv_fallback
        
        # Initialize CV engine if enabled
        if use_cv_fallback:
            self.cv_engine = CVFallbackEngine(
                RemoteDesktopConfig(
                    type="auto",  # Auto-detect RDP/Citrix
                    optimize_for="balanced",
                    use_gpu=True
                )
            )
        else:
            self.cv_engine = None
        
        # Template cache for frequently used elements
        self.template_cache: Dict[str, CVTemplate] = {}
        
        # Performance metrics
        self.cv_fallback_count = 0
        self.standard_success_count = 0
    
    def find_element(self,
                    window: Any,
                    locator: Dict[str, Any],
                    timeout: int = 10) -> Any:
        """Find element using standard method with CV fallback"""
        
        start_time = time.time()
        
        # Try standard pywinauto method first
        try:
            element = self._find_standard(window, locator, timeout)
            self.standard_success_count += 1
            return element
        except (ElementNotFoundError, PywinautoTimeoutError) as e:
            self.logger.info(f"Standard method failed: {e}, trying CV fallback")
        
        # Use CV fallback if enabled
        if not self.use_cv_fallback or not self.cv_engine:
            raise ElementNotFoundError(f"Element not found: {locator}")
        
        self.cv_fallback_count += 1
        
        # Capture window screenshot
        screenshot = self._capture_window_screenshot(window)
        
        # Determine CV search strategy
        cv_match = None
        
        if 'text' in locator:
            # Use OCR to find text
            cv_match = self.cv_engine.find_element(
                screenshot,
                locator['text'],
                method=CVMatchMethod.OCR_TEXT,
                confidence=CVConfidence.MEDIUM.value
            )
        elif 'image' in locator:
            # Use template matching
            template = self._get_or_create_template(locator['image'])
            cv_match = self.cv_engine.find_element(
                screenshot,
                template,
                method=CVMatchMethod.TEMPLATE_MATCHING,
                confidence=locator.get('confidence', CVConfidence.HIGH.value)
            )
        elif 'ml_detect' in locator:
            # Use ML object detection
            cv_match = self.cv_engine.find_element(
                screenshot,
                {
                    'model_id': locator.get('model', 'ui_detector'),
                    'type': locator['ml_detect']
                },
                method=CVMatchMethod.ML_OBJECT_DETECTION
            )
        
        if cv_match:
            # Create wrapper for CV-found element
            return self._create_cv_element_wrapper(window, cv_match, locator)
        
        # If all methods fail
        elapsed = time.time() - start_time
        raise ElementNotFoundError(
            f"Element not found after {elapsed:.2f}s using standard and CV methods: {locator}"
        )
    
    def click_element(self,
                     window: Any,
                     locator: Dict[str, Any],
                     timeout: int = 10,
                     offset: Optional[tuple] = None) -> bool:
        """Click element with CV fallback"""
        
        # Try to find element
        element = self.find_element(window, locator, timeout)
        
        if isinstance(element, CVElementWrapper):
            # CV-based click
            return element.click(offset)
        else:
            # Standard pywinauto click
            try:
                element.click()
                return True
            except Exception as e:
                self.logger.error(f"Click failed: {e}")
                return False
    
    def type_text(self,
                 window: Any,
                 locator: Dict[str, Any],
                 text: str,
                 timeout: int = 10) -> bool:
        """Type text into element with CV fallback"""
        
        element = self.find_element(window, locator, timeout)
        
        if isinstance(element, CVElementWrapper):
            # CV-based typing
            return element.type_text(text)
        else:
            # Standard pywinauto typing
            try:
                element.type_keys(text)
                return True
            except Exception as e:
                self.logger.error(f"Type text failed: {e}")
                return False
    
    def wait_for_element(self,
                        window: Any,
                        locator: Dict[str, Any],
                        timeout: int = 30,
                        appear: bool = True) -> bool:
        """Wait for element to appear/disappear with CV fallback"""
        
        start_time = time.time()
        
        while time.time() - start_time < timeout:
            try:
                element = self.find_element(window, locator, 1)
                if appear:
                    return True  # Element found
            except ElementNotFoundError:
                if not appear:
                    return True  # Element not found (disappeared)
            
            time.sleep(0.5)
        
        return False
    
    def extract_text(self,
                    window: Any,
                    region: Optional[Dict[str, int]] = None) -> str:
        """Extract text from window or region using OCR"""
        
        if not self.cv_engine:
            raise RuntimeError("CV engine not initialized")
        
        screenshot = self._capture_window_screenshot(window)
        
        # Convert region dict to CVRegion
        cv_region = None
        if region:
            from .types import CVRegion
            cv_region = CVRegion(
                region['x'], region['y'],
                region['width'], region['height']
            )
        
        ocr_results = self.cv_engine.extract_text(screenshot, cv_region)
        
        # Combine all text
        return '\n'.join(result.text for result in ocr_results)
    
    def find_all_elements(self,
                         window: Any,
                         locator: Dict[str, Any],
                         timeout: int = 10) -> List[Any]:
        """Find all matching elements with CV fallback"""
        
        # Try standard method first
        try:
            elements = self._find_all_standard(window, locator, timeout)
            if elements:
                return elements
        except Exception as e:
            self.logger.info(f"Standard find_all failed: {e}")
        
        # Use CV fallback
        if not self.use_cv_fallback or not self.cv_engine:
            return []
        
        screenshot = self._capture_window_screenshot(window)
        cv_matches = []
        
        if 'text' in locator:
            cv_matches = self.cv_engine.find_all_elements(
                screenshot,
                locator['text'],
                method=CVMatchMethod.OCR_TEXT
            )
        elif 'image' in locator:
            template = self._get_or_create_template(locator['image'])
            cv_matches = self.cv_engine.find_all_elements(
                screenshot,
                template,
                method=CVMatchMethod.TEMPLATE_MATCHING
            )
        
        # Create wrappers for all matches
        return [self._create_cv_element_wrapper(window, match, locator) 
                for match in cv_matches]
    
    def is_window_remote_session(self, window: Any) -> bool:
        """Detect if window is a remote desktop session"""
        
        # Check window title
        try:
            title = window.window_text()
            remote_indicators = [
                'remote desktop', 'rdp', 'citrix',
                'vmware', 'vnc', 'teamviewer'
            ]
            if any(ind in title.lower() for ind in remote_indicators):
                return True
        except:
            pass
        
        # Use CV to check for remote session indicators
        if self.cv_engine:
            screenshot = self._capture_window_screenshot(window)
            context = self.cv_engine._analyze_context(screenshot)
            return context.get('connection_type') in ['rdp', 'citrix']
        
        return False
    
    def register_cv_template(self,
                           name: str,
                           image_path: str,
                           match_threshold: float = 0.8,
                           **kwargs) -> None:
        """Register a template for CV matching"""
        
        template = CVTemplate(
            id=name,
            name=name,
            image_path=image_path,
            match_threshold=match_threshold,
            **kwargs
        )
        self.template_cache[name] = template
    
    def register_ml_model(self,
                         model_id: str,
                         model_path: str,
                         model_type: str = "yolo",
                         **kwargs) -> None:
        """Register ML model for object detection"""
        
        if not self.cv_engine:
            raise RuntimeError("CV engine not initialized")
        
        from .types import MLModel
        model = MLModel(
            id=model_id,
            name=model_id,
            type=model_type,
            model_path=model_path,
            **kwargs
        )
        self.cv_engine.ml_provider.register_model(model)
    
    def get_performance_stats(self) -> Dict[str, Any]:
        """Get performance statistics"""
        
        stats = {
            'standard_success_count': self.standard_success_count,
            'cv_fallback_count': self.cv_fallback_count,
            'cv_fallback_rate': (
                self.cv_fallback_count / 
                (self.standard_success_count + self.cv_fallback_count)
                if (self.standard_success_count + self.cv_fallback_count) > 0
                else 0
            )
        }
        
        if self.cv_engine:
            stats['cv_stats'] = self.cv_engine.get_performance_stats()
        
        return stats
    
    # Private helper methods
    def _find_standard(self, window: Any, locator: Dict[str, Any], timeout: int) -> Any:
        """Find element using standard pywinauto methods"""
        
        # Build search criteria
        criteria = {}
        
        if 'title' in locator:
            criteria['title'] = locator['title']
        if 'class_name' in locator:
            criteria['class_name'] = locator['class_name']
        if 'control_type' in locator:
            criteria['control_type'] = locator['control_type']
        if 'automation_id' in locator:
            criteria['auto_id'] = locator['automation_id']
        
        # Find element
        return window.child_window(**criteria).wait('exists', timeout=timeout)
    
    def _find_all_standard(self, window: Any, locator: Dict[str, Any], timeout: int) -> List[Any]:
        """Find all elements using standard methods"""
        
        criteria = {}
        if 'title' in locator:
            criteria['title'] = locator['title']
        if 'class_name' in locator:
            criteria['class_name'] = locator['class_name']
        if 'control_type' in locator:
            criteria['control_type'] = locator['control_type']
        
        # Wait for at least one to exist
        window.child_window(**criteria).wait('exists', timeout=timeout)
        
        # Find all matching
        return window.children(**criteria)
    
    def _capture_window_screenshot(self, window: Any) -> np.ndarray:
        """Capture screenshot of window"""
        
        try:
            # Get window rectangle
            rect = window.rectangle()
            
            # Use mss for screenshot
            import mss
            with mss.mss() as sct:
                monitor = {
                    "top": rect.top,
                    "left": rect.left,
                    "width": rect.width(),
                    "height": rect.height()
                }
                img = sct.grab(monitor)
                return np.array(img)
        except Exception as e:
            self.logger.error(f"Failed to capture window screenshot: {e}")
            # Fallback to full screen
            import mss
            with mss.mss() as sct:
                img = sct.grab(sct.monitors[1])
                return np.array(img)
    
    def _get_or_create_template(self, image_ref: Union[str, Dict[str, Any]]) -> CVTemplate:
        """Get template from cache or create new one"""
        
        if isinstance(image_ref, str):
            # Check cache first
            if image_ref in self.template_cache:
                return self.template_cache[image_ref]
            
            # Create new template
            template = CVTemplate(
                id=image_ref,
                name=image_ref,
                image_path=image_ref
            )
            self.template_cache[image_ref] = template
            return template
        
        elif isinstance(image_ref, dict):
            template_id = image_ref.get('id', image_ref.get('path', 'unknown'))
            
            if template_id in self.template_cache:
                return self.template_cache[template_id]
            
            template = CVTemplate(
                id=template_id,
                name=template_id,
                image_path=image_ref.get('path'),
                match_threshold=image_ref.get('threshold', 0.8),
                use_grayscale=image_ref.get('grayscale', True),
                scale_invariant=image_ref.get('scale_invariant', False)
            )
            self.template_cache[template_id] = template
            return template
        
        raise ValueError(f"Invalid image reference: {image_ref}")
    
    def _create_cv_element_wrapper(self,
                                  window: Any,
                                  cv_match: CVMatch,
                                  original_locator: Dict[str, Any]) -> 'CVElementWrapper':
        """Create wrapper for CV-found element"""
        
        return CVElementWrapper(
            window=window,
            cv_match=cv_match,
            cv_engine=self.cv_engine,
            original_locator=original_locator
        )


class CVElementWrapper:
    """Wrapper for elements found using computer vision"""
    
    def __init__(self,
                window: Any,
                cv_match: CVMatch,
                cv_engine: CVFallbackEngine,
                original_locator: Dict[str, Any]):
        self.window = window
        self.cv_match = cv_match
        self.cv_engine = cv_engine
        self.original_locator = original_locator
        self.logger = logging.getLogger(__name__)
    
    @property
    def region(self):
        """Get element region"""
        return self.cv_match.region
    
    @property
    def center(self):
        """Get element center point"""
        return self.cv_match.center
    
    def click(self, offset: Optional[tuple] = None) -> bool:
        """Click the element"""
        try:
            # Calculate click position
            if offset:
                x = self.center[0] + offset[0]
                y = self.center[1] + offset[1]
            else:
                x, y = self.center
            
            # Convert to screen coordinates
            rect = self.window.rectangle()
            screen_x = rect.left + x
            screen_y = rect.top + y
            
            # Perform click
            import pyautogui
            pyautogui.click(screen_x, screen_y)
            
            self.logger.info(f"CV click at ({screen_x}, {screen_y})")
            return True
            
        except Exception as e:
            self.logger.error(f"CV click failed: {e}")
            return False
    
    def type_text(self, text: str) -> bool:
        """Type text after clicking the element"""
        try:
            # Click to focus
            if not self.click():
                return False
            
            # Small delay for focus
            time.sleep(0.1)
            
            # Type text
            import pyautogui
            pyautogui.typewrite(text)
            
            self.logger.info(f"CV typed text: {text}")
            return True
            
        except Exception as e:
            self.logger.error(f"CV type text failed: {e}")
            return False
    
    def double_click(self) -> bool:
        """Double click the element"""
        try:
            x, y = self.center
            rect = self.window.rectangle()
            screen_x = rect.left + x
            screen_y = rect.top + y
            
            import pyautogui
            pyautogui.doubleClick(screen_x, screen_y)
            
            return True
        except Exception as e:
            self.logger.error(f"CV double click failed: {e}")
            return False
    
    def right_click(self) -> bool:
        """Right click the element"""
        try:
            x, y = self.center
            rect = self.window.rectangle()
            screen_x = rect.left + x
            screen_y = rect.top + y
            
            import pyautogui
            pyautogui.rightClick(screen_x, screen_y)
            
            return True
        except Exception as e:
            self.logger.error(f"CV right click failed: {e}")
            return False
    
    def hover(self) -> bool:
        """Hover over the element"""
        try:
            x, y = self.center
            rect = self.window.rectangle()
            screen_x = rect.left + x
            screen_y = rect.top + y
            
            import pyautogui
            pyautogui.moveTo(screen_x, screen_y)
            
            return True
        except Exception as e:
            self.logger.error(f"CV hover failed: {e}")
            return False
    
    def get_text(self) -> str:
        """Extract text from element region using OCR"""
        try:
            screenshot = self._capture_element_screenshot()
            ocr_results = self.cv_engine.extract_text(screenshot)
            return '\n'.join(result.text for result in ocr_results)
        except Exception as e:
            self.logger.error(f"CV get text failed: {e}")
            return ""
    
    def is_visible(self) -> bool:
        """Check if element is still visible"""
        try:
            # Re-capture and search
            screenshot = self._capture_window_screenshot()
            
            # Try to find again with same method
            if self.cv_match.method == CVMatchMethod.OCR_TEXT:
                match = self.cv_engine.find_element(
                    screenshot,
                    self.cv_match.text,
                    method=CVMatchMethod.OCR_TEXT
                )
            elif self.cv_match.method == CVMatchMethod.TEMPLATE_MATCHING:
                # Need original template
                match = self.cv_engine.find_element(
                    screenshot,
                    self.original_locator.get('image'),
                    method=CVMatchMethod.TEMPLATE_MATCHING
                )
            else:
                return True  # Assume visible if we can't re-check
            
            return match is not None
            
        except Exception:
            return False
    
    def _capture_element_screenshot(self) -> np.ndarray:
        """Capture screenshot of element region"""
        
        # Get window screenshot
        window_screenshot = self._capture_window_screenshot()
        
        # Crop to element region
        r = self.region
        return window_screenshot[r.y:r.y+r.height, r.x:r.x+r.width]
    
    def _capture_window_screenshot(self) -> np.ndarray:
        """Capture window screenshot"""
        
        rect = self.window.rectangle()
        import mss
        with mss.mss() as sct:
            monitor = {
                "top": rect.top,
                "left": rect.left,
                "width": rect.width(),
                "height": rect.height()
            }
            img = sct.grab(monitor)
            return np.array(img) 