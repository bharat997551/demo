"""
Element Resolver - Resolves UI elements using pywinauto and Windows UI Automation
"""
import logging
from typing import Optional, Dict, Any, List
import win32gui
import win32con
from pywinauto import Desktop, Application
from pywinauto.controls.uiawrapper import UIAWrapper
from pywinauto.findwindows import ElementNotFoundError
from pywinauto.uia_defines import IUIA
import pywinauto.uia_defines as uia_defs

from .types import UIElement, LocatorStrategy

logger = logging.getLogger(__name__)

class ElementResolver:
    """Resolves UI elements using Windows UI Automation"""
    
    def __init__(self):
        self.desktop = None
        self.is_initialized = False

    async def initialize(self):
        """Initialize the element resolver"""
        try:
            logger.info("Initializing Element Resolver")
            self.desktop = Desktop(backend="uia")
            self.is_initialized = True
            logger.info("Element Resolver initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize Element Resolver: {e}")
            raise

    async def cleanup(self):
        """Cleanup resolver resources"""
        self.is_initialized = False
        self.desktop = None
        logger.info("Element Resolver cleanup completed")

    def get_element_at_point(self, x: int, y: int) -> Optional[UIElement]:
        """Get UI element at specific coordinates"""
        if not self.is_initialized:
            return None
            
        try:
            # Use Windows UI Automation to get element at point
            element = self.desktop.from_point(x, y)
            
            if element:
                return self._create_ui_element(element)
            
        except Exception as e:
            logger.debug(f"Could not get element at point ({x}, {y}): {e}")
        
        return None

    def find_element(self, strategy: LocatorStrategy, value: str, parent_window_title: Optional[str] = None) -> Optional[UIElement]:
        """Find element using specified strategy"""
        if not self.is_initialized:
            return None
            
        try:
            # Get parent window if specified
            parent = self.desktop
            if parent_window_title:
                try:
                    parent = self.desktop.window(title=parent_window_title)
                except ElementNotFoundError:
                    logger.warning(f"Parent window not found: {parent_window_title}")
                    return None
            
            element = None
            
            if strategy == LocatorStrategy.AUTOMATION_ID:
                element = parent.child_window(auto_id=value)
            elif strategy == LocatorStrategy.NAME:
                element = parent.child_window(title=value)
            elif strategy == LocatorStrategy.CLASS_NAME:
                element = parent.child_window(class_name=value)
            elif strategy == LocatorStrategy.CONTROL_TYPE:
                element = parent.child_window(control_type=value)
            
            if element:
                return self._create_ui_element(element)
                
        except ElementNotFoundError:
            logger.debug(f"Element not found with strategy {strategy.value}: {value}")
        except Exception as e:
            logger.error(f"Error finding element: {e}")
        
        return None

    def find_elements(self, strategy: LocatorStrategy, value: str, parent_window_title: Optional[str] = None) -> List[UIElement]:
        """Find multiple elements using specified strategy"""
        if not self.is_initialized:
            return []
            
        elements = []
        try:
            # Get parent window if specified
            parent = self.desktop
            if parent_window_title:
                try:
                    parent = self.desktop.window(title=parent_window_title)
                except ElementNotFoundError:
                    logger.warning(f"Parent window not found: {parent_window_title}")
                    return []
            
            found_elements = []
            
            if strategy == LocatorStrategy.AUTOMATION_ID:
                found_elements = parent.child_window(auto_id=value, found_index=None)
            elif strategy == LocatorStrategy.NAME:
                found_elements = parent.child_window(title=value, found_index=None)
            elif strategy == LocatorStrategy.CLASS_NAME:
                found_elements = parent.child_window(class_name=value, found_index=None)
            elif strategy == LocatorStrategy.CONTROL_TYPE:
                found_elements = parent.child_window(control_type=value, found_index=None)
            
            # Convert to UIElement list
            if not isinstance(found_elements, list):
                found_elements = [found_elements] if found_elements else []
            
            for element in found_elements:
                ui_element = self._create_ui_element(element)
                if ui_element:
                    elements.append(ui_element)
                    
        except Exception as e:
            logger.error(f"Error finding elements: {e}")
        
        return elements

    def get_window_elements(self, window_title: str) -> List[UIElement]:
        """Get all elements in a specific window"""
        if not self.is_initialized:
            return []
            
        elements = []
        try:
            window = self.desktop.window(title=window_title)
            descendants = window.descendants()
            
            for element in descendants:
                ui_element = self._create_ui_element(element)
                if ui_element:
                    elements.append(ui_element)
                    
        except ElementNotFoundError:
            logger.warning(f"Window not found: {window_title}")
        except Exception as e:
            logger.error(f"Error getting window elements: {e}")
        
        return elements

    def get_element_properties(self, element) -> Dict[str, Any]:
        """Get all properties of a UI element"""
        properties = {}
        
        try:
            # Basic properties
            if hasattr(element, 'automation_id'):
                properties['automation_id'] = element.automation_id()
            if hasattr(element, 'window_text'):
                properties['name'] = element.window_text()
            if hasattr(element, 'class_name'):
                properties['class_name'] = element.class_name()
            if hasattr(element, 'control_type'):
                properties['control_type'] = element.control_type()
            
            # Rectangle/bounds
            if hasattr(element, 'rectangle'):
                rect = element.rectangle()
                properties['bounding_rect'] = {
                    'x': rect.left,
                    'y': rect.top,
                    'width': rect.width(),
                    'height': rect.height()
                }
            
            # Additional UIA properties
            if isinstance(element, UIAWrapper):
                try:
                    properties['is_enabled'] = element.is_enabled()
                    properties['is_visible'] = element.is_visible()
                    properties['is_keyboard_focusable'] = element.is_keyboard_focusable()
                    properties['has_keyboard_focus'] = element.has_keyboard_focus()
                    properties['is_control_element'] = element.is_control_element()
                    properties['is_content_element'] = element.is_content_element()
                except Exception as e:
                    logger.debug(f"Could not get UIA properties: {e}")
            
            # Control patterns
            patterns = self._get_control_patterns(element)
            if patterns:
                properties['patterns'] = patterns
                
        except Exception as e:
            logger.debug(f"Error getting element properties: {e}")
        
        return properties

    def _create_ui_element(self, element) -> Optional[UIElement]:
        """Create UIElement from pywinauto element"""
        if not element:
            return None
            
        try:
            ui_element = UIElement()
            
            # Get automation ID
            try:
                if hasattr(element, 'automation_id'):
                    ui_element.automation_id = element.automation_id()
            except:
                pass
            
            # Get name/title
            try:
                if hasattr(element, 'window_text'):
                    name = element.window_text()
                    if name and name.strip():
                        ui_element.name = name.strip()
            except:
                pass
            
            # Get class name
            try:
                if hasattr(element, 'class_name'):
                    class_name = element.class_name()
                    if class_name and class_name.strip():
                        ui_element.class_name = class_name.strip()
            except:
                pass
            
            # Get control type
            try:
                if hasattr(element, 'control_type'):
                    control_type = element.control_type()
                    if control_type:
                        ui_element.control_type = control_type
            except:
                pass
            
            # Get bounding rectangle
            try:
                if hasattr(element, 'rectangle'):
                    rect = element.rectangle()
                    ui_element.bounding_rect = {
                        'x': rect.left,
                        'y': rect.top,
                        'width': rect.width(),
                        'height': rect.height()
                    }
            except:
                pass
            
            # Get additional properties
            ui_element.properties = self.get_element_properties(element)
            
            return ui_element
            
        except Exception as e:
            logger.debug(f"Error creating UIElement: {e}")
            return None

    def _get_control_patterns(self, element) -> List[str]:
        """Get available control patterns for element"""
        patterns = []
        
        if not isinstance(element, UIAWrapper):
            return patterns
            
        try:
            # Check common control patterns
            pattern_checks = [
                ('Invoke', 'invoke_pattern'),
                ('Selection', 'selection_pattern'),
                ('Value', 'value_pattern'),
                ('Text', 'text_pattern'),
                ('Toggle', 'toggle_pattern'),
                ('Scroll', 'scroll_pattern'),
                ('Window', 'window_pattern'),
                ('Transform', 'transform_pattern'),
                ('Grid', 'grid_pattern'),
                ('Table', 'table_pattern'),
            ]
            
            for pattern_name, pattern_attr in pattern_checks:
                try:
                    if hasattr(element, pattern_attr):
                        pattern = getattr(element, pattern_attr)()
                        if pattern:
                            patterns.append(pattern_name)
                except:
                    pass
                    
        except Exception as e:
            logger.debug(f"Error getting control patterns: {e}")
        
        return patterns

    def get_element_locators(self, element) -> List[Dict[str, str]]:
        """Get possible locators for an element"""
        locators = []
        
        try:
            ui_element = self._create_ui_element(element)
            if not ui_element:
                return locators
            
            # Automation ID locator (highest priority)
            if ui_element.automation_id:
                locators.append({
                    'strategy': LocatorStrategy.AUTOMATION_ID.value,
                    'value': ui_element.automation_id,
                    'confidence': 0.9
                })
            
            # Name locator
            if ui_element.name:
                locators.append({
                    'strategy': LocatorStrategy.NAME.value,
                    'value': ui_element.name,
                    'confidence': 0.8
                })
            
            # Class name locator
            if ui_element.class_name:
                locators.append({
                    'strategy': LocatorStrategy.CLASS_NAME.value,
                    'value': ui_element.class_name,
                    'confidence': 0.7
                })
            
            # Control type locator
            if ui_element.control_type:
                locators.append({
                    'strategy': LocatorStrategy.CONTROL_TYPE.value,
                    'value': ui_element.control_type,
                    'confidence': 0.6
                })
            
            # Coordinate locator (fallback)
            if ui_element.bounding_rect:
                center_x = ui_element.bounding_rect['x'] + ui_element.bounding_rect['width'] // 2
                center_y = ui_element.bounding_rect['y'] + ui_element.bounding_rect['height'] // 2
                locators.append({
                    'strategy': LocatorStrategy.COORDINATE.value,
                    'value': f"{center_x},{center_y}",
                    'confidence': 0.3
                })
            
        except Exception as e:
            logger.error(f"Error getting element locators: {e}")
        
        return locators

    def validate_element(self, element) -> bool:
        """Validate that element still exists and is accessible"""
        try:
            if not element:
                return False
                
            # Try to access basic properties
            element.automation_id()
            element.window_text()
            
            return True
            
        except:
            return False 