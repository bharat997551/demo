"""
Structured logging configuration using structlog
"""

import logging
import sys
import json
import time
import uuid
from typing import Any, Dict, Optional, List
from datetime import datetime
from functools import wraps

import structlog
from structlog.processors import JSONRenderer, TimeStamper, add_log_level
from structlog.stdlib import BoundLogger, LoggerFactory


# Log levels
TRACE = 5
DEBUG = logging.DEBUG
INFO = logging.INFO
WARNING = logging.WARNING
ERROR = logging.ERROR
CRITICAL = logging.CRITICAL

# Add TRACE level
logging.addLevelName(TRACE, "TRACE")


class ObservabilityConfig:
    """Configuration for observability features"""
    
    def __init__(
        self,
        log_level: str = "INFO",
        log_format: str = "json",  # json or console
        enable_telemetry: bool = False,
        enable_metrics: bool = True,
        correlation_id: Optional[str] = None,
        redact_fields: Optional[List[str]] = None
    ):
        self.log_level = log_level
        self.log_format = log_format
        self.enable_telemetry = enable_telemetry
        self.enable_metrics = enable_metrics
        self.correlation_id = correlation_id or str(uuid.uuid4())
        self.redact_fields = redact_fields or [
            "password", "token", "key", "secret", "ssn", 
            "credit_card", "api_key", "authorization"
        ]


def setup_logging(config: ObservabilityConfig) -> BoundLogger:
    """Setup structured logging with structlog"""
    
    # Configure Python stdlib logging
    logging.basicConfig(
        format="%(message)s",
        stream=sys.stdout,
        level=getattr(logging, config.log_level.upper())
    )
    
    # Processors for structlog
    processors = [
        structlog.stdlib.filter_by_level,
        structlog.stdlib.add_logger_name,
        add_log_level,
        structlog.stdlib.PositionalArgumentsFormatter(),
        TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        add_context_processor,
        redact_sensitive_data(config.redact_fields),
    ]
    
    # Add appropriate renderer based on format
    if config.log_format == "json":
        processors.append(JSONRenderer())
    else:
        processors.append(structlog.dev.ConsoleRenderer())
    
    # Configure structlog
    structlog.configure(
        processors=processors,
        context_class=dict,
        logger_factory=LoggerFactory(),
        cache_logger_on_first_use=True,
    )
    
    # Create logger with initial context
    logger = structlog.get_logger()
    logger = logger.bind(
        correlation_id=config.correlation_id,
        environment=os.environ.get("ENVIRONMENT", "production"),
        service="engine-desktop",
        hostname=socket.gethostname(),
        pid=os.getpid()
    )
    
    return logger


def add_context_processor(logger: Any, method_name: str, event_dict: Dict[str, Any]) -> Dict[str, Any]:
    """Add additional context to all log entries"""
    
    # Add timestamp if not present
    if "timestamp" not in event_dict:
        event_dict["timestamp"] = datetime.utcnow().isoformat()
    
    # Add thread info
    event_dict["thread"] = threading.current_thread().name
    
    # Add memory usage
    process = psutil.Process()
    event_dict["memory_mb"] = process.memory_info().rss / 1024 / 1024
    
    return event_dict


def redact_sensitive_data(redact_fields: List[str]):
    """Processor to redact sensitive data from logs"""
    
    def processor(logger: Any, method_name: str, event_dict: Dict[str, Any]) -> Dict[str, Any]:
        def redact_value(obj: Any, depth: int = 0) -> Any:
            if depth > 10:  # Prevent infinite recursion
                return obj
                
            if isinstance(obj, dict):
                return {
                    k: "[REDACTED]" if any(field in k.lower() for field in redact_fields) else redact_value(v, depth + 1)
                    for k, v in obj.items()
                }
            elif isinstance(obj, list):
                return [redact_value(item, depth + 1) for item in obj]
            elif isinstance(obj, str):
                # Redact patterns like API keys, tokens
                if any(field in obj.lower() for field in redact_fields):
                    return "[REDACTED]"
            return obj
        
        event_dict = redact_value(event_dict)
        return event_dict
    
    return processor


class ContextLogger:
    """Logger with context management"""
    
    def __init__(self, logger: BoundLogger, context: Optional[Dict[str, Any]] = None):
        self.logger = logger
        self.context = context or {}
    
    def bind(self, **kwargs) -> "ContextLogger":
        """Create a new logger with additional context"""
        new_context = {**self.context, **kwargs}
        new_logger = self.logger.bind(**kwargs)
        return ContextLogger(new_logger, new_context)
    
    def trace(self, message: str, **kwargs):
        """Log at TRACE level"""
        self.logger.log(TRACE, message, **kwargs)
    
    def debug(self, message: str, **kwargs):
        """Log at DEBUG level"""
        self.logger.debug(message, **kwargs)
    
    def info(self, message: str, **kwargs):
        """Log at INFO level"""
        self.logger.info(message, **kwargs)
    
    def warning(self, message: str, **kwargs):
        """Log at WARNING level"""
        self.logger.warning(message, **kwargs)
    
    def error(self, message: str, exc_info: bool = False, **kwargs):
        """Log at ERROR level"""
        self.logger.error(message, exc_info=exc_info, **kwargs)
    
    def critical(self, message: str, exc_info: bool = False, **kwargs):
        """Log at CRITICAL level"""
        self.logger.critical(message, exc_info=exc_info, **kwargs)
    
    def log_performance(self, operation: str, duration: float, **kwargs):
        """Log performance metrics"""
        self.info(
            "Performance metric",
            operation=operation,
            duration_ms=duration,
            performance=True,
            **kwargs
        )
    
    def log_step_execution(self, step_name: str, status: str, duration: float, **kwargs):
        """Log test step execution"""
        level = "error" if status == "failed" else "info"
        getattr(self, level)(
            "Step executed",
            step_name=step_name,
            status=status,
            duration_ms=duration,
            step_execution=True,
            **kwargs
        )
    
    def log_window_action(self, action: str, window_title: str, success: bool, **kwargs):
        """Log window automation actions"""
        level = "info" if success else "warning"
        getattr(self, level)(
            "Window action",
            action=action,
            window_title=window_title,
            success=success,
            window_action=True,
            **kwargs
        )


def get_logger(name: Optional[str] = None, **context) -> ContextLogger:
    """Get a logger instance with optional context"""
    logger = structlog.get_logger(name)
    if context:
        logger = logger.bind(**context)
    return ContextLogger(logger, context)


def log_execution_time(logger: Optional[ContextLogger] = None):
    """Decorator to log function execution time"""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            nonlocal logger
            if logger is None:
                logger = get_logger(func.__module__)
            
            start_time = time.time()
            
            try:
                result = func(*args, **kwargs)
                duration = (time.time() - start_time) * 1000
                logger.log_performance(
                    f"{func.__name__}",
                    duration,
                    function=func.__name__,
                    module=func.__module__
                )
                return result
            except Exception as e:
                duration = (time.time() - start_time) * 1000
                logger.error(
                    f"Function {func.__name__} failed",
                    exc_info=True,
                    function=func.__name__,
                    module=func.__module__,
                    duration_ms=duration
                )
                raise
        
        return wrapper
    return decorator


# Import required modules
import os
import socket
import threading
import psutil


# Global logger instance
_global_logger: Optional[ContextLogger] = None


def initialize_logging(config: ObservabilityConfig) -> ContextLogger:
    """Initialize global logging configuration"""
    global _global_logger
    base_logger = setup_logging(config)
    _global_logger = ContextLogger(base_logger)
    return _global_logger


def get_global_logger() -> ContextLogger:
    """Get the global logger instance"""
    global _global_logger
    if _global_logger is None:
        _global_logger = initialize_logging(ObservabilityConfig())
    return _global_logger 