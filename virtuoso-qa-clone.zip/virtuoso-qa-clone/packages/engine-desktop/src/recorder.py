"""
Desktop Recorder - Captures system-wide mouse and keyboard events
Uses pywin32 hooks to capture raw events and pywinauto to resolve UI elements
"""
import asyncio
import logging
import threading
import time
import ctypes
from ctypes import wintypes
from datetime import datetime
from typing import Dict, List, Optional, Callable, Any
from uuid import uuid4

import pywinauto
from pywinauto import Desktop
from pywinauto.findwindows import ElementNotFoundError
import win32api
import win32con
import win32gui
import win32process
import psutil

from .types import (
    RecordedEvent, RecordingSession, EventType, UIElement, 
    DesktopStep, RecordingStatus, LocatorStrategy
)
from .element_resolver import ElementResolver

logger = logging.getLogger(__name__)

# Windows constants
WM_KEYDOWN = 0x0100
WM_KEYUP = 0x0101
WM_LBUTTONDOWN = 0x0201
WM_LBUTTONUP = 0x0202
WM_RBUTTONDOWN = 0x0204
WM_RBUTTONUP = 0x0205
WM_MOUSEMOVE = 0x0200

WH_MOUSE_LL = 14
WH_KEYBOARD_LL = 13

HC_ACTION = 0

class POINT(ctypes.Structure):
    _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]

class MSLLHOOKSTRUCT(ctypes.Structure):
    _fields_ = [
        ("pt", POINT),
        ("mouseData", wintypes.DWORD),
        ("flags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ctypes.POINTER(ctypes.c_ulong))
    ]

class KBDLLHOOKSTRUCT(ctypes.Structure):
    _fields_ = [
        ("vkCode", wintypes.DWORD),
        ("scanCode", wintypes.DWORD),
        ("flags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ctypes.POINTER(ctypes.c_ulong))
    ]

class DesktopRecorder:
    """System-wide desktop interaction recorder"""
    
    def __init__(self):
        self.element_resolver = ElementResolver()
        self.active_sessions: Dict[str, RecordingSession] = {}
        self.event_callbacks: Dict[str, Callable] = {}
        
        # Hook handles
        self.mouse_hook = None
        self.keyboard_hook = None
        self.hook_thread = None
        self.stop_event = threading.Event()
        
        # State tracking
        self.last_mouse_move_time = 0
        self.last_click_time = 0
        self.mouse_down_time = 0
        self.mouse_down_pos = None
        self.active_window_cache = {}
        
        self.is_initialized = False

    async def initialize(self):
        """Initialize the recorder"""
        try:
            logger.info("Initializing Desktop Recorder")
            await self.element_resolver.initialize()
            self.is_initialized = True
            logger.info("Desktop Recorder initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize Desktop Recorder: {e}")
            raise

    async def cleanup(self):
        """Cleanup recorder resources"""
        try:
            # Stop all recording sessions
            for session_id in list(self.active_sessions.keys()):
                await self.stop_recording(session_id)
            
            await self.element_resolver.cleanup()
            self.is_initialized = False
            logger.info("Desktop Recorder cleanup completed")
        except Exception as e:
            logger.error(f"Error during recorder cleanup: {e}")

    async def start_recording(self, session: RecordingSession):
        """Start a new recording session"""
        if not self.is_initialized:
            raise RuntimeError("Recorder not initialized")
        
        logger.info(f"Starting recording session: {session.id}")
        
        # Store session
        self.active_sessions[session.id] = session
        session.status = RecordingStatus.ACTIVE
        
        # Start hooks if this is the first active session
        if len(self.active_sessions) == 1:
            await self._start_hooks()

    async def stop_recording(self, session_id: str):
        """Stop a recording session"""
        if session_id not in self.active_sessions:
            raise ValueError(f"Session {session_id} not found")
        
        logger.info(f"Stopping recording session: {session_id}")
        
        session = self.active_sessions[session_id]
        session.status = RecordingStatus.STOPPED
        session.end_time = datetime.now()
        
        # Remove session
        self.active_sessions.pop(session_id, None)
        self.event_callbacks.pop(session_id, None)
        
        # Stop hooks if no more active sessions
        if not self.active_sessions:
            await self._stop_hooks()

    def set_event_callback(self, session_id: str, callback: Callable):
        """Set callback for recording events"""
        self.event_callbacks[session_id] = callback

    async def get_health(self) -> Dict[str, Any]:
        """Get recorder health status"""
        return {
            "status": "healthy" if self.is_initialized else "unhealthy",
            "active_sessions": len(self.active_sessions),
            "hooks_active": self.mouse_hook is not None and self.keyboard_hook is not None
        }

    async def _start_hooks(self):
        """Start system-wide hooks"""
        if self.hook_thread and self.hook_thread.is_alive():
            return
        
        logger.info("Starting system hooks")
        self.stop_event.clear()
        
        # Start hook thread
        self.hook_thread = threading.Thread(target=self._hook_thread_func, daemon=True)
        self.hook_thread.start()

    async def _stop_hooks(self):
        """Stop system-wide hooks"""
        if not self.hook_thread or not self.hook_thread.is_alive():
            return
        
        logger.info("Stopping system hooks")
        self.stop_event.set()
        
        # Unhook
        if self.mouse_hook:
            ctypes.windll.user32.UnhookWindowsHookExW(self.mouse_hook)
            self.mouse_hook = None
        
        if self.keyboard_hook:
            ctypes.windll.user32.UnhookWindowsHookExW(self.keyboard_hook)
            self.keyboard_hook = None

    def _hook_thread_func(self):
        """Thread function for running hooks"""
        try:
            # Set up hooks
            self._install_hooks()
            
            # Message loop
            msg = wintypes.MSG()
            while not self.stop_event.is_set():
                bRet = ctypes.windll.user32.GetMessageW(ctypes.byref(msg), None, 0, 0)
                if bRet == 0 or bRet == -1:
                    break
                ctypes.windll.user32.TranslateMessage(ctypes.byref(msg))
                ctypes.windll.user32.DispatchMessageW(ctypes.byref(msg))
                
        except Exception as e:
            logger.error(f"Hook thread error: {e}")
        finally:
            # Clean up hooks
            if self.mouse_hook:
                ctypes.windll.user32.UnhookWindowsHookExW(self.mouse_hook)
                self.mouse_hook = None
            if self.keyboard_hook:
                ctypes.windll.user32.UnhookWindowsHookExW(self.keyboard_hook)
                self.keyboard_hook = None

    def _install_hooks(self):
        """Install Windows hooks"""
        # Mouse hook
        mouse_proc = ctypes.WINFUNCTYPE(ctypes.c_int, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM)(self._mouse_proc)
        self.mouse_hook = ctypes.windll.user32.SetWindowsHookExW(
            WH_MOUSE_LL, mouse_proc, ctypes.windll.kernel32.GetModuleHandleW(None), 0
        )
        
        if not self.mouse_hook:
            raise RuntimeError("Failed to install mouse hook")
        
        # Keyboard hook
        keyboard_proc = ctypes.WINFUNCTYPE(ctypes.c_int, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM)(self._keyboard_proc)
        self.keyboard_hook = ctypes.windll.user32.SetWindowsHookExW(
            WH_KEYBOARD_LL, keyboard_proc, ctypes.windll.kernel32.GetModuleHandleW(None), 0
        )
        
        if not self.keyboard_hook:
            raise RuntimeError("Failed to install keyboard hook")
        
        logger.info("Hooks installed successfully")

    def _mouse_proc(self, nCode: int, wParam: int, lParam: int) -> int:
        """Mouse hook procedure"""
        if nCode >= HC_ACTION and self.active_sessions:
            try:
                # Parse mouse data
                mouse_struct = ctypes.cast(lParam, ctypes.POINTER(MSLLHOOKSTRUCT)).contents
                x, y = mouse_struct.pt.x, mouse_struct.pt.y
                
                current_time = time.time()
                
                if wParam == WM_LBUTTONDOWN:
                    self.mouse_down_time = current_time
                    self.mouse_down_pos = (x, y)
                    
                elif wParam == WM_LBUTTONUP:
                    # Check if this is a drag or click
                    if (self.mouse_down_pos and 
                        abs(x - self.mouse_down_pos[0]) > 5 or abs(y - self.mouse_down_pos[1]) > 5):
                        # This was a drag
                        self._handle_drag_event(self.mouse_down_pos[0], self.mouse_down_pos[1], x, y)
                    else:
                        # This was a click
                        self._handle_click_event(x, y, "left")
                    
                elif wParam == WM_RBUTTONUP:
                    self._handle_click_event(x, y, "right")
                    
                elif wParam == WM_MOUSEMOVE:
                    # Only record mouse moves if enabled and not too frequent
                    if current_time - self.last_mouse_move_time > 0.1:  # Max 10 moves per second
                        self._handle_mouse_move_event(x, y)
                        self.last_mouse_move_time = current_time
                
            except Exception as e:
                logger.error(f"Error in mouse proc: {e}")
        
        return ctypes.windll.user32.CallNextHookEx(self.mouse_hook, nCode, wParam, lParam)

    def _keyboard_proc(self, nCode: int, wParam: int, lParam: int) -> int:
        """Keyboard hook procedure"""
        if nCode >= HC_ACTION and self.active_sessions:
            try:
                # Parse keyboard data
                kb_struct = ctypes.cast(lParam, ctypes.POINTER(KBDLLHOOKSTRUCT)).contents
                
                if wParam == WM_KEYDOWN:
                    vk_code = kb_struct.vkCode
                    self._handle_key_press_event(vk_code)
                
            except Exception as e:
                logger.error(f"Error in keyboard proc: {e}")
        
        return ctypes.windll.user32.CallNextHookEx(self.keyboard_hook, nCode, wParam, lParam)

    def _handle_click_event(self, x: int, y: int, button: str):
        """Handle mouse click event"""
        try:
            # Get current window and element
            window_info = self._get_window_at_point(x, y)
            element_info = self._get_element_at_point(x, y)
            
            # Create recorded event
            event = RecordedEvent(
                id=str(uuid4()),
                timestamp=datetime.now(),
                event_type=EventType.MOUSE_CLICK,
                position={"x": x, "y": y},
                target_element=element_info,
                window_title=window_info.get("title"),
                application=window_info.get("process_name")
            )
            
            # Generate DSL step
            step = self._generate_click_step(event, button)
            event.generated_step = step
            
            # Broadcast to all active sessions
            self._broadcast_event(event)
            
        except Exception as e:
            logger.error(f"Error handling click event: {e}")

    def _handle_drag_event(self, start_x: int, start_y: int, end_x: int, end_y: int):
        """Handle mouse drag event"""
        try:
            # Get element at start position
            element_info = self._get_element_at_point(start_x, start_y)
            window_info = self._get_window_at_point(start_x, start_y)
            
            event = RecordedEvent(
                id=str(uuid4()),
                timestamp=datetime.now(),
                event_type=EventType.MOUSE_DRAG,
                position={"start_x": start_x, "start_y": start_y, "end_x": end_x, "end_y": end_y},
                target_element=element_info,
                window_title=window_info.get("title"),
                application=window_info.get("process_name")
            )
            
            # Generate DSL step
            step = self._generate_drag_step(event)
            event.generated_step = step
            
            self._broadcast_event(event)
            
        except Exception as e:
            logger.error(f"Error handling drag event: {e}")

    def _handle_key_press_event(self, vk_code: int):
        """Handle key press event"""
        try:
            # Get key name
            key_name = self._get_key_name(vk_code)
            
            # Get current window
            hwnd = win32gui.GetForegroundWindow()
            window_info = self._get_window_info(hwnd)
            
            event = RecordedEvent(
                id=str(uuid4()),
                timestamp=datetime.now(),
                event_type=EventType.KEY_PRESS,
                key_code=vk_code,
                key_name=key_name,
                window_title=window_info.get("title"),
                application=window_info.get("process_name")
            )
            
            # Generate DSL step
            step = self._generate_key_step(event)
            event.generated_step = step
            
            self._broadcast_event(event)
            
        except Exception as e:
            logger.error(f"Error handling key press event: {e}")

    def _handle_mouse_move_event(self, x: int, y: int):
        """Handle mouse move event"""
        # Only record for sessions that have mouse moves enabled
        active_sessions = [s for s in self.active_sessions.values() 
                          if s.config.include_mouse_moves]
        
        if not active_sessions:
            return
        
        try:
            event = RecordedEvent(
                id=str(uuid4()),
                timestamp=datetime.now(),
                event_type=EventType.MOUSE_MOVE,
                position={"x": x, "y": y}
            )
            
            self._broadcast_event(event)
            
        except Exception as e:
            logger.error(f"Error handling mouse move event: {e}")

    def _get_window_at_point(self, x: int, y: int) -> Dict[str, Any]:
        """Get window information at given point"""
        try:
            hwnd = win32gui.WindowFromPoint((x, y))
            return self._get_window_info(hwnd)
        except Exception as e:
            logger.error(f"Error getting window at point: {e}")
            return {}

    def _get_window_info(self, hwnd: int) -> Dict[str, Any]:
        """Get window information"""
        try:
            title = win32gui.GetWindowText(hwnd)
            _, process_id = win32process.GetWindowThreadProcessId(hwnd)
            
            try:
                process = psutil.Process(process_id)
                process_name = process.name()
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                process_name = "unknown"
            
            return {
                "hwnd": hwnd,
                "title": title,
                "process_id": process_id,
                "process_name": process_name
            }
        except Exception as e:
            logger.error(f"Error getting window info: {e}")
            return {}

    def _get_element_at_point(self, x: int, y: int) -> Optional[UIElement]:
        """Get UI element at given point using pywinauto"""
        try:
            return self.element_resolver.get_element_at_point(x, y)
        except Exception as e:
            logger.error(f"Error getting element at point: {e}")
            return None

    def _generate_click_step(self, event: RecordedEvent, button: str) -> DesktopStep:
        """Generate DSL step for click event"""
        target = {}
        
        if event.target_element:
            if event.target_element.automation_id:
                target["automation_id"] = event.target_element.automation_id
            elif event.target_element.name:
                target["name"] = event.target_element.name
            elif event.target_element.class_name:
                target["class_name"] = event.target_element.class_name
        
        # Fallback to coordinates
        if not target and event.position:
            target["coordinate"] = {"x": event.position["x"], "y": event.position["y"]}
        
        action = "desktop.click" if button == "left" else "desktop.rightClick"
        
        return DesktopStep(
            id=str(uuid4()),
            name=f"Click {button} button",
            kind=action,
            target=target,
            options={"button": button}
        )

    def _generate_drag_step(self, event: RecordedEvent) -> DesktopStep:
        """Generate DSL step for drag event"""
        target = {}
        
        if event.target_element:
            if event.target_element.automation_id:
                target["automation_id"] = event.target_element.automation_id
            elif event.target_element.name:
                target["name"] = event.target_element.name
        
        return DesktopStep(
            id=str(uuid4()),
            name="Drag element",
            kind="desktop.drag",
            target=target,
            options={
                "from": {"x": event.position["start_x"], "y": event.position["start_y"]},
                "to": {"x": event.position["end_x"], "y": event.position["end_y"]}
            }
        )

    def _generate_key_step(self, event: RecordedEvent) -> DesktopStep:
        """Generate DSL step for key press event"""
        if event.key_name and len(event.key_name) == 1 and event.key_name.isalnum():
            # Regular character typing
            return DesktopStep(
                id=str(uuid4()),
                name=f"Type '{event.key_name}'",
                kind="desktop.type",
                value=event.key_name
            )
        else:
            # Special key press
            return DesktopStep(
                id=str(uuid4()),
                name=f"Press {event.key_name}",
                kind="desktop.keyPress",
                options={"key": event.key_name or str(event.key_code)}
            )

    def _get_key_name(self, vk_code: int) -> str:
        """Convert virtual key code to key name"""
        key_names = {
            8: "Backspace", 9: "Tab", 13: "Enter", 16: "Shift", 17: "Ctrl", 18: "Alt",
            20: "CapsLock", 27: "Escape", 32: "Space", 33: "PageUp", 34: "PageDown",
            35: "End", 36: "Home", 37: "Left", 38: "Up", 39: "Right", 40: "Down",
            45: "Insert", 46: "Delete", 91: "Win", 112: "F1", 113: "F2", 114: "F3",
            115: "F4", 116: "F5", 117: "F6", 118: "F7", 119: "F8", 120: "F9",
            121: "F10", 122: "F11", 123: "F12"
        }
        
        if vk_code in key_names:
            return key_names[vk_code]
        elif 65 <= vk_code <= 90:  # A-Z
            return chr(vk_code)
        elif 48 <= vk_code <= 57:  # 0-9
            return chr(vk_code)
        else:
            return f"Key{vk_code}"

    def _broadcast_event(self, event: RecordedEvent):
        """Broadcast event to all active sessions"""
        for session_id, session in self.active_sessions.items():
            try:
                # Check if event should be included based on config
                if self._should_include_event(event, session.config):
                    # Add event to session
                    session.events.append(event)
                    
                    # Call event callback if set
                    if session_id in self.event_callbacks:
                        callback = self.event_callbacks[session_id]
                        # Run callback in asyncio event loop
                        asyncio.create_task(callback(event))
                        
            except Exception as e:
                logger.error(f"Error broadcasting event to session {session_id}: {e}")

    def _should_include_event(self, event: RecordedEvent, config) -> bool:
        """Check if event should be included based on recording config"""
        # Check application filters
        if config.target_applications and event.application:
            if event.application not in config.target_applications:
                return False
        
        if config.ignore_applications and event.application:
            if event.application in config.ignore_applications:
                return False
        
        # Check event type filters
        if event.event_type == EventType.MOUSE_MOVE and not config.include_mouse_moves:
            return False
        
        if event.event_type == EventType.KEY_PRESS and not config.include_key_presses:
            return False
        
        # Check max events limit
        if len(self.active_sessions) > 0:
            session = next(iter(self.active_sessions.values()))
            if len(session.events) >= config.max_events:
                return False
        
        return True 