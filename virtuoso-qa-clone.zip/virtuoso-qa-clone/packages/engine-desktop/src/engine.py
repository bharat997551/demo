"""
Desktop Engine - Executes DSL desktop.* steps using pywinauto
"""
import asyncio
import logging
import os
import time
from datetime import datetime
from typing import Dict, Any, Optional, List
import win32gui
import win32api
import win32con
from PIL import Image, ImageGrab
import pywinauto
from pywinauto import Desktop, Application
from pywinauto.findwindows import ElementNotFoundError
from pywinauto.timings import TimeoutError

from .types import (
    DesktopStep, StepContext, StepResult, StepStatus, 
    DesktopAction, LocatorStrategy, EngineConfig
)
from .element_resolver import ElementResolver

logger = logging.getLogger(__name__)

class DesktopEngine:
    """Desktop automation engine using pywinauto"""
    
    def __init__(self, config: Optional[EngineConfig] = None):
        self.config = config or EngineConfig()
        self.element_resolver = ElementResolver()
        self.desktop = None
        self.is_initialized = False

    async def initialize(self):
        """Initialize the desktop engine"""
        try:
            logger.info("Initializing Desktop Engine")
            
            # Initialize element resolver
            await self.element_resolver.initialize()
            
            # Initialize desktop
            self.desktop = Desktop(backend="uia")
            
            # Ensure artifacts directory exists
            os.makedirs(self.config.artifacts_dir, exist_ok=True)
            
            self.is_initialized = True
            logger.info("Desktop Engine initialized successfully")
            
        except Exception as e:
            logger.error(f"Failed to initialize Desktop Engine: {e}")
            raise

    async def cleanup(self):
        """Cleanup engine resources"""
        try:
            if self.element_resolver:
                await self.element_resolver.cleanup()
            
            self.is_initialized = False
            logger.info("Desktop Engine cleanup completed")
            
        except Exception as e:
            logger.error(f"Error during engine cleanup: {e}")

    async def run_step(self, step: DesktopStep, context: StepContext) -> StepResult:
        """Execute a desktop automation step"""
        if not self.is_initialized:
            raise RuntimeError("Engine not initialized")
        
        start_time = datetime.now()
        logs = []
        screenshot_path = None
        error = None
        extracted_data = None
        status = StepStatus.RUNNING
        
        try:
            logger.info(f"Executing step {step.id}: {step.kind}")
            logs.append(f"Starting execution of {step.kind}")
            
            # Execute step with retry logic
            for attempt in range(self.config.retry_attempts):
                try:
                    if step.kind == DesktopAction.CLICK:
                        extracted_data = await self._execute_click(step, context)
                    elif step.kind == DesktopAction.DOUBLE_CLICK:
                        extracted_data = await self._execute_double_click(step, context)
                    elif step.kind == DesktopAction.RIGHT_CLICK:
                        extracted_data = await self._execute_right_click(step, context)
                    elif step.kind == DesktopAction.TYPE:
                        extracted_data = await self._execute_type(step, context)
                    elif step.kind == DesktopAction.KEY_PRESS:
                        extracted_data = await self._execute_key_press(step, context)
                    elif step.kind == DesktopAction.KEY_COMBINATION:
                        extracted_data = await self._execute_key_combination(step, context)
                    elif step.kind == DesktopAction.DRAG:
                        extracted_data = await self._execute_drag(step, context)
                    elif step.kind == DesktopAction.SCROLL:
                        extracted_data = await self._execute_scroll(step, context)
                    elif step.kind == DesktopAction.WAIT:
                        extracted_data = await self._execute_wait(step, context)
                    elif step.kind == DesktopAction.SCREENSHOT:
                        extracted_data = await self._execute_screenshot(step, context)
                    elif step.kind == DesktopAction.WINDOW_ACTIVATE:
                        extracted_data = await self._execute_window_activate(step, context)
                    elif step.kind == DesktopAction.WINDOW_CLOSE:
                        extracted_data = await self._execute_window_close(step, context)
                    elif step.kind == DesktopAction.WINDOW_MAXIMIZE:
                        extracted_data = await self._execute_window_maximize(step, context)
                    elif step.kind == DesktopAction.WINDOW_MINIMIZE:
                        extracted_data = await self._execute_window_minimize(step, context)
                    elif step.kind == DesktopAction.GET_TEXT:
                        extracted_data = await self._execute_get_text(step, context)
                    elif step.kind == DesktopAction.GET_ATTRIBUTE:
                        extracted_data = await self._execute_get_attribute(step, context)
                    elif step.kind == DesktopAction.ELEMENT_EXISTS:
                        extracted_data = await self._execute_element_exists(step, context)
                    else:
                        raise ValueError(f"Unsupported step kind: {step.kind}")
                    
                    # Success
                    status = StepStatus.COMPLETED
                    logs.append(f"Step executed successfully on attempt {attempt + 1}")
                    break
                    
                except Exception as e:
                    logs.append(f"Attempt {attempt + 1} failed: {str(e)}")
                    
                    if attempt == self.config.retry_attempts - 1:
                        # Final attempt failed
                        raise
                    else:
                        # Wait before retry
                        await asyncio.sleep(self.config.retry_delay)
                        logs.append(f"Retrying in {self.config.retry_delay} seconds...")
            
            # Take success screenshot if enabled
            if self.config.screenshot_on_success or context.screenshots_enabled:
                screenshot_path = await self.take_screenshot(f"{step.id}_success")
                
        except Exception as e:
            status = StepStatus.FAILED
            error = str(e)
            logs.append(f"Step execution failed: {error}")
            logger.error(f"Step {step.id} failed: {error}")
            
            # Take failure screenshot if enabled
            if self.config.screenshot_on_failure:
                try:
                    screenshot_path = await self.take_screenshot(f"{step.id}_failure")
                except Exception as screenshot_error:
                    logs.append(f"Failed to take failure screenshot: {screenshot_error}")
        
        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds()
        
        return StepResult(
            step_id=step.id,
            status=status,
            start_time=start_time,
            end_time=end_time,
            duration=duration,
            screenshot_path=screenshot_path,
            error=error,
            extracted_data=extracted_data,
            logs=logs
        )

    async def take_screenshot(self, filename: Optional[str] = None) -> str:
        """Take a desktop screenshot"""
        if not filename:
            filename = f"screenshot_{int(time.time())}"
        
        if not filename.endswith('.png'):
            filename += '.png'
        
        screenshot_path = os.path.join(self.config.artifacts_dir, filename)
        
        try:
            # Ensure directory exists
            os.makedirs(os.path.dirname(screenshot_path), exist_ok=True)
            
            # Take screenshot
            screenshot = ImageGrab.grab()
            screenshot.save(screenshot_path, 'PNG')
            
            logger.info(f"Screenshot saved: {screenshot_path}")
            return screenshot_path
            
        except Exception as e:
            logger.error(f"Failed to take screenshot: {e}")
            raise

    async def get_health(self) -> Dict[str, Any]:
        """Get engine health status"""
        return {
            "status": "healthy" if self.is_initialized else "unhealthy",
            "initialized": self.is_initialized,
            "backend": "uia",
            "config": self.config.dict()
        }

    def get_supported_steps(self) -> List[str]:
        """Get list of supported step kinds"""
        return [action.value for action in DesktopAction]

    # Step execution methods
    
    async def _execute_click(self, step: DesktopStep, context: StepContext) -> Any:
        """Execute click step"""
        element = await self._find_element(step, context)
        
        if not element:
            raise ElementNotFoundError(f"Element not found: {step.target}")
        
        # Click the element
        element.click()
        await asyncio.sleep(0.1)  # Brief wait for UI to respond
        
        return {"clicked": True}

    async def _execute_double_click(self, step: DesktopStep, context: StepContext) -> Any:
        """Execute double click step"""
        element = await self._find_element(step, context)
        
        if not element:
            raise ElementNotFoundError(f"Element not found: {step.target}")
        
        # Double click the element
        element.double_click()
        await asyncio.sleep(0.1)
        
        return {"double_clicked": True}

    async def _execute_right_click(self, step: DesktopStep, context: StepContext) -> Any:
        """Execute right click step"""
        element = await self._find_element(step, context)
        
        if not element:
            raise ElementNotFoundError(f"Element not found: {step.target}")
        
        # Right click the element
        element.right_click()
        await asyncio.sleep(0.1)
        
        return {"right_clicked": True}

    async def _execute_type(self, step: DesktopStep, context: StepContext) -> Any:
        """Execute type step"""
        if step.target:
            # Type into specific element
            element = await self._find_element(step, context)
            if not element:
                raise ElementNotFoundError(f"Element not found: {step.target}")
            
            # Clear existing text if specified
            if step.options and step.options.get("clear_first", True):
                try:
                    element.select_all()
                    element.type_keys("{DELETE}")
                except:
                    pass  # Not all elements support select_all
            
            # Type the text
            text = self._interpolate_variables(step.value or "", context.variables)
            element.type_keys(text)
        else:
            # Type into currently focused element
            text = self._interpolate_variables(step.value or "", context.variables)
            pywinauto.keyboard.send_keys(text)
        
        await asyncio.sleep(0.1)
        return {"typed": step.value}

    async def _execute_key_press(self, step: DesktopStep, context: StepContext) -> Any:
        """Execute key press step"""
        key = step.options.get("key", step.value) if step.options else step.value
        
        if not key:
            raise ValueError("Key not specified")
        
        # Convert key to pywinauto format
        key_code = self._convert_key_to_pywinauto(key)
        pywinauto.keyboard.send_keys(key_code)
        
        await asyncio.sleep(0.1)
        return {"key_pressed": key}

    async def _execute_key_combination(self, step: DesktopStep, context: StepContext) -> Any:
        """Execute key combination step"""
        keys = step.options.get("keys", []) if step.options else []
        
        if not keys:
            raise ValueError("Key combination not specified")
        
        # Convert keys to pywinauto format and join with +
        key_codes = [self._convert_key_to_pywinauto(key) for key in keys]
        combination = "+".join(key_codes)
        
        pywinauto.keyboard.send_keys(combination)
        
        await asyncio.sleep(0.1)
        return {"key_combination": keys}

    async def _execute_drag(self, step: DesktopStep, context: StepContext) -> Any:
        """Execute drag step"""
        if step.target:
            # Drag from element
            element = await self._find_element(step, context)
            if not element:
                raise ElementNotFoundError(f"Source element not found: {step.target}")
            
            # Get drag destination
            if step.options:
                to_coords = step.options.get("to")
                if to_coords:
                    element.drag_mouse_input(
                        dst=(to_coords["x"], to_coords["y"]),
                        button="left"
                    )
                else:
                    raise ValueError("Drag destination not specified")
        else:
            # Drag from coordinates
            from_coords = step.options.get("from") if step.options else None
            to_coords = step.options.get("to") if step.options else None
            
            if not from_coords or not to_coords:
                raise ValueError("Drag coordinates not specified")
            
            # Use win32api for coordinate-based drag
            win32api.SetCursorPos((from_coords["x"], from_coords["y"]))
            win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN, 0, 0)
            await asyncio.sleep(0.1)
            win32api.SetCursorPos((to_coords["x"], to_coords["y"]))
            win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP, 0, 0)
        
        await asyncio.sleep(0.2)
        return {"dragged": True}

    async def _execute_scroll(self, step: DesktopStep, context: StepContext) -> Any:
        """Execute scroll step"""
        if step.target:
            element = await self._find_element(step, context)
            if not element:
                raise ElementNotFoundError(f"Element not found: {step.target}")
            
            direction = step.options.get("direction", "down") if step.options else "down"
            amount = step.options.get("amount", 3) if step.options else 3
            
            if direction.lower() == "down":
                element.wheel_mouse_input(wheel_dist=-amount)
            elif direction.lower() == "up":
                element.wheel_mouse_input(wheel_dist=amount)
            else:
                raise ValueError(f"Unsupported scroll direction: {direction}")
        else:
            # Scroll at current cursor position
            direction = step.options.get("direction", "down") if step.options else "down"
            amount = step.options.get("amount", 3) if step.options else 3
            
            if direction.lower() == "down":
                win32api.mouse_event(win32con.MOUSEEVENTF_WHEEL, 0, 0, -120 * amount)
            elif direction.lower() == "up":
                win32api.mouse_event(win32con.MOUSEEVENTF_WHEEL, 0, 0, 120 * amount)
        
        await asyncio.sleep(0.1)
        return {"scrolled": direction}

    async def _execute_wait(self, step: DesktopStep, context: StepContext) -> Any:
        """Execute wait step"""
        duration = step.options.get("duration", 1.0) if step.options else 1.0
        await asyncio.sleep(duration)
        return {"waited": duration}

    async def _execute_screenshot(self, step: DesktopStep, context: StepContext) -> Any:
        """Execute screenshot step"""
        filename = step.options.get("filename") if step.options else None
        screenshot_path = await self.take_screenshot(filename)
        return {"screenshot_path": screenshot_path}

    async def _execute_window_activate(self, step: DesktopStep, context: StepContext) -> Any:
        """Execute window activate step"""
        title = step.options.get("title") if step.options else None
        
        if not title:
            raise ValueError("Window title not specified")
        
        try:
            window = self.desktop.window(title=title)
            window.set_focus()
            await asyncio.sleep(0.2)
            return {"activated": title}
        except ElementNotFoundError:
            raise ElementNotFoundError(f"Window not found: {title}")

    async def _execute_window_close(self, step: DesktopStep, context: StepContext) -> Any:
        """Execute window close step"""
        title = step.options.get("title") if step.options else None
        
        if not title:
            raise ValueError("Window title not specified")
        
        try:
            window = self.desktop.window(title=title)
            window.close()
            await asyncio.sleep(0.2)
            return {"closed": title}
        except ElementNotFoundError:
            raise ElementNotFoundError(f"Window not found: {title}")

    async def _execute_window_maximize(self, step: DesktopStep, context: StepContext) -> Any:
        """Execute window maximize step"""
        title = step.options.get("title") if step.options else None
        
        if not title:
            raise ValueError("Window title not specified")
        
        try:
            window = self.desktop.window(title=title)
            window.maximize()
            await asyncio.sleep(0.2)
            return {"maximized": title}
        except ElementNotFoundError:
            raise ElementNotFoundError(f"Window not found: {title}")

    async def _execute_window_minimize(self, step: DesktopStep, context: StepContext) -> Any:
        """Execute window minimize step"""
        title = step.options.get("title") if step.options else None
        
        if not title:
            raise ValueError("Window title not specified")
        
        try:
            window = self.desktop.window(title=title)
            window.minimize()
            await asyncio.sleep(0.2)
            return {"minimized": title}
        except ElementNotFoundError:
            raise ElementNotFoundError(f"Window not found: {title}")

    async def _execute_get_text(self, step: DesktopStep, context: StepContext) -> Any:
        """Execute get text step"""
        element = await self._find_element(step, context)
        
        if not element:
            raise ElementNotFoundError(f"Element not found: {step.target}")
        
        try:
            text = element.window_text()
            return {"text": text}
        except Exception as e:
            raise Exception(f"Failed to get text: {e}")

    async def _execute_get_attribute(self, step: DesktopStep, context: StepContext) -> Any:
        """Execute get attribute step"""
        element = await self._find_element(step, context)
        
        if not element:
            raise ElementNotFoundError(f"Element not found: {step.target}")
        
        attribute = step.options.get("attribute") if step.options else None
        if not attribute:
            raise ValueError("Attribute not specified")
        
        try:
            if attribute == "automation_id":
                value = element.automation_id()
            elif attribute == "class_name":
                value = element.class_name()
            elif attribute == "control_type":
                value = element.control_type()
            elif attribute == "is_enabled":
                value = element.is_enabled()
            elif attribute == "is_visible":
                value = element.is_visible()
            else:
                # Try to get custom property
                properties = self.element_resolver.get_element_properties(element)
                value = properties.get(attribute)
            
            return {attribute: value}
        except Exception as e:
            raise Exception(f"Failed to get attribute {attribute}: {e}")

    async def _execute_element_exists(self, step: DesktopStep, context: StepContext) -> Any:
        """Execute element exists step"""
        try:
            element = await self._find_element(step, context, raise_on_not_found=False)
            exists = element is not None
            return {"exists": exists}
        except:
            return {"exists": False}

    # Helper methods
    
    async def _find_element(self, step: DesktopStep, context: StepContext, raise_on_not_found: bool = True):
        """Find element using step target information"""
        if not step.target:
            if raise_on_not_found:
                raise ValueError("No target specified")
            return None
        
        target = step.target
        timeout = step.timeout or self.config.default_timeout
        
        # Try different locator strategies
        strategies = [
            ("automation_id", LocatorStrategy.AUTOMATION_ID),
            ("name", LocatorStrategy.NAME),
            ("class_name", LocatorStrategy.CLASS_NAME),
            ("control_type", LocatorStrategy.CONTROL_TYPE),
        ]
        
        for key, strategy in strategies:
            if key in target:
                value = target[key]
                
                # Try with timeout
                start_time = time.time()
                while time.time() - start_time < timeout:
                    try:
                        if strategy == LocatorStrategy.AUTOMATION_ID:
                            element = self.desktop.child_window(auto_id=value)
                        elif strategy == LocatorStrategy.NAME:
                            element = self.desktop.child_window(title=value)
                        elif strategy == LocatorStrategy.CLASS_NAME:
                            element = self.desktop.child_window(class_name=value)
                        elif strategy == LocatorStrategy.CONTROL_TYPE:
                            element = self.desktop.child_window(control_type=value)
                        
                        # Verify element exists and is accessible
                        if element and self.element_resolver.validate_element(element):
                            return element
                            
                    except (ElementNotFoundError, TimeoutError):
                        pass
                    
                    await asyncio.sleep(0.5)
        
        # Try coordinate-based location as fallback
        if "coordinate" in target:
            coords = target["coordinate"]
            x, y = coords["x"], coords["y"]
            
            # Click at coordinates (for coordinate-based targeting)
            return CoordinateElement(x, y)
        
        if raise_on_not_found:
            raise ElementNotFoundError(f"Element not found with target: {target}")
        
        return None

    def _convert_key_to_pywinauto(self, key: str) -> str:
        """Convert key name to pywinauto format"""
        key_mapping = {
            "enter": "{ENTER}",
            "tab": "{TAB}",
            "space": "{SPACE}",
            "escape": "{ESC}",
            "backspace": "{BACKSPACE}",
            "delete": "{DELETE}",
            "home": "{HOME}",
            "end": "{END}",
            "pageup": "{PGUP}",
            "pagedown": "{PGDN}",
            "up": "{UP}",
            "down": "{DOWN}",
            "left": "{LEFT}",
            "right": "{RIGHT}",
            "f1": "{F1}", "f2": "{F2}", "f3": "{F3}", "f4": "{F4}",
            "f5": "{F5}", "f6": "{F6}", "f7": "{F7}", "f8": "{F8}",
            "f9": "{F9}", "f10": "{F10}", "f11": "{F11}", "f12": "{F12}",
            "ctrl": "^", "alt": "%", "shift": "+", "win": "{LWIN}"
        }
        
        return key_mapping.get(key.lower(), key)

    def _interpolate_variables(self, text: str, variables: Dict[str, Any]) -> str:
        """Interpolate variables in text"""
        for var_name, var_value in variables.items():
            placeholder = f"${{{var_name}}}"
            text = text.replace(placeholder, str(var_value))
        return text

class CoordinateElement:
    """Mock element for coordinate-based operations"""
    
    def __init__(self, x: int, y: int):
        self.x = x
        self.y = y
    
    def click(self):
        win32api.SetCursorPos((self.x, self.y))
        win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN, 0, 0)
        win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP, 0, 0)
    
    def double_click(self):
        win32api.SetCursorPos((self.x, self.y))
        win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN, 0, 0)
        win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP, 0, 0)
        win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN, 0, 0)
        win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP, 0, 0)
    
    def right_click(self):
        win32api.SetCursorPos((self.x, self.y))
        win32api.mouse_event(win32con.MOUSEEVENTF_RIGHTDOWN, 0, 0)
        win32api.mouse_event(win32con.MOUSEEVENTF_RIGHTUP, 0, 0) 