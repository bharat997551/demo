"""
Hybrid QA Desktop Engine (Windows)
FastAPI-based desktop automation engine with recording capabilities
"""
import asyncio
import json
import logging
import os
import sys
import threading
import time
from datetime import datetime
from typing import Dict, List, Optional, Any
from uuid import uuid4

import uvicorn
from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import websockets
from websockets.exceptions import ConnectionClosed

from .recorder import DesktopRecorder
from .engine import DesktopEngine
from .types import (
    HealthResponse, RecordingSession, StepRequest, StepResponse,
    RecordingConfig, RecordedEvent, ScreenshotResponse
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# FastAPI app instance
app = FastAPI(
    title="Hybrid QA Desktop Engine",
    description="Windows desktop automation engine with recording capabilities",
    version="1.0.0"
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify exact origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global instances
desktop_engine = DesktopEngine()
desktop_recorder = DesktopRecorder()
recording_sessions: Dict[str, RecordingSession] = {}
websocket_connections: set = set()

class RecordStartRequest(BaseModel):
    config: RecordingConfig

class RecordStopRequest(BaseModel):
    session_id: str

@app.on_event("startup")
async def startup_event():
    """Initialize engine and recorder on startup"""
    try:
        await desktop_engine.initialize()
        await desktop_recorder.initialize()
        logger.info("Desktop engine and recorder initialized successfully")
    except Exception as e:
        logger.error(f"Failed to initialize: {e}")
        raise

@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup on shutdown"""
    try:
        # Stop all active recording sessions
        for session_id in list(recording_sessions.keys()):
            await stop_recording_internal(session_id)
        
        await desktop_engine.cleanup()
        await desktop_recorder.cleanup()
        logger.info("Desktop engine cleanup completed")
    except Exception as e:
        logger.error(f"Error during cleanup: {e}")

@app.get("/health", response_model=HealthResponse)
async def health_check() -> HealthResponse:
    """Get engine health status"""
    try:
        engine_status = await desktop_engine.get_health()
        recorder_status = await desktop_recorder.get_health()
        
        overall_status = "healthy" if (
            engine_status.get("status") == "healthy" and 
            recorder_status.get("status") == "healthy"
        ) else "unhealthy"
        
        return HealthResponse(
            status=overall_status,
            timestamp=datetime.now(),
            engine_info=engine_status,
            recorder_info=recorder_status,
            active_sessions=len(recording_sessions),
            capabilities=desktop_engine.get_supported_steps()
        )
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        return HealthResponse(
            status="unhealthy",
            timestamp=datetime.now(),
            error=str(e)
        )

@app.post("/record/start")
async def start_recording(request: RecordStartRequest) -> Dict[str, Any]:
    """Start a new recording session"""
    try:
        session_id = str(uuid4())
        
        # Create recording session
        session = RecordingSession(
            id=session_id,
            config=request.config,
            start_time=datetime.now(),
            status="active",
            events=[]
        )
        
        # Start recording
        await desktop_recorder.start_recording(session)
        recording_sessions[session_id] = session
        
        # Set up event callback
        async def event_callback(event: RecordedEvent):
            session.events.append(event)
            await broadcast_event(session_id, event)
        
        desktop_recorder.set_event_callback(session_id, event_callback)
        
        logger.info(f"Recording session {session_id} started")
        
        return {
            "session_id": session_id,
            "status": "started",
            "config": request.config.dict()
        }
        
    except Exception as e:
        logger.error(f"Failed to start recording: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/record/stop")
async def stop_recording(request: RecordStopRequest) -> Dict[str, Any]:
    """Stop a recording session"""
    try:
        session_id = request.session_id
        if session_id not in recording_sessions:
            raise HTTPException(status_code=404, detail="Recording session not found")
        
        session = await stop_recording_internal(session_id)
        
        return {
            "session_id": session_id,
            "status": "stopped",
            "events_count": len(session.events),
            "duration": (session.end_time - session.start_time).total_seconds() if session.end_time else None,
            "events": [event.dict() for event in session.events]
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to stop recording: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/runStep", response_model=StepResponse)
async def run_step(request: StepRequest) -> StepResponse:
    """Execute a single DSL step"""
    try:
        logger.info(f"Executing step: {request.step.kind}")
        
        # Execute step using desktop engine
        result = await desktop_engine.run_step(request.step, request.context)
        
        return StepResponse(
            step_id=request.step.id,
            status=result.status,
            start_time=result.start_time,
            end_time=result.end_time,
            duration=result.duration,
            screenshot_path=result.screenshot_path,
            error=result.error,
            extracted_data=result.extracted_data,
            logs=result.logs
        )
        
    except Exception as e:
        logger.error(f"Step execution failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/screenshot", response_model=ScreenshotResponse)
async def take_screenshot() -> ScreenshotResponse:
    """Capture current desktop screenshot"""
    try:
        screenshot_path = await desktop_engine.take_screenshot()
        
        return ScreenshotResponse(
            timestamp=datetime.now(),
            screenshot_path=screenshot_path,
            status="success"
        )
        
    except Exception as e:
        logger.error(f"Screenshot capture failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/sessions")
async def get_sessions() -> Dict[str, Any]:
    """Get all active recording sessions"""
    sessions_info = {}
    for session_id, session in recording_sessions.items():
        sessions_info[session_id] = {
            "id": session_id,
            "status": session.status,
            "start_time": session.start_time,
            "events_count": len(session.events),
            "config": session.config.dict()
        }
    
    return {"sessions": sessions_info}

@app.websocket("/ws")
async def websocket_endpoint(websocket):
    """WebSocket endpoint for real-time event streaming"""
    await websocket.accept()
    websocket_connections.add(websocket)
    
    try:
        while True:
            # Keep connection alive and handle incoming messages
            data = await websocket.receive_text()
            message = json.loads(data)
            
            if message.get("type") == "ping":
                await websocket.send_text(json.dumps({"type": "pong"}))
                
    except ConnectionClosed:
        pass
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
    finally:
        websocket_connections.discard(websocket)

# Internal helper functions

async def stop_recording_internal(session_id: str) -> RecordingSession:
    """Internal function to stop recording session"""
    session = recording_sessions.get(session_id)
    if not session:
        raise ValueError("Session not found")
    
    # Stop recording
    await desktop_recorder.stop_recording(session_id)
    
    # Update session
    session.status = "stopped"
    session.end_time = datetime.now()
    
    # Remove from active sessions
    recording_sessions.pop(session_id, None)
    
    logger.info(f"Recording session {session_id} stopped")
    return session

async def broadcast_event(session_id: str, event: RecordedEvent):
    """Broadcast event to all connected WebSocket clients"""
    if not websocket_connections:
        return
    
    message = {
        "type": "recorded_event",
        "session_id": session_id,
        "event": event.dict()
    }
    
    message_json = json.dumps(message, default=str)
    
    # Send to all connected clients
    disconnected = set()
    for websocket in websocket_connections:
        try:
            await websocket.send_text(message_json)
        except Exception as e:
            logger.warning(f"Failed to send to WebSocket client: {e}")
            disconnected.add(websocket)
    
    # Remove disconnected clients
    websocket_connections -= disconnected

# Development server runner
if __name__ == "__main__":
    # Check if running on Windows
    if sys.platform != "win32":
        logger.error("This engine is designed for Windows only")
        sys.exit(1)
    
    # Configure uvicorn
    config = uvicorn.Config(
        "main:app",
        host="0.0.0.0",
        port=8000,
        log_level="info",
        reload=False  # Set to True for development
    )
    
    server = uvicorn.Server(config)
    
    try:
        server.run()
    except KeyboardInterrupt:
        logger.info("Server stopped by user")
    except Exception as e:
        logger.error(f"Server error: {e}")
        sys.exit(1) 