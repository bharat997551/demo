"""Desktop locator healing for self-healing selectors"""

import json
import logging
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, asdict
from difflib import SequenceMatcher
import pywinauto
from pywinauto import Application
from pywinauto.controls.win32_controls import DialogWrapper
from pywinauto.timings import TimeoutError as PywinautoTimeoutError

logger = logging.getLogger(__name__)

@dataclass
class DesktopLocatorVariant:
    """Represents a desktop control locator variant"""
    selector: str
    type: str  # 'automation_id', 'title', 'class_name', 'control_type', 'text', 'index'
    score: float
    metadata: Optional[Dict[str, Any]] = None

class DesktopLocatorHealer:
    """Handles locator healing for desktop applications"""
    
    def __init__(self, app: Application):
        self.app = app
    
    def capture_context(self, control: DialogWrapper) -> Dict[str, Any]:
        """Capture window hierarchy and control metadata"""
        try:
            # Capture control metadata
            control_metadata = {
                'automation_id': control.automation_id() if hasattr(control, 'automation_id') else None,
                'class_name': control.class_name() if hasattr(control, 'class_name') else None,
                'control_type': control.element_info.control_type if hasattr(control.element_info, 'control_type') else None,
                'name': control.element_info.name if hasattr(control.element_info, 'name') else None,
                'visible': control.is_visible() if hasattr(control, 'is_visible') else True,
                'enabled': control.is_enabled() if hasattr(control, 'is_enabled') else True,
                'rectangle': self._get_rectangle(control),
                'text': self._get_control_text(control)
            }
            
            # Capture window hierarchy
            window_hierarchy = self._capture_window_hierarchy(control.top_level_parent())
            
            return {
                'windowHierarchy': window_hierarchy,
                'controlMetadata': control_metadata
            }
        except Exception as e:
            logger.error(f"Failed to capture context: {e}")
            raise
    
    def generate_alternative_locators(
        self, 
        original_selector: str,
        original_type: str,
        window_spec: Optional[Dict[str, Any]] = None
    ) -> List[DesktopLocatorVariant]:
        """Generate alternative locators for a control"""
        alternatives = []
        
        try:
            # Try to find the control with original selector
            control = self._find_control_by_selector(original_selector, original_type, window_spec)
            if not control:
                return alternatives
            
            # Generate alternatives based on control properties
            control_data = self.capture_context(control)['controlMetadata']
            
            # Automation ID (highest priority)
            if control_data.get('automation_id'):
                alternatives.append(DesktopLocatorVariant(
                    selector=control_data['automation_id'],
                    type='automation_id',
                    score=1.0,
                    metadata=control_data
                ))
            
            # Control name/title
            if control_data.get('name'):
                alternatives.append(DesktopLocatorVariant(
                    selector=control_data['name'],
                    type='title',
                    score=0.9,
                    metadata=control_data
                ))
            
            # Class name
            if control_data.get('class_name'):
                alternatives.append(DesktopLocatorVariant(
                    selector=control_data['class_name'],
                    type='class_name',
                    score=0.7,
                    metadata=control_data
                ))
            
            # Control type
            if control_data.get('control_type'):
                alternatives.append(DesktopLocatorVariant(
                    selector=str(control_data['control_type']),
                    type='control_type',
                    score=0.6,
                    metadata=control_data
                ))
            
            # Text content
            if control_data.get('text'):
                alternatives.append(DesktopLocatorVariant(
                    selector=control_data['text'],
                    type='text',
                    score=0.8,
                    metadata=control_data
                ))
            
            # Index-based selector (as fallback)
            try:
                parent = control.parent()
                if parent:
                    siblings = parent.children(class_name=control.class_name())
                    index = list(siblings).index(control)
                    alternatives.append(DesktopLocatorVariant(
                        selector=f"{control.class_name()}[{index}]",
                        type='index',
                        score=0.4,
                        metadata=control_data
                    ))
            except:
                pass
            
        except Exception as e:
            logger.error(f"Failed to generate alternative locators: {e}")
        
        return alternatives
    
    def try_locator(
        self, 
        variant: DesktopLocatorVariant,
        window_spec: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Try a locator variant and return success/failure"""
        try:
            control = self._find_control_by_variant(variant, window_spec)
            if control:
                # Verify control is visible and enabled
                is_visible = control.is_visible() if hasattr(control, 'is_visible') else True
                is_enabled = control.is_enabled() if hasattr(control, 'is_enabled') else True
                
                if is_visible and is_enabled:
                    return {
                        'success': True,
                        'control': control
                    }
                else:
                    return {
                        'success': False,
                        'error': f'Control found but not interactable (visible: {is_visible}, enabled: {is_enabled})'
                    }
            
            return {
                'success': False,
                'error': 'Control not found'
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    def find_similar_controls(
        self,
        original_selector: str,
        original_type: str,
        old_hierarchy: Dict[str, Any],
        new_hierarchy: Dict[str, Any]
    ) -> List[DesktopLocatorVariant]:
        """Find similar controls between two window hierarchies"""
        # Extract control properties from old hierarchy
        original_control = self._find_control_in_hierarchy(
            old_hierarchy, 
            original_selector, 
            original_type
        )
        
        if not original_control:
            return []
        
        # Find similar controls in new hierarchy
        similar_controls = []
        candidates = self._flatten_hierarchy(new_hierarchy)
        
        for candidate in candidates:
            similarity = self._calculate_similarity(original_control, candidate)
            if similarity > 0.7:  # Threshold for similarity
                variant = self._create_variant_from_control(candidate, similarity)
                if variant:
                    similar_controls.append(variant)
        
        # Sort by similarity score
        similar_controls.sort(key=lambda x: x.score, reverse=True)
        return similar_controls[:10]  # Return top 10 candidates
    
    def _find_control_by_selector(
        self,
        selector: str,
        selector_type: str,
        window_spec: Optional[Dict[str, Any]] = None
    ) -> Optional[DialogWrapper]:
        """Find control by selector and type"""
        try:
            window = self._get_window(window_spec)
            
            if selector_type == 'automation_id':
                return window.child_window(auto_id=selector)
            elif selector_type == 'title':
                return window.child_window(title=selector)
            elif selector_type == 'class_name':
                return window.child_window(class_name=selector)
            elif selector_type == 'control_type':
                return window.child_window(control_type=selector)
            elif selector_type == 'text':
                return window.child_window(title=selector, found_index=0)
            elif selector_type == 'index':
                # Parse index selector like "Button[2]"
                if '[' in selector and ']' in selector:
                    class_name = selector[:selector.index('[')]
                    index = int(selector[selector.index('[') + 1:selector.index(']')])
                    controls = window.children(class_name=class_name)
                    return list(controls)[index] if index < len(controls) else None
            
            return None
        except (PywinautoTimeoutError, IndexError, ValueError):
            return None
    
    def _find_control_by_variant(
        self,
        variant: DesktopLocatorVariant,
        window_spec: Optional[Dict[str, Any]] = None
    ) -> Optional[DialogWrapper]:
        """Find control by locator variant"""
        return self._find_control_by_selector(variant.selector, variant.type, window_spec)
    
    def _get_window(self, window_spec: Optional[Dict[str, Any]] = None) -> DialogWrapper:
        """Get the window to search within"""
        if window_spec:
            return self.app.window(**window_spec)
        return self.app.top_window()
    
    def _capture_window_hierarchy(self, window: DialogWrapper) -> Dict[str, Any]:
        """Capture the full window hierarchy"""
        hierarchy = {
            'title': window.window_text() if hasattr(window, 'window_text') else '',
            'class_name': window.class_name() if hasattr(window, 'class_name') else '',
            'automation_id': window.automation_id() if hasattr(window, 'automation_id') else '',
            'control_type': window.element_info.control_type if hasattr(window.element_info, 'control_type') else None,
            'rectangle': self._get_rectangle(window),
            'children': []
        }
        
        try:
            for child in window.children():
                child_info = self._capture_control_info(child)
                hierarchy['children'].append(child_info)
        except:
            pass
        
        return hierarchy
    
    def _capture_control_info(self, control: DialogWrapper) -> Dict[str, Any]:
        """Capture information about a single control"""
        info = {
            'automation_id': control.automation_id() if hasattr(control, 'automation_id') else '',
            'class_name': control.class_name() if hasattr(control, 'class_name') else '',
            'name': control.element_info.name if hasattr(control.element_info, 'name') else '',
            'control_type': control.element_info.control_type if hasattr(control.element_info, 'control_type') else None,
            'visible': control.is_visible() if hasattr(control, 'is_visible') else True,
            'enabled': control.is_enabled() if hasattr(control, 'is_enabled') else True,
            'rectangle': self._get_rectangle(control),
            'text': self._get_control_text(control),
            'children': []
        }
        
        # Limit depth to avoid infinite recursion
        try:
            if hasattr(control, 'children'):
                children = control.children()
                if len(children) < 20:  # Limit number of children
                    for child in children[:10]:  # Process only first 10 children
                        child_info = {
                            'automation_id': child.automation_id() if hasattr(child, 'automation_id') else '',
                            'class_name': child.class_name() if hasattr(child, 'class_name') else '',
                            'name': child.element_info.name if hasattr(child.element_info, 'name') else '',
                            'control_type': child.element_info.control_type if hasattr(child.element_info, 'control_type') else None
                        }
                        info['children'].append(child_info)
        except:
            pass
        
        return info
    
    def _get_rectangle(self, control: DialogWrapper) -> Optional[Dict[str, int]]:
        """Get control rectangle"""
        try:
            rect = control.rectangle()
            return {
                'left': rect.left,
                'top': rect.top,
                'right': rect.right,
                'bottom': rect.bottom,
                'width': rect.right - rect.left,
                'height': rect.bottom - rect.top
            }
        except:
            return None
    
    def _get_control_text(self, control: DialogWrapper) -> str:
        """Get control text content"""
        try:
            # Try different methods to get text
            if hasattr(control, 'window_text'):
                return control.window_text()
            elif hasattr(control, 'texts'):
                texts = control.texts()
                return texts[0] if texts else ''
            elif hasattr(control.element_info, 'name'):
                return control.element_info.name or ''
        except:
            pass
        return ''
    
    def _find_control_in_hierarchy(
        self,
        hierarchy: Dict[str, Any],
        selector: str,
        selector_type: str
    ) -> Optional[Dict[str, Any]]:
        """Find control in hierarchy by selector"""
        # Check current level
        if selector_type == 'automation_id' and hierarchy.get('automation_id') == selector:
            return hierarchy
        elif selector_type == 'title' and hierarchy.get('name') == selector:
            return hierarchy
        elif selector_type == 'class_name' and hierarchy.get('class_name') == selector:
            return hierarchy
        elif selector_type == 'control_type' and str(hierarchy.get('control_type')) == selector:
            return hierarchy
        elif selector_type == 'text' and hierarchy.get('text') == selector:
            return hierarchy
        
        # Check children
        for child in hierarchy.get('children', []):
            result = self._find_control_in_hierarchy(child, selector, selector_type)
            if result:
                return result
        
        return None
    
    def _flatten_hierarchy(self, hierarchy: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Flatten hierarchy into list of controls"""
        controls = [hierarchy]
        for child in hierarchy.get('children', []):
            controls.extend(self._flatten_hierarchy(child))
        return controls
    
    def _calculate_similarity(
        self,
        control1: Dict[str, Any],
        control2: Dict[str, Any]
    ) -> float:
        """Calculate similarity between two controls"""
        score = 0.0
        weights = {
            'automation_id': 0.3,
            'class_name': 0.2,
            'control_type': 0.2,
            'text': 0.2,
            'position': 0.1
        }
        
        # Compare automation ID
        if control1.get('automation_id') and control2.get('automation_id'):
            if control1['automation_id'] == control2['automation_id']:
                score += weights['automation_id']
        
        # Compare class name
        if control1.get('class_name') and control2.get('class_name'):
            if control1['class_name'] == control2['class_name']:
                score += weights['class_name']
        
        # Compare control type
        if control1.get('control_type') and control2.get('control_type'):
            if control1['control_type'] == control2['control_type']:
                score += weights['control_type']
        
        # Compare text (using similarity ratio)
        text1 = control1.get('text', '')
        text2 = control2.get('text', '')
        if text1 and text2:
            text_similarity = SequenceMatcher(None, text1, text2).ratio()
            score += weights['text'] * text_similarity
        
        # Compare position (relative to parent)
        rect1 = control1.get('rectangle')
        rect2 = control2.get('rectangle')
        if rect1 and rect2:
            # Simple position similarity based on distance
            dx = abs(rect1['left'] - rect2['left'])
            dy = abs(rect1['top'] - rect2['top'])
            max_distance = 100  # Maximum pixel distance for similarity
            position_similarity = max(0, 1 - (dx + dy) / (2 * max_distance))
            score += weights['position'] * position_similarity
        
        return score
    
    def _create_variant_from_control(
        self,
        control: Dict[str, Any],
        similarity_score: float
    ) -> Optional[DesktopLocatorVariant]:
        """Create locator variant from control info"""
        # Prefer automation ID
        if control.get('automation_id'):
            return DesktopLocatorVariant(
                selector=control['automation_id'],
                type='automation_id',
                score=similarity_score,
                metadata=control
            )
        # Then name/title
        elif control.get('name'):
            return DesktopLocatorVariant(
                selector=control['name'],
                type='title',
                score=similarity_score * 0.9,
                metadata=control
            )
        # Then text
        elif control.get('text'):
            return DesktopLocatorVariant(
                selector=control['text'],
                type='text',
                score=similarity_score * 0.8,
                metadata=control
            )
        # Finally class name
        elif control.get('class_name'):
            return DesktopLocatorVariant(
                selector=control['class_name'],
                type='class_name',
                score=similarity_score * 0.7,
                metadata=control
            )
        
        return None 