"""
Notepad Automation Demo
Demonstrates recording and replaying desktop automation with Notepad
"""
import asyncio
import json
import logging
import os
import time
from datetime import datetime
from typing import List, Dict, Any

from ..types import (
    DesktopStep, StepContext, RecordingConfig, DesktopAction, StepStatus
)
from ..engine import DesktopEngine
from ..recorder import DesktopRecorder

logger = logging.getLogger(__name__)

class NotepadDemo:
    """Demo class for Notepad automation"""
    
    def __init__(self):
        self.engine = DesktopEngine()
        self.recorder = DesktopRecorder()
        self.artifacts_dir = "./artifacts/demo"
        
    async def initialize(self):
        """Initialize demo components"""
        try:
            await self.engine.initialize()
            await self.recorder.initialize()
            
            # Ensure artifacts directory exists
            os.makedirs(self.artifacts_dir, exist_ok=True)
            
            logger.info("Notepad demo initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize demo: {e}")
            raise
    
    async def cleanup(self):
        """Cleanup demo components"""
        try:
            await self.engine.cleanup()
            await self.recorder.cleanup()
            logger.info("Notepad demo cleanup completed")
        except Exception as e:
            logger.error(f"Error during demo cleanup: {e}")
    
    async def run_demo(self, mode: str = "both"):
        """
        Run the complete Notepad demo
        mode: 'record', 'replay', or 'both'
        """
        logger.info(f"Starting Notepad demo in {mode} mode")
        
        try:
            if mode in ['record', 'both']:
                await self.record_notepad_session()
            
            if mode in ['replay', 'both']:
                # Wait a bit between record and replay
                if mode == 'both':
                    await asyncio.sleep(2)
                await self.replay_notepad_session()
            
            logger.info("Notepad demo completed successfully")
            
        except Exception as e:
            logger.error(f"Demo failed: {e}")
            raise
    
    async def record_notepad_session(self):
        """Record a Notepad automation session"""
        logger.info("Starting Notepad recording session")
        
        # Configure recording
        config = RecordingConfig(
            include_mouse_moves=False,
            include_key_presses=True,
            include_window_changes=True,
            min_action_interval=0.2,
            target_applications=[],  # Record all apps
            ignore_applications=["explorer.exe", "dwm.exe", "winlogon.exe"],
            screenshot_on_action=True,
            max_events=100
        )
        
        # Create recording session
        from ..types import RecordingSession, RecordingStatus
        session = RecordingSession(
            id="notepad_demo_session",
            config=config,
            start_time=datetime.now(),
            status=RecordingStatus.ACTIVE,
            events=[]
        )
        
        # Set up event callback to save events
        recorded_events = []
        
        async def event_callback(event):
            recorded_events.append(event)
            logger.info(f"Recorded event: {event.event_type.value}")
        
        # Start recording
        await self.recorder.start_recording(session)
        self.recorder.set_event_callback(session.id, event_callback)
        
        try:
            # Perform automated Notepad operations
            logger.info("Performing Notepad automation for recording...")
            
            # Wait a moment for user to see what's happening
            await asyncio.sleep(1)
            
            # Open Notepad programmatically (so we have consistent behavior)
            await self._open_notepad()
            await asyncio.sleep(2)
            
            # Type some text
            await self._type_demo_text()
            await asyncio.sleep(1)
            
            # Save the file
            await self._save_notepad_file()
            await asyncio.sleep(1)
            
            # Close Notepad
            await self._close_notepad()
            
            # Stop recording
            await self.recorder.stop_recording(session.id)
            
            # Save recorded events
            events_file = os.path.join(self.artifacts_dir, "recorded_events.json")
            with open(events_file, 'w') as f:
                events_data = [
                    {
                        'id': event.id,
                        'timestamp': event.timestamp.isoformat(),
                        'event_type': event.event_type.value,
                        'position': event.position,
                        'key_name': event.key_name,
                        'window_title': event.window_title,
                        'application': event.application,
                        'generated_step': event.generated_step.dict() if event.generated_step else None
                    }
                    for event in recorded_events
                ]
                json.dump(events_data, f, indent=2)
            
            logger.info(f"Recording completed. {len(recorded_events)} events recorded.")
            logger.info(f"Events saved to: {events_file}")
            
        except Exception as e:
            logger.error(f"Recording failed: {e}")
            await self.recorder.stop_recording(session.id)
            raise
    
    async def replay_notepad_session(self):
        """Replay recorded Notepad session or run predefined steps"""
        logger.info("Starting Notepad replay session")
        
        # Define predefined steps for reliable replay
        steps = await self._get_predefined_notepad_steps()
        
        # Create execution context
        context = StepContext(
            run_id="notepad_demo_replay",
            session_id="replay_session",
            variables={
                "demo_text": "Hello from Desktop Automation!\nThis is a demo of automated Notepad interaction.",
                "filename": "demo_file.txt"
            },
            environment={"demo_mode": True},
            screenshots_enabled=True,
            artifacts_dir=self.artifacts_dir
        )
        
        results = []
        
        try:
            logger.info(f"Executing {len(steps)} predefined steps...")
            
            for i, step in enumerate(steps):
                logger.info(f"Executing step {i+1}/{len(steps)}: {step.kind}")
                
                # Execute step
                result = await self.engine.run_step(step, context)
                results.append(result)
                
                # Log result
                if result.status == StepStatus.COMPLETED:
                    logger.info(f"✓ Step {i+1} completed successfully")
                else:
                    logger.error(f"✗ Step {i+1} failed: {result.error}")
                    # Continue with remaining steps for demo purposes
                
                # Small delay between steps
                await asyncio.sleep(0.5)
            
            # Save results
            results_file = os.path.join(self.artifacts_dir, "replay_results.json")
            with open(results_file, 'w') as f:
                results_data = [
                    {
                        'step_id': result.step_id,
                        'status': result.status.value,
                        'start_time': result.start_time.isoformat(),
                        'end_time': result.end_time.isoformat(),
                        'duration': result.duration,
                        'error': result.error,
                        'logs': result.logs
                    }
                    for result in results
                ]
                json.dump(results_data, f, indent=2)
            
            successful_steps = sum(1 for r in results if r.status == StepStatus.COMPLETED)
            logger.info(f"Replay completed. {successful_steps}/{len(results)} steps successful.")
            logger.info(f"Results saved to: {results_file}")
            
        except Exception as e:
            logger.error(f"Replay failed: {e}")
            raise
    
    async def _get_predefined_notepad_steps(self) -> List[DesktopStep]:
        """Get predefined Notepad automation steps"""
        return [
            # Step 1: Take initial screenshot
            DesktopStep(
                id="step_1_initial_screenshot",
                name="Take initial desktop screenshot",
                kind=DesktopAction.SCREENSHOT,
                options={"filename": "01_initial_desktop"}
            ),
            
            # Step 2: Open Notepad
            DesktopStep(
                id="step_2_open_notepad",
                name="Open Notepad",
                kind=DesktopAction.KEY_COMBINATION,
                options={"keys": ["win", "r"]},  # Win+R to open Run dialog
                timeout=10
            ),
            
            # Step 3: Type notepad command
            DesktopStep(
                id="step_3_type_notepad",
                name="Type notepad command",
                kind=DesktopAction.TYPE,
                value="notepad",
                timeout=5
            ),
            
            # Step 4: Press Enter to run
            DesktopStep(
                id="step_4_press_enter",
                name="Press Enter to run Notepad",
                kind=DesktopAction.KEY_PRESS,
                options={"key": "enter"},
                timeout=5
            ),
            
            # Step 5: Wait for Notepad to open
            DesktopStep(
                id="step_5_wait_notepad",
                name="Wait for Notepad to open",
                kind=DesktopAction.WAIT,
                options={"duration": 2.0}
            ),
            
            # Step 6: Take screenshot after Notepad opens
            DesktopStep(
                id="step_6_notepad_opened",
                name="Screenshot after Notepad opens",
                kind=DesktopAction.SCREENSHOT,
                options={"filename": "02_notepad_opened"}
            ),
            
            # Step 7: Type demo text
            DesktopStep(
                id="step_7_type_text",
                name="Type demo text in Notepad",
                kind=DesktopAction.TYPE,
                value="${demo_text}",
                timeout=10
            ),
            
            # Step 8: Take screenshot after typing
            DesktopStep(
                id="step_8_text_typed",
                name="Screenshot after typing text",
                kind=DesktopAction.SCREENSHOT,
                options={"filename": "03_text_typed"}
            ),
            
            # Step 9: Save file (Ctrl+S)
            DesktopStep(
                id="step_9_save_file",
                name="Save file with Ctrl+S",
                kind=DesktopAction.KEY_COMBINATION,
                options={"keys": ["ctrl", "s"]},
                timeout=10
            ),
            
            # Step 10: Wait for Save dialog
            DesktopStep(
                id="step_10_wait_save_dialog",
                name="Wait for Save dialog",
                kind=DesktopAction.WAIT,
                options={"duration": 1.0}
            ),
            
            # Step 11: Type filename
            DesktopStep(
                id="step_11_type_filename",
                name="Type filename",
                kind=DesktopAction.TYPE,
                value="${filename}",
                timeout=5
            ),
            
            # Step 12: Press Enter to save
            DesktopStep(
                id="step_12_save_enter",
                name="Press Enter to save file",
                kind=DesktopAction.KEY_PRESS,
                options={"key": "enter"},
                timeout=5
            ),
            
            # Step 13: Wait after saving
            DesktopStep(
                id="step_13_wait_saved",
                name="Wait after saving",
                kind=DesktopAction.WAIT,
                options={"duration": 1.0}
            ),
            
            # Step 14: Take screenshot after saving
            DesktopStep(
                id="step_14_file_saved",
                name="Screenshot after saving file",
                kind=DesktopAction.SCREENSHOT,
                options={"filename": "04_file_saved"}
            ),
            
            # Step 15: Close Notepad (Alt+F4)
            DesktopStep(
                id="step_15_close_notepad",
                name="Close Notepad with Alt+F4",
                kind=DesktopAction.KEY_COMBINATION,
                options={"keys": ["alt", "f4"]},
                timeout=5
            ),
            
            # Step 16: Final screenshot
            DesktopStep(
                id="step_16_final_screenshot",
                name="Take final desktop screenshot",
                kind=DesktopAction.SCREENSHOT,
                options={"filename": "05_final_desktop"}
            )
        ]
    
    async def _open_notepad(self):
        """Open Notepad programmatically"""
        import subprocess
        subprocess.Popen(["notepad.exe"])
    
    async def _type_demo_text(self):
        """Type demo text in Notepad"""
        demo_text = "Hello from Desktop Automation!\n\nThis text was automatically typed by the Desktop Engine.\n\nTimestamp: " + datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # Send keys to the focused window (Notepad)
        import pywinauto
        pywinauto.keyboard.send_keys(demo_text)
    
    async def _save_notepad_file(self):
        """Save Notepad file"""
        import pywinauto
        
        # Ctrl+S to open Save dialog
        pywinauto.keyboard.send_keys("^s")
        await asyncio.sleep(1)
        
        # Type filename
        filename = f"notepad_demo_{int(time.time())}.txt"
        pywinauto.keyboard.send_keys(filename)
        await asyncio.sleep(0.5)
        
        # Press Enter to save
        pywinauto.keyboard.send_keys("{ENTER}")
    
    async def _close_notepad(self):
        """Close Notepad"""
        import pywinauto
        
        # Alt+F4 to close
        pywinauto.keyboard.send_keys("%{F4}")


# Demo runner function
async def run_notepad_demo(mode: str = "both"):
    """
    Run the Notepad demo
    mode: 'record', 'replay', or 'both'
    """
    demo = NotepadDemo()
    
    try:
        await demo.initialize()
        await demo.run_demo(mode)
    finally:
        await demo.cleanup()


if __name__ == "__main__":
    import sys
    
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )
    
    # Check if running on Windows
    if sys.platform != "win32":
        print("This demo requires Windows")
        sys.exit(1)
    
    # Get mode from command line arguments
    mode = "both"
    if len(sys.argv) > 1:
        mode = sys.argv[1].lower()
        if mode not in ["record", "replay", "both"]:
            print("Mode must be 'record', 'replay', or 'both'")
            sys.exit(1)
    
    print(f"Starting Notepad demo in {mode} mode...")
    print("Make sure you can see the desktop and don't interfere with the automation!")
    
    # Run the demo
    asyncio.run(run_notepad_demo(mode)) 