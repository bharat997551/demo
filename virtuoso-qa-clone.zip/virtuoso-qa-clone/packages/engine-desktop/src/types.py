"""
Type definitions for the Desktop Engine
"""
from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional, Any, Union
from pydantic import BaseModel

class StepStatus(str, Enum):
    """Step execution status"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"

class RecordingStatus(str, Enum):
    """Recording session status"""
    ACTIVE = "active"
    STOPPED = "stopped"
    PAUSED = "paused"
    ERROR = "error"

class EventType(str, Enum):
    """Types of recorded events"""
    MOUSE_CLICK = "mouse_click"
    MOUSE_MOVE = "mouse_move"
    MOUSE_DRAG = "mouse_drag"
    KEY_PRESS = "key_press"
    KEY_COMBINATION = "key_combination"
    WINDOW_CHANGE = "window_change"
    UI_ELEMENT_CHANGE = "ui_element_change"

# DSL Step Definitions
class DesktopStep(BaseModel):
    """Desktop automation step"""
    id: str
    name: Optional[str] = None
    kind: str  # desktop.click, desktop.type, etc.
    target: Optional[Dict[str, Any]] = None  # Element locators
    value: Optional[str] = None  # Text to type, etc.
    options: Optional[Dict[str, Any]] = None  # Additional options
    timeout: int = 30
    retry_count: int = 3
    retry_delay: int = 1

class StepContext(BaseModel):
    """Context for step execution"""
    run_id: str
    session_id: Optional[str] = None
    variables: Dict[str, Any] = {}
    environment: Dict[str, Any] = {}
    screenshots_enabled: bool = True
    artifacts_dir: str = "./artifacts"

class StepResult(BaseModel):
    """Result of step execution"""
    step_id: str
    status: StepStatus
    start_time: datetime
    end_time: datetime
    duration: float  # in seconds
    screenshot_path: Optional[str] = None
    error: Optional[str] = None
    extracted_data: Optional[Any] = None
    logs: List[str] = []

# API Request/Response Models
class StepRequest(BaseModel):
    """Request to execute a step"""
    step: DesktopStep
    context: StepContext

class StepResponse(BaseModel):
    """Response from step execution"""
    step_id: str
    status: StepStatus
    start_time: datetime
    end_time: datetime
    duration: float
    screenshot_path: Optional[str] = None
    error: Optional[str] = None
    extracted_data: Optional[Any] = None
    logs: List[str] = []

class RecordingConfig(BaseModel):
    """Configuration for recording session"""
    include_mouse_moves: bool = False
    include_key_presses: bool = True
    include_window_changes: bool = True
    min_action_interval: float = 0.1  # seconds
    target_applications: List[str] = []  # Empty means all apps
    ignore_applications: List[str] = ["explorer.exe", "dwm.exe"]
    screenshot_on_action: bool = True
    max_events: int = 1000

class UIElement(BaseModel):
    """UI element information"""
    automation_id: Optional[str] = None
    name: Optional[str] = None
    class_name: Optional[str] = None
    control_type: Optional[str] = None
    bounding_rect: Optional[Dict[str, int]] = None  # x, y, width, height
    properties: Dict[str, Any] = {}

class RecordedEvent(BaseModel):
    """A recorded desktop interaction event"""
    id: str
    timestamp: datetime
    event_type: EventType
    position: Optional[Dict[str, int]] = None  # x, y coordinates
    target_element: Optional[UIElement] = None
    key_code: Optional[int] = None
    key_name: Optional[str] = None
    window_title: Optional[str] = None
    application: Optional[str] = None
    generated_step: Optional[DesktopStep] = None
    screenshot_path: Optional[str] = None

class RecordingSession(BaseModel):
    """Recording session data"""
    id: str
    config: RecordingConfig
    start_time: datetime
    end_time: Optional[datetime] = None
    status: RecordingStatus
    events: List[RecordedEvent] = []

class HealthResponse(BaseModel):
    """Health check response"""
    status: str  # healthy, unhealthy, degraded
    timestamp: datetime
    engine_info: Optional[Dict[str, Any]] = None
    recorder_info: Optional[Dict[str, Any]] = None
    active_sessions: int = 0
    capabilities: List[str] = []
    error: Optional[str] = None

class ScreenshotResponse(BaseModel):
    """Screenshot capture response"""
    timestamp: datetime
    screenshot_path: str
    status: str
    error: Optional[str] = None

# Element Locator Types
class LocatorStrategy(str, Enum):
    """Strategies for locating UI elements"""
    AUTOMATION_ID = "automation_id"
    NAME = "name"
    CLASS_NAME = "class_name"
    CONTROL_TYPE = "control_type"
    XPATH = "xpath"
    COORDINATE = "coordinate"
    IMAGE = "image"

class ElementLocator(BaseModel):
    """Element locator definition"""
    strategy: LocatorStrategy
    value: str
    confidence: float = 1.0  # For image-based locators
    timeout: int = 10

class DesktopAction(str, Enum):
    """Supported desktop actions"""
    CLICK = "desktop.click"
    DOUBLE_CLICK = "desktop.doubleClick"
    RIGHT_CLICK = "desktop.rightClick"
    TYPE = "desktop.type"
    KEY_PRESS = "desktop.keyPress"
    KEY_COMBINATION = "desktop.keyCombination"
    DRAG = "desktop.drag"
    SCROLL = "desktop.scroll"
    WAIT = "desktop.wait"
    SCREENSHOT = "desktop.screenshot"
    WINDOW_ACTIVATE = "desktop.windowActivate"
    WINDOW_CLOSE = "desktop.windowClose"
    WINDOW_MAXIMIZE = "desktop.windowMaximize"
    WINDOW_MINIMIZE = "desktop.windowMinimize"
    GET_TEXT = "desktop.getText"
    GET_ATTRIBUTE = "desktop.getAttribute"
    ELEMENT_EXISTS = "desktop.elementExists"

# Engine Configuration
class EngineConfig(BaseModel):
    """Desktop engine configuration"""
    default_timeout: int = 30
    retry_attempts: int = 3
    retry_delay: float = 1.0
    screenshot_on_failure: bool = True
    screenshot_on_success: bool = False
    artifacts_dir: str = "./artifacts"
    log_level: str = "INFO"
    enable_ui_automation: bool = True
    enable_legacy_mode: bool = False  # For older Windows versions 