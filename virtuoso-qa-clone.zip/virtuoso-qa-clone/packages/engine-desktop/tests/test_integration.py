"""
Integration tests for Desktop Engine with mocking layer for CI compatibility
"""
import pytest
import asyncio
import os
import json
import tempfile
from unittest.mock import Mock, patch, MagicMock, AsyncMock
from datetime import datetime

from src.engine import DesktopEngine
from src.recorder import DesktopRecorder
from src.types import (
    DesktopStep, StepContext, DesktopAction, 
    RecordingConfig, RecordingSession, RecordingStatus,
    StepStatus, EngineConfig
)


class MockPywinauto:
    """Mock pywinauto for testing without actual GUI"""
    
    class MockElement:
        def __init__(self, automation_id=None, title=None, class_name=None):
            self._automation_id = automation_id
            self._title = title
            self._class_name = class_name
            self._enabled = True
            self._visible = True
        
        def automation_id(self):
            return self._automation_id or "mock_id"
        
        def window_text(self):
            return self._title or "Mock Element"
        
        def class_name(self):
            return self._class_name or "MockClass"
        
        def control_type(self):
            return "Button"
        
        def rectangle(self):
            rect = Mock()
            rect.left = 100
            rect.top = 100
            rect.width.return_value = 200
            rect.height.return_value = 50
            return rect
        
        def is_enabled(self):
            return self._enabled
        
        def is_visible(self):
            return self._visible
        
        def click(self):
            pass
        
        def double_click(self):
            pass
        
        def right_click(self):
            pass
        
        def type_keys(self, text):
            pass
        
        def set_focus(self):
            pass
    
    class MockDesktop:
        def __init__(self):
            self._elements = {}
        
        def child_window(self, **kwargs):
            # Return mock element based on criteria
            return MockPywinauto.MockElement()
        
        def window(self, **kwargs):
            return MockPywinauto.MockElement()
        
        def from_point(self, x, y):
            return MockPywinauto.MockElement()
    
    @staticmethod
    def Desktop(backend=None):
        return MockPywinauto.MockDesktop()
    
    class keyboard:
        @staticmethod
        def send_keys(keys):
            pass


@pytest.fixture
async def mock_engine():
    """Create a mocked desktop engine"""
    with patch('src.engine.Desktop', MockPywinauto.Desktop), \
         patch('src.engine.ImageGrab') as mock_grab, \
         patch('src.engine.os.makedirs'):
        
        # Mock screenshot functionality
        mock_image = Mock()
        mock_grab.grab.return_value = mock_image
        
        engine = DesktopEngine(EngineConfig(artifacts_dir="./test_artifacts"))
        await engine.initialize()
        yield engine
        await engine.cleanup()


@pytest.fixture
def temp_artifacts_dir():
    """Create temporary artifacts directory"""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield tmpdir


@pytest.fixture
def sample_step():
    """Create a sample desktop step"""
    return DesktopStep(
        id="test_step_1",
        name="Test Click Button",
        kind=DesktopAction.CLICK,
        target={"automation_id": "test_button"},
        timeout=10
    )


@pytest.fixture
def sample_context(temp_artifacts_dir):
    """Create a sample step context"""
    return StepContext(
        run_id="test_run",
        session_id="test_session",
        variables={"test_var": "test_value"},
        environment={"test_env": True},
        screenshots_enabled=True,
        artifacts_dir=temp_artifacts_dir
    )


class TestDesktopEngine:
    """Test cases for DesktopEngine"""
    
    @pytest.mark.asyncio
    async def test_engine_initialization(self, mock_engine):
        """Test engine initialization"""
        assert mock_engine.is_initialized
        assert mock_engine.desktop is not None
        assert mock_engine.element_resolver.is_initialized
    
    @pytest.mark.asyncio
    async def test_click_step_execution(self, mock_engine, sample_step, sample_context):
        """Test click step execution"""
        result = await mock_engine.run_step(sample_step, sample_context)
        
        assert result.step_id == sample_step.id
        assert result.status == StepStatus.COMPLETED
        assert result.duration > 0
        assert result.extracted_data["clicked"] is True
    
    @pytest.mark.asyncio
    async def test_type_step_execution(self, mock_engine, sample_context):
        """Test type step execution"""
        step = DesktopStep(
            id="test_type",
            kind=DesktopAction.TYPE,
            target={"automation_id": "text_field"},
            value="Hello ${test_var}!"
        )
        
        result = await mock_engine.run_step(step, sample_context)
        
        assert result.status == StepStatus.COMPLETED
        assert result.extracted_data["typed"] == "Hello ${test_var}!"
    
    @pytest.mark.asyncio
    async def test_key_press_execution(self, mock_engine, sample_context):
        """Test key press execution"""
        step = DesktopStep(
            id="test_key",
            kind=DesktopAction.KEY_PRESS,
            options={"key": "enter"}
        )
        
        with patch('src.engine.pywinauto.keyboard.send_keys') as mock_send:
            result = await mock_engine.run_step(step, sample_context)
            
            assert result.status == StepStatus.COMPLETED
            mock_send.assert_called_once_with("{ENTER}")
    
    @pytest.mark.asyncio
    async def test_key_combination_execution(self, mock_engine, sample_context):
        """Test key combination execution"""
        step = DesktopStep(
            id="test_combo",
            kind=DesktopAction.KEY_COMBINATION,
            options={"keys": ["ctrl", "c"]}
        )
        
        with patch('src.engine.pywinauto.keyboard.send_keys') as mock_send:
            result = await mock_engine.run_step(step, sample_context)
            
            assert result.status == StepStatus.COMPLETED
            mock_send.assert_called_once_with("^+c")  # ctrl+c in pywinauto format
    
    @pytest.mark.asyncio
    async def test_screenshot_execution(self, mock_engine, sample_context):
        """Test screenshot execution"""
        step = DesktopStep(
            id="test_screenshot",
            kind=DesktopAction.SCREENSHOT,
            options={"filename": "test_screen"}
        )
        
        result = await mock_engine.run_step(step, sample_context)
        
        assert result.status == StepStatus.COMPLETED
        assert "screenshot_path" in result.extracted_data
    
    @pytest.mark.asyncio
    async def test_wait_execution(self, mock_engine, sample_context):
        """Test wait execution"""
        step = DesktopStep(
            id="test_wait",
            kind=DesktopAction.WAIT,
            options={"duration": 0.1}
        )
        
        start_time = datetime.now()
        result = await mock_engine.run_step(step, sample_context)
        end_time = datetime.now()
        
        assert result.status == StepStatus.COMPLETED
        assert (end_time - start_time).total_seconds() >= 0.1
    
    @pytest.mark.asyncio
    async def test_element_not_found_handling(self, mock_engine, sample_context):
        """Test handling of element not found"""
        step = DesktopStep(
            id="test_not_found",
            kind=DesktopAction.CLICK,
            target={"automation_id": "nonexistent_element"},
            timeout=1  # Short timeout for testing
        )
        
        with patch.object(mock_engine, '_find_element', side_effect=Exception("Element not found")):
            result = await mock_engine.run_step(step, sample_context)
            
            assert result.status == StepStatus.FAILED
            assert "Element not found" in result.error
    
    @pytest.mark.asyncio
    async def test_retry_logic(self, mock_engine, sample_context):
        """Test step retry logic"""
        step = DesktopStep(
            id="test_retry",
            kind=DesktopAction.CLICK,
            target={"automation_id": "flaky_element"}
        )
        
        # Mock element finder to fail twice, then succeed
        call_count = 0
        def mock_find_element(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count <= 2:
                raise Exception("Temporary failure")
            return MockPywinauto.MockElement()
        
        with patch.object(mock_engine, '_find_element', side_effect=mock_find_element):
            result = await mock_engine.run_step(step, sample_context)
            
            assert result.status == StepStatus.COMPLETED
            assert call_count == 3  # Failed twice, succeeded on third try
    
    @pytest.mark.asyncio
    async def test_get_health(self, mock_engine):
        """Test engine health check"""
        health = await mock_engine.get_health()
        
        assert health["status"] == "healthy"
        assert health["initialized"] is True
        assert "config" in health
    
    def test_supported_steps(self, mock_engine):
        """Test getting supported step kinds"""
        steps = mock_engine.get_supported_steps()
        
        assert isinstance(steps, list)
        assert len(steps) > 0
        assert DesktopAction.CLICK.value in steps
        assert DesktopAction.TYPE.value in steps


class MockWindowsHook:
    """Mock Windows hook functionality"""
    
    def __init__(self):
        self.callbacks = {}
        self.active = False
    
    def install_hook(self, hook_type, callback):
        self.callbacks[hook_type] = callback
        return True
    
    def uninstall_hook(self, hook_handle):
        return True
    
    def simulate_click(self, x, y, button="left"):
        if "mouse" in self.callbacks:
            self.callbacks["mouse"](x, y, button)
    
    def simulate_key_press(self, key_code):
        if "keyboard" in self.callbacks:
            self.callbacks["keyboard"](key_code)


@pytest.fixture
async def mock_recorder():
    """Create a mocked desktop recorder"""
    with patch('src.recorder.ctypes'), \
         patch('src.recorder.win32api'), \
         patch('src.recorder.win32gui'), \
         patch('src.recorder.psutil'):
        
        recorder = DesktopRecorder()
        recorder.mock_hook = MockWindowsHook()
        await recorder.initialize()
        yield recorder
        await recorder.cleanup()


class TestDesktopRecorder:
    """Test cases for DesktopRecorder"""
    
    @pytest.mark.asyncio
    async def test_recorder_initialization(self, mock_recorder):
        """Test recorder initialization"""
        assert mock_recorder.is_initialized
        assert mock_recorder.element_resolver.is_initialized
    
    @pytest.mark.asyncio
    async def test_start_recording_session(self, mock_recorder):
        """Test starting a recording session"""
        config = RecordingConfig(
            include_mouse_moves=False,
            include_key_presses=True,
            max_events=100
        )
        
        session = RecordingSession(
            id="test_session",
            config=config,
            start_time=datetime.now(),
            status=RecordingStatus.ACTIVE,
            events=[]
        )
        
        await mock_recorder.start_recording(session)
        
        assert "test_session" in mock_recorder.active_sessions
        assert mock_recorder.active_sessions["test_session"].status == RecordingStatus.ACTIVE
    
    @pytest.mark.asyncio
    async def test_stop_recording_session(self, mock_recorder):
        """Test stopping a recording session"""
        # First start a session
        config = RecordingConfig()
        session = RecordingSession(
            id="test_session",
            config=config,
            start_time=datetime.now(),
            status=RecordingStatus.ACTIVE,
            events=[]
        )
        
        await mock_recorder.start_recording(session)
        
        # Then stop it
        await mock_recorder.stop_recording("test_session")
        
        assert "test_session" not in mock_recorder.active_sessions
    
    @pytest.mark.asyncio
    async def test_recorder_health(self, mock_recorder):
        """Test recorder health check"""
        health = await mock_recorder.get_health()
        
        assert health["status"] == "healthy"
        assert health["active_sessions"] == 0
        assert "hooks_active" in health


class TestIntegrationScenarios:
    """Integration test scenarios"""
    
    @pytest.mark.asyncio
    async def test_complete_automation_workflow(self, mock_engine, sample_context):
        """Test complete automation workflow"""
        steps = [
            DesktopStep(
                id="step1",
                kind=DesktopAction.SCREENSHOT,
                options={"filename": "workflow_start"}
            ),
            DesktopStep(
                id="step2", 
                kind=DesktopAction.CLICK,
                target={"automation_id": "start_button"}
            ),
            DesktopStep(
                id="step3",
                kind=DesktopAction.TYPE,
                target={"automation_id": "input_field"},
                value="Test workflow"
            ),
            DesktopStep(
                id="step4",
                kind=DesktopAction.KEY_PRESS,
                options={"key": "enter"}
            ),
            DesktopStep(
                id="step5",
                kind=DesktopAction.WAIT,
                options={"duration": 0.5}
            )
        ]
        
        results = []
        for step in steps:
            result = await mock_engine.run_step(step, sample_context)
            results.append(result)
        
        # All steps should complete successfully
        assert all(r.status == StepStatus.COMPLETED for r in results)
        assert len(results) == len(steps)
    
    @pytest.mark.asyncio
    async def test_error_recovery_workflow(self, mock_engine, sample_context):
        """Test workflow with error recovery"""
        # Create a step that will fail initially but succeed on retry
        step = DesktopStep(
            id="flaky_step",
            kind=DesktopAction.CLICK,
            target={"automation_id": "flaky_button"},
            retry_count=3
        )
        
        # Mock the element finder to fail first two times
        call_count = 0
        def mock_find_element(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count <= 2:
                raise Exception("Temporary failure")
            return MockPywinauto.MockElement()
        
        with patch.object(mock_engine, '_find_element', side_effect=mock_find_element):
            result = await mock_engine.run_step(step, sample_context)
            
            # Should eventually succeed
            assert result.status == StepStatus.COMPLETED
            assert "successfully on attempt 3" in ' '.join(result.logs)
    
    @pytest.mark.asyncio
    async def test_variable_interpolation(self, mock_engine, sample_context):
        """Test variable interpolation in steps"""
        # Add test variables to context
        sample_context.variables.update({
            "username": "testuser",
            "password": "secret123",
            "message": "Hello World"
        })
        
        step = DesktopStep(
            id="var_test",
            kind=DesktopAction.TYPE,
            target={"automation_id": "input_field"},
            value="User: ${username}, Message: ${message}"
        )
        
        result = await mock_engine.run_step(step, sample_context)
        
        assert result.status == StepStatus.COMPLETED
        # The actual interpolation happens in the engine's _interpolate_variables method


@pytest.mark.asyncio
async def test_notepad_demo_simulation():
    """Test Notepad demo with full mocking"""
    with patch('src.demo.notepad_demo.DesktopEngine') as MockEngine, \
         patch('src.demo.notepad_demo.DesktopRecorder') as MockRecorder, \
         patch('subprocess.Popen'), \
         patch('pywinauto.keyboard.send_keys'):
        
        # Mock engine and recorder
        mock_engine_instance = AsyncMock()
        mock_recorder_instance = AsyncMock()
        
        MockEngine.return_value = mock_engine_instance
        MockRecorder.return_value = mock_recorder_instance
        
        # Import and run demo
        from src.demo.notepad_demo import NotepadDemo
        
        demo = NotepadDemo()
        await demo.initialize()
        
        # Test that initialization was called
        mock_engine_instance.initialize.assert_called_once()
        mock_recorder_instance.initialize.assert_called_once()
        
        await demo.cleanup()
        
        # Test that cleanup was called
        mock_engine_instance.cleanup.assert_called_once()
        mock_recorder_instance.cleanup.assert_called_once()


if __name__ == "__main__":
    # Run tests with pytest
    pytest.main([__file__, "-v", "--tb=short"]) 