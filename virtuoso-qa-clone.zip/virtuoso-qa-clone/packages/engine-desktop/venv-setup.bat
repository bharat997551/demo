@echo off
echo Setting up Python virtual environment for Desktop Engine...

:: Check if Python is installed
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo Error: Python is not installed or not in PATH
    pause
    exit /b 1
)

:: Create virtual environment
if not exist "venv" (
    echo Creating virtual environment...
    python -m venv venv
) else (
    echo Virtual environment already exists.
)

:: Activate virtual environment
call venv\Scripts\activate.bat

:: Upgrade pip
echo Upgrading pip...
python -m pip install --upgrade pip

:: Install requirements
echo Installing requirements...
pip install -r requirements.txt

echo.
echo Setup complete! To activate the environment, run:
echo   venv\Scripts\activate.bat
echo.
echo To start the desktop engine server, run:
echo   python src/main.py
echo.
pause 