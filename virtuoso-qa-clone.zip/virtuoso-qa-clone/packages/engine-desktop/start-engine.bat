@echo off
setlocal enabledelayedexpansion

REM Hybrid QA Desktop Engine Startup Script
REM This script verifies Python environment, installs requirements, and starts the engine

echo ========================================
echo Hybrid QA Desktop Engine Startup
echo ========================================
echo.

REM Color definitions for output
set "RED=[31m"
set "GREEN=[32m"
set "YELLOW=[33m"
set "BLUE=[34m"
set "NC=[0m"

REM Configuration
set PYTHON_MIN_VERSION=3.8
set VENV_DIR=venv
set HOST=0.0.0.0
set PORT=8000
set LOG_LEVEL=info

REM Check if Python is installed
echo %BLUE%[INFO]%NC% Checking Python installation...
python --version >nul 2>&1
if errorlevel 1 (
    echo %RED%[ERROR]%NC% Python is not installed or not in PATH
    echo Please install Python 3.8+ from https://python.org
    pause
    exit /b 1
)

REM Check Python version
for /f "tokens=2" %%a in ('python --version 2^>^&1') do set PYTHON_VERSION=%%a
echo %GREEN%[SUCCESS]%NC% Python %PYTHON_VERSION% found

REM Extract major.minor version
for /f "tokens=1,2 delims=." %%a in ("%PYTHON_VERSION%") do (
    set PYTHON_MAJOR=%%a
    set PYTHON_MINOR=%%b
)

REM Check if version meets minimum requirement
if %PYTHON_MAJOR% LSS 3 (
    echo %RED%[ERROR]%NC% Python version %PYTHON_VERSION% is too old. Minimum required: %PYTHON_MIN_VERSION%
    pause
    exit /b 1
)
if %PYTHON_MAJOR% EQU 3 if %PYTHON_MINOR% LSS 8 (
    echo %RED%[ERROR]%NC% Python version %PYTHON_VERSION% is too old. Minimum required: %PYTHON_MIN_VERSION%
    pause
    exit /b 1
)

REM Check if virtual environment exists
echo %BLUE%[INFO]%NC% Checking virtual environment...
if not exist "%VENV_DIR%\Scripts\activate.bat" (
    echo %YELLOW%[WARN]%NC% Virtual environment not found. Creating new one...
    python -m venv %VENV_DIR%
    if errorlevel 1 (
        echo %RED%[ERROR]%NC% Failed to create virtual environment
        pause
        exit /b 1
    )
    echo %GREEN%[SUCCESS]%NC% Virtual environment created
) else (
    echo %GREEN%[SUCCESS]%NC% Virtual environment found
)

REM Activate virtual environment
echo %BLUE%[INFO]%NC% Activating virtual environment...
call "%VENV_DIR%\Scripts\activate.bat"
if errorlevel 1 (
    echo %RED%[ERROR]%NC% Failed to activate virtual environment
    pause
    exit /b 1
)

REM Upgrade pip
echo %BLUE%[INFO]%NC% Upgrading pip...
python -m pip install --upgrade pip >nul 2>&1

REM Check if requirements.txt exists
if not exist "requirements.txt" (
    echo %RED%[ERROR]%NC% requirements.txt not found in current directory
    echo Please run this script from the engine-desktop directory
    pause
    exit /b 1
)

REM Install or upgrade requirements
echo %BLUE%[INFO]%NC% Installing/upgrading requirements...
pip install -r requirements.txt
if errorlevel 1 (
    echo %RED%[ERROR]%NC% Failed to install requirements
    echo %YELLOW%[INFO]%NC% You may need to install Visual Studio Build Tools for some packages
    echo Download from: https://visualstudio.microsoft.com/visual-cpp-build-tools/
    pause
    exit /b 1
)
echo %GREEN%[SUCCESS]%NC% Requirements installed successfully

REM Check for Windows-specific dependencies
echo %BLUE%[INFO]%NC% Checking Windows-specific dependencies...
python -c "import pywin32_system32" >nul 2>&1
if errorlevel 1 (
    echo %YELLOW%[WARN]%NC% pywin32 may need post-install setup...
    python Scripts/pywin32_postinstall.py -install >nul 2>&1
)

REM Verify critical imports
echo %BLUE%[INFO]%NC% Verifying critical dependencies...
python -c "import pywinauto, win32gui, win32api, fastapi, uvicorn" >nul 2>&1
if errorlevel 1 (
    echo %RED%[ERROR]%NC% Some critical dependencies are missing or not working
    echo Please check the error messages above
    pause
    exit /b 1
)
echo %GREEN%[SUCCESS]%NC% All dependencies verified

REM Create artifacts directory if it doesn't exist
if not exist "artifacts" (
    mkdir artifacts
    echo %BLUE%[INFO]%NC% Created artifacts directory
)

REM Set environment variables
set WEB_ENGINE_PORT=%PORT%
set WEB_ENGINE_HOST=%HOST%
set WEB_ENGINE_LOG_LEVEL=%LOG_LEVEL%

REM Parse command line arguments
set "START_MODE=server"
set "DEMO_MODE="
if not "%1"=="" set "START_MODE=%1"
if not "%2"=="" set "DEMO_MODE=%2"

REM Display startup information
echo.
echo %BLUE%========================================%NC%
echo %BLUE%           Startup Information          %NC%
echo %BLUE%========================================%NC%
echo Python Version: %PYTHON_VERSION%
echo Virtual Environment: %VENV_DIR%
echo Host: %HOST%
echo Port: %PORT%
echo Log Level: %LOG_LEVEL%
echo Start Mode: %START_MODE%
if not "%DEMO_MODE%"=="" echo Demo Mode: %DEMO_MODE%
echo.

REM Start the engine based on mode
if "%START_MODE%"=="server" (
    echo %GREEN%[STARTING]%NC% Desktop Engine Server...
    echo.
    echo %YELLOW%[INFO]%NC% Server will be available at: http://%HOST%:%PORT%
    echo %YELLOW%[INFO]%NC% Health check: http://%HOST%:%PORT%/health
    echo %YELLOW%[INFO]%NC% API documentation: http://%HOST%:%PORT%/docs
    echo.
    echo %YELLOW%[INFO]%NC% Press Ctrl+C to stop the server
    echo.
    
    REM Start uvicorn server
    uvicorn src.main:app --host %HOST% --port %PORT% --log-level %LOG_LEVEL% --reload
    
) else if "%START_MODE%"=="demo" (
    echo %GREEN%[STARTING]%NC% Notepad Demo...
    echo.
    if "%DEMO_MODE%"=="" set "DEMO_MODE=both"
    
    echo %YELLOW%[INFO]%NC% Running demo in %DEMO_MODE% mode
    echo %YELLOW%[WARNING]%NC% Make sure you can see the desktop and don't interfere!
    echo.
    
    REM Start demo
    python -m src.demo.notepad_demo %DEMO_MODE%
    
) else if "%START_MODE%"=="test" (
    echo %GREEN%[STARTING]%NC% Running Tests...
    echo.
    
    REM Install pytest if not present
    pip show pytest >nul 2>&1
    if errorlevel 1 (
        echo %BLUE%[INFO]%NC% Installing pytest...
        pip install pytest pytest-asyncio
    )
    
    REM Run tests
    python -m pytest tests/ -v --tb=short
    
) else if "%START_MODE%"=="health" (
    echo %GREEN%[CHECKING]%NC% Engine Health...
    echo.
    
    REM Quick health check
    python -c "
import asyncio
import sys
sys.path.append('.')
from src.engine import DesktopEngine
from src.recorder import DesktopRecorder

async def health_check():
    try:
        engine = DesktopEngine()
        recorder = DesktopRecorder()
        
        await engine.initialize()
        await recorder.initialize()
        
        engine_health = await engine.get_health()
        recorder_health = await recorder.get_health()
        
        print(f'Engine Status: {engine_health[\"status\"]}')
        print(f'Recorder Status: {recorder_health[\"status\"]}')
        print('All systems operational!')
        
        await engine.cleanup()
        await recorder.cleanup()
        
    except Exception as e:
        print(f'Health check failed: {e}')
        sys.exit(1)

asyncio.run(health_check())
    "
    
) else (
    echo %RED%[ERROR]%NC% Unknown start mode: %START_MODE%
    echo.
    echo Available modes:
    echo   server  - Start the FastAPI server (default)
    echo   demo    - Run Notepad automation demo
    echo   test    - Run integration tests
    echo   health  - Perform health check
    echo.
    echo Usage: %0 [mode] [demo_mode]
    echo   demo_mode: record, replay, both (only for demo mode)
    echo.
    echo Examples:
    echo   %0 server
    echo   %0 demo both
    echo   %0 test
    echo   %0 health
    pause
    exit /b 1
)

if errorlevel 1 (
    echo.
    echo %RED%[ERROR]%NC% Operation failed with error level %errorlevel%
    pause
    exit /b %errorlevel%
)

echo.
echo %GREEN%[COMPLETED]%NC% Operation completed successfully
pause
endlocal 