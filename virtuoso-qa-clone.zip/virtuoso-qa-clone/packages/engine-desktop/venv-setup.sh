#!/bin/bash

echo "Setting up Python virtual environment for Desktop Engine..."

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "Error: Python 3 is not installed or not in PATH"
    exit 1
fi

# Create virtual environment
if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
else
    echo "Virtual environment already exists."
fi

# Activate virtual environment
source venv/bin/activate

# Upgrade pip
echo "Upgrading pip..."
python -m pip install --upgrade pip

# Install requirements
echo "Installing requirements..."
pip install -r requirements.txt

echo
echo "Setup complete! To activate the environment, run:"
echo "  source venv/bin/activate"
echo
echo "To start the desktop engine server, run:"
echo "  python src/main.py"
echo 