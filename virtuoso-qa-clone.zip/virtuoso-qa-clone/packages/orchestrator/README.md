# Hybrid QA Orchestrator

The core orchestration service that manages test execution, engine coordination, artifact collection, and real-time event broadcasting for the Hybrid QA platform.

## 🎯 Features

### ✅ Core Engine Interface
- **Universal Engine Contract**: All automation engines implement the same `IEngine` interface
- **Engine Registration**: Dynamic engine discovery and registration system
- **Health Monitoring**: Continuous health checking with automatic restart capabilities
- **Step Validation**: Engine-specific step validation before execution

### ✅ Comprehensive Runner Service
- **DSL Validation**: Full validation using the `@hybrid-qa/dsl` schema system
- **Execution Planning**: DAG-based execution planning with dependency resolution
- **Variable Resolution**: Dynamic variable interpolation with scope management
- **Data-Driven Testing**: Support for data tables and parameterized test execution
- **Parallel Execution**: Configurable parallel execution with concurrency limits
- **Tag Filtering**: Environment-based test filtering using tags

### ✅ Real-Time Event System
- **EventEmitter Integration**: Internal event system for service communication
- **WebSocket Broadcasting**: Real-time event streaming to connected clients
- **Typed Messages**: Zod-validated event schemas for type safety
- **Client Subscriptions**: Selective event subscription by client
- **Event Types**:
  - `run:started` / `run:finished`
  - `step:started` / `step:ended`
  - `artifact:created`
  - `engine:health`
  - `error` / `log`

### ✅ Artifact Management
- **Structured Storage**: Organized artifact storage by run ID and type
- **Metadata Tracking**: JSON metadata for all artifacts with search capabilities
- **Multiple Formats**: Support for screenshots, videos, logs, reports, and data
- **HTTP Access**: RESTful endpoints for artifact download and management
- **Automatic Cleanup**: Configurable retention policies for storage management

### ✅ Engine Adapters
- **Direct Integration**: TypeScript engines (web, api) imported directly
- **Python Lifecycle Management**: `child_process` management for Python engines
- **HTTP Communication**: RESTful communication with Python FastAPI services
- **Health Checks**: Automatic health monitoring and restart logic
- **Process Management**: Graceful startup, shutdown, and error handling

### ✅ Self-Healing System
- **Locator Learning**: Records successful locator usage for machine learning
- **Fallback Logic**: Automatic fallback to alternative locators on failure
- **SQLite Persistence**: Prisma-based locator history storage
- **Confidence Scoring**: Statistical confidence tracking for locator reliability
- **Performance Analytics**: Comprehensive statistics and strategy analysis

## 🏗️ Architecture

```mermaid
graph TB
    subgraph "Orchestrator Core"
        Controller[OrchestratorController]
        Runner[RunnerService]
        Events[EventService]
        Artifacts[ArtifactService]
        Healing[SelfHealingService]
    end
    
    subgraph "Engine Adapters"
        WebEngine[WebEngineAdapter]
        PythonAdapter[PythonEngineAdapter]
        DesktopEngine[Desktop Engine Process]
        MainframeEngine[Mainframe Engine Process]
    end
    
    subgraph "External Interfaces"
        HTTP[REST API]
        WebSocket[WebSocket Server]
        Database[(SQLite + Prisma)]
        FileSystem[(Artifact Storage)]
    end
    
    Controller --> Runner
    Controller --> Events
    Controller --> Artifacts
    Controller --> Healing
    
    Runner --> WebEngine
    Runner --> PythonAdapter
    PythonAdapter --> DesktopEngine
    PythonAdapter --> MainframeEngine
    
    Controller --> HTTP
    Events --> WebSocket
    Healing --> Database
    Artifacts --> FileSystem
```

## 🚀 Quick Start

### Installation

```bash
cd packages/orchestrator
pnpm install
```

### Development

```bash
# Start in development mode
pnpm dev

# Build for production
pnpm build

# Start production server
pnpm start
```

### Environment Variables

```bash
# Server Configuration
PORT=3001
HOST=localhost
WS_PORT=3002
CORS_ORIGIN=http://localhost:5173

# Artifact Storage
ARTIFACT_DIR=./artifacts

# Engine Configuration
ENGINE_WEB_ENABLED=true
ENGINE_WEB_PORT=8001

ENGINE_DESKTOP_ENABLED=true
ENGINE_DESKTOP_PORT=8002
DESKTOP_VENV_PATH=../engine-desktop/venv

ENGINE_MAINFRAME_ENABLED=true
ENGINE_MAINFRAME_PORT=8003
MAINFRAME_VENV_PATH=../engine-mainframe/venv

ENGINE_API_ENABLED=true
ENGINE_API_PORT=8004

# Python Configuration
PYTHON_PATH=/usr/bin/python3

# Database
DATABASE_URL=file:./dev.db
```

## 📡 API Endpoints

### Health & Status

```bash
GET /health
```

**Response:**
```json
{
  "status": "healthy",
  "timestamp": "2024-01-01T12:00:00Z",
  "version": "1.0.0",
  "uptime": 3600,
  "services": {
    "orchestrator": "healthy",
    "events": { "status": "healthy", "connectedClients": 5 },
    "artifacts": "healthy",
    "selfHealing": { "status": "healthy", "totalElements": 150 }
  },
  "engines": [
    {
      "type": "desktop",
      "name": "Desktop Engine",
      "health": {
        "status": "healthy",
        "responseTime": 45,
        "capabilities": ["desktop.click", "desktop.type"]
      }
    }
  ]
}
```

### Test Execution

```bash
POST /runs
Content-Type: application/json

{
  "dsl": {
    "id": "test-case-id",
    "name": "Login Test",
    "steps": [
      {
        "id": "step-1",
        "name": "Navigate to login",
        "kind": "web.navigate",
        "engine": "web",
        "options": { "url": "https://app.example.com/login" }
      }
    ]
  },
  "config": {
    "environment": "staging",
    "variables": { "username": "testuser" },
    "maxConcurrency": 2,
    "screenshots": { "onFailure": true }
  }
}
```

### Engine Management

```bash
# List all engines
GET /engines

# Check specific engine health
GET /engines/desktop/health
```

### Artifact Management

```bash
# List run artifacts
GET /artifacts/{runId}?type=screenshot

# Download specific artifact
GET /artifacts/{runId}/{artifactId}
```

### Self-Healing

```bash
# Get healing statistics
GET /healing/stats?elementId=login-button

# Cleanup old history
POST /healing/cleanup
{ "olderThanDays": 90 }
```

## 🔌 WebSocket Events

Connect to `ws://localhost:3002` to receive real-time events.

### Client Connection

```javascript
const ws = new WebSocket('ws://localhost:3002');

ws.onopen = () => {
  // Subscribe to specific events
  ws.send(JSON.stringify({
    type: 'subscribe',
    eventTypes: ['run:started', 'step:ended', 'artifact:created']
  }));
};

ws.onmessage = (event) => {
  const message = JSON.parse(event.data);
  console.log('Event received:', message.event);
};
```

### Event Schema

```typescript
interface WebSocketMessage {
  id: string;
  event: OrchestratorEvent;
  clientId?: string;
  timestamp: Date;
}

// Example event
{
  "id": "msg-1234567890",
  "event": {
    "type": "step:started",
    "timestamp": "2024-01-01T12:00:00Z",
    "runId": "run-1234567890",
    "stepId": "step-1",
    "stepName": "Navigate to login",
    "stepKind": "web.navigate",
    "engine": "web",
    "stepNumber": 1,
    "totalSteps": 5
  },
  "timestamp": "2024-01-01T12:00:00Z"
}
```

## 🔧 Engine Integration

### Python Engine Adapter

The `PythonEngineAdapter` manages Python-based engines (desktop, mainframe) with full lifecycle management:

```typescript
import { createPythonEngineAdapter } from './adapters/python-engine.adapter';

// Create desktop engine adapter
const desktopEngine = createPythonEngineAdapter('desktop', {
  port: 8002,
  pythonPath: '/usr/bin/python3',
  venvPath: './venv',
  startupTimeout: 30000,
  maxRestarts: 3
});

// Initialize and register
await desktopEngine.initialize();
runnerService.registerEngine('desktop', desktopEngine);
```

### Engine Interface Implementation

```typescript
export class CustomEngine extends BaseEngine {
  supports(stepKind: string): boolean {
    return this.getSupportedStepKinds().includes(stepKind);
  }

  getSupportedStepKinds(): string[] {
    return ['custom.action', 'custom.verify'];
  }

  async runStep(step: Step, context: RunContext): Promise<StepExecutionResult> {
    // Implement step execution logic
    return this.createStepResult(step, 'completed', context, {
      extractedData: 'result',
      screenshots: ['screenshot.png']
    });
  }

  protected async doInitialize(): Promise<void> {
    // Engine-specific initialization
  }

  protected async doHealthCheck(): Promise<void> {
    // Health check implementation
  }
}
```

## 🧪 Testing

The orchestrator includes comprehensive unit and integration tests using Jest.

### Test Structure

```
tests/
├── unit/
│   └── runner.service.test.ts    # Unit tests for Runner execution plan building
├── integration/
│   └── web-engine.integration.test.ts  # Integration tests with mock web engine
└── setup.ts                      # Test configuration
```

### Running Tests

```bash
# Install dependencies
pnpm install

# Run all tests
pnpm test

# Run with coverage
pnpm test --coverage

# Run specific test files
pnpm test runner.service.test.ts
pnpm test web-engine.integration.test.ts
```

### Test Coverage

- **Unit Tests**: Focus on execution plan building, variable resolution, and DSL validation
- **Integration Tests**: Test complete workflow with mock engines, event emission, and error handling
- **Event Testing**: Verify proper event emission sequence and payload structure
- **Error Handling**: Test retry logic, failure scenarios, and recovery mechanisms

### Mock Implementations

The tests include a `MockWebEngine` that implements the `IEngine` interface for realistic testing without external dependencies.

## 🚀 Production Deployment

### Docker Support

```