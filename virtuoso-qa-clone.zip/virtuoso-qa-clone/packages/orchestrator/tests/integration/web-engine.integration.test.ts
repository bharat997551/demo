import { RunnerService } from '../../src/services/runner.service';
import { ArtifactService } from '../../src/services/artifact.service';
import { SelfHealingService } from '../../src/services/self-healing.service';
import { IEngine, RunContext, StepExecutionResult, EngineConfig, EngineHealth } from '../../src/interfaces/engine.interface';
import { EventTypes } from '../../src/types/events.types';

// Mock web engine for testing
class MockWebEngine implements IEngine {
  public readonly config: EngineConfig = {
    id: 'mock-web-engine',
    name: 'Mock Web Engine',
    type: 'web',
    version: '1.0.0',
    enabled: true,
    settings: {},
    healthCheck: {
      enabled: true,
      interval: 30000,
      timeout: 5000,
      retries: 3,
    },
  };

  supports(stepKind: string): boolean {
    return stepKind.startsWith('web.');
  }

  async runStep(step: any, context: RunContext): Promise<StepExecutionResult> {
    const startTime = new Date();
    const executionTime = Math.floor(Math.random() * 1000) + 100;
    
    // Simulate step execution
    await new Promise(resolve => setTimeout(resolve, Math.min(executionTime, 50)));
    
    const endTime = new Date();
    
    // Simulate occasional failures for retry testing
    if (step.kind === 'web.click' && Math.random() < 0.3) {
      return {
        stepId: step.id,
        status: 'failed',
        startTime,
        endTime,
        duration: endTime.getTime() - startTime.getTime(),
        error: 'Element not found',
        screenshots: [],
        logs: ['Failed to find element'],
      };
    }

    return {
      stepId: step.id,
      status: 'completed',
      startTime,
      endTime,
      duration: endTime.getTime() - startTime.getTime(),
      screenshots: step.kind === 'web.navigate' ? ['screenshot.png'] : [],
      logs: [`Executed ${step.kind} successfully`],
    };
  }

  async initialize(): Promise<void> {
    // Mock initialization
  }

  async cleanup(): Promise<void> {
    // Mock cleanup
  }

  async healthCheck(): Promise<EngineHealth> {
    return { 
      status: 'healthy', 
      lastCheck: new Date(),
      responseTime: 50,
      version: '1.0.0',
      capabilities: ['web.navigate', 'web.click', 'web.type'] 
    };
  }

  getSupportedStepKinds(): string[] {
    return ['web.navigate', 'web.click', 'web.type', 'web.wait', 'web.exists'];
  }

  validateStep(step: any): { valid: boolean; errors?: string[] } {
    if (!step.kind || !step.kind.startsWith('web.')) {
      return { valid: false, errors: ['Invalid web step kind'] };
    }
    return { valid: true };
  }
}

describe('Web Engine Integration Test', () => {
  let runnerService: RunnerService;
  let mockArtifactService: ArtifactService;
  let mockSelfHealingService: SelfHealingService;
  let mockWebEngine: MockWebEngine;
  let emittedEvents: Array<{ type: string; data: any }>;

  beforeEach(() => {
    emittedEvents = [];
    
    // Create mock services
    mockArtifactService = {
      initialize: jest.fn().mockResolvedValue(undefined),
      createArtifact: jest.fn().mockResolvedValue('artifact-path'),
      getArtifactPath: jest.fn().mockReturnValue('/mock/path'),
    } as any;

    mockSelfHealingService = {
      recordSuccessfulLocator: jest.fn().mockResolvedValue(undefined),
      suggestAlternativeLocator: jest.fn().mockResolvedValue(null),
    } as any;

    // Create actual mock web engine
    mockWebEngine = new MockWebEngine();

    // Create runner service
    runnerService = new RunnerService(mockArtifactService, mockSelfHealingService);
    runnerService.registerEngine('web', mockWebEngine);

    // Capture events
    runnerService.on(EventTypes.RUN_STARTED, (event) => {
      emittedEvents.push({ type: EventTypes.RUN_STARTED, data: event });
    });

    runnerService.on(EventTypes.RUN_FINISHED, (event) => {
      emittedEvents.push({ type: EventTypes.RUN_FINISHED, data: event });
    });

    runnerService.on(EventTypes.STEP_STARTED, (event) => {
      emittedEvents.push({ type: EventTypes.STEP_STARTED, data: event });
    });

    runnerService.on(EventTypes.STEP_ENDED, (event) => {
      emittedEvents.push({ type: EventTypes.STEP_ENDED, data: event });
    });
  });

  it('should execute web test case and emit correct events', async () => {
    // Arrange
    const testCase = {
      id: 'web-test-case',
      name: 'Web Automation Test',
      steps: [
        {
          id: 'step-navigate',
          name: 'Navigate to homepage',
          kind: 'web.navigate',
          engine: 'web',
          options: { url: 'https://example.com' },
          retryCount: 0,
          retryDelay: 1000,
        },
        {
          id: 'step-click',
          name: 'Click login button',
          kind: 'web.click',
          engine: 'web',
          locator: {
            primary: { strategy: 'css', value: '#login-btn' },
          },
          retryCount: 2,
          retryDelay: 1000,
        },
        {
          id: 'step-type',
          name: 'Enter username',
          kind: 'web.type',
          engine: 'web',
          locator: {
            primary: { strategy: 'css', value: '#username' },
          },
          options: { text: 'testuser' },
          retryCount: 0,
          retryDelay: 1000,
        },
      ],
      variables: [],
      dataTables: [],
      settings: { parallel: false },
      metadata: {
        createdAt: new Date(),
        updatedAt: new Date(),
        version: '1.0.0',
      },
    };

    // Act
    const result = await runnerService.executeTestCase(testCase, {
      screenshots: { onStep: true },
    });

    // Assert - Check execution result
    expect(result).toBeDefined();
    expect(result.runId).toBeDefined();
    expect(result.results).toHaveLength(3);

    // Assert - Check event emission sequence
    expect(emittedEvents.length).toBeGreaterThan(0);

    // Check RUN_STARTED event
    const runStartedEvents = emittedEvents.filter(e => e.type === EventTypes.RUN_STARTED);
    expect(runStartedEvents).toHaveLength(1);
    expect(runStartedEvents[0].data).toMatchObject({
      runId: result.runId,
      testCaseName: 'Web Automation Test',
      totalSteps: 3,
    });

    // Check STEP_STARTED events
    const stepStartedEvents = emittedEvents.filter(e => e.type === EventTypes.STEP_STARTED);
    expect(stepStartedEvents).toHaveLength(3);
    expect(stepStartedEvents[0].data.stepName).toBe('Navigate to homepage');
    expect(stepStartedEvents[1].data.stepName).toBe('Click login button');
    expect(stepStartedEvents[2].data.stepName).toBe('Enter username');

    // Check STEP_ENDED events
    const stepEndedEvents = emittedEvents.filter(e => e.type === EventTypes.STEP_ENDED);
    expect(stepEndedEvents).toHaveLength(3);
    stepEndedEvents.forEach(event => {
      expect(event.data).toHaveProperty('stepId');
      expect(event.data).toHaveProperty('status');
      expect(event.data).toHaveProperty('executionTime');
    });

    // Check RUN_FINISHED event
    const runFinishedEvents = emittedEvents.filter(e => e.type === EventTypes.RUN_FINISHED);
    expect(runFinishedEvents).toHaveLength(1);
    expect(runFinishedEvents[0].data).toMatchObject({
      runId: result.runId,
      status: expect.stringMatching(/^(completed|failed)$/),
      totalSteps: 3,
    });
    expect(runFinishedEvents[0].data.duration).toBeGreaterThan(0);
  }, 10000);

  it('should handle parallel execution and event emission', async () => {
    // Arrange
    const parallelTestCase = {
      id: 'parallel-test-case',
      name: 'Parallel Web Test',
      steps: [
        {
          id: 'step-check-1',
          name: 'Check element 1',
          kind: 'web.exists',
          engine: 'web',
          locator: {
            primary: { strategy: 'css', value: '#element1' },
          },
          retryCount: 0,
          retryDelay: 1000,
        },
        {
          id: 'step-check-2',
          name: 'Check element 2',
          kind: 'web.exists',
          engine: 'web',
          locator: {
            primary: { strategy: 'css', value: '#element2' },
          },
          retryCount: 0,
          retryDelay: 1000,
        },
      ],
      variables: [],
      dataTables: [],
      settings: { parallel: true },
      metadata: {
        createdAt: new Date(),
        updatedAt: new Date(),
        version: '1.0.0',
      },
    };

    // Act
    const result = await runnerService.executeTestCase(parallelTestCase, {
      maxConcurrency: 2,
    });

    // Assert
    expect(result).toBeDefined();
    expect(result.results).toHaveLength(2);

    // Check that all events were emitted
    const runStartedEvents = emittedEvents.filter(e => e.type === EventTypes.RUN_STARTED);
    const stepStartedEvents = emittedEvents.filter(e => e.type === EventTypes.STEP_STARTED);
    const stepEndedEvents = emittedEvents.filter(e => e.type === EventTypes.STEP_ENDED);
    const runFinishedEvents = emittedEvents.filter(e => e.type === EventTypes.RUN_FINISHED);

    expect(runStartedEvents).toHaveLength(1);
    expect(stepStartedEvents).toHaveLength(2);
    expect(stepEndedEvents).toHaveLength(2);
    expect(runFinishedEvents).toHaveLength(1);
  }, 10000);

  it('should handle step failures and retry logic with proper events', async () => {
    // Arrange - Create a test case that might fail
    const flakyTestCase = {
      id: 'flaky-test-case',
      name: 'Flaky Test Case',
      steps: [
        {
          id: 'step-flaky',
          name: 'Flaky click',
          kind: 'web.click', // This might fail in our mock engine
          engine: 'web',
          locator: {
            primary: { strategy: 'css', value: '#flaky-element' },
          },
          retryCount: 2,
          retryDelay: 100,
        },
      ],
      variables: [],
      dataTables: [],
      settings: { parallel: false },
      metadata: {
        createdAt: new Date(),
        updatedAt: new Date(),
        version: '1.0.0',
      },
    };

    // Act
    const result = await runnerService.executeTestCase(flakyTestCase, {
      continueOnFailure: true,
    });

    // Assert
    expect(result).toBeDefined();
    expect(result.results).toHaveLength(1);

    // Check event emission
    const stepEndedEvents = emittedEvents.filter(e => e.type === EventTypes.STEP_ENDED);
    expect(stepEndedEvents).toHaveLength(1);
    
    const stepResult = stepEndedEvents[0].data;
    expect(stepResult.status).toMatch(/^(completed|failed)$/);
    
    // Check run finished event includes proper status
    const runFinishedEvents = emittedEvents.filter(e => e.type === EventTypes.RUN_FINISHED);
    expect(runFinishedEvents).toHaveLength(1);
    expect(runFinishedEvents[0].data.status).toMatch(/^(completed|failed)$/);
  }, 10000);

  it('should emit events with correct timestamps and metadata', async () => {
    // Arrange
    const testCase = {
      id: 'timestamp-test',
      name: 'Timestamp Test',
      steps: [
        {
          id: 'step-1',
          name: 'Single step',
          kind: 'web.navigate',
          engine: 'web',
          options: { url: 'https://example.com' },
          retryCount: 0,
          retryDelay: 1000,
        },
      ],
      variables: [],
      dataTables: [],
      settings: { parallel: false },
      metadata: {
        createdAt: new Date(),
        updatedAt: new Date(),
        version: '1.0.0',
      },
    };

    const startTime = Date.now();

    // Act
    await runnerService.executeTestCase(testCase, {});

    const endTime = Date.now();

    // Assert - Check timestamps
    emittedEvents.forEach(event => {
      expect(event.data.timestamp).toBeDefined();
      const eventTime = new Date(event.data.timestamp).getTime();
      expect(eventTime).toBeGreaterThanOrEqual(startTime - 100); // Allow small margin
      expect(eventTime).toBeLessThanOrEqual(endTime + 100);
    });

    // Check event sequence
    const runStartedEvent = emittedEvents.find(e => e.type === EventTypes.RUN_STARTED);
    const runFinishedEvent = emittedEvents.find(e => e.type === EventTypes.RUN_FINISHED);
    
    expect(runStartedEvent?.data.timestamp).toBeDefined();
    expect(runFinishedEvent?.data.timestamp).toBeDefined();
    
    const startTimestamp = new Date(runStartedEvent!.data.timestamp).getTime();
    const finishTimestamp = new Date(runFinishedEvent!.data.timestamp).getTime();
    
    expect(finishTimestamp).toBeGreaterThan(startTimestamp);
  }, 10000);
}); 