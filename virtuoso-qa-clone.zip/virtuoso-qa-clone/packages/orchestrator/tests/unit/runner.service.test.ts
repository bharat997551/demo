// Mock the DSL module first
const mockValidateDSL = jest.fn();
const mockCompileToPlan = jest.fn();

jest.mock('@hybrid-qa/dsl', () => ({
  validateDSL: mockValidateDSL,
  compileToPlan: mockCompileToPlan,
}));

import { RunnerService } from '../../src/services/runner.service';
import { ArtifactService } from '../../src/services/artifact.service';
import { SelfHealingService } from '../../src/services/self-healing.service';
import { IEngine } from '../../src/interfaces/engine.interface';

describe('RunnerService - Execution Plan Building', () => {
  let runnerService: RunnerService;
  let mockArtifactService: jest.Mocked<ArtifactService>;
  let mockSelfHealingService: jest.Mocked<SelfHealingService>;
  let mockEngine: jest.Mocked<IEngine>;

  beforeEach(() => {
    // Reset mocks
    jest.clearAllMocks();

    // Mock services
    mockArtifactService = {
      initialize: jest.fn().mockResolvedValue(undefined),
      createArtifact: jest.fn().mockResolvedValue('artifact-path'),
      getArtifactPath: jest.fn().mockReturnValue('mock-path'),
    } as any;

    mockSelfHealingService = {
      recordSuccessfulLocator: jest.fn().mockResolvedValue(undefined),
      suggestAlternativeLocator: jest.fn().mockResolvedValue(null),
    } as any;

    // Mock engine
    mockEngine = {
      config: { 
        timeout: { step: 5000, navigation: 10000, retries: 3 } 
      },
      supports: jest.fn().mockReturnValue(true),
      runStep: jest.fn().mockResolvedValue({
        status: 'completed',
        executionTime: 1000,
        stepId: 'test-step',
        artifacts: [],
      }),
      initialize: jest.fn().mockResolvedValue(undefined),
      cleanup: jest.fn().mockResolvedValue(undefined),
      healthCheck: jest.fn().mockResolvedValue({ status: 'healthy' }),
      getSupportedStepKinds: jest.fn().mockReturnValue(['web.navigate', 'web.click']),
      validateStep: jest.fn().mockReturnValue({ valid: true }),
    } as any;

    runnerService = new RunnerService(mockArtifactService, mockSelfHealingService);
    runnerService.registerEngine('web', mockEngine);
  });

  describe('execution plan building', () => {
    it('should build execution plan for sequential test case', async () => {
      // Arrange
      const testCase = {
        id: 'test-case-1',
        name: 'Sequential Test',
        steps: [
          {
            id: 'step-1',
            name: 'Navigate to page',
            kind: 'web.navigate',
            engine: 'web',
            options: { url: 'https://example.com' },
            retryCount: 0,
            retryDelay: 1000,
          },
          {
            id: 'step-2',
            name: 'Click button',
            kind: 'web.click',
            engine: 'web',
            locator: {
              primary: { strategy: 'css', value: '#submit-btn' },
            },
            retryCount: 2,
            retryDelay: 1000,
          },
        ],
        variables: [
          { name: 'baseUrl', type: 'string', value: 'https://example.com' },
        ],
        dataTables: [],
        settings: { parallel: false },
        metadata: {
          createdAt: new Date(),
          updatedAt: new Date(),
          version: '1.0.0',
        },
      };

      const expectedPlan = {
        id: 'plan-1',
        name: 'Sequential Test',
        type: 'testcase',
        strategy: 'sequential',
        maxConcurrency: 1,
        steps: [
          {
            id: 'step-1',
            step: testCase.steps[0],
            dependencies: [],
            parallelGroup: undefined,
          },
          {
            id: 'step-2',
            step: testCase.steps[1],
            dependencies: ['step-1'],
            parallelGroup: undefined,
            retryPolicy: {
              maxRetries: 2,
              backoffStrategy: 'fixed',
              backoffDelay: 1000,
            },
          },
        ],
        environment: {},
        variables: { baseUrl: 'https://example.com' },
        preChecks: [],
        postChecks: [],
        compiledAt: new Date(),
        compiledFrom: 'test-case-1',
        version: '1.0.0',
      };

      mockValidateDSL.mockReturnValue({ valid: true });
      mockCompileToPlan.mockReturnValue(expectedPlan);

      // Act
      const result = await runnerService.executeTestCase(testCase, {});

      // Assert
      expect(mockValidateDSL).toHaveBeenCalledWith(testCase);
      expect(mockCompileToPlan).toHaveBeenCalledWith(testCase, expect.objectContaining({
        variables: { baseUrl: 'https://example.com' },
        engines: { web: true },
      }));
      expect(result).toBeDefined();
      expect(result.runId).toBeDefined();
      expect(mockEngine.runStep).toHaveBeenCalledTimes(2);
    });

    it('should handle variable overrides in execution plan', async () => {
      // Arrange
      const testCase = {
        id: 'test-case-variables',
        name: 'Variable Test',
        steps: [
          {
            id: 'step-1',
            name: 'Navigate with variable',
            kind: 'web.navigate',
            engine: 'web',
            options: { url: '${baseUrl}/login' },
            retryCount: 0,
            retryDelay: 1000,
          },
        ],
        variables: [
          { name: 'baseUrl', type: 'string', value: 'https://staging.example.com' },
          { name: 'username', type: 'string', value: 'testuser' },
        ],
        dataTables: [],
        settings: { parallel: false },
        metadata: {
          createdAt: new Date(),
          updatedAt: new Date(),
          version: '1.0.0',
        },
      };

      const expectedPlan = {
        id: 'plan-variables',
        name: 'Variable Test',
        type: 'testcase',
        strategy: 'sequential',
        maxConcurrency: 1,
        steps: [
          {
            id: 'step-1',
            step: testCase.steps[0],
            dependencies: [],
            parallelGroup: undefined,
          },
        ],
        environment: {},
        variables: {
          baseUrl: 'https://prod.example.com', // Override value
          username: 'testuser',
        },
        preChecks: [],
        postChecks: [],
        compiledAt: new Date(),
        compiledFrom: 'test-case-variables',
        version: '1.0.0',
      };

      mockValidateDSL.mockReturnValue({ valid: true });
      mockCompileToPlan.mockReturnValue(expectedPlan);

      // Act - Override variables in config
      const result = await runnerService.executeTestCase(testCase, {
        variables: { baseUrl: 'https://prod.example.com' },
      });

      // Assert
      expect(mockCompileToPlan).toHaveBeenCalledWith(testCase, expect.objectContaining({
        variables: expect.objectContaining({
          baseUrl: 'https://prod.example.com', // Should be overridden
          username: 'testuser',
        }),
        engines: { web: true },
      }));
      expect(result).toBeDefined();
    });

    it('should throw error when DSL validation fails', async () => {
      // Arrange
      const invalidTestCase = {
        id: 'invalid-test',
        name: 'Invalid Test',
        // Missing required fields like steps
      };

      mockValidateDSL.mockReturnValue({
        valid: false,
        errors: [{ message: 'Missing required field: steps', path: 'steps' }],
      });

      // Act & Assert
      await expect(
        runnerService.executeTestCase(invalidTestCase as any, {})
      ).rejects.toThrow();

      expect(mockValidateDSL).toHaveBeenCalledWith(invalidTestCase);
      expect(mockCompileToPlan).not.toHaveBeenCalled();
    });

    it('should handle retry policies in execution plan', async () => {
      // Arrange
      const testCase = {
        id: 'test-case-retry',
        name: 'Retry Test',
        steps: [
          {
            id: 'step-1',
            name: 'Flaky step',
            kind: 'web.click',
            engine: 'web',
            locator: {
              primary: { strategy: 'css', value: '#flaky-button' },
            },
            retryCount: 3,
            retryDelay: 2000,
          },
        ],
        variables: [],
        dataTables: [],
        settings: { parallel: false },
        metadata: {
          createdAt: new Date(),
          updatedAt: new Date(),
          version: '1.0.0',
        },
      };

      const expectedPlan = {
        id: 'plan-retry',
        name: 'Retry Test',
        type: 'testcase',
        strategy: 'sequential',
        maxConcurrency: 1,
        steps: [
          {
            id: 'step-1',
            step: testCase.steps[0],
            dependencies: [],
            parallelGroup: undefined,
            retryPolicy: {
              maxRetries: 3,
              backoffStrategy: 'fixed',
              backoffDelay: 2000,
            },
          },
        ],
        environment: {},
        variables: {},
        preChecks: [],
        postChecks: [],
        compiledAt: new Date(),
        compiledFrom: 'test-case-retry',
        version: '1.0.0',
      };

      mockValidateDSL.mockReturnValue({ valid: true });
      mockCompileToPlan.mockReturnValue(expectedPlan);

      // Act
      const result = await runnerService.executeTestCase(testCase, {});

      // Assert
      expect(mockCompileToPlan).toHaveBeenCalledWith(testCase, expect.objectContaining({
        variables: {},
        engines: { web: true },
      }));
      expect(result).toBeDefined();
      expect(mockEngine.runStep).toHaveBeenCalledTimes(1);
    });
  });
}); 