import { z } from 'zod';

/**
 * Base event schema with common fields
 */
const BaseEventSchema = z.object({
  type: z.string(),
  timestamp: z.date(),
  runId: z.string().uuid(),
});

/**
 * Run lifecycle events
 */
export const RunStartedEventSchema = BaseEventSchema.extend({
  type: z.literal('run:started'),
  testCaseId: z.string().uuid().optional(),
  testSuiteId: z.string().uuid().optional(),
  totalSteps: z.number().min(0),
  environment: z.record(z.any()).optional(),
  tags: z.array(z.string()).optional(),
});

export const RunFinishedEventSchema = BaseEventSchema.extend({
  type: z.literal('run:finished'),
  status: z.enum(['completed', 'failed', 'cancelled']),
  duration: z.number().min(0),
  totalSteps: z.number().min(0),
  passedSteps: z.number().min(0),
  failedSteps: z.number().min(0),
  skippedSteps: z.number().min(0),
  artifacts: z.array(z.string()).optional(),
  summary: z.string().optional(),
});

/**
 * Step lifecycle events
 */
export const StepStartedEventSchema = BaseEventSchema.extend({
  type: z.literal('step:started'),
  stepId: z.string().uuid(),
  stepName: z.string(),
  stepKind: z.string(),
  engine: z.string(),
  stepNumber: z.number().min(1),
  totalSteps: z.number().min(1),
  retryAttempt: z.number().min(0).default(0),
});

export const StepEndedEventSchema = BaseEventSchema.extend({
  type: z.literal('step:ended'),
  stepId: z.string().uuid(),
  stepName: z.string(),
  status: z.enum(['completed', 'failed', 'skipped']),
  duration: z.number().min(0),
  retryAttempt: z.number().min(0).default(0),
  error: z.string().optional(),
  extractedData: z.any().optional(),
  screenshots: z.array(z.string()).optional(),
  healing: z.object({
    locatorUsed: z.string().optional(),
    alternativesAttempted: z.array(z.string()).optional(),
    newLocatorLearned: z.string().optional(),
  }).optional(),
});

/**
 * Artifact events
 */
export const ArtifactCreatedEventSchema = BaseEventSchema.extend({
  type: z.literal('artifact:created'),
  artifactId: z.string().uuid(),
  artifactType: z.enum(['screenshot', 'video', 'log', 'report', 'data']),
  filename: z.string(),
  path: z.string(),
  size: z.number().min(0),
  stepId: z.string().uuid().optional(),
  metadata: z.record(z.any()).optional(),
});

/**
 * Error events
 */
export const ErrorEventSchema = BaseEventSchema.extend({
  type: z.literal('error'),
  error: z.object({
    message: z.string(),
    code: z.string().optional(),
    stack: z.string().optional(),
  }),
  stepId: z.string().uuid().optional(),
  severity: z.enum(['low', 'medium', 'high', 'critical']).default('medium'),
  context: z.record(z.any()).optional(),
});

/**
 * Log events
 */
export const LogEventSchema = BaseEventSchema.extend({
  type: z.literal('log'),
  level: z.enum(['debug', 'info', 'warn', 'error']),
  message: z.string(),
  stepId: z.string().uuid().optional(),
  metadata: z.record(z.any()).optional(),
});

/**
 * Engine events
 */
export const EngineHealthEventSchema = BaseEventSchema.extend({
  type: z.literal('engine:health'),
  engineId: z.string(),
  engineType: z.enum(['web', 'desktop', 'mainframe', 'api']),
  status: z.enum(['healthy', 'degraded', 'unhealthy', 'offline']),
  responseTime: z.number().min(0).optional(),
  message: z.string().optional(),
});

/**
 * Union of all event types
 */
export const EventSchema = z.discriminatedUnion('type', [
  RunStartedEventSchema,
  RunFinishedEventSchema,
  StepStartedEventSchema,
  StepEndedEventSchema,
  ArtifactCreatedEventSchema,
  ErrorEventSchema,
  LogEventSchema,
  EngineHealthEventSchema,
]);

/**
 * Type exports
 */
export type RunStartedEvent = z.infer<typeof RunStartedEventSchema>;
export type RunFinishedEvent = z.infer<typeof RunFinishedEventSchema>;
export type StepStartedEvent = z.infer<typeof StepStartedEventSchema>;
export type StepEndedEvent = z.infer<typeof StepEndedEventSchema>;
export type ArtifactCreatedEvent = z.infer<typeof ArtifactCreatedEventSchema>;
export type ErrorEvent = z.infer<typeof ErrorEventSchema>;
export type LogEvent = z.infer<typeof LogEventSchema>;
export type EngineHealthEvent = z.infer<typeof EngineHealthEventSchema>;

/**
 * Union type for all events
 */
export type OrchestratorEvent = z.infer<typeof EventSchema>;

/**
 * Event type enumeration
 */
export const EventTypes = {
  RUN_STARTED: 'run:started' as const,
  RUN_FINISHED: 'run:finished' as const,
  STEP_STARTED: 'step:started' as const,
  STEP_ENDED: 'step:ended' as const,
  ARTIFACT_CREATED: 'artifact:created' as const,
  ERROR: 'error' as const,
  LOG: 'log' as const,
  ENGINE_HEALTH: 'engine:health' as const,
} as const;

/**
 * WebSocket message wrapper
 */
export const WebSocketMessageSchema = z.object({
  id: z.string().uuid(),
  event: EventSchema,
  clientId: z.string().optional(),
  timestamp: z.date().default(() => new Date()),
});

export type WebSocketMessage = z.infer<typeof WebSocketMessageSchema>;

/**
 * Event validation utility
 */
export class EventValidator {
  /**
   * Validate an event against its schema
   */
  static validate(event: unknown): { valid: boolean; data?: OrchestratorEvent; error?: string } {
    try {
      const validatedEvent = EventSchema.parse(event);
      return { valid: true, data: validatedEvent };
    } catch (error) {
      return {
        valid: false,
        error: error instanceof Error ? error.message : 'Invalid event format'
      };
    }
  }

  /**
   * Validate a WebSocket message
   */
  static validateMessage(message: unknown): { valid: boolean; data?: WebSocketMessage; error?: string } {
    try {
      const validatedMessage = WebSocketMessageSchema.parse(message);
      return { valid: true, data: validatedMessage };
    } catch (error) {
      return {
        valid: false,
        error: error instanceof Error ? error.message : 'Invalid message format'
      };
    }
  }
} 