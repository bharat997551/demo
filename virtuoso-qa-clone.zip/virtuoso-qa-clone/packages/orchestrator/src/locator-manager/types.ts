export interface LocatorVariant {
  selector: string;
  type: 'css' | 'xpath' | 'text' | 'id' | 'class' | 'data-testid' | 'aria-label' | 'role';
  score: number;
  metadata?: {
    visibility?: boolean;
    boundingBox?: { x: number; y: number; width: number; height: number };
    attributes?: Record<string, string>;
    textContent?: string;
    tagName?: string;
  };
}

export interface LocatorHistory {
  id: string;
  testId: string;
  stepId: string;
  timestamp: Date;
  success: boolean;
  locatorUsed: LocatorVariant;
  alternativesAttempted?: LocatorVariant[];
  domSnapshot?: string;
  windowHierarchy?: any;
  executionTimeMs: number;
}

export interface HealedLocator {
  id: string;
  testId: string;
  stepId: string;
  originalLocator: LocatorVariant;
  healedLocator: LocatorVariant;
  confidence: number;
  reason: string;
  diff: {
    before: string;
    after: string;
    changes: Array<{
      type: 'addition' | 'deletion' | 'modification';
      path: string;
      value: string;
    }>;
  };
  timestamp: Date;
  accepted: boolean;
  acceptedBy?: string;
  acceptedAt?: Date;
}

export interface LocatorContext {
  parentSelector?: string;
  siblingSelectors?: string[];
  pageUrl?: string;
  windowTitle?: string;
  domDepth?: number;
  nearbyText?: string[];
}

export interface SimilarityScore {
  textSimilarity: number;
  structuralSimilarity: number;
  attributeSimilarity: number;
  contextSimilarity: number;
  overall: number;
}

export interface LocatorPriorityList {
  primary: LocatorVariant;
  alternatives: LocatorVariant[];
  context: LocatorContext;
  lastSuccessful?: LocatorVariant;
  lastUpdated: Date;
}

export interface LocatorHealingConfig {
  enableAutoHealing: boolean;
  maxAlternativesToTry: number;
  minConfidenceThreshold: number;
  recordDomSnapshots: boolean;
  recordWindowHierarchy: boolean;
  textSimilarityWeight: number;
  structuralSimilarityWeight: number;
  attributeSimilarityWeight: number;
  contextSimilarityWeight: number;
}

export interface LocatorHealingResult {
  success: boolean;
  locatorUsed?: LocatorVariant;
  healingSuggestion?: HealedLocator;
  attemptedLocators: Array<{
    locator: LocatorVariant;
    success: boolean;
    error?: string;
    similarityScore?: SimilarityScore;
  }>;
  executionTimeMs: number;
} 