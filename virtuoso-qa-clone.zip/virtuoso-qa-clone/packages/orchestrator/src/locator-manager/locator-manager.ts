import { v4 as uuidv4 } from 'uuid';
import * as levenshtein from 'fast-levenshtein';
import { EventEmitter } from 'events';
import {
  LocatorVariant,
  LocatorHistory,
  HealedLocator,
  LocatorContext,
  SimilarityScore,
  LocatorPriorityList,
  LocatorHealingConfig,
  LocatorHealingResult
} from './types';
import { LocatorStorage } from './storage';
import { SimilarityEngine } from './similarity-engine';
import { LocatorGenerator } from './locator-generator';

export class LocatorManager extends EventEmitter {
  private storage: LocatorStorage;
  private similarityEngine: SimilarityEngine;
  private locatorGenerator: LocatorGenerator;
  private config: LocatorHealingConfig;

  constructor(config?: Partial<LocatorHealingConfig>) {
    super();
    this.config = {
      enableAutoHealing: true,
      maxAlternativesToTry: 10,
      minConfidenceThreshold: 0.7,
      recordDomSnapshots: true,
      recordWindowHierarchy: true,
      textSimilarityWeight: 0.3,
      structuralSimilarityWeight: 0.3,
      attributeSimilarityWeight: 0.2,
      contextSimilarityWeight: 0.2,
      ...config
    };

    this.storage = new LocatorStorage();
    this.similarityEngine = new SimilarityEngine(this.config);
    this.locatorGenerator = new LocatorGenerator();
  }

  async recordSuccess(
    testId: string,
    stepId: string,
    locator: LocatorVariant,
    context: {
      domSnapshot?: string;
      windowHierarchy?: any;
      executionTimeMs: number;
    }
  ): Promise<void> {
    const history: LocatorHistory = {
      id: uuidv4(),
      testId,
      stepId,
      timestamp: new Date(),
      success: true,
      locatorUsed: locator,
      domSnapshot: this.config.recordDomSnapshots ? context.domSnapshot : undefined,
      windowHierarchy: this.config.recordWindowHierarchy ? context.windowHierarchy : undefined,
      executionTimeMs: context.executionTimeMs
    };

    await this.storage.saveHistory(history);
    await this.updatePriorityList(testId, stepId, locator);
    
    this.emit('locatorSuccess', { testId, stepId, locator });
  }

  async recordFailure(
    testId: string,
    stepId: string,
    failedLocator: LocatorVariant,
    attemptedAlternatives: LocatorVariant[],
    context: {
      domSnapshot?: string;
      windowHierarchy?: any;
      executionTimeMs: number;
    }
  ): Promise<void> {
    const history: LocatorHistory = {
      id: uuidv4(),
      testId,
      stepId,
      timestamp: new Date(),
      success: false,
      locatorUsed: failedLocator,
      alternativesAttempted: attemptedAlternatives,
      domSnapshot: this.config.recordDomSnapshots ? context.domSnapshot : undefined,
      windowHierarchy: this.config.recordWindowHierarchy ? context.windowHierarchy : undefined,
      executionTimeMs: context.executionTimeMs
    };

    await this.storage.saveHistory(history);
    this.emit('locatorFailure', { testId, stepId, failedLocator, attemptedAlternatives });
  }

  async attemptHealing(
    testId: string,
    stepId: string,
    originalLocator: LocatorVariant,
    currentContext: {
      domSnapshot?: string;
      windowHierarchy?: any;
      pageUrl?: string;
      windowTitle?: string;
    }
  ): Promise<LocatorHealingResult> {
    const startTime = Date.now();
    const attemptedLocators: LocatorHealingResult['attemptedLocators'] = [];

    if (!this.config.enableAutoHealing) {
      return {
        success: false,
        attemptedLocators,
        executionTimeMs: Date.now() - startTime
      };
    }

    // Get priority list and historical data
    const priorityList = await this.storage.getPriorityList(testId, stepId);
    const recentHistory = await this.storage.getRecentHistory(testId, stepId, 10);

    // Generate alternative locators based on current context
    const alternatives = await this.generateAlternatives(
      originalLocator,
      currentContext,
      priorityList,
      recentHistory
    );

    // Try alternatives in order
    for (const alternative of alternatives.slice(0, this.config.maxAlternativesToTry)) {
      const similarityScore = await this.similarityEngine.calculateScore(
        originalLocator,
        alternative,
        currentContext
      );

      attemptedLocators.push({
        locator: alternative,
        success: false,
        similarityScore
      });

      // Emit event for engines to try the locator
      const result = await this.tryLocator(testId, stepId, alternative);
      
      if (result.success) {
        attemptedLocators[attemptedLocators.length - 1].success = true;

        // Create healing suggestion if confidence is high enough
        if (similarityScore.overall >= this.config.minConfidenceThreshold) {
          const healingSuggestion = await this.createHealingSuggestion(
            testId,
            stepId,
            originalLocator,
            alternative,
            similarityScore,
            currentContext
          );

          return {
            success: true,
            locatorUsed: alternative,
            healingSuggestion,
            attemptedLocators,
            executionTimeMs: Date.now() - startTime
          };
        }

        return {
          success: true,
          locatorUsed: alternative,
          attemptedLocators,
          executionTimeMs: Date.now() - startTime
        };
      }

      attemptedLocators[attemptedLocators.length - 1].error = result.error;
    }

    return {
      success: false,
      attemptedLocators,
      executionTimeMs: Date.now() - startTime
    };
  }

  private async generateAlternatives(
    originalLocator: LocatorVariant,
    currentContext: any,
    priorityList: LocatorPriorityList | null,
    recentHistory: LocatorHistory[]
  ): Promise<LocatorVariant[]> {
    const alternatives: LocatorVariant[] = [];

    // Add alternatives from priority list
    if (priorityList) {
      alternatives.push(...priorityList.alternatives);
    }

    // Generate new alternatives based on current DOM/window
    const generated = await this.locatorGenerator.generate(
      originalLocator,
      currentContext.domSnapshot || currentContext.windowHierarchy
    );
    alternatives.push(...generated);

    // Add successful locators from history
    const historicalSuccesses = recentHistory
      .filter(h => h.success)
      .map(h => h.locatorUsed);
    alternatives.push(...historicalSuccesses);

    // Remove duplicates and sort by score
    const uniqueAlternatives = this.deduplicateLocators(alternatives);
    return uniqueAlternatives.sort((a, b) => b.score - a.score);
  }

  private async createHealingSuggestion(
    testId: string,
    stepId: string,
    originalLocator: LocatorVariant,
    healedLocator: LocatorVariant,
    similarityScore: SimilarityScore,
    context: any
  ): Promise<HealedLocator> {
    const diff = this.generateDiff(originalLocator, healedLocator);
    
    const suggestion: HealedLocator = {
      id: uuidv4(),
      testId,
      stepId,
      originalLocator,
      healedLocator,
      confidence: similarityScore.overall,
      reason: this.generateHealingReason(originalLocator, healedLocator, similarityScore),
      diff,
      timestamp: new Date(),
      accepted: false
    };

    await this.storage.saveHealedLocator(suggestion);
    this.emit('healingSuggestion', suggestion);

    return suggestion;
  }

  async acceptHealing(healingId: string, acceptedBy: string): Promise<void> {
    const healing = await this.storage.getHealedLocator(healingId);
    if (!healing) {
      throw new Error(`Healed locator not found: ${healingId}`);
    }

    healing.accepted = true;
    healing.acceptedBy = acceptedBy;
    healing.acceptedAt = new Date();

    await this.storage.updateHealedLocator(healing);
    
    // Update priority list with the healed locator
    await this.updatePriorityList(
      healing.testId,
      healing.stepId,
      healing.healedLocator,
      true
    );

    this.emit('healingAccepted', healing);
  }

  async getHealedLocators(
    filter?: {
      testId?: string;
      accepted?: boolean;
      minConfidence?: number;
    }
  ): Promise<HealedLocator[]> {
    return this.storage.getHealedLocators(filter);
  }

  async getPriorityList(testId: string, stepId: string): Promise<LocatorPriorityList | null> {
    return this.storage.getPriorityList(testId, stepId);
  }

  private async updatePriorityList(
    testId: string,
    stepId: string,
    successfulLocator: LocatorVariant,
    isPrimary: boolean = false
  ): Promise<void> {
    const existing = await this.storage.getPriorityList(testId, stepId);
    
    if (!existing) {
      // Create new priority list
      const priorityList: LocatorPriorityList = {
        primary: successfulLocator,
        alternatives: [],
        context: {},
        lastSuccessful: successfulLocator,
        lastUpdated: new Date()
      };
      await this.storage.savePriorityList(testId, stepId, priorityList);
    } else {
      // Update existing priority list
      if (isPrimary) {
        existing.primary = successfulLocator;
      }
      
      existing.lastSuccessful = successfulLocator;
      existing.lastUpdated = new Date();
      
      // Add to alternatives if not already present
      const isNew = !existing.alternatives.some(
        alt => alt.selector === successfulLocator.selector && alt.type === successfulLocator.type
      );
      
      if (isNew && !isPrimary) {
        existing.alternatives.push(successfulLocator);
        // Keep only top 20 alternatives
        existing.alternatives.sort((a, b) => b.score - a.score);
        existing.alternatives = existing.alternatives.slice(0, 20);
      }
      
      await this.storage.savePriorityList(testId, stepId, existing);
    }
  }

  private async tryLocator(
    testId: string,
    stepId: string,
    locator: LocatorVariant
  ): Promise<{ success: boolean; error?: string }> {
    return new Promise((resolve) => {
      const timeout = setTimeout(() => {
        resolve({ success: false, error: 'Timeout' });
      }, 5000);

      this.once(`locatorTryResult:${testId}:${stepId}`, (result) => {
        clearTimeout(timeout);
        resolve(result);
      });

      this.emit('tryLocator', { testId, stepId, locator });
    });
  }

  private deduplicateLocators(locators: LocatorVariant[]): LocatorVariant[] {
    const seen = new Set<string>();
    return locators.filter(loc => {
      const key = `${loc.type}:${loc.selector}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }

  private generateDiff(original: LocatorVariant, healed: LocatorVariant): HealedLocator['diff'] {
    const changes: HealedLocator['diff']['changes'] = [];

    if (original.type !== healed.type) {
      changes.push({
        type: 'modification',
        path: 'type',
        value: `${original.type} → ${healed.type}`
      });
    }

    if (original.selector !== healed.selector) {
      // Simple diff for selectors
      const originalParts = original.selector.split(/[\s>+~]/);
      const healedParts = healed.selector.split(/[\s>+~]/);

      originalParts.forEach((part, i) => {
        if (part !== healedParts[i]) {
          changes.push({
            type: healedParts[i] ? 'modification' : 'deletion',
            path: `selector.part[${i}]`,
            value: healedParts[i] || part
          });
        }
      });

      healedParts.slice(originalParts.length).forEach((part, i) => {
        changes.push({
          type: 'addition',
          path: `selector.part[${originalParts.length + i}]`,
          value: part
        });
      });
    }

    return {
      before: `${original.type}: ${original.selector}`,
      after: `${healed.type}: ${healed.selector}`,
      changes
    };
  }

  private generateHealingReason(
    original: LocatorVariant,
    healed: LocatorVariant,
    score: SimilarityScore
  ): string {
    const reasons: string[] = [];

    if (score.textSimilarity > 0.8) {
      reasons.push('Text content remains similar');
    }
    if (score.structuralSimilarity > 0.8) {
      reasons.push('DOM structure is preserved');
    }
    if (score.attributeSimilarity > 0.8) {
      reasons.push('Element attributes match');
    }
    if (score.contextSimilarity > 0.8) {
      reasons.push('Surrounding context is consistent');
    }

    if (original.type !== healed.type) {
      reasons.push(`Locator type changed from ${original.type} to ${healed.type}`);
    }

    return reasons.join('. ') || 'Element identified with high confidence';
  }

  async cleanup(): Promise<void> {
    await this.storage.cleanup();
    this.removeAllListeners();
  }
} 