import {
  LocatorHistory,
  HealedLocator,
  LocatorPriorityList
} from './types';

// In-memory storage implementation
// In production, this would use a database (e.g., Prisma)
export class LocatorStorage {
  private history: Map<string, LocatorHistory[]> = new Map();
  private healedLocators: Map<string, HealedLocator> = new Map();
  private priorityLists: Map<string, LocatorPriorityList> = new Map();

  private getKey(testId: string, stepId: string): string {
    return `${testId}:${stepId}`;
  }

  async saveHistory(history: LocatorHistory): Promise<void> {
    const key = this.getKey(history.testId, history.stepId);
    const existing = this.history.get(key) || [];
    existing.push(history);
    
    // Keep only last 100 entries per step
    if (existing.length > 100) {
      existing.splice(0, existing.length - 100);
    }
    
    this.history.set(key, existing);
  }

  async getRecentHistory(
    testId: string,
    stepId: string,
    limit: number
  ): Promise<LocatorHistory[]> {
    const key = this.getKey(testId, stepId);
    const history = this.history.get(key) || [];
    return history.slice(-limit);
  }

  async saveHealedLocator(healed: HealedLocator): Promise<void> {
    this.healedLocators.set(healed.id, healed);
  }

  async getHealedLocator(id: string): Promise<HealedLocator | null> {
    return this.healedLocators.get(id) || null;
  }

  async updateHealedLocator(healed: HealedLocator): Promise<void> {
    this.healedLocators.set(healed.id, healed);
  }

  async getHealedLocators(filter?: {
    testId?: string;
    accepted?: boolean;
    minConfidence?: number;
  }): Promise<HealedLocator[]> {
    let results = Array.from(this.healedLocators.values());

    if (filter) {
      if (filter.testId) {
        results = results.filter(h => h.testId === filter.testId);
      }
      if (filter.accepted !== undefined) {
        results = results.filter(h => h.accepted === filter.accepted);
      }
      if (filter.minConfidence !== undefined) {
        results = results.filter(h => h.confidence >= filter.minConfidence!);
      }
    }

    // Sort by timestamp, newest first
    return results.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }

  async savePriorityList(
    testId: string,
    stepId: string,
    priorityList: LocatorPriorityList
  ): Promise<void> {
    const key = this.getKey(testId, stepId);
    this.priorityLists.set(key, priorityList);
  }

  async getPriorityList(
    testId: string,
    stepId: string
  ): Promise<LocatorPriorityList | null> {
    const key = this.getKey(testId, stepId);
    return this.priorityLists.get(key) || null;
  }

  async getHistoryStats(testId?: string): Promise<{
    totalAttempts: number;
    successRate: number;
    averageExecutionTime: number;
    mostFailedSteps: Array<{ stepId: string; failures: number }>;
  }> {
    let allHistory: LocatorHistory[] = [];

    if (testId) {
      // Get history for specific test
      for (const [key, history] of this.history.entries()) {
        if (key.startsWith(testId + ':')) {
          allHistory.push(...history);
        }
      }
    } else {
      // Get all history
      for (const history of this.history.values()) {
        allHistory.push(...history);
      }
    }

    const totalAttempts = allHistory.length;
    const successfulAttempts = allHistory.filter(h => h.success).length;
    const successRate = totalAttempts > 0 ? successfulAttempts / totalAttempts : 0;
    
    const totalExecutionTime = allHistory.reduce((sum, h) => sum + h.executionTimeMs, 0);
    const averageExecutionTime = totalAttempts > 0 ? totalExecutionTime / totalAttempts : 0;

    // Count failures by step
    const failuresByStep = new Map<string, number>();
    allHistory.filter(h => !h.success).forEach(h => {
      const key = h.stepId;
      failuresByStep.set(key, (failuresByStep.get(key) || 0) + 1);
    });

    const mostFailedSteps = Array.from(failuresByStep.entries())
      .map(([stepId, failures]) => ({ stepId, failures }))
      .sort((a, b) => b.failures - a.failures)
      .slice(0, 10);

    return {
      totalAttempts,
      successRate,
      averageExecutionTime,
      mostFailedSteps
    };
  }

  async cleanup(): Promise<void> {
    // Clear old data (older than 30 days)
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    // Clean history
    for (const [key, history] of this.history.entries()) {
      const filtered = history.filter(h => h.timestamp > thirtyDaysAgo);
      if (filtered.length === 0) {
        this.history.delete(key);
      } else if (filtered.length < history.length) {
        this.history.set(key, filtered);
      }
    }

    // Clean healed locators
    for (const [id, healed] of this.healedLocators.entries()) {
      if (healed.timestamp < thirtyDaysAgo) {
        this.healedLocators.delete(id);
      }
    }
  }
} 