import { parse as parseHTML } from 'node-html-parser';
import { LocatorVariant } from './types';

export class LocatorGenerator {
  async generate(
    originalLocator: LocatorVariant,
    contextData: string | any
  ): Promise<LocatorVariant[]> {
    const alternatives: LocatorVariant[] = [];

    // Check if it's DOM snapshot or window hierarchy
    if (typeof contextData === 'string') {
      // DOM snapshot - generate web locators
      alternatives.push(...this.generateWebLocators(originalLocator, contextData));
    } else if (contextData && typeof contextData === 'object') {
      // Window hierarchy - generate desktop locators
      alternatives.push(...this.generateDesktopLocators(originalLocator, contextData));
    }

    return alternatives;
  }

  private generateWebLocators(
    originalLocator: LocatorVariant,
    domSnapshot: string
  ): LocatorVariant[] {
    const alternatives: LocatorVariant[] = [];

    try {
      const dom = parseHTML(domSnapshot);
      let element: any = null;

      // Try to find the original element
      switch (originalLocator.type) {
        case 'css':
          element = dom.querySelector(originalLocator.selector);
          break;
        case 'id':
          element = dom.querySelector(`#${originalLocator.selector}`);
          break;
        case 'class':
          element = dom.querySelector(`.${originalLocator.selector}`);
          break;
        case 'data-testid':
          element = dom.querySelector(`[data-testid="${originalLocator.selector}"]`);
          break;
        case 'aria-label':
          element = dom.querySelector(`[aria-label="${originalLocator.selector}"]`);
          break;
        case 'role':
          element = dom.querySelector(`[role="${originalLocator.selector}"]`);
          break;
        case 'text':
          // Find element by text content
          element = this.findElementByText(dom, originalLocator.selector);
          break;
      }

      if (!element) {
        // If original element not found, try fuzzy matching
        element = this.findSimilarElement(dom, originalLocator);
      }

      if (element) {
        // Generate various locator strategies for the element
        alternatives.push(...this.generateLocatorsForElement(element));
      }

      // Add generic alternatives based on original type
      alternatives.push(...this.generateGenericAlternatives(originalLocator));

    } catch (error) {
      console.error('Error generating web locators:', error);
    }

    return this.scoreAndSort(alternatives);
  }

  private generateDesktopLocators(
    originalLocator: LocatorVariant,
    windowHierarchy: any
  ): LocatorVariant[] {
    const alternatives: LocatorVariant[] = [];

    // Generate alternatives based on window control properties
    if (originalLocator.metadata?.attributes) {
      const attrs = originalLocator.metadata.attributes;

      // Try different control identification strategies
      if (attrs.name) {
        alternatives.push({
          selector: attrs.name,
          type: 'id',
          score: 0.9,
          metadata: originalLocator.metadata
        });
      }

      if (attrs.automationId) {
        alternatives.push({
          selector: attrs.automationId,
          type: 'id',
          score: 0.95,
          metadata: originalLocator.metadata
        });
      }

      if (attrs.className) {
        alternatives.push({
          selector: attrs.className,
          type: 'class',
          score: 0.7,
          metadata: originalLocator.metadata
        });
      }

      if (attrs.text) {
        alternatives.push({
          selector: attrs.text,
          type: 'text',
          score: 0.8,
          metadata: originalLocator.metadata
        });
      }
    }

    return this.scoreAndSort(alternatives);
  }

  private generateLocatorsForElement(element: any): LocatorVariant[] {
    const locators: LocatorVariant[] = [];
    const metadata = this.extractElementMetadata(element);

    // ID selector (highest priority)
    const id = element.getAttribute('id');
    if (id) {
      locators.push({
        selector: id,
        type: 'id',
        score: 1.0,
        metadata
      });
    }

    // Data-testid selector (very high priority)
    const testId = element.getAttribute('data-testid');
    if (testId) {
      locators.push({
        selector: testId,
        type: 'data-testid',
        score: 0.95,
        metadata
      });
    }

    // Aria-label selector
    const ariaLabel = element.getAttribute('aria-label');
    if (ariaLabel) {
      locators.push({
        selector: ariaLabel,
        type: 'aria-label',
        score: 0.85,
        metadata
      });
    }

    // Role selector
    const role = element.getAttribute('role');
    if (role) {
      locators.push({
        selector: role,
        type: 'role',
        score: 0.7,
        metadata
      });
    }

    // Class selector
    const className = element.getAttribute('class');
    if (className) {
      const classes = className.split(' ').filter((c: string) => c.trim());
      if (classes.length > 0) {
        locators.push({
          selector: classes[0], // Use first class
          type: 'class',
          score: 0.6,
          metadata
        });
      }
    }

    // Text content selector
    const textContent = element.textContent?.trim();
    if (textContent && textContent.length < 100) {
      locators.push({
        selector: textContent,
        type: 'text',
        score: 0.7,
        metadata
      });
    }

    // CSS selector using tag and attributes
    const cssSelector = this.buildCssSelector(element);
    if (cssSelector) {
      locators.push({
        selector: cssSelector,
        type: 'css',
        score: 0.5,
        metadata
      });
    }

    // XPath selector as fallback
    const xpathSelector = this.buildXPathSelector(element);
    if (xpathSelector) {
      locators.push({
        selector: xpathSelector,
        type: 'xpath',
        score: 0.4,
        metadata
      });
    }

    return locators;
  }

  private buildCssSelector(element: any): string {
    const tag = element.tagName.toLowerCase();
    const attributes: string[] = [];

    // Build attribute selectors
    const attrs = element.attributes || {};
    for (const [key, value] of Object.entries(attrs)) {
      if (key !== 'class' && key !== 'id' && value) {
        attributes.push(`[${key}="${value}"]`);
      }
    }

    // Build selector
    let selector = tag;
    if (attributes.length > 0) {
      selector += attributes.slice(0, 2).join(''); // Use max 2 attributes
    }

    // Add nth-child if needed
    const parent = element.parentElement;
    if (parent) {
      const siblings = parent.querySelectorAll(selector);
      if (siblings.length > 1) {
        const index = Array.from(siblings).indexOf(element) + 1;
        selector += `:nth-child(${index})`;
      }
    }

    return selector;
  }

  private buildXPathSelector(element: any): string {
    const tag = element.tagName.toLowerCase();
    const textContent = element.textContent?.trim();

    if (textContent && textContent.length < 50) {
      return `//${tag}[contains(text(),'${textContent.substring(0, 30)}')]`;
    }

    return `//${tag}`;
  }

  private extractElementMetadata(element: any): LocatorVariant['metadata'] {
    return {
      tagName: element.tagName?.toLowerCase(),
      textContent: element.textContent?.trim().substring(0, 100),
      attributes: element.attributes || {},
      visibility: true // In real implementation, check computed styles
    };
  }

  private findElementByText(dom: any, text: string): any {
    // Simple text search implementation
    const allElements = dom.querySelectorAll('*');
    
    for (const element of allElements) {
      if (element.textContent?.trim() === text) {
        return element;
      }
    }

    // Try partial match
    for (const element of allElements) {
      if (element.textContent?.includes(text)) {
        return element;
      }
    }

    return null;
  }

  private findSimilarElement(dom: any, originalLocator: LocatorVariant): any {
    // Try to find elements with similar attributes or text
    const allElements = dom.querySelectorAll('*');

    if (originalLocator.metadata?.textContent) {
      // Find by similar text
      const targetText = originalLocator.metadata.textContent.toLowerCase();
      
      for (const element of allElements) {
        const elementText = element.textContent?.toLowerCase();
        if (elementText && this.isSimilarText(targetText, elementText)) {
          return element;
        }
      }
    }

    if (originalLocator.metadata?.tagName) {
      // Find by same tag and similar attributes
      const sameTagElements = dom.querySelectorAll(originalLocator.metadata.tagName);
      
      for (const element of sameTagElements) {
        if (this.hasSimilarAttributes(
          originalLocator.metadata.attributes || {},
          element.attributes || {}
        )) {
          return element;
        }
      }
    }

    return null;
  }

  private isSimilarText(text1: string, text2: string): boolean {
    // Simple similarity check
    const distance = this.levenshteinDistance(text1, text2);
    const maxLength = Math.max(text1.length, text2.length);
    const similarity = 1 - (distance / maxLength);
    return similarity > 0.8;
  }

  private hasSimilarAttributes(attrs1: any, attrs2: any): boolean {
    const keys1 = Object.keys(attrs1);
    const keys2 = Object.keys(attrs2);
    
    let matches = 0;
    for (const key of keys1) {
      if (attrs2[key] === attrs1[key]) {
        matches++;
      }
    }

    const totalKeys = new Set([...keys1, ...keys2]).size;
    return totalKeys > 0 && (matches / totalKeys) > 0.5;
  }

  private levenshteinDistance(str1: string, str2: string): number {
    const matrix: number[][] = [];

    for (let i = 0; i <= str2.length; i++) {
      matrix[i] = [i];
    }

    for (let j = 0; j <= str1.length; j++) {
      matrix[0][j] = j;
    }

    for (let i = 1; i <= str2.length; i++) {
      for (let j = 1; j <= str1.length; j++) {
        if (str2.charAt(i - 1) === str1.charAt(j - 1)) {
          matrix[i][j] = matrix[i - 1][j - 1];
        } else {
          matrix[i][j] = Math.min(
            matrix[i - 1][j - 1] + 1,
            matrix[i][j - 1] + 1,
            matrix[i - 1][j] + 1
          );
        }
      }
    }

    return matrix[str2.length][str1.length];
  }

  private generateGenericAlternatives(originalLocator: LocatorVariant): LocatorVariant[] {
    const alternatives: LocatorVariant[] = [];

    // Generate alternatives based on the original type
    switch (originalLocator.type) {
      case 'id':
        // Try as data-testid
        alternatives.push({
          selector: originalLocator.selector,
          type: 'data-testid',
          score: 0.7
        });
        break;

      case 'class':
        // Try as CSS selector
        alternatives.push({
          selector: `.${originalLocator.selector}`,
          type: 'css',
          score: 0.6
        });
        break;

      case 'text':
        // Try partial text match
        if (originalLocator.selector.length > 10) {
          alternatives.push({
            selector: originalLocator.selector.substring(0, 20),
            type: 'text',
            score: 0.5
          });
        }
        break;
    }

    return alternatives;
  }

  private scoreAndSort(locators: LocatorVariant[]): LocatorVariant[] {
    // Remove duplicates
    const uniqueLocators = new Map<string, LocatorVariant>();
    
    for (const locator of locators) {
      const key = `${locator.type}:${locator.selector}`;
      const existing = uniqueLocators.get(key);
      
      if (!existing || locator.score > existing.score) {
        uniqueLocators.set(key, locator);
      }
    }

    // Sort by score descending
    return Array.from(uniqueLocators.values())
      .sort((a, b) => b.score - a.score);
  }
} 