import * as levenshtein from 'fast-levenshtein';
import { parse as parseHTML } from 'node-html-parser';
import {
  LocatorVariant,
  SimilarityScore,
  LocatorHealingConfig
} from './types';

export class SimilarityEngine {
  constructor(private config: LocatorHealingConfig) {}

  async calculateScore(
    original: LocatorVariant,
    candidate: LocatorVariant,
    context: {
      domSnapshot?: string;
      windowHierarchy?: any;
    }
  ): Promise<SimilarityScore> {
    const textSimilarity = this.calculateTextSimilarity(original, candidate);
    const structuralSimilarity = await this.calculateStructuralSimilarity(
      original,
      candidate,
      context
    );
    const attributeSimilarity = this.calculateAttributeSimilarity(original, candidate);
    const contextSimilarity = await this.calculateContextSimilarity(
      original,
      candidate,
      context
    );

    const overall = 
      textSimilarity * this.config.textSimilarityWeight +
      structuralSimilarity * this.config.structuralSimilarityWeight +
      attributeSimilarity * this.config.attributeSimilarityWeight +
      contextSimilarity * this.config.contextSimilarityWeight;

    return {
      textSimilarity,
      structuralSimilarity,
      attributeSimilarity,
      contextSimilarity,
      overall
    };
  }

  private calculateTextSimilarity(
    original: LocatorVariant,
    candidate: LocatorVariant
  ): number {
    // If both have text content metadata, compare them
    if (original.metadata?.textContent && candidate.metadata?.textContent) {
      const distance = levenshtein.get(
        original.metadata.textContent.toLowerCase(),
        candidate.metadata.textContent.toLowerCase()
      );
      const maxLength = Math.max(
        original.metadata.textContent.length,
        candidate.metadata.textContent.length
      );
      return maxLength > 0 ? 1 - (distance / maxLength) : 0;
    }

    // Compare selectors for text-based locators
    if (original.type === 'text' && candidate.type === 'text') {
      const distance = levenshtein.get(
        original.selector.toLowerCase(),
        candidate.selector.toLowerCase()
      );
      const maxLength = Math.max(
        original.selector.length,
        candidate.selector.length
      );
      return maxLength > 0 ? 1 - (distance / maxLength) : 0;
    }

    // No text similarity available
    return 0;
  }

  private async calculateStructuralSimilarity(
    original: LocatorVariant,
    candidate: LocatorVariant,
    context: { domSnapshot?: string; windowHierarchy?: any }
  ): Promise<number> {
    if (!context.domSnapshot && !context.windowHierarchy) {
      return 0;
    }

    // For DOM-based comparison
    if (context.domSnapshot) {
      return this.calculateDOMStructuralSimilarity(original, candidate, context.domSnapshot);
    }

    // For window hierarchy comparison (desktop)
    if (context.windowHierarchy) {
      return this.calculateWindowStructuralSimilarity(
        original,
        candidate,
        context.windowHierarchy
      );
    }

    return 0;
  }

  private calculateDOMStructuralSimilarity(
    original: LocatorVariant,
    candidate: LocatorVariant,
    domSnapshot: string
  ): number {
    try {
      const dom = parseHTML(domSnapshot);
      
      // Get element paths
      const originalPath = this.getElementPath(original, dom);
      const candidatePath = this.getElementPath(candidate, dom);

      if (!originalPath || !candidatePath) {
        return 0;
      }

      // Compare paths
      let commonDepth = 0;
      const minDepth = Math.min(originalPath.length, candidatePath.length);
      
      for (let i = 0; i < minDepth; i++) {
        if (originalPath[i] === candidatePath[i]) {
          commonDepth++;
        } else {
          break;
        }
      }

      // Calculate similarity based on common ancestor depth
      const maxDepth = Math.max(originalPath.length, candidatePath.length);
      return maxDepth > 0 ? commonDepth / maxDepth : 0;
    } catch (error) {
      return 0;
    }
  }

  private getElementPath(locator: LocatorVariant, dom: any): string[] | null {
    try {
      let element: any = null;

      switch (locator.type) {
        case 'css':
          element = dom.querySelector(locator.selector);
          break;
        case 'id':
          element = dom.querySelector(`#${locator.selector}`);
          break;
        case 'class':
          element = dom.querySelector(`.${locator.selector}`);
          break;
        case 'data-testid':
          element = dom.querySelector(`[data-testid="${locator.selector}"]`);
          break;
        case 'aria-label':
          element = dom.querySelector(`[aria-label="${locator.selector}"]`);
          break;
        case 'role':
          element = dom.querySelector(`[role="${locator.selector}"]`);
          break;
      }

      if (!element) return null;

      // Build path from element to root
      const path: string[] = [];
      let current = element;
      
      while (current && current.tagName) {
        const tag = current.tagName.toLowerCase();
        const id = current.getAttribute('id');
        const className = current.getAttribute('class');
        
        let pathSegment = tag;
        if (id) pathSegment += `#${id}`;
        else if (className) pathSegment += `.${className.split(' ')[0]}`;
        
        path.unshift(pathSegment);
        current = current.parentElement;
      }

      return path;
    } catch (error) {
      return null;
    }
  }

  private calculateWindowStructuralSimilarity(
    original: LocatorVariant,
    candidate: LocatorVariant,
    windowHierarchy: any
  ): number {
    // Simple comparison for desktop controls
    // In a real implementation, this would analyze the window hierarchy tree
    
    if (original.metadata?.attributes && candidate.metadata?.attributes) {
      // Compare control properties
      const originalProps = Object.keys(original.metadata.attributes);
      const candidateProps = Object.keys(candidate.metadata.attributes);
      
      const commonProps = originalProps.filter(prop => candidateProps.includes(prop));
      const allProps = new Set([...originalProps, ...candidateProps]);
      
      return allProps.size > 0 ? commonProps.length / allProps.size : 0;
    }

    return 0;
  }

  private calculateAttributeSimilarity(
    original: LocatorVariant,
    candidate: LocatorVariant
  ): number {
    if (!original.metadata?.attributes || !candidate.metadata?.attributes) {
      // If same selector type, give partial credit
      return original.type === candidate.type ? 0.5 : 0;
    }

    const originalAttrs = original.metadata.attributes;
    const candidateAttrs = candidate.metadata.attributes;

    // Key attributes that are more important
    const importantAttrs = ['id', 'data-testid', 'name', 'type', 'role', 'aria-label'];
    const normalAttrs = Object.keys({ ...originalAttrs, ...candidateAttrs })
      .filter(attr => !importantAttrs.includes(attr));

    let score = 0;
    let totalWeight = 0;

    // Compare important attributes (higher weight)
    for (const attr of importantAttrs) {
      if (originalAttrs[attr] || candidateAttrs[attr]) {
        const weight = 2;
        totalWeight += weight;
        if (originalAttrs[attr] === candidateAttrs[attr]) {
          score += weight;
        }
      }
    }

    // Compare normal attributes
    for (const attr of normalAttrs) {
      if (originalAttrs[attr] || candidateAttrs[attr]) {
        const weight = 1;
        totalWeight += weight;
        if (originalAttrs[attr] === candidateAttrs[attr]) {
          score += weight;
        }
      }
    }

    return totalWeight > 0 ? score / totalWeight : 0;
  }

  private async calculateContextSimilarity(
    original: LocatorVariant,
    candidate: LocatorVariant,
    context: { domSnapshot?: string; windowHierarchy?: any }
  ): Promise<number> {
    // This would analyze surrounding elements, nearby text, etc.
    // For now, simplified implementation

    if (original.metadata?.tagName === candidate.metadata?.tagName) {
      // Same element type is a good sign
      return 0.8;
    }

    if (original.type === candidate.type) {
      // Same locator strategy suggests similar context
      return 0.5;
    }

    return 0.2; // Base context similarity
  }

  calculateLevenshteinDistance(str1: string, str2: string): number {
    return levenshtein.get(str1.toLowerCase(), str2.toLowerCase());
  }

  normalizeSelector(selector: string): string {
    // Remove spaces and convert to lowercase for comparison
    return selector.replace(/\s+/g, ' ').trim().toLowerCase();
  }
} 