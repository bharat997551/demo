import { Request, Response } from 'express';
import { logger } from '@hybrid-qa/common';
import { validateDSL } from '@hybrid-qa/dsl';
import { RunnerService } from '../services/runner.service';
import { ArtifactService } from '../services/artifact.service';
import { EventService } from '../services/event.service';
import { SelfHealingService } from '../services/self-healing.service';

/**
 * Main orchestrator controller handling HTTP endpoints
 */
export class OrchestratorController {
  constructor(
    private readonly runnerService: RunnerService,
    private readonly artifactService: ArtifactService,
    private readonly eventService: EventService,
    private readonly selfHealingService: SelfHealingService
  ) {}

  /**
   * GET /health - Health check endpoint
   */
  async health(req: Request, res: Response): Promise<void> {
    try {
      const engines = this.runnerService.getEngines();
      const engineHealth = await Promise.all(
        engines.map(async ({ type, engine }) => ({
          type,
          name: engine.config.name,
          health: await engine.healthCheck()
        }))
      );

      const eventStats = this.eventService.getEventStats();
      const selfHealingStats = await this.selfHealingService.getLocatorStats();

      res.json({
        status: 'healthy',
        timestamp: new Date().toISOString(),
        version: process.env.npm_package_version || '1.0.0',
        uptime: process.uptime(),
        services: {
          orchestrator: 'healthy',
          events: {
            status: 'healthy',
            connectedClients: eventStats.connectedClients,
            uptime: eventStats.uptime
          },
          artifacts: 'healthy',
          selfHealing: {
            status: 'healthy',
            totalElements: selfHealingStats.totalElements,
            totalLocators: selfHealingStats.totalLocators,
            averageConfidence: selfHealingStats.averageConfidence
          }
        },
        engines: engineHealth
      });
    } catch (error) {
      logger.error('Health check failed', { error });
      res.status(503).json({
        status: 'unhealthy',
        error: error instanceof Error ? error.message : 'Unknown error',
        timestamp: new Date().toISOString()
      });
    }
  }

  /**
   * POST /runs - Execute a test case or suite
   */
  async createRun(req: Request, res: Response): Promise<void> {
    try {
      const { dsl, config = {} } = req.body;

      if (!dsl) {
        res.status(400).json({
          success: false,
          error: 'DSL is required'
        });
        return;
      }

      // Validate DSL
      const validation = validateDSL(dsl);
      if (!validation.valid) {
        res.status(400).json({
          success: false,
          error: 'Invalid DSL',
          details: validation.errors
        });
        return;
      }

      // Determine if it's a test case or test suite
      let result;
      if (dsl.testCases) {
        // Test suite
        result = await this.runnerService.executeTestSuite(dsl, config);
      } else {
        // Test case
        result = await this.runnerService.executeTestCase(dsl, config);
      }

      res.status(201).json({
        success: true,
        data: {
          runId: result.runId,
          status: 'started',
          timestamp: new Date().toISOString()
        }
      });
    } catch (error) {
      logger.error('Failed to create run', { error });
      res.status(500).json({
        success: false,
        error: error instanceof Error ? error.message : 'Internal server error'
      });
    }
  }

  /**
   * GET /runs/:runId - Get run status and results
   */
  async getRun(req: Request, res: Response): Promise<void> {
    try {
      const { runId } = req.params;

      // Get run artifacts to determine status
      const artifacts = this.artifactService.getRunArtifacts(runId);
      const runExists = await this.artifactService.runDirectoryExists(runId);

      if (!runExists) {
        res.status(404).json({
          success: false,
          error: 'Run not found'
        });
        return;
      }

      res.json({
        success: true,
        data: {
          runId,
          artifacts: artifacts.map(artifact => ({
            id: artifact.id,
            type: artifact.type,
            filename: artifact.filename,
            size: artifact.size,
            createdAt: artifact.createdAt,
            stepId: artifact.stepId
          })),
          status: 'completed', // This would be tracked in a real implementation
          artifactCount: artifacts.length
        }
      });
    } catch (error) {
      logger.error('Failed to get run', { error, runId: req.params.runId });
      res.status(500).json({
        success: false,
        error: error instanceof Error ? error.message : 'Internal server error'
      });
    }
  }

  /**
   * GET /runs - List recent runs
   */
  async getRuns(req: Request, res: Response): Promise<void> {
    try {
      const { limit = 50, offset = 0 } = req.query;

      // This would query a database in a real implementation
      // For now, just return empty list
      res.json({
        success: true,
        data: {
          runs: [],
          total: 0,
          limit: Number(limit),
          offset: Number(offset)
        }
      });
    } catch (error) {
      logger.error('Failed to list runs', { error });
      res.status(500).json({
        success: false,
        error: error instanceof Error ? error.message : 'Internal server error'
      });
    }
  }

  /**
   * POST /cases/validate - Validate a test case DSL
   */
  async validateCase(req: Request, res: Response): Promise<void> {
    try {
      const { dsl } = req.body;

      if (!dsl) {
        res.status(400).json({
          success: false,
          error: 'DSL is required'
        });
        return;
      }

      const validation = validateDSL(dsl);
      
      res.json({
        success: true,
        data: {
          valid: validation.valid,
          errors: validation.errors,
          warnings: validation.warnings
        }
      });
    } catch (error) {
      logger.error('Failed to validate case', { error });
      res.status(500).json({
        success: false,
        error: error instanceof Error ? error.message : 'Internal server error'
      });
    }
  }

  /**
   * GET /engines - List registered engines and their status
   */
  async getEngines(req: Request, res: Response): Promise<void> {
    try {
      const engines = this.runnerService.getEngines();
      const engineStatus = await Promise.all(
        engines.map(async ({ type, engine }) => {
          const health = await engine.healthCheck();
          return {
            type,
            id: engine.config.id,
            name: engine.config.name,
            version: engine.config.version,
            enabled: engine.config.enabled,
            status: health.status,
            lastCheck: health.lastCheck,
            responseTime: health.responseTime,
            supportedSteps: engine.getSupportedStepKinds(),
            capabilities: health.capabilities
          };
        })
      );

      res.json({
        success: true,
        data: {
          engines: engineStatus,
          total: engineStatus.length
        }
      });
    } catch (error) {
      logger.error('Failed to get engines', { error });
      res.status(500).json({
        success: false,
        error: error instanceof Error ? error.message : 'Internal server error'
      });
    }
  }

  /**
   * GET /engines/:engineType/health - Check specific engine health
   */
  async getEngineHealth(req: Request, res: Response): Promise<void> {
    try {
      const { engineType } = req.params;
      const engine = this.runnerService.getEngine(engineType);

      if (!engine) {
        res.status(404).json({
          success: false,
          error: 'Engine not found'
        });
        return;
      }

      const health = await engine.healthCheck();
      
      res.json({
        success: true,
        data: health
      });
    } catch (error) {
      logger.error('Failed to check engine health', { error, engineType: req.params.engineType });
      res.status(500).json({
        success: false,
        error: error instanceof Error ? error.message : 'Internal server error'
      });
    }
  }

  /**
   * GET /artifacts/:runId - List artifacts for a run
   */
  async getRunArtifacts(req: Request, res: Response): Promise<void> {
    try {
      const { runId } = req.params;
      const { type } = req.query;

      let artifacts = this.artifactService.getRunArtifacts(runId);

      // Filter by type if specified
      if (type && typeof type === 'string') {
        artifacts = artifacts.filter(artifact => artifact.type === type);
      }

      res.json({
        success: true,
        data: {
          runId,
          artifacts: artifacts.map(artifact => ({
            id: artifact.id,
            type: artifact.type,
            filename: artifact.filename,
            size: artifact.size,
            contentType: artifact.contentType,
            createdAt: artifact.createdAt,
            stepId: artifact.stepId,
            metadata: artifact.metadata
          })),
          total: artifacts.length
        }
      });
    } catch (error) {
      logger.error('Failed to get run artifacts', { error, runId: req.params.runId });
      res.status(500).json({
        success: false,
        error: error instanceof Error ? error.message : 'Internal server error'
      });
    }
  }

  /**
   * GET /artifacts/:runId/:artifactId - Download an artifact
   */
  async downloadArtifact(req: Request, res: Response): Promise<void> {
    try {
      const { runId, artifactId } = req.params;
      
      const artifact = this.artifactService.getArtifact(artifactId);
      
      if (!artifact || artifact.runId !== runId) {
        res.status(404).json({
          success: false,
          error: 'Artifact not found'
        });
        return;
      }

      const content = await this.artifactService.readArtifact(artifactId);
      
      res.set({
        'Content-Type': artifact.contentType || 'application/octet-stream',
        'Content-Length': artifact.size,
        'Content-Disposition': `attachment; filename="${artifact.filename}"`
      });
      
      res.send(content);
    } catch (error) {
      logger.error('Failed to download artifact', { 
        error, 
        runId: req.params.runId,
        artifactId: req.params.artifactId 
      });
      res.status(500).json({
        success: false,
        error: error instanceof Error ? error.message : 'Internal server error'
      });
    }
  }

  /**
   * GET /events/stats - Get event service statistics
   */
  async getEventStats(req: Request, res: Response): Promise<void> {
    try {
      const stats = this.eventService.getEventStats();
      const clients = this.eventService.getConnectedClients();
      
      res.json({
        success: true,
        data: {
          ...stats,
          clients: clients.map(client => ({
            id: client.id,
            connectedAt: client.connectedAt,
            subscriptions: client.subscriptions,
            metadata: client.metadata
          }))
        }
      });
    } catch (error) {
      logger.error('Failed to get event stats', { error });
      res.status(500).json({
        success: false,
        error: error instanceof Error ? error.message : 'Internal server error'
      });
    }
  }

  /**
   * GET /healing/stats - Get self-healing statistics
   */
  async getSelfHealingStats(req: Request, res: Response): Promise<void> {
    try {
      const { elementId } = req.query;
      const stats = await this.selfHealingService.getLocatorStats(elementId as string);
      
      res.json({
        success: true,
        data: stats
      });
    } catch (error) {
      logger.error('Failed to get self-healing stats', { error });
      res.status(500).json({
        success: false,
        error: error instanceof Error ? error.message : 'Internal server error'
      });
    }
  }

  /**
   * POST /healing/cleanup - Clean up old locator history
   */
  async cleanupSelfHealing(req: Request, res: Response): Promise<void> {
    try {
      const { olderThanDays = 90 } = req.body;
      
      const deletedCount = await this.selfHealingService.cleanupOldHistory(Number(olderThanDays));
      
      res.json({
        success: true,
        data: {
          deletedRecords: deletedCount,
          olderThanDays: Number(olderThanDays)
        }
      });
    } catch (error) {
      logger.error('Failed to cleanup self-healing data', { error });
      res.status(500).json({
        success: false,
        error: error instanceof Error ? error.message : 'Internal server error'
      });
    }
  }
} 