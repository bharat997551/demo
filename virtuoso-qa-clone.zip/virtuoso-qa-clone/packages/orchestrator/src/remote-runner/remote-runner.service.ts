/**
 * Remote Runner Service Implementation
 * Manages distributed test execution across remote agents
 */

import { EventEmitter } from 'events';
import { v4 as uuidv4 } from 'uuid';
import { 
  AgentInfo, 
  AgentRegistration, 
  AgentStatus,
  RemoteExecutionRequest,
  RemoteExecutionResult,
  RemoteRunnerService,
  CloudGridConfig,
  GridMetrics,
  RemoteRunnerPlugin,
  AgentPlatform
} from './types';
import { getLogger } from '@hybrid-qa/common';

export class RemoteRunnerServiceImpl extends EventEmitter implements RemoteRunnerService {
  private agents: Map<string, AgentRegistration> = new Map();
  private jobQueue: RemoteExecutionRequest[] = [];
  private activeJobs: Map<string, { agentId: string; request: RemoteExecutionRequest }> = new Map();
  private plugins: Map<string, RemoteRunnerPlugin> = new Map();
  private cloudConfig?: CloudGridConfig;
  private logger = getLogger().child({ service: 'RemoteRunner' });

  constructor() {
    super();
    this.startHealthCheckLoop();
    this.startJobScheduler();
  }

  // Agent Management
  async registerAgent(info: AgentInfo, token: string): Promise<AgentRegistration> {
    this.logger.info('Registering agent', { 
      agentId: info.id, 
      platform: info.platform,
      capabilities: info.capabilities 
    });

    const registration: AgentRegistration = {
      agentInfo: info,
      authToken: token,
      registeredAt: new Date(),
      lastHeartbeat: new Date(),
      status: 'online',
      currentJobs: [],
      maxConcurrentJobs: this.calculateMaxJobs(info)
    };

    this.agents.set(info.id, registration);
    
    // Notify plugins
    for (const plugin of this.plugins.values()) {
      if (plugin.onAgentConnect) {
        await plugin.onAgentConnect(info);
      }
    }

    this.emit('agent:connected', info);
    return registration;
  }

  async unregisterAgent(agentId: string): Promise<void> {
    const agent = this.agents.get(agentId);
    if (!agent) return;

    this.logger.info('Unregistering agent', { agentId });

    // Cancel active jobs
    for (const [jobId, job] of this.activeJobs.entries()) {
      if (job.agentId === agentId) {
        await this.cancelJob(jobId);
      }
    }

    this.agents.delete(agentId);

    // Notify plugins
    for (const plugin of this.plugins.values()) {
      if (plugin.onAgentDisconnect) {
        await plugin.onAgentDisconnect(agentId, 'unregistered');
      }
    }

    this.emit('agent:disconnected', agentId);
  }

  async getAgents(filter?: Partial<AgentInfo>): Promise<AgentRegistration[]> {
    let agents = Array.from(this.agents.values());

    if (filter) {
      agents = agents.filter(agent => {
        if (filter.platform && agent.agentInfo.platform !== filter.platform) return false;
        if (filter.capabilities) {
          const hasAll = filter.capabilities.every(cap => 
            agent.agentInfo.capabilities.includes(cap)
          );
          if (!hasAll) return false;
        }
        if (filter.tags) {
          const hasAll = filter.tags.every(tag => 
            agent.agentInfo.tags.includes(tag)
          );
          if (!hasAll) return false;
        }
        return true;
      });
    }

    return agents;
  }

  async getAgentStatus(agentId: string): Promise<AgentStatus> {
    const agent = this.agents.get(agentId);
    return agent?.status || 'offline';
  }

  async updateAgentStatus(agentId: string, status: AgentStatus): Promise<void> {
    const agent = this.agents.get(agentId);
    if (agent) {
      agent.status = status;
      agent.lastHeartbeat = new Date();
      this.emit('agent:status', { agentId, status });
    }
  }

  // Job Execution
  async submitJob(request: RemoteExecutionRequest): Promise<string> {
    const jobId = request.id || uuidv4();
    request.id = jobId;

    this.logger.info('Submitting job', { 
      jobId, 
      engine: request.engine,
      requirements: request.requirements 
    });

    // Let plugins modify the request
    for (const plugin of this.plugins.values()) {
      if (plugin.onBeforeExecute) {
        request = await plugin.onBeforeExecute(request);
      }
    }

    this.jobQueue.push(request);
    this.emit('job:queued', request);

    // Trigger scheduling
    setImmediate(() => this.scheduleJobs());

    return jobId;
  }

  async getJobStatus(jobId: string): Promise<RemoteExecutionResult | null> {
    // TODO: Implement job result storage
    const activeJob = this.activeJobs.get(jobId);
    if (activeJob) {
      return {
        requestId: jobId,
        agentId: activeJob.agentId,
        status: 'success', // TODO: Get actual status
        metrics: {
          startTime: new Date(),
          endTime: new Date(),
          duration: 0
        },
        artifacts: []
      };
    }
    return null;
  }

  async cancelJob(jobId: string): Promise<boolean> {
    this.logger.info('Cancelling job', { jobId });

    // Remove from queue
    const queueIndex = this.jobQueue.findIndex(job => job.id === jobId);
    if (queueIndex !== -1) {
      this.jobQueue.splice(queueIndex, 1);
      this.emit('job:cancelled', jobId);
      return true;
    }

    // Cancel active job
    const activeJob = this.activeJobs.get(jobId);
    if (activeJob) {
      // TODO: Send cancellation to agent
      this.activeJobs.delete(jobId);
      this.emit('job:cancelled', jobId);
      return true;
    }

    return false;
  }

  async getQueuedJobs(): Promise<RemoteExecutionRequest[]> {
    return [...this.jobQueue];
  }

  // Cloud Grid Management
  async configureCloudGrid(config: CloudGridConfig): Promise<void> {
    this.logger.info('Configuring cloud grid', { provider: config.provider });
    this.cloudConfig = config;
    
    // TODO: Initialize cloud provider SDK
    // TODO: Set up auto-scaling rules
    
    this.emit('grid:configured', config);
  }

  async scaleGrid(targetSize: number): Promise<void> {
    if (!this.cloudConfig) {
      throw new Error('Cloud grid not configured');
    }

    this.logger.info('Scaling grid', { targetSize });

    // TODO: Implement scaling logic for each cloud provider
    switch (this.cloudConfig.provider) {
      case 'aws':
        await this.scaleAWSGrid(targetSize);
        break;
      case 'azure':
        await this.scaleAzureGrid(targetSize);
        break;
      case 'gcp':
        await this.scaleGCPGrid(targetSize);
        break;
      case 'custom':
        await this.scaleCustomGrid(targetSize);
        break;
    }

    this.emit('grid:scaled', { targetSize });
  }

  async getGridMetrics(): Promise<GridMetrics> {
    const agents = Array.from(this.agents.values());
    const onlineAgents = agents.filter(a => a.status === 'online').length;
    const busyAgents = agents.filter(a => a.currentJobs.length > 0).length;

    return {
      totalAgents: agents.length,
      onlineAgents,
      busyAgents,
      queuedJobs: this.jobQueue.length,
      averageJobDuration: this.calculateAverageJobDuration(),
      averageQueueTime: this.calculateAverageQueueTime(),
      resourceUtilization: {
        cpu: this.calculateAverageCPU(),
        memory: this.calculateAverageMemory(),
        network: 0 // TODO: Implement network metrics
      }
    };
  }

  // Plugin System
  registerPlugin(plugin: RemoteRunnerPlugin): void {
    this.logger.info('Registering plugin', { name: plugin.name });
    this.plugins.set(plugin.name, plugin);
  }

  unregisterPlugin(name: string): void {
    this.logger.info('Unregistering plugin', { name });
    this.plugins.delete(name);
  }

  // Private Methods
  private calculateMaxJobs(info: AgentInfo): number {
    // Simple heuristic based on resources
    const cpuJobs = Math.floor(info.metadata.cpuCount / 2);
    const memoryJobs = Math.floor(info.metadata.memoryGB / 2);
    return Math.min(cpuJobs, memoryJobs, 5); // Cap at 5 concurrent jobs
  }

  private async scheduleJobs(): Promise<void> {
    if (this.jobQueue.length === 0) return;

    const availableAgents = Array.from(this.agents.values())
      .filter(agent => 
        agent.status === 'online' && 
        agent.currentJobs.length < agent.maxConcurrentJobs
      );

    for (const job of [...this.jobQueue]) {
      const agent = await this.selectAgentForJob(job, availableAgents);
      if (agent) {
        await this.assignJobToAgent(job, agent);
      }
    }
  }

  private async selectAgentForJob(
    job: RemoteExecutionRequest, 
    availableAgents: AgentRegistration[]
  ): Promise<AgentRegistration | null> {
    // Let plugins handle agent selection first
    for (const plugin of this.plugins.values()) {
      if (plugin.selectAgent) {
        const agentId = await plugin.selectAgent(job, availableAgents);
        if (agentId) {
          const agent = availableAgents.find(a => a.agentInfo.id === agentId);
          if (agent) return agent;
        }
      }
    }

    // Default selection logic
    const compatibleAgents = availableAgents.filter(agent => {
      // Check platform requirement
      if (job.requirements.platform && 
          agent.agentInfo.platform !== job.requirements.platform) {
        return false;
      }

      // Check capabilities
      const hasCapabilities = job.requirements.capabilities.every(cap =>
        agent.agentInfo.capabilities.includes(cap)
      );
      if (!hasCapabilities) return false;

      // Check resource requirements
      if (job.requirements.minMemoryGB && 
          agent.agentInfo.metadata.memoryGB < job.requirements.minMemoryGB) {
        return false;
      }

      if (job.requirements.minCpuCount && 
          agent.agentInfo.metadata.cpuCount < job.requirements.minCpuCount) {
        return false;
      }

      return true;
    });

    // Select agent with least load
    if (compatibleAgents.length > 0) {
      return compatibleAgents.reduce((best, current) => 
        current.currentJobs.length < best.currentJobs.length ? current : best
      );
    }

    return null;
  }

  private async assignJobToAgent(
    job: RemoteExecutionRequest, 
    agent: AgentRegistration
  ): Promise<void> {
    // Remove from queue
    const index = this.jobQueue.findIndex(j => j.id === job.id);
    if (index !== -1) {
      this.jobQueue.splice(index, 1);
    }

    // Assign to agent
    agent.currentJobs.push(job.id);
    this.activeJobs.set(job.id, { agentId: agent.agentInfo.id, request: job });

    this.logger.info('Job assigned to agent', { 
      jobId: job.id, 
      agentId: agent.agentInfo.id 
    });

    // TODO: Send job to agent via appropriate protocol
    this.emit('job:assigned', { jobId: job.id, agentId: agent.agentInfo.id });
  }

  private startHealthCheckLoop(): void {
    setInterval(() => {
      const now = new Date();
      for (const [agentId, agent] of this.agents.entries()) {
        const timeSinceHeartbeat = now.getTime() - agent.lastHeartbeat.getTime();
        if (timeSinceHeartbeat > 60000 && agent.status === 'online') {
          // Agent hasn't reported in 60 seconds
          agent.status = 'offline';
          this.emit('agent:offline', agentId);
          
          // Requeue jobs from offline agent
          for (const jobId of agent.currentJobs) {
            const job = this.activeJobs.get(jobId);
            if (job) {
              this.jobQueue.push(job.request);
              this.activeJobs.delete(jobId);
              this.emit('job:requeued', jobId);
            }
          }
          agent.currentJobs = [];
        }
      }
    }, 10000); // Check every 10 seconds
  }

  private startJobScheduler(): void {
    setInterval(() => {
      this.scheduleJobs();
      this.checkAutoScaling();
    }, 5000); // Schedule every 5 seconds
  }

  private async checkAutoScaling(): Promise<void> {
    if (!this.cloudConfig) return;

    const metrics = await this.getGridMetrics();
    
    // Check if we should scale up
    const utilizationPercent = (metrics.busyAgents / metrics.onlineAgents) * 100;
    if (utilizationPercent > this.cloudConfig.scaling.scaleUpThreshold) {
      // Let plugins decide
      for (const plugin of this.plugins.values()) {
        if (plugin.shouldScaleUp && await plugin.shouldScaleUp(metrics)) {
          const newSize = Math.min(
            metrics.totalAgents + 1,
            this.cloudConfig.scaling.maxAgents
          );
          await this.scaleGrid(newSize);
          return;
        }
      }
    }

    // Check if we should scale down
    if (utilizationPercent < this.cloudConfig.scaling.scaleDownThreshold) {
      for (const plugin of this.plugins.values()) {
        if (plugin.shouldScaleDown && await plugin.shouldScaleDown(metrics)) {
          const newSize = Math.max(
            metrics.totalAgents - 1,
            this.cloudConfig.scaling.minAgents
          );
          await this.scaleGrid(newSize);
          return;
        }
      }
    }
  }

  // Cloud provider specific implementations (stubs)
  private async scaleAWSGrid(targetSize: number): Promise<void> {
    this.logger.info('Scaling AWS grid', { targetSize });
    // TODO: Use AWS SDK to scale EC2 instances
  }

  private async scaleAzureGrid(targetSize: number): Promise<void> {
    this.logger.info('Scaling Azure grid', { targetSize });
    // TODO: Use Azure SDK to scale VMs
  }

  private async scaleGCPGrid(targetSize: number): Promise<void> {
    this.logger.info('Scaling GCP grid', { targetSize });
    // TODO: Use GCP SDK to scale compute instances
  }

  private async scaleCustomGrid(targetSize: number): Promise<void> {
    this.logger.info('Scaling custom grid', { targetSize });
    // TODO: Use custom API to scale infrastructure
  }

  // Metrics calculation helpers
  private calculateAverageJobDuration(): number {
    // TODO: Implement based on historical data
    return 0;
  }

  private calculateAverageQueueTime(): number {
    // TODO: Implement based on queue history
    return 0;
  }

  private calculateAverageCPU(): number {
    // TODO: Aggregate from agent health metrics
    return 0;
  }

  private calculateAverageMemory(): number {
    // TODO: Aggregate from agent health metrics
    return 0;
  }
} 