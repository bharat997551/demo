/**
 * Remote Runner Agent Types and Interfaces
 * Foundation for distributed test execution across different platforms
 */

export type AgentPlatform = 'windows' | 'linux' | 'macos' | 'docker' | 'cloud';
export type AgentStatus = 'online' | 'offline' | 'busy' | 'maintenance' | 'error';
export type AgentCapability = 'web' | 'desktop' | 'mainframe' | 'api' | 'mobile';

export interface AgentInfo {
  id: string;
  name: string;
  platform: AgentPlatform;
  version: string;
  hostname: string;
  ip: string;
  port: number;
  capabilities: AgentCapability[];
  tags: string[];
  metadata: {
    os: string;
    osVersion: string;
    arch: string;
    cpuCount: number;
    memoryGB: number;
    diskGB: number;
    browsers?: string[];
    pythonVersion?: string;
    nodeVersion?: string;
  };
}

export interface AgentRegistration {
  agentInfo: AgentInfo;
  authToken: string;
  registeredAt: Date;
  lastHeartbeat: Date;
  status: AgentStatus;
  currentJobs: string[];
  maxConcurrentJobs: number;
}

export interface RemoteExecutionRequest {
  id: string;
  testId: string;
  engine: string;
  requirements: {
    platform?: AgentPlatform;
    capabilities: AgentCapability[];
    tags?: string[];
    minMemoryGB?: number;
    minCpuCount?: number;
    browsers?: string[];
  };
  payload: any;
  priority: number;
  timeout: number;
  retryPolicy?: {
    maxRetries: number;
    backoffMs: number;
  };
}

export interface RemoteExecutionResult {
  requestId: string;
  agentId: string;
  status: 'success' | 'failure' | 'timeout' | 'cancelled';
  result?: any;
  error?: {
    message: string;
    stack?: string;
    code?: string;
  };
  metrics: {
    startTime: Date;
    endTime: Date;
    duration: number;
    resourceUsage?: {
      cpuPercent: number;
      memoryMB: number;
      networkMB: number;
    };
  };
  artifacts: RemoteArtifact[];
}

export interface RemoteArtifact {
  id: string;
  type: 'screenshot' | 'video' | 'log' | 'file' | 'report';
  name: string;
  size: number;
  mimeType: string;
  url?: string;
  data?: Buffer;
  metadata?: Record<string, any>;
}

export interface CloudGridConfig {
  provider: 'aws' | 'azure' | 'gcp' | 'custom';
  region: string;
  credentials: {
    accessKey?: string;
    secretKey?: string;
    projectId?: string;
    customAuth?: Record<string, any>;
  };
  scaling: {
    minAgents: number;
    maxAgents: number;
    scaleUpThreshold: number;
    scaleDownThreshold: number;
    cooldownSeconds: number;
  };
  instanceConfig: {
    type: string;
    image: string;
    securityGroups?: string[];
    userData?: string;
  };
}

export interface AgentCommunication {
  protocol: 'websocket' | 'grpc' | 'rest';
  encryption: boolean;
  compression: boolean;
  heartbeatInterval: number;
  reconnectPolicy: {
    maxRetries: number;
    backoffMs: number;
  };
}

export interface RemoteRunnerPlugin {
  name: string;
  version: string;
  
  // Lifecycle hooks
  onAgentConnect?(agent: AgentInfo): Promise<void>;
  onAgentDisconnect?(agentId: string, reason: string): Promise<void>;
  onBeforeExecute?(request: RemoteExecutionRequest): Promise<RemoteExecutionRequest>;
  onAfterExecute?(result: RemoteExecutionResult): Promise<void>;
  
  // Custom scheduling logic
  selectAgent?(request: RemoteExecutionRequest, availableAgents: AgentRegistration[]): Promise<string | null>;
  
  // Resource management
  shouldScaleUp?(metrics: GridMetrics): Promise<boolean>;
  shouldScaleDown?(metrics: GridMetrics): Promise<boolean>;
}

export interface GridMetrics {
  totalAgents: number;
  onlineAgents: number;
  busyAgents: number;
  queuedJobs: number;
  averageJobDuration: number;
  averageQueueTime: number;
  resourceUtilization: {
    cpu: number;
    memory: number;
    network: number;
  };
}

export interface RemoteRunnerService {
  // Agent management
  registerAgent(info: AgentInfo, token: string): Promise<AgentRegistration>;
  unregisterAgent(agentId: string): Promise<void>;
  getAgents(filter?: Partial<AgentInfo>): Promise<AgentRegistration[]>;
  getAgentStatus(agentId: string): Promise<AgentStatus>;
  updateAgentStatus(agentId: string, status: AgentStatus): Promise<void>;
  
  // Job execution
  submitJob(request: RemoteExecutionRequest): Promise<string>;
  getJobStatus(jobId: string): Promise<RemoteExecutionResult | null>;
  cancelJob(jobId: string): Promise<boolean>;
  getQueuedJobs(): Promise<RemoteExecutionRequest[]>;
  
  // Cloud grid management
  configureCloudGrid(config: CloudGridConfig): Promise<void>;
  scaleGrid(targetSize: number): Promise<void>;
  getGridMetrics(): Promise<GridMetrics>;
  
  // Plugin system
  registerPlugin(plugin: RemoteRunnerPlugin): void;
  unregisterPlugin(name: string): void;
}

// Agent SDK interfaces for different platforms
export interface AgentSDK {
  platform: AgentPlatform;
  
  // Core functionality
  connect(orchestratorUrl: string, token: string): Promise<void>;
  disconnect(): Promise<void>;
  
  // Job handling
  onJobReceived(handler: (job: RemoteExecutionRequest) => Promise<RemoteExecutionResult>): void;
  reportProgress(jobId: string, progress: number, message?: string): Promise<void>;
  uploadArtifact(jobId: string, artifact: RemoteArtifact): Promise<string>;
  
  // Health monitoring
  reportHealth(metrics: AgentHealthMetrics): Promise<void>;
  onHealthCheck(handler: () => Promise<AgentHealthMetrics>): void;
}

export interface AgentHealthMetrics {
  cpuUsage: number;
  memoryUsage: number;
  diskUsage: number;
  activeJobs: number;
  completedJobs: number;
  failedJobs: number;
  uptime: number;
  custom?: Record<string, any>;
}

// Configuration for agent deployment
export interface AgentDeploymentConfig {
  platform: AgentPlatform;
  installMethod: 'script' | 'docker' | 'kubernetes' | 'manual';
  
  // Script-based deployment
  script?: {
    url: string;
    checksum: string;
    args?: string[];
  };
  
  // Container-based deployment
  container?: {
    image: string;
    tag: string;
    env?: Record<string, string>;
    volumes?: Array<{
      host: string;
      container: string;
      readOnly?: boolean;
    }>;
  };
  
  // Kubernetes deployment
  kubernetes?: {
    namespace: string;
    deployment: string;
    replicas: number;
    resources?: {
      requests?: { cpu: string; memory: string };
      limits?: { cpu: string; memory: string };
    };
  };
} 