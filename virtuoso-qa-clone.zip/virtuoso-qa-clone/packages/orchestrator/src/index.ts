import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import { 
  initializeObservability, 
  getLogger, 
  getMetrics, 
  getTelemetry,
  requestLoggingMiddleware,
  metricsEndpoint,
  ObservabilityConfig,
  LogLevel
} from '@hybrid-qa/common';
import { RunnerService } from './services/runner.service';
import { ArtifactService } from './services/artifact.service';
import { EventService } from './services/event.service';
import { SelfHealingService } from './services/self-healing.service';
import { LocatorHealingService } from './services/locator-healing.service';
import { OrchestratorController } from './controllers/orchestrator.controller';
import { createPythonEngineAdapter } from './adapters/python-engine.adapter';
import { AIService } from './ai';

/**
 * Orchestrator configuration
 */
interface OrchestratorConfig {
  port: number;
  host: string;
  wsPort: number;
  corsOrigin: string | string[];
  artifactDir: string;
  observability?: {
    logLevel?: LogLevel;
    logPretty?: boolean;
    metricsEnabled?: boolean;
    telemetryEnabled?: boolean;
    telemetryEndpoint?: string;
  };
  engines: {
    web?: {
      enabled: boolean;
      port?: number;
    };
    desktop?: {
      enabled: boolean;
      port?: number;
      pythonPath?: string;
      venvPath?: string;
    };
    mainframe?: {
      enabled: boolean;
      port?: number;
      pythonPath?: string;
      venvPath?: string;
    };
    api?: {
      enabled: boolean;
      port?: number;
    };
  };
}

/**
 * Main orchestrator application
 */
export class Orchestrator {
  private app: express.Application;
  private config: OrchestratorConfig;
  private controller: OrchestratorController;
  private runnerService: RunnerService;
  private artifactService: ArtifactService;
  private eventService: EventService;
  private selfHealingService: SelfHealingService;
  private locatorHealingService: LocatorHealingService;
  private aiService: AIService;
  private logger: any;
  private metrics: any;
  private telemetry: any;

  constructor(config: Partial<OrchestratorConfig> = {}) {
    this.config = {
      port: 3001,
      host: 'localhost',
      wsPort: 3002,
      corsOrigin: '*',
      artifactDir: './artifacts',
      observability: {
        logLevel: 'info',
        logPretty: process.env.NODE_ENV !== 'production',
        metricsEnabled: true,
        telemetryEnabled: false
      },
      engines: {
        web: { enabled: true, port: 8001 },
        desktop: { enabled: true, port: 8002 },
        mainframe: { enabled: false, port: 8003 },
        api: { enabled: true, port: 8004 }
      },
      ...config
    };

    // Initialize observability
    const observabilityConfig: ObservabilityConfig = {
      logging: {
        level: this.config.observability?.logLevel || 'info',
        pretty: this.config.observability?.logPretty,
        redact: ['password', 'token', 'apiKey', 'secret']
      },
      metrics: {
        enabled: this.config.observability?.metricsEnabled ?? true,
        endpoint: '/metrics'
      },
      telemetry: {
        enabled: this.config.observability?.telemetryEnabled ?? false,
        endpoint: this.config.observability?.telemetryEndpoint
      }
    };

    const { logger, metrics, telemetry } = initializeObservability(observabilityConfig);
    this.logger = logger;
    this.metrics = metrics;
    this.telemetry = telemetry;

    this.app = express();
    this.setupMiddleware();
    this.initializeServices();
    this.setupRoutes();
    this.setupEngines();
  }

  private setupMiddleware(): void {
    // Security
    this.app.use(helmet());
    
    // CORS
    this.app.use(cors({
      origin: this.config.corsOrigin,
      credentials: true
    }));

    // Body parsing
    this.app.use(express.json({ limit: '50mb' }));
    this.app.use(express.urlencoded({ extended: true, limit: '50mb' }));

    // Compression
    this.app.use(compression());

    // Request logging
    this.app.use(requestLoggingMiddleware());

    // Health check
    this.app.get('/health', (req, res) => {
      res.json({ 
        status: 'ok', 
        timestamp: new Date().toISOString(),
        uptime: process.uptime()
      });
    });

    // Metrics endpoint
    if (this.config.observability?.metricsEnabled) {
      this.app.get('/metrics', metricsEndpoint('prometheus'));
      this.app.get('/metrics.json', metricsEndpoint('json'));
    }
  }

  private initializeServices(): void {
    this.logger.info('Initializing services');
    
    // Initialize services with logger
    this.artifactService = new ArtifactService(this.config.artifactDir, this.logger);
    this.eventService = new EventService(this.logger);
    this.runnerService = new RunnerService(this.eventService, this.logger, this.metrics);
    this.selfHealingService = new SelfHealingService(this.logger);
    this.locatorHealingService = new LocatorHealingService(this.logger);
    this.aiService = new AIService(this.logger);
    
    this.controller = new OrchestratorController(
      this.runnerService,
      this.artifactService,
      this.eventService,
      this.selfHealingService,
      this.logger
    );

    // Forward events from services to WebSocket clients
    this.setupEventForwarding();
  }

  private setupEventForwarding(): void {
    // Forward runner events
    this.runnerService.on('run:started', (data) => {
      this.eventService.emit('run:started', data);
      this.telemetry.trackTestExecution(data.runId, 'started', 0, 'orchestrator');
    });

    this.runnerService.on('run:completed', (data) => {
      this.eventService.emit('run:completed', data);
      this.metrics.recordTestRun(data.runId, data.status, data.duration);
      this.telemetry.trackTestExecution(data.runId, data.status, data.duration, 'orchestrator');
    });

    this.runnerService.on('step:started', (data) => {
      this.eventService.emit('step:started', data);
      this.logger.logStepStart(data.stepName, data.stepIndex, { runId: data.runId });
    });

    this.runnerService.on('step:completed', (data) => {
      this.eventService.emit('step:completed', data);
      this.metrics.recordStepExecution(data.stepName, data.status, data.duration, data.engine);
      this.logger.logStepEnd(data.stepName, data.stepIndex, data.status, data.duration, { runId: data.runId });
    });

    // Forward self-healing events
    this.selfHealingService.on('healing:suggested', (data) => {
      this.eventService.emit('healing:suggested', data);
      this.telemetry.trackUsage('self-healing-suggestion', data);
    });

    this.selfHealingService.on('healing:applied', (data) => {
      this.eventService.emit('healing:applied', data);
      this.telemetry.trackUsage('self-healing-applied', data);
    });

    // Forward locator healing events
    this.locatorHealingService.on('locator:healed', (data) => {
      this.eventService.emit('locator:healed', data);
    });

    // Forward AI events
    this.aiService.on('ai:response', (data) => {
      this.eventService.emit('ai:response', data);
      this.telemetry.trackUsage('ai-assistant', { capability: data.capability });
    });
  }

  private setupRoutes(): void {
    const router = express.Router();

    // Test runs
    router.get('/runs', this.controller.getRuns.bind(this.controller));
    router.get('/runs/:id', this.controller.getRun.bind(this.controller));
    router.post('/runs', this.controller.createRun.bind(this.controller));
    router.post('/runs/:id/stop', this.controller.stopRun.bind(this.controller));
    router.delete('/runs/:id', this.controller.deleteRun.bind(this.controller));

    // Test cases
    router.get('/cases', this.controller.getCases.bind(this.controller));
    router.get('/cases/:id', this.controller.getCase.bind(this.controller));
    router.post('/cases', this.controller.createCase.bind(this.controller));
    router.put('/cases/:id', this.controller.updateCase.bind(this.controller));
    router.delete('/cases/:id', this.controller.deleteCase.bind(this.controller));

    // Engine management
    router.get('/engines', this.controller.getEngines.bind(this.controller));
    router.get('/engines/:name/status', this.controller.getEngineStatus.bind(this.controller));
    router.post('/engines/:name/start', this.controller.startEngine.bind(this.controller));
    router.post('/engines/:name/stop', this.controller.stopEngine.bind(this.controller));

    // Artifacts
    router.get('/artifacts', this.controller.getArtifacts.bind(this.controller));
    router.get('/artifacts/:id', this.controller.getArtifact.bind(this.controller));
    router.get('/artifacts/:id/download', this.controller.downloadArtifact.bind(this.controller));
    router.delete('/artifacts/:id', this.controller.deleteArtifact.bind(this.controller));

    // Self-healing locators API
    router.post('/locator-healing/record', async (req, res) => {
      try {
        await this.locatorHealingService.recordLocator(req.body);
        res.json({ success: true });
      } catch (error) {
        this.logger.error('Failed to record locator', error);
        res.status(500).json({ error: error.message });
      }
    });

    router.post('/locator-healing/heal', async (req, res) => {
      try {
        const result = await this.locatorHealingService.attemptHealing(req.body);
        res.json(result);
      } catch (error) {
        this.logger.error('Failed to heal locator', error);
        res.status(500).json({ error: error.message });
      }
    });

    router.post('/locator-healing/accept', async (req, res) => {
      try {
        await this.locatorHealingService.acceptSuggestion(req.body.suggestionId);
        res.json({ success: true });
      } catch (error) {
        this.logger.error('Failed to accept healing suggestion', error);
        res.status(500).json({ error: error.message });
      }
    });

    router.get('/locator-healing/suggestions', async (req, res) => {
      try {
        const suggestions = await this.locatorHealingService.getSuggestions(req.query);
        res.json(suggestions);
      } catch (error) {
        this.logger.error('Failed to get healing suggestions', error);
        res.status(500).json({ error: error.message });
      }
    });

    // AI API
    router.post('/ai/chat', async (req, res) => {
      try {
        const response = await this.aiService.chat(req.body.message, req.body.context);
        res.json(response);
      } catch (error) {
        this.logger.error('AI chat error', error);
        res.status(500).json({ error: error.message });
      }
    });

    router.post('/ai/nl-to-dsl', async (req, res) => {
      try {
        const result = await this.aiService.convertNLToDSL(req.body);
        res.json(result);
      } catch (error) {
        this.logger.error('NL to DSL conversion error', error);
        res.status(500).json({ error: error.message });
      }
    });

    router.post('/ai/analyze-failure', async (req, res) => {
      try {
        const result = await this.aiService.analyzeFailure(req.body);
        res.json(result);
      } catch (error) {
        this.logger.error('Failure analysis error', error);
        res.status(500).json({ error: error.message });
      }
    });

    router.post('/ai/suggest-locators', async (req, res) => {
      try {
        const result = await this.aiService.suggestLocators(req.body);
        res.json(result);
      } catch (error) {
        this.logger.error('Locator suggestion error', error);
        res.status(500).json({ error: error.message });
      }
    });

    router.post('/ai/optimize-test', async (req, res) => {
      try {
        const result = await this.aiService.optimizeTest(req.body);
        res.json(result);
      } catch (error) {
        this.logger.error('Test optimization error', error);
        res.status(500).json({ error: error.message });
      }
    });

    router.get('/ai/models', async (req, res) => {
      try {
        const models = await this.aiService.getAvailableModels();
        res.json(models);
      } catch (error) {
        this.logger.error('Failed to get AI models', error);
        res.status(500).json({ error: error.message });
      }
    });

    router.post('/ai/configure', async (req, res) => {
      try {
        await this.aiService.configure(req.body);
        res.json({ success: true });
      } catch (error) {
        this.logger.error('Failed to configure AI', error);
        res.status(500).json({ error: error.message });
      }
    });

    // Apply routes
    this.app.use('/api/v1', router);

    // WebSocket endpoint for real-time events
    this.eventService.setupWebSocket(this.config.wsPort);

    // Log level update endpoint
    this.app.post('/api/v1/logging/level', (req, res) => {
      const { level } = req.body;
      if (['trace', 'debug', 'info', 'warn', 'error', 'fatal'].includes(level)) {
        this.logger.level = level;
        this.logger.info('Log level updated', { newLevel: level });
        res.json({ success: true, level });
      } else {
        res.status(400).json({ error: 'Invalid log level' });
      }
    });

    // Telemetry consent endpoint
    this.app.post('/api/v1/telemetry/consent', (req, res) => {
      const consent = req.body;
      this.telemetry.updateConsent(consent);
      res.json({ success: true });
    });

    this.app.get('/api/v1/telemetry/consent', (req, res) => {
      res.json(this.telemetry.getConsent());
    });
  }

  private setupEngines(): void {
    // Initialize engine adapters if enabled
    if (this.config.engines.desktop?.enabled) {
      this.logger.info('Setting up desktop engine adapter');
      const desktopAdapter = createPythonEngineAdapter({
        name: 'desktop',
        port: this.config.engines.desktop.port!,
        pythonPath: this.config.engines.desktop.pythonPath,
        venvPath: this.config.engines.desktop.venvPath,
        logger: this.logger
      });
      this.runnerService.registerEngine('desktop', desktopAdapter);
    }

    if (this.config.engines.mainframe?.enabled) {
      this.logger.info('Setting up mainframe engine adapter');
      const mainframeAdapter = createPythonEngineAdapter({
        name: 'mainframe',
        port: this.config.engines.mainframe.port!,
        pythonPath: this.config.engines.mainframe.pythonPath,
        venvPath: this.config.engines.mainframe.venvPath,
        logger: this.logger
      });
      this.runnerService.registerEngine('mainframe', mainframeAdapter);
    }

    // Note: Web and API engines would be registered similarly
  }

  /**
   * Start the orchestrator
   */
  async start(): Promise<void> {
    return new Promise((resolve) => {
      this.app.listen(this.config.port, this.config.host, () => {
        this.logger.info('Orchestrator started', {
          host: this.config.host,
          port: this.config.port,
          wsPort: this.config.wsPort,
          engines: Object.entries(this.config.engines)
            .filter(([_, config]) => config?.enabled)
            .map(([name]) => name)
        });
        resolve();
      });
    });
  }

  /**
   * Stop the orchestrator
   */
  async stop(): Promise<void> {
    this.logger.info('Stopping orchestrator');
    await this.runnerService.stopAllRuns();
    await this.eventService.close();
    await this.telemetry.shutdown();
  }

  /**
   * Get orchestrator instance
   */
  getApp(): express.Application {
    return this.app;
  }
}

// Export convenience function
export function createOrchestrator(config?: Partial<OrchestratorConfig>): Orchestrator {
  return new Orchestrator(config);
}

// Start orchestrator if run directly
if (require.main === module) {
  const orchestrator = createOrchestrator({
    port: parseInt(process.env.PORT || '3001'),
    host: process.env.HOST || 'localhost',
    wsPort: parseInt(process.env.WS_PORT || '3002'),
    observability: {
      logLevel: (process.env.LOG_LEVEL || 'info') as LogLevel,
      metricsEnabled: process.env.METRICS_ENABLED !== 'false',
      telemetryEnabled: process.env.TELEMETRY_ENABLED === 'true',
      telemetryEndpoint: process.env.TELEMETRY_ENDPOINT
    }
  });

  orchestrator.start().catch((error) => {
    console.error('Failed to start orchestrator:', error);
    process.exit(1);
  });

  // Graceful shutdown
  process.on('SIGTERM', async () => {
    await orchestrator.stop();
    process.exit(0);
  });

  process.on('SIGINT', async () => {
    await orchestrator.stop();
    process.exit(0);
  });
} 

// Export orchestrator
export { Orchestrator, createOrchestrator };

// Export self-healing modules
export * from './locator-manager';
export { LocatorHealingService } from './services/locator-healing.service';

// Export AI modules
export * from './ai';

// Export remote runner modules
export * from './remote-runner';

// Export collaboration modules
export * from './collaboration'; 