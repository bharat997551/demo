import { spawn, ChildProcess } from 'child_process';
import axios, { AxiosInstance } from 'axios';
import { logger } from '@hybrid-qa/common';
import { BaseEngine, IEngine, EngineConfig, RunContext, StepExecutionResult, EngineHealth } from '../interfaces/engine.interface';
import { Step } from '@hybrid-qa/dsl';
import path from 'path';

/**
 * Python engine configuration
 */
interface PythonEngineConfig extends EngineConfig {
  pythonPath?: string;
  scriptPath: string;
  port: number;
  host: string;
  venvPath?: string;
  startupTimeout: number;
  maxRestarts: number;
}

/**
 * Python engine lifecycle states
 */
type EngineState = 'stopped' | 'starting' | 'running' | 'stopping' | 'failed';

/**
 * Adapter for Python-based engines (desktop, mainframe) with lifecycle management
 */
export class PythonEngineAdapter extends BaseEngine {
  private process?: ChildProcess;
  private httpClient?: AxiosInstance;
  private state: EngineState = 'stopped';
  private restartCount = 0;
  private lastStartTime?: Date;
  private healthCheckInterval?: NodeJS.Timeout;

  constructor(config: PythonEngineConfig) {
    super(config);
    this.initializeHttpClient();
  }

  get pythonConfig(): PythonEngineConfig {
    return this.config as PythonEngineConfig;
  }

  supports(stepKind: string): boolean {
    const supportedKinds = this.getSupportedStepKinds();
    return supportedKinds.includes(stepKind);
  }

  getSupportedStepKinds(): string[] {
    // This would be determined based on the engine type
    if (this.config.type === 'desktop') {
      return [
        'desktop.click',
        'desktop.double-click',
        'desktop.right-click',
        'desktop.type',
        'desktop.key-press',
        'desktop.hotkey',
        'desktop.drag-drop',
        'desktop.scroll',
        'desktop.wait',
        'desktop.screenshot',
        'desktop.extract',
        'desktop.window-focus',
        'desktop.window-close',
        'desktop.window-maximize',
        'desktop.window-minimize'
      ];
    } else if (this.config.type === 'mainframe') {
      return [
        'mainframe.connect',
        'mainframe.disconnect',
        'mainframe.send',
        'mainframe.send-key',
        'mainframe.wait',
        'mainframe.screenshot',
        'mainframe.extract',
        'mainframe.clear-field',
        'mainframe.set-cursor',
        'mainframe.execute-command'
      ];
    }
    return [];
  }

  async runStep(step: Step, context: RunContext): Promise<StepExecutionResult> {
    if (!this.httpClient || this.state !== 'running') {
      throw new Error(`Engine not ready. Current state: ${this.state}`);
    }

    const startTime = new Date();

    try {
      const response = await this.httpClient.post('/runStep', {
        action: step.kind,
        target: step.locator,
        value: step.value,
        options: step.options,
        timeout: step.timeout || context.timeout,
        context: {
          runId: context.runId,
          stepId: context.stepId,
          variables: context.variables
        }
      });

      const endTime = new Date();
      const duration = endTime.getTime() - startTime.getTime();

      if (response.data.success) {
        return {
          stepId: step.id,
          status: 'completed',
          startTime,
          endTime,
          duration,
          extractedData: response.data.result,
          screenshots: response.data.screenshot ? [response.data.screenshot] : [],
          logs: [],
          healing: response.data.healing
        };
      } else {
        return {
          stepId: step.id,
          status: 'failed',
          startTime,
          endTime,
          duration,
          error: response.data.error,
          screenshots: response.data.screenshot ? [response.data.screenshot] : [],
          logs: []
        };
      }
    } catch (error) {
      const endTime = new Date();
      const duration = endTime.getTime() - startTime.getTime();

      logger.error('Python engine step execution failed', {
        engineType: this.config.type,
        stepKind: step.kind,
        error: error instanceof Error ? error.message : 'Unknown error'
      });

      return {
        stepId: step.id,
        status: 'failed',
        startTime,
        endTime,
        duration,
        error: error instanceof Error ? error.message : 'HTTP request failed',
        screenshots: [],
        logs: []
      };
    }
  }

  protected async doInitialize(): Promise<void> {
    await this.startPythonProcess();
    await this.waitForEngineReady();
    this.setupHealthChecking();
  }

  protected async doCleanup(): Promise<void> {
    this.clearHealthCheck();
    await this.stopPythonProcess();
  }

  protected async doHealthCheck(): Promise<void> {
    if (!this.httpClient || this.state !== 'running') {
      throw new Error(`Engine not running. State: ${this.state}`);
    }

    try {
      const response = await this.httpClient.get('/health', {
        timeout: this.config.healthCheck.timeout
      });

      if (response.status !== 200 || response.data.status !== 'healthy') {
        throw new Error(`Health check failed: ${JSON.stringify(response.data)}`);
      }
    } catch (error) {
      // Try to restart if health check fails
      logger.warn('Python engine health check failed, attempting restart', {
        engineType: this.config.type,
        error: error instanceof Error ? error.message : 'Unknown error'
      });

      await this.restart();
      throw error;
    }
  }

  protected doValidateStep(step: Step): string[] {
    const errors: string[] = [];

    // Basic validation
    if (!step.kind) {
      errors.push('Step kind is required');
    }

    // Engine-specific validation based on step kind
    if (this.config.type === 'desktop') {
      if (step.kind.startsWith('desktop.') && !step.locator && 
          !['desktop.wait', 'desktop.screenshot'].includes(step.kind)) {
        errors.push('Desktop steps require a locator (except wait and screenshot)');
      }
    } else if (this.config.type === 'mainframe') {
      if (step.kind === 'mainframe.connect' && !step.options?.host) {
        errors.push('Mainframe connect requires host in options');
      }
    }

    return errors;
  }

  /**
   * Restart the Python engine process
   */
  async restart(): Promise<void> {
    if (this.restartCount >= this.pythonConfig.maxRestarts) {
      throw new Error('Maximum restart attempts exceeded');
    }

    logger.info('Restarting Python engine', {
      engineType: this.config.type,
      restartCount: this.restartCount + 1
    });

    try {
      await this.stopPythonProcess();
      this.restartCount++;
      await this.startPythonProcess();
      await this.waitForEngineReady();
    } catch (error) {
      logger.error('Failed to restart Python engine', {
        engineType: this.config.type,
        error
      });
      throw error;
    }
  }

  /**
   * Get engine process information
   */
  getProcessInfo(): {
    pid?: number;
    state: EngineState;
    uptime?: number;
    restartCount: number;
  } {
    return {
      pid: this.process?.pid,
      state: this.state,
      uptime: this.lastStartTime ? Date.now() - this.lastStartTime.getTime() : undefined,
      restartCount: this.restartCount
    };
  }

  // Private methods

  private initializeHttpClient(): void {
    this.httpClient = axios.create({
      baseURL: `http://${this.pythonConfig.host}:${this.pythonConfig.port}`,
      timeout: 30000,
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }

  private async startPythonProcess(): Promise<void> {
    if (this.state === 'starting' || this.state === 'running') {
      return;
    }

    this.state = 'starting';
    const config = this.pythonConfig;

    try {
      // Determine Python executable path
      const pythonExe = config.pythonPath || (process.platform === 'win32' ? 'python.exe' : 'python3');
      const pythonPath = config.venvPath 
        ? path.join(config.venvPath, process.platform === 'win32' ? 'Scripts/python.exe' : 'bin/python3')
        : pythonExe;

      // Start the Python process
      this.process = spawn(pythonPath, [config.scriptPath], {
        cwd: path.dirname(config.scriptPath),
        env: {
          ...process.env,
          PYTHONPATH: path.dirname(config.scriptPath),
          ENGINE_PORT: config.port.toString(),
          ENGINE_HOST: config.host
        },
        stdio: ['pipe', 'pipe', 'pipe']
      });

      this.lastStartTime = new Date();

      // Handle process events
      this.process.on('error', (error) => {
        logger.error('Python engine process error', {
          engineType: this.config.type,
          error
        });
        this.state = 'failed';
      });

      this.process.on('exit', (code, signal) => {
        logger.warn('Python engine process exited', {
          engineType: this.config.type,
          code,
          signal
        });
        this.state = 'stopped';
        this.process = undefined;
      });

      // Capture stdout/stderr for logging
      this.process.stdout?.on('data', (data) => {
        logger.debug('Python engine stdout', {
          engineType: this.config.type,
          output: data.toString().trim()
        });
      });

      this.process.stderr?.on('data', (data) => {
        logger.debug('Python engine stderr', {
          engineType: this.config.type,
          output: data.toString().trim()
        });
      });

      logger.info('Python engine process started', {
        engineType: this.config.type,
        pid: this.process.pid,
        pythonPath,
        scriptPath: config.scriptPath
      });

    } catch (error) {
      this.state = 'failed';
      logger.error('Failed to start Python engine process', {
        engineType: this.config.type,
        error
      });
      throw error;
    }
  }

  private async stopPythonProcess(): Promise<void> {
    if (!this.process || this.state === 'stopped') {
      return;
    }

    this.state = 'stopping';

    return new Promise((resolve) => {
      const timeout = setTimeout(() => {
        // Force kill if graceful shutdown fails
        if (this.process && !this.process.killed) {
          logger.warn('Force killing Python engine process', {
            engineType: this.config.type,
            pid: this.process.pid
          });
          this.process.kill('SIGKILL');
        }
        resolve();
      }, 10000); // 10 second timeout

      this.process!.on('exit', () => {
        clearTimeout(timeout);
        this.state = 'stopped';
        this.process = undefined;
        resolve();
      });

      // Try graceful shutdown first
      this.process!.kill('SIGTERM');
    });
  }

  private async waitForEngineReady(): Promise<void> {
    const startTime = Date.now();
    const timeout = this.pythonConfig.startupTimeout;

    while (Date.now() - startTime < timeout) {
      try {
        if (this.httpClient) {
          const response = await this.httpClient.get('/health', { timeout: 5000 });
          if (response.status === 200 && response.data.status === 'healthy') {
            this.state = 'running';
            logger.info('Python engine ready', {
              engineType: this.config.type,
              startupTime: Date.now() - startTime
            });
            return;
          }
        }
      } catch (error) {
        // Continue waiting
      }

      await new Promise(resolve => setTimeout(resolve, 1000));
    }

    this.state = 'failed';
    throw new Error(`Python engine failed to start within ${timeout}ms`);
  }

  private setupHealthChecking(): void {
    if (!this.config.healthCheck.enabled) {
      return;
    }

    this.healthCheckInterval = setInterval(async () => {
      try {
        await this.doHealthCheck();
      } catch (error) {
        logger.error('Scheduled health check failed', {
          engineType: this.config.type,
          error
        });
      }
    }, this.config.healthCheck.interval);
  }

  private clearHealthCheck(): void {
    if (this.healthCheckInterval) {
      clearInterval(this.healthCheckInterval);
      this.healthCheckInterval = undefined;
    }
  }
}

/**
 * Factory function to create Python engine adapters
 */
export function createPythonEngineAdapter(
  engineType: 'desktop' | 'mainframe',
  config: Partial<PythonEngineConfig> = {}
): PythonEngineAdapter {
  const defaultConfig: PythonEngineConfig = {
    id: `${engineType}-engine`,
    name: `${engineType.charAt(0).toUpperCase()}${engineType.slice(1)} Engine`,
    type: engineType,
    version: '1.0.0',
    enabled: true,
    host: 'localhost',
    port: engineType === 'desktop' ? 8002 : 8003,
    scriptPath: path.resolve(`../engine-${engineType}/src/main.py`),
    startupTimeout: 30000,
    maxRestarts: 3,
    settings: {},
    healthCheck: {
      enabled: true,
      interval: 60000, // 1 minute
      timeout: 10000,  // 10 seconds
      retries: 3
    }
  };

  const mergedConfig = { ...defaultConfig, ...config };
  return new PythonEngineAdapter(mergedConfig);
} 