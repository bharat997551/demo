import { Step, StepResult, ExecutionStatus } from '@hybrid-qa/dsl';

/**
 * Execution context provided to engines during step execution
 */
export interface RunContext {
  /** Unique run identifier */
  runId: string;
  /** Current test case being executed */
  testCaseId: string;
  /** Step being executed */
  stepId: string;
  /** Variable values available for interpolation */
  variables: Record<string, any>;
  /** Environment configuration */
  environment: Record<string, any>;
  /** Artifact storage directory for this run */
  artifactDir: string;
  /** Timeout for this step execution */
  timeout: number;
  /** Screenshot settings */
  screenshots: {
    onFailure: boolean;
    onSuccess: boolean;
    onStep: boolean;
  };
  /** Previous step results for reference */
  previousResults: StepResult[];
  /** Self-healing context */
  healing: {
    enabled: boolean;
    maxRetries: number;
    learnFromSuccess: boolean;
  };
}

/**
 * Result of executing a single step
 */
export interface StepExecutionResult extends StepResult {
  /** Extracted data from the step (e.g., text, attributes) */
  extractedData?: any;
  /** Screenshot paths captured during execution */
  screenshots: string[];
  /** Performance metrics */
  metrics?: {
    startTime: Date;
    endTime: Date;
    duration: number;
    retryCount: number;
  };
  /** Self-healing information */
  healing?: {
    locatorUsed?: string;
    alternativesAttempted?: string[];
    newLocatorLearned?: string;
  };
}

/**
 * Engine health status
 */
export interface EngineHealth {
  status: 'healthy' | 'degraded' | 'unhealthy' | 'offline';
  message?: string;
  lastCheck: Date;
  responseTime?: number;
  version?: string;
  capabilities?: string[];
}

/**
 * Engine configuration
 */
export interface EngineConfig {
  /** Engine identifier */
  id: string;
  /** Engine name */
  name: string;
  /** Engine type */
  type: 'web' | 'desktop' | 'mainframe' | 'api';
  /** Engine version */
  version: string;
  /** Whether engine is enabled */
  enabled: boolean;
  /** Engine-specific configuration */
  settings: Record<string, any>;
  /** Health check configuration */
  healthCheck: {
    enabled: boolean;
    interval: number;
    timeout: number;
    retries: number;
  };
}

/**
 * Base Engine interface that all automation engines must implement
 */
export interface IEngine {
  /** Engine configuration */
  readonly config: EngineConfig;

  /**
   * Check if this engine supports executing a specific step kind
   * @param stepKind The step kind to check (e.g., 'web.click', 'api.request')
   * @returns true if the engine can execute this step kind
   */
  supports(stepKind: string): boolean;

  /**
   * Execute a single automation step
   * @param step The step to execute
   * @param context Execution context with variables, artifacts, etc.
   * @returns Promise resolving to step execution result
   */
  runStep(step: Step, context: RunContext): Promise<StepExecutionResult>;

  /**
   * Initialize the engine (setup connections, load resources, etc.)
   * @returns Promise resolving when engine is ready
   */
  initialize(): Promise<void>;

  /**
   * Cleanup engine resources and close connections
   * @returns Promise resolving when cleanup is complete
   */
  cleanup(): Promise<void>;

  /**
   * Check engine health status
   * @returns Promise resolving to health status
   */
  healthCheck(): Promise<EngineHealth>;

  /**
   * Get list of step kinds supported by this engine
   * @returns Array of supported step kinds
   */
  getSupportedStepKinds(): string[];

  /**
   * Validate engine-specific step configuration
   * @param step Step to validate
   * @returns Validation result with errors if any
   */
  validateStep(step: Step): { valid: boolean; errors?: string[] };

  /**
   * Record successful locator usage for self-healing
   * @param elementId Unique identifier for the element
   * @param locator Locator that was successful
   * @param context Current execution context
   */
  recordSuccessfulLocator?(elementId: string, locator: string, context: RunContext): Promise<void>;
}

/**
 * Base abstract engine class providing common functionality
 */
export abstract class BaseEngine implements IEngine {
  protected _initialized = false;
  protected _health: EngineHealth = {
    status: 'offline',
    lastCheck: new Date(),
    message: 'Engine not initialized'
  };

  constructor(public readonly config: EngineConfig) {}

  abstract supports(stepKind: string): boolean;
  abstract runStep(step: Step, context: RunContext): Promise<StepExecutionResult>;
  abstract getSupportedStepKinds(): string[];

  async initialize(): Promise<void> {
    if (this._initialized) {
      return;
    }

    try {
      await this.doInitialize();
      this._initialized = true;
      this._health = {
        status: 'healthy',
        lastCheck: new Date(),
        message: 'Engine initialized successfully',
        version: this.config.version
      };
    } catch (error) {
      this._health = {
        status: 'unhealthy',
        lastCheck: new Date(),
        message: `Initialization failed: ${error instanceof Error ? error.message : 'Unknown error'}`
      };
      throw error;
    }
  }

  async cleanup(): Promise<void> {
    if (!this._initialized) {
      return;
    }

    try {
      await this.doCleanup();
      this._initialized = false;
      this._health = {
        status: 'offline',
        lastCheck: new Date(),
        message: 'Engine cleaned up'
      };
    } catch (error) {
      this._health = {
        status: 'unhealthy',
        lastCheck: new Date(),
        message: `Cleanup failed: ${error instanceof Error ? error.message : 'Unknown error'}`
      };
      throw error;
    }
  }

  async healthCheck(): Promise<EngineHealth> {
    if (!this._initialized) {
      return {
        status: 'offline',
        lastCheck: new Date(),
        message: 'Engine not initialized'
      };
    }

    try {
      const startTime = Date.now();
      await this.doHealthCheck();
      const responseTime = Date.now() - startTime;

      this._health = {
        status: 'healthy',
        lastCheck: new Date(),
        responseTime,
        version: this.config.version,
        capabilities: this.getSupportedStepKinds()
      };
    } catch (error) {
      this._health = {
        status: 'unhealthy',
        lastCheck: new Date(),
        message: error instanceof Error ? error.message : 'Health check failed'
      };
    }

    return this._health;
  }

  validateStep(step: Step): { valid: boolean; errors?: string[] } {
    const errors: string[] = [];

    // Check if step kind is supported
    if (!this.supports(step.kind)) {
      errors.push(`Step kind '${step.kind}' is not supported by engine '${this.config.name}'`);
    }

    // Engine-specific validation
    const engineErrors = this.doValidateStep(step);
    if (engineErrors.length > 0) {
      errors.push(...engineErrors);
    }

    return {
      valid: errors.length === 0,
      errors: errors.length > 0 ? errors : undefined
    };
  }

  /**
   * Engine-specific initialization logic
   */
  protected abstract doInitialize(): Promise<void>;

  /**
   * Engine-specific cleanup logic
   */
  protected abstract doCleanup(): Promise<void>;

  /**
   * Engine-specific health check logic
   */
  protected abstract doHealthCheck(): Promise<void>;

  /**
   * Engine-specific step validation logic
   * @param step Step to validate
   * @returns Array of validation errors
   */
  protected abstract doValidateStep(step: Step): string[];

  /**
   * Create a step execution result with common fields
   */
  protected createStepResult(
    step: Step,
    status: ExecutionStatus,
    context: RunContext,
    additional: Partial<StepExecutionResult> = {}
  ): StepExecutionResult {
    const endTime = new Date();
    const startTime = additional.metrics?.startTime || endTime;
    
    return {
      stepId: step.id,
      status,
      startTime,
      endTime,
      duration: endTime.getTime() - startTime.getTime(),
      screenshots: [],
      logs: [],
      ...additional
    };
  }
} 