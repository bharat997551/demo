import { EventEmitter } from 'events';
import { logger } from '@hybrid-qa/common';
import {
  AIAdapter,
  AIConfig,
  NLToDSLRequest,
  NLToDSLResponse,
  FailureTriageRequest,
  FailureTriageResponse,
  LocatorSuggestionRequest,
  LocatorSuggestionResponse,
  TestOptimizationRequest,
  TestOptimizationResponse,
  AssistantRequest,
  AssistantResponse,
  ChatMessage
} from './types';
import { OllamaAdapter } from './adapters/ollama-adapter';
import { OpenAIAdapter } from './adapters/openai-adapter';
import { MockAdapter } from './adapters/mock-adapter';
import { SYSTEM_PROMPTS, FEW_SHOT_EXAMPLES, buildPrompt } from './prompts';

export class AIService extends EventEmitter {
  private adapter: AIAdapter | null = null;
  private config: AIConfig | null = null;
  private conversationHistory: ChatMessage[] = [];

  async initialize(config: AIConfig): Promise<void> {
    this.config = config;
    
    // Create appropriate adapter
    switch (config.provider) {
      case 'ollama':
        this.adapter = new OllamaAdapter();
        break;
      case 'openai':
        this.adapter = new OpenAIAdapter();
        break;
      case 'mock':
        this.adapter = new MockAdapter();
        break;
      default:
        throw new Error(`Unknown AI provider: ${config.provider}`);
    }

    await this.adapter.initialize(config);
    
    const modelInfo = await this.adapter.getModelInfo();
    logger.info('AI service initialized', { provider: config.provider, model: modelInfo });
    
    this.emit('initialized', { config, modelInfo });
  }

  async convertNLToDSL(request: NLToDSLRequest): Promise<NLToDSLResponse> {
    if (!this.adapter) {
      throw new Error('AI service not initialized');
    }

    try {
      // Select appropriate examples based on target type
      const examples = request.targetType 
        ? FEW_SHOT_EXAMPLES.nlToDsl[request.targetType] || []
        : [...FEW_SHOT_EXAMPLES.nlToDsl.web, ...FEW_SHOT_EXAMPLES.nlToDsl.api];

      const prompt = buildPrompt('nlToDsl', examples, {
        intent: request.intent,
        context: request.context,
        targetType: request.targetType
      });

      const response = await this.adapter.complete(prompt, {
        temperature: 0.3, // Lower temperature for more consistent output
        maxTokens: 2000
      });

      // Parse response
      const parsed = this.parseJSONResponse(response);
      
      return {
        steps: parsed.steps || [],
        confidence: parsed.confidence || this.estimateConfidence(parsed.steps),
        explanation: parsed.explanation,
        alternatives: parsed.alternatives
      };
    } catch (error) {
      logger.error('NL to DSL conversion failed', { error, request });
      throw error;
    }
  }

  async triageFailure(request: FailureTriageRequest): Promise<FailureTriageResponse> {
    if (!this.adapter) {
      throw new Error('AI service not initialized');
    }

    try {
      const prompt = buildPrompt('failureTriage', FEW_SHOT_EXAMPLES.failureTriage, request);
      
      const response = await this.adapter.complete(prompt, {
        temperature: 0.5,
        maxTokens: 1500
      });

      const parsed = this.parseJSONResponse(response);
      
      return {
        summary: parsed.summary || 'Unable to determine failure cause',
        rootCause: parsed.rootCause || 'Unknown',
        suggestedFixes: parsed.suggestedFixes || [],
        relatedIssues: parsed.relatedIssues
      };
    } catch (error) {
      logger.error('Failure triage failed', { error, request });
      throw error;
    }
  }

  async suggestLocators(request: LocatorSuggestionRequest): Promise<LocatorSuggestionResponse> {
    if (!this.adapter) {
      throw new Error('AI service not initialized');
    }

    try {
      const prompt = buildPrompt('locatorSuggestion', FEW_SHOT_EXAMPLES.locatorSuggestion, request);
      
      const response = await this.adapter.complete(prompt, {
        temperature: 0.3,
        maxTokens: 1000
      });

      const parsed = this.parseJSONResponse(response);
      
      return {
        locators: parsed.locators || [],
        bestPractices: parsed.bestPractices
      };
    } catch (error) {
      logger.error('Locator suggestion failed', { error, request });
      throw error;
    }
  }

  async optimizeTest(request: TestOptimizationRequest): Promise<TestOptimizationResponse> {
    if (!this.adapter) {
      throw new Error('AI service not initialized');
    }

    try {
      const prompt = buildPrompt('testOptimization', FEW_SHOT_EXAMPLES.testOptimization, request);
      
      const response = await this.adapter.complete(prompt, {
        temperature: 0.5,
        maxTokens: 2000
      });

      const parsed = this.parseJSONResponse(response);
      
      return {
        optimizedSteps: parsed.optimizedSteps || request.steps,
        improvements: parsed.improvements || [],
        estimatedTimeSaving: parsed.estimatedTimeSaving
      };
    } catch (error) {
      logger.error('Test optimization failed', { error, request });
      throw error;
    }
  }

  async processAssistantRequest(request: AssistantRequest): Promise<AssistantResponse> {
    if (!this.adapter) {
      throw new Error('AI service not initialized');
    }

    try {
      // Determine the intent from the message
      const intent = await this.classifyIntent(request.message);
      
      // Add to conversation history
      this.conversationHistory.push({
        role: 'user',
        content: request.message
      });

      let response: AssistantResponse;

      switch (intent) {
        case 'create-test':
          const nlResponse = await this.convertNLToDSL({
            intent: request.message,
            context: request.context
          });
          response = {
            type: 'steps',
            content: nlResponse.steps,
            suggestions: nlResponse.alternatives,
            requiresConfirmation: true,
            metadata: {
              confidence: nlResponse.confidence
            }
          };
          break;

        case 'debug-error':
          if (request.context?.recentErrors?.length) {
            const triageResponse = await this.triageFailure({
              error: request.context.recentErrors[0],
              logs: [],
              step: {}
            });
            response = {
              type: 'explanation',
              content: triageResponse,
              requiresConfirmation: false
            };
          } else {
            response = {
              type: 'question',
              content: 'Could you share the error details or logs you need help with?',
              requiresConfirmation: false
            };
          }
          break;

        case 'optimize':
          if (request.context?.currentFlow) {
            const optimizeResponse = await this.optimizeTest({
              steps: request.context.currentFlow.steps || []
            });
            response = {
              type: 'steps',
              content: optimizeResponse.optimizedSteps,
              suggestions: [{
                description: 'Optimization suggestions',
                improvements: optimizeResponse.improvements
              }],
              requiresConfirmation: true
            };
          } else {
            response = {
              type: 'question',
              content: 'Which test would you like me to optimize?',
              requiresConfirmation: false
            };
          }
          break;

        default:
          // General chat
          const chatResponse = await this.adapter.chat([
            {
              role: 'system',
              content: 'You are a helpful test automation assistant. Help users create, debug, and optimize their tests.'
            },
            ...this.conversationHistory
          ]);
          
          response = {
            type: 'explanation',
            content: chatResponse,
            requiresConfirmation: false
          };
      }

      // Add assistant response to history
      this.conversationHistory.push({
        role: 'assistant',
        content: JSON.stringify(response)
      });

      // Keep conversation history limited
      if (this.conversationHistory.length > 20) {
        this.conversationHistory = this.conversationHistory.slice(-20);
      }

      return response;
    } catch (error) {
      logger.error('Assistant request failed', { error, request });
      return {
        type: 'error',
        content: 'I encountered an error processing your request. Please try again.',
        requiresConfirmation: false
      };
    }
  }

  async isAvailable(): Promise<boolean> {
    return this.adapter?.isAvailable() || false;
  }

  private parseJSONResponse(response: string): any {
    try {
      // Try to extract JSON from the response
      const jsonMatch = response.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0]);
      }
      
      // If no JSON found, try to parse the entire response
      return JSON.parse(response);
    } catch (error) {
      // If parsing fails, return structured response based on content
      logger.warn('Failed to parse AI response as JSON', { response });
      return { content: response };
    }
  }

  private estimateConfidence(steps: any[]): number {
    if (!steps || steps.length === 0) return 0;
    
    // Simple heuristic: confidence based on step completeness
    let score = 0;
    let total = steps.length;
    
    steps.forEach(step => {
      if (step.type && step.selector || step.url || step.text) {
        score += 1;
      } else if (step.type) {
        score += 0.5;
      }
    });
    
    return Math.min(score / total, 0.95);
  }

  private async classifyIntent(message: string): Promise<string> {
    const lowerMessage = message.toLowerCase();
    
    // Simple keyword-based classification
    if (lowerMessage.includes('create') || lowerMessage.includes('test') || lowerMessage.includes('click') || lowerMessage.includes('fill') || lowerMessage.includes('navigate')) {
      return 'create-test';
    }
    
    if (lowerMessage.includes('error') || lowerMessage.includes('fail') || lowerMessage.includes('debug') || lowerMessage.includes('fix')) {
      return 'debug-error';
    }
    
    if (lowerMessage.includes('optimize') || lowerMessage.includes('improve') || lowerMessage.includes('faster') || lowerMessage.includes('reduce')) {
      return 'optimize';
    }
    
    return 'general';
  }

  clearConversation(): void {
    this.conversationHistory = [];
  }
} 