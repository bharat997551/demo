import { AIAdapter, AIConfig, ChatMessage, CompletionOptions, ModelInfo } from '../types';
import { logger } from '@hybrid-qa/common';

export class OpenAIAdapter implements AIAdapter {
  private config!: AIConfig;
  private baseUrl: string = 'https://api.openai.com/v1';

  async initialize(config: AIConfig): Promise<void> {
    this.config = config;
    if (!config.apiKey) {
      throw new Error('OpenAI API key is required');
    }
    
    if (config.baseUrl) {
      this.baseUrl = config.baseUrl;
    }
    
    // Test connection
    const available = await this.isAvailable();
    if (!available) {
      throw new Error('OpenAI API is not available or invalid API key');
    }
    
    logger.info('OpenAI adapter initialized', {
      model: config.model,
      baseUrl: this.baseUrl
    });
  }

  async complete(prompt: string, options?: CompletionOptions): Promise<string> {
    return this.chat([
      { role: 'system', content: options?.systemPrompt || 'You are a helpful assistant.' },
      { role: 'user', content: prompt }
    ], options);
  }

  async chat(messages: ChatMessage[], options?: CompletionOptions): Promise<string> {
    try {
      const response = await fetch(`${this.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.config.apiKey}`
        },
        body: JSON.stringify({
          model: this.config.model,
          messages,
          temperature: options?.temperature ?? this.config.temperature ?? 0.7,
          max_tokens: options?.maxTokens ?? this.config.maxTokens ?? 1000,
          stop: options?.stopSequences
        })
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(`OpenAI API error: ${error.error?.message || response.status}`);
      }

      const data = await response.json();
      return data.choices[0].message.content;
    } catch (error) {
      logger.error('OpenAI chat failed', { error });
      throw error;
    }
  }

  async isAvailable(): Promise<boolean> {
    try {
      const response = await fetch(`${this.baseUrl}/models`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${this.config.apiKey}`
        },
        signal: AbortSignal.timeout(5000)
      });
      return response.ok;
    } catch {
      return false;
    }
  }

  async getModelInfo(): Promise<ModelInfo> {
    const modelCapabilities: Record<string, ModelInfo> = {
      'gpt-4': {
        name: 'gpt-4',
        provider: 'openai',
        contextWindow: 8192,
        capabilities: ['completion', 'chat', 'code', 'reasoning', 'function-calling']
      },
      'gpt-4-turbo': {
        name: 'gpt-4-turbo',
        provider: 'openai',
        contextWindow: 128000,
        capabilities: ['completion', 'chat', 'code', 'reasoning', 'function-calling', 'vision']
      },
      'gpt-3.5-turbo': {
        name: 'gpt-3.5-turbo',
        provider: 'openai',
        contextWindow: 4096,
        capabilities: ['completion', 'chat', 'code', 'function-calling']
      },
      'gpt-3.5-turbo-16k': {
        name: 'gpt-3.5-turbo-16k',
        provider: 'openai',
        contextWindow: 16384,
        capabilities: ['completion', 'chat', 'code', 'function-calling']
      }
    };

    // Check if we have info for the specific model
    if (modelCapabilities[this.config.model]) {
      return modelCapabilities[this.config.model];
    }

    // Default for unknown models
    return {
      name: this.config.model,
      provider: 'openai',
      contextWindow: 4096,
      capabilities: ['completion', 'chat']
    };
  }
} 