import { AIAdapter, AIConfig, ChatMessage, CompletionOptions, ModelInfo } from '../types';
import { logger } from '@hybrid-qa/common';

export class MockAdapter implements AIAdapter {
  private config!: AIConfig;
  private responses: Map<string, string> = new Map();

  constructor() {
    // Pre-configure some mock responses
    this.setupMockResponses();
  }

  async initialize(config: AIConfig): Promise<void> {
    this.config = config;
    logger.info('Mock AI adapter initialized', { model: config.model });
  }

  async complete(prompt: string, options?: CompletionOptions): Promise<string> {
    // Look for pre-configured responses
    for (const [key, response] of this.responses) {
      if (prompt.toLowerCase().includes(key.toLowerCase())) {
        return response;
      }
    }
    
    // Default mock response
    return `Mock response for: ${prompt.substring(0, 50)}...`;
  }

  async chat(messages: ChatMessage[], options?: CompletionOptions): Promise<string> {
    const lastMessage = messages[messages.length - 1];
    return this.complete(lastMessage.content, options);
  }

  async isAvailable(): Promise<boolean> {
    return true;
  }

  async getModelInfo(): Promise<ModelInfo> {
    return {
      name: 'mock-model',
      provider: 'mock',
      contextWindow: 100000,
      capabilities: ['completion', 'chat', 'code', 'reasoning']
    };
  }

  private setupMockResponses() {
    // Natural Language to DSL examples
    this.responses.set('login', JSON.stringify({
      steps: [
        {
          type: 'web.navigate',
          url: '${baseUrl}/login'
        },
        {
          type: 'web.fill',
          selector: '#username',
          value: '${username}'
        },
        {
          type: 'web.fill',
          selector: '#password',
          value: '${password}'
        },
        {
          type: 'web.click',
          selector: 'button[type="submit"]'
        },
        {
          type: 'web.waitForSelector',
          selector: '.dashboard',
          timeout: 5000
        }
      ]
    }));

    this.responses.set('click button', JSON.stringify({
      steps: [
        {
          type: 'web.click',
          selector: 'button',
          text: 'Submit'
        }
      ]
    }));

    this.responses.set('api test', JSON.stringify({
      steps: [
        {
          type: 'api.request',
          method: 'GET',
          url: '${apiUrl}/users',
          headers: {
            'Authorization': 'Bearer ${token}'
          }
        },
        {
          type: 'api.expect',
          status: 200,
          body: {
            users: '${array}'
          }
        }
      ]
    }));

    this.responses.set('mainframe', JSON.stringify({
      steps: [
        {
          type: 'mainframe.connect',
          host: '${mainframeHost}',
          port: 3270
        },
        {
          type: 'mainframe.waitForField',
          row: 24,
          col: 2,
          text: 'READY'
        },
        {
          type: 'mainframe.type',
          text: 'LOGON ${userId}'
        },
        {
          type: 'mainframe.sendKey',
          key: 'ENTER'
        }
      ]
    }));

    this.responses.set('desktop click', JSON.stringify({
      steps: [
        {
          type: 'desktop.click',
          locator: {
            type: 'name',
            value: 'Save'
          }
        }
      ]
    }));

    // Failure triage responses
    this.responses.set('element not found', JSON.stringify({
      summary: 'The element could not be located on the page',
      rootCause: 'The selector "#submit-button" did not match any elements',
      suggestedFixes: [
        {
          description: 'Update the selector to use a more stable attribute',
          confidence: 0.85,
          steps: [
            'Use data-testid instead of id',
            'Try selector: [data-testid="submit-button"]'
          ]
        },
        {
          description: 'Wait for element to be visible',
          confidence: 0.65,
          steps: [
            'Add waitForSelector before clicking',
            'Increase timeout to 10000ms'
          ]
        }
      ]
    }));

    // Locator suggestions
    this.responses.set('suggest locator', JSON.stringify({
      locators: [
        {
          selector: '[data-testid="submit-form"]',
          type: 'css',
          confidence: 0.95,
          reasoning: 'data-testid attributes are stable and recommended'
        },
        {
          selector: '//button[contains(text(), "Submit")]',
          type: 'xpath',
          confidence: 0.75,
          reasoning: 'Text-based selector for buttons with unique text'
        },
        {
          selector: '.form-actions button:first-child',
          type: 'css',
          confidence: 0.60,
          reasoning: 'Structural selector based on form layout'
        }
      ]
    }));

    // Test optimization
    this.responses.set('optimize', JSON.stringify({
      optimizedSteps: [
        {
          type: 'web.navigate',
          url: '${baseUrl}/dashboard'
        },
        {
          type: 'web.fill',
          selector: '#search',
          value: 'test query'
        },
        {
          type: 'web.click',
          selector: '[data-testid="search-button"]'
        }
      ],
      improvements: [
        {
          type: 'merge',
          description: 'Combined login steps into single action',
          impact: 'Reduced 5 steps to 1'
        },
        {
          type: 'remove',
          description: 'Removed redundant wait steps',
          impact: 'Saved 3 seconds'
        }
      ]
    }));
  }
} 