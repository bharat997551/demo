import { AIAdapter, AIConfig, ChatMessage, CompletionOptions, ModelInfo } from '../types';
import { logger } from '@hybrid-qa/common';

export class OllamaAdapter implements AIAdapter {
  private config!: AIConfig;
  private baseUrl: string = 'http://localhost:11434';

  async initialize(config: AIConfig): Promise<void> {
    this.config = config;
    if (config.baseUrl) {
      this.baseUrl = config.baseUrl;
    }
    
    // Test connection
    const available = await this.isAvailable();
    if (!available) {
      throw new Error(`Ollama is not available at ${this.baseUrl}`);
    }
    
    logger.info('Ollama adapter initialized', {
      model: config.model,
      baseUrl: this.baseUrl
    });
  }

  async complete(prompt: string, options?: CompletionOptions): Promise<string> {
    try {
      const response = await fetch(`${this.baseUrl}/api/generate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: this.config.model,
          prompt: options?.systemPrompt ? `${options.systemPrompt}\n\n${prompt}` : prompt,
          stream: false,
          options: {
            temperature: options?.temperature ?? this.config.temperature ?? 0.7,
            num_predict: options?.maxTokens ?? this.config.maxTokens ?? 1000,
            stop: options?.stopSequences
          }
        })
      });

      if (!response.ok) {
        throw new Error(`Ollama request failed: ${response.status}`);
      }

      const data = await response.json();
      return data.response;
    } catch (error) {
      logger.error('Ollama completion failed', { error });
      throw error;
    }
  }

  async chat(messages: ChatMessage[], options?: CompletionOptions): Promise<string> {
    try {
      // Convert messages to Ollama format
      const formattedMessages = messages.map(msg => ({
        role: msg.role === 'system' ? 'system' : msg.role,
        content: msg.content
      }));

      const response = await fetch(`${this.baseUrl}/api/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: this.config.model,
          messages: formattedMessages,
          stream: false,
          options: {
            temperature: options?.temperature ?? this.config.temperature ?? 0.7,
            num_predict: options?.maxTokens ?? this.config.maxTokens ?? 1000,
            stop: options?.stopSequences
          }
        })
      });

      if (!response.ok) {
        throw new Error(`Ollama chat request failed: ${response.status}`);
      }

      const data = await response.json();
      return data.message.content;
    } catch (error) {
      logger.error('Ollama chat failed', { error });
      throw error;
    }
  }

  async isAvailable(): Promise<boolean> {
    try {
      const response = await fetch(`${this.baseUrl}/api/tags`, {
        method: 'GET',
        signal: AbortSignal.timeout(5000)
      });
      return response.ok;
    } catch {
      return false;
    }
  }

  async getModelInfo(): Promise<ModelInfo> {
    try {
      const response = await fetch(`${this.baseUrl}/api/show`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: this.config.model })
      });

      if (!response.ok) {
        throw new Error('Failed to get model info');
      }

      const data = await response.json();
      
      return {
        name: this.config.model,
        provider: 'ollama',
        contextWindow: this.extractContextWindow(data),
        capabilities: ['completion', 'chat', 'code', 'reasoning']
      };
    } catch (error) {
      logger.error('Failed to get Ollama model info', { error });
      
      // Return default info
      return {
        name: this.config.model,
        provider: 'ollama',
        contextWindow: 4096,
        capabilities: ['completion', 'chat']
      };
    }
  }

  private extractContextWindow(modelData: any): number {
    // Try to extract context window from model parameters
    if (modelData.parameters?.num_ctx) {
      return parseInt(modelData.parameters.num_ctx);
    }
    
    // Default context windows for common models
    const defaults: Record<string, number> = {
      'llama2': 4096,
      'codellama': 16384,
      'mistral': 8192,
      'mixtral': 32768,
      'phi': 2048
    };
    
    for (const [model, size] of Object.entries(defaults)) {
      if (this.config.model.toLowerCase().includes(model)) {
        return size;
      }
    }
    
    return 4096; // Default
  }
} 