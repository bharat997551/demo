export const SYSTEM_PROMPTS = {
  nlToDsl: `You are an expert test automation engineer. Convert natural language test descriptions into structured DSL steps.
Always return valid JSON with a 'steps' array. Each step should have a 'type' and relevant parameters.
Available step types:
- Web: web.navigate, web.click, web.fill, web.select, web.waitForSelector, web.expect
- API: api.request, api.expect, api.extract
- Desktop: desktop.click, desktop.type, desktop.waitFor, desktop.expect
- Mainframe: mainframe.connect, mainframe.type, mainframe.sendKey, mainframe.waitForField, mainframe.expect`,

  failureTriage: `You are a test failure analysis expert. Analyze test failures and provide actionable insights.
Consider the error message, stack trace, and logs to determine the root cause.
Suggest specific fixes with confidence levels. Be concise but thorough.`,

  locatorSuggestion: `You are a UI automation expert specializing in robust element locators.
Suggest stable, maintainable selectors based on element properties and context.
Prioritize: data-testid > aria-label > unique text > semantic HTML > ID > class.
Explain your reasoning for each suggestion.`,

  testOptimization: `You are a test optimization specialist. Analyze test steps and suggest improvements.
Look for: redundant steps, inefficient waits, steps that can be merged or parallelized.
Consider performance, maintainability, and reliability.`
};

export const FEW_SHOT_EXAMPLES = {
  nlToDsl: {
    web: [
      {
        input: "Login to the application with username 'testuser' and password 'testpass'",
        output: {
          steps: [
            {
              type: "web.navigate",
              url: "${baseUrl}/login",
              description: "Navigate to login page"
            },
            {
              type: "web.fill",
              selector: "#username",
              value: "testuser",
              description: "Enter username"
            },
            {
              type: "web.fill",
              selector: "#password", 
              value: "testpass",
              description: "Enter password"
            },
            {
              type: "web.click",
              selector: "button[type='submit']",
              description: "Click login button"
            },
            {
              type: "web.waitForSelector",
              selector: ".dashboard",
              timeout: 5000,
              description: "Wait for dashboard to load"
            }
          ]
        }
      },
      {
        input: "Search for 'laptop' and add the first result to cart",
        output: {
          steps: [
            {
              type: "web.fill",
              selector: "[data-testid='search-input']",
              value: "laptop",
              description: "Enter search term"
            },
            {
              type: "web.click",
              selector: "[data-testid='search-button']",
              description: "Click search button"
            },
            {
              type: "web.waitForSelector",
              selector: ".search-results",
              timeout: 3000,
              description: "Wait for results"
            },
            {
              type: "web.click",
              selector: ".search-results .product-item:first-child .add-to-cart",
              description: "Add first product to cart"
            }
          ]
        }
      }
    ],
    api: [
      {
        input: "Test the user creation API endpoint",
        output: {
          steps: [
            {
              type: "api.request",
              method: "POST",
              url: "${apiUrl}/users",
              headers: {
                "Authorization": "Bearer ${token}",
                "Content-Type": "application/json"
              },
              body: {
                "name": "Test User",
                "email": "test@example.com",
                "role": "user"
              },
              description: "Create new user"
            },
            {
              type: "api.expect",
              status: 201,
              body: {
                "id": "${notEmpty}",
                "name": "Test User",
                "email": "test@example.com"
              },
              description: "Verify user created"
            },
            {
              type: "api.extract",
              from: "response.body.id",
              to: "userId",
              description: "Save user ID"
            }
          ]
        }
      }
    ],
    desktop: [
      {
        input: "Open Notepad and save a file",
        output: {
          steps: [
            {
              type: "desktop.launch",
              application: "notepad.exe",
              description: "Launch Notepad"
            },
            {
              type: "desktop.type",
              text: "Hello, World!",
              description: "Type text"
            },
            {
              type: "desktop.keyboard",
              keys: "Ctrl+S",
              description: "Open save dialog"
            },
            {
              type: "desktop.waitFor",
              window: "Save As",
              timeout: 3000,
              description: "Wait for save dialog"
            },
            {
              type: "desktop.type",
              text: "test_file.txt",
              description: "Enter filename"
            },
            {
              type: "desktop.click",
              locator: { type: "name", value: "Save" },
              description: "Click save button"
            }
          ]
        }
      }
    ],
    mainframe: [
      {
        input: "Login to CICS and check account balance",
        output: {
          steps: [
            {
              type: "mainframe.connect",
              host: "${mainframeHost}",
              port: 3270,
              description: "Connect to mainframe"
            },
            {
              type: "mainframe.waitForField",
              row: 24,
              col: 2,
              text: "READY",
              description: "Wait for ready prompt"
            },
            {
              type: "mainframe.type",
              text: "CESN",
              description: "Enter CICS sign-on"
            },
            {
              type: "mainframe.sendKey",
              key: "ENTER",
              description: "Submit command"
            },
            {
              type: "mainframe.waitForField",
              row: 10,
              col: 20,
              text: "Userid",
              description: "Wait for login screen"
            },
            {
              type: "mainframe.type",
              text: "${userId}",
              row: 10,
              col: 30,
              description: "Enter user ID"
            },
            {
              type: "mainframe.type",
              text: "${password}",
              row: 11,
              col: 30,
              description: "Enter password"
            },
            {
              type: "mainframe.sendKey",
              key: "ENTER",
              description: "Submit credentials"
            },
            {
              type: "mainframe.type",
              text: "ACCT",
              description: "Enter account transaction"
            },
            {
              type: "mainframe.sendKey",
              key: "ENTER",
              description: "Submit transaction"
            },
            {
              type: "mainframe.expect",
              row: 15,
              col: 40,
              pattern: "\\$[0-9,]+\\.[0-9]{2}",
              description: "Verify balance displayed"
            }
          ]
        }
      }
    ]
  },

  failureTriage: [
    {
      input: {
        error: {
          message: "Element not found: Unable to locate element: #submit-button",
          stackTrace: "at Locator.click (locator.js:123)\nat LoginPage.submit (login.page.js:45)"
        },
        logs: [
          { level: "info", message: "Navigating to /login" },
          { level: "info", message: "Page loaded" },
          { level: "error", message: "Element #submit-button not found after 30s" }
        ]
      },
      output: {
        summary: "Login button selector failed to match any element on the page",
        rootCause: "The #submit-button selector is not finding the expected element, likely due to a DOM structure change",
        suggestedFixes: [
          {
            description: "Use a more stable selector based on button text or data-testid",
            confidence: 0.85,
            steps: [
              "Replace selector '#submit-button' with '[data-testid=\"submit-button\"]'",
              "Or use text-based selector: 'button:has-text(\"Login\")'",
              "Add explicit wait before clicking: await page.waitForSelector('[data-testid=\"submit-button\"]', { state: 'visible' })"
            ]
          },
          {
            description: "Check if login page structure has changed",
            confidence: 0.70,
            steps: [
              "Verify the login page URL is correct",
              "Check if there's a new authentication flow",
              "Inspect the actual button element and update selector accordingly"
            ]
          }
        ]
      }
    }
  ],

  locatorSuggestion: [
    {
      input: {
        element: {
          html: '<button class="btn btn-primary submit-form" onclick="submitForm()">Submit</button>',
          attributes: {
            class: "btn btn-primary submit-form",
            onclick: "submitForm()"
          },
          text: "Submit"
        }
      },
      output: {
        locators: [
          {
            selector: "button:has-text('Submit')",
            type: "text",
            confidence: 0.90,
            reasoning: "Unique button text provides good stability if text doesn't change"
          },
          {
            selector: ".submit-form",
            type: "css",
            confidence: 0.75,
            reasoning: "Semantic class name suggests form submission purpose"
          },
          {
            selector: "button.btn-primary:has-text('Submit')",
            type: "css+text",
            confidence: 0.85,
            reasoning: "Combines structural and text-based selection for better specificity"
          }
        ],
        bestPractices: [
          "Add data-testid='submit-form-button' for most stable selection",
          "Avoid onclick attribute selectors as they're implementation details"
        ]
      }
    }
  ],

  testOptimization: [
    {
      input: {
        steps: [
          { type: "web.navigate", url: "/login" },
          { type: "web.waitForSelector", selector: "#username" },
          { type: "web.fill", selector: "#username", value: "user" },
          { type: "web.waitForSelector", selector: "#password" },
          { type: "web.fill", selector: "#password", value: "pass" },
          { type: "web.waitForSelector", selector: "#submit" },
          { type: "web.click", selector: "#submit" },
          { type: "web.waitForSelector", selector: ".dashboard" },
          { type: "web.waitForSelector", selector: ".user-menu" },
          { type: "web.waitForSelector", selector: ".notifications" }
        ]
      },
      output: {
        optimizedSteps: [
          {
            type: "web.navigate",
            url: "/login",
            waitUntil: "networkidle"
          },
          {
            type: "web.fill",
            selector: "#username",
            value: "user"
          },
          {
            type: "web.fill",
            selector: "#password",
            value: "pass"
          },
          {
            type: "web.click",
            selector: "#submit"
          },
          {
            type: "web.waitForSelector",
            selector: ".dashboard",
            state: "visible",
            timeout: 10000
          }
        ],
        improvements: [
          {
            type: "remove",
            description: "Removed redundant waitForSelector before actions - Playwright auto-waits",
            impact: "Reduced 10 steps to 5, saving ~3-5 seconds"
          },
          {
            type: "merge",
            description: "Combined multiple dashboard element waits into single wait for main element",
            impact: "More reliable - waiting for one key element instead of multiple"
          }
        ],
        estimatedTimeSaving: 4
      }
    }
  ]
};

export function buildPrompt(capability: string, examples: any[], input: any): string {
  const systemPrompt = SYSTEM_PROMPTS[capability as keyof typeof SYSTEM_PROMPTS];
  
  let prompt = `${systemPrompt}\n\nExamples:\n`;
  
  // Add few-shot examples
  examples.forEach((example, index) => {
    prompt += `\nExample ${index + 1}:\nInput: ${JSON.stringify(example.input, null, 2)}\nOutput: ${JSON.stringify(example.output, null, 2)}\n`;
  });
  
  // Add current input
  prompt += `\nNow process this input:\nInput: ${JSON.stringify(input, null, 2)}\nOutput:`;
  
  return prompt;
} 