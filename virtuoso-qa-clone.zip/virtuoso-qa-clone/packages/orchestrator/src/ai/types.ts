export interface AIConfig {
  provider: 'ollama' | 'openai' | 'mock';
  apiKey?: string;
  baseUrl?: string;
  model: string;
  temperature?: number;
  maxTokens?: number;
  systemPrompt?: string;
}

export interface AIAdapter {
  initialize(config: AIConfig): Promise<void>;
  complete(prompt: string, options?: CompletionOptions): Promise<string>;
  chat(messages: ChatMessage[], options?: CompletionOptions): Promise<string>;
  isAvailable(): Promise<boolean>;
  getModelInfo(): Promise<ModelInfo>;
}

export interface CompletionOptions {
  temperature?: number;
  maxTokens?: number;
  stopSequences?: string[];
  systemPrompt?: string;
}

export interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export interface ModelInfo {
  name: string;
  provider: string;
  contextWindow: number;
  capabilities: string[];
}

// NL to DSL conversion
export interface NLToDSLRequest {
  intent: string;
  context?: {
    currentSteps?: any[];
    availableElements?: string[];
    recentActions?: string[];
  };
  targetType?: 'web' | 'desktop' | 'mainframe' | 'api';
}

export interface NLToDSLResponse {
  steps: any[];
  confidence: number;
  explanation?: string;
  alternatives?: any[][];
}

// Failure Triage
export interface FailureTriageRequest {
  error: {
    message: string;
    stackTrace?: string;
    code?: string;
  };
  logs: Array<{
    timestamp: Date;
    level: string;
    message: string;
  }>;
  step: any;
  context?: {
    previousSteps?: any[];
    environment?: string;
  };
}

export interface FailureTriageResponse {
  summary: string;
  rootCause: string;
  suggestedFixes: Array<{
    description: string;
    confidence: number;
    steps: string[];
  }>;
  relatedIssues?: string[];
}

// Locator Suggestion
export interface LocatorSuggestionRequest {
  element: {
    html?: string;
    attributes?: Record<string, string>;
    text?: string;
    position?: { x: number; y: number };
  };
  failedLocator?: string;
  context?: {
    pageUrl?: string;
    pageTitle?: string;
    nearbyElements?: any[];
  };
}

export interface LocatorSuggestionResponse {
  locators: Array<{
    selector: string;
    type: string;
    confidence: number;
    reasoning: string;
  }>;
  bestPractices?: string[];
}

// Test Optimization
export interface TestOptimizationRequest {
  steps: any[];
  metrics?: {
    executionTime?: number;
    failureRate?: number;
    maintenanceCount?: number;
  };
}

export interface TestOptimizationResponse {
  optimizedSteps: any[];
  improvements: Array<{
    type: 'merge' | 'remove' | 'reorder' | 'parallelize';
    description: string;
    impact: string;
  }>;
  estimatedTimeSaving?: number;
}

// Assistant
export interface AssistantRequest {
  message: string;
  context?: {
    currentFlow?: any;
    recentErrors?: any[];
    availableActions?: string[];
  };
  capabilities?: Array<'nl-to-dsl' | 'triage' | 'optimize' | 'suggest'>;
}

export interface AssistantResponse {
  type: 'steps' | 'explanation' | 'question' | 'error';
  content: any;
  suggestions?: any[];
  requiresConfirmation?: boolean;
  metadata?: {
    confidence?: number;
    sources?: string[];
  };
} 