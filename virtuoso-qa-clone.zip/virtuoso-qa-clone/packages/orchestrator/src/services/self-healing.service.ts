import { logger } from '@hybrid-qa/common';
import { prisma } from '@hybrid-qa/common';
import { RunContext } from '../interfaces/engine.interface';

/**
 * Locator success record for learning
 */
interface LocatorUsage {
  elementId: string;
  locator: string;
  strategy: string;
  success: boolean;
  timestamp: Date;
  context: {
    runId: string;
    stepId: string;
    testCaseId: string;
  };
}

/**
 * Healed locator result
 */
interface HealingResult {
  success: boolean;
  locatorUsed?: string;
  alternativesAttempted: string[];
  newLocatorLearned?: string;
  confidence: number;
}

/**
 * Self-healing service for intelligent locator fallback and learning
 */
export class SelfHealingService {
  private readonly maxAlternatives = 5;
  private readonly minConfidenceThreshold = 0.6;
  private readonly learningEnabled: boolean;

  constructor(options: { learningEnabled?: boolean } = {}) {
    this.learningEnabled = options.learningEnabled ?? true;
  }

  /**
   * Record a successful locator usage for learning
   */
  async recordSuccessfulLocator(
    elementId: string,
    locator: string,
    context: RunContext
  ): Promise<void> {
    if (!this.learningEnabled) {
      return;
    }

    try {
      const strategy = this.extractLocatorStrategy(locator);
      
      // Record the usage
      await this.recordLocatorUsage({
        elementId,
        locator,
        strategy,
        success: true,
        timestamp: new Date(),
        context: {
          runId: context.runId,
          stepId: context.stepId,
          testCaseId: context.testCaseId,
        }
      });

      logger.debug('Recorded successful locator', {
        elementId,
        locator,
        strategy,
        runId: context.runId
      });
    } catch (error) {
      logger.warn('Failed to record successful locator', { elementId, locator, error });
    }
  }

  /**
   * Record a failed locator usage
   */
  async recordFailedLocator(
    elementId: string,
    locator: string,
    context: RunContext
  ): Promise<void> {
    if (!this.learningEnabled) {
      return;
    }

    try {
      const strategy = this.extractLocatorStrategy(locator);
      
      await this.recordLocatorUsage({
        elementId,
        locator,
        strategy,
        success: false,
        timestamp: new Date(),
        context: {
          runId: context.runId,
          stepId: context.stepId,
          testCaseId: context.testCaseId,
        }
      });

      logger.debug('Recorded failed locator', {
        elementId,
        locator,
        strategy,
        runId: context.runId
      });
    } catch (error) {
      logger.warn('Failed to record failed locator', { elementId, locator, error });
    }
  }

  /**
   * Get alternative locators for a failed element lookup
   */
  async getAlternativeLocators(
    elementId: string,
    failedLocator: string
  ): Promise<string[]> {
    try {
      // Get historical successful locators for this element
      const history = await prisma.selectorHistory.findMany({
        where: { elementId },
        orderBy: { lastUsed: 'desc' },
        take: this.maxAlternatives * 2 // Get more than needed for filtering
      });

      const alternatives: string[] = [];
      
      for (const record of history) {
        const selectors = JSON.parse(record.selectors as string);
        
        // Find selectors with good success rate
        for (const selector of selectors) {
          if (
            selector.locator !== failedLocator &&
            selector.confidence >= this.minConfidenceThreshold &&
            !alternatives.includes(selector.locator)
          ) {
            alternatives.push(selector.locator);
            
            if (alternatives.length >= this.maxAlternatives) {
              break;
            }
          }
        }
        
        if (alternatives.length >= this.maxAlternatives) {
          break;
        }
      }

      logger.debug('Retrieved alternative locators', {
        elementId,
        failedLocator,
        alternatives: alternatives.length
      });

      return alternatives;
    } catch (error) {
      logger.error('Failed to get alternative locators', { elementId, failedLocator, error });
      return [];
    }
  }

  /**
   * Attempt to heal a failed locator by trying alternatives
   */
  async attemptHealing(
    elementId: string,
    originalLocator: string,
    tryLocator: (locator: string) => Promise<boolean>
  ): Promise<HealingResult> {
    const result: HealingResult = {
      success: false,
      alternativesAttempted: [],
      confidence: 0
    };

    // Record the original failure
    try {
      const alternatives = await this.getAlternativeLocators(elementId, originalLocator);
      
      if (alternatives.length === 0) {
        logger.debug('No alternative locators available for healing', { elementId, originalLocator });
        return result;
      }

      // Try alternatives in order of confidence
      for (const alternative of alternatives) {
        result.alternativesAttempted.push(alternative);
        
        try {
          const success = await tryLocator(alternative);
          
          if (success) {
            result.success = true;
            result.locatorUsed = alternative;
            result.confidence = await this.calculateLocatorConfidence(elementId, alternative);
            
            // Learn that this locator works
            await this.updateLocatorConfidence(elementId, alternative, true);
            
            logger.info('Self-healing successful', {
              elementId,
              originalLocator,
              healedLocator: alternative,
              alternativesTried: result.alternativesAttempted.length
            });
            
            break;
          } else {
            // Record that this alternative also failed
            await this.updateLocatorConfidence(elementId, alternative, false);
          }
        } catch (error) {
          logger.debug('Alternative locator failed', { 
            elementId, 
            alternative, 
            error: error instanceof Error ? error.message : 'Unknown error' 
          });
          
          await this.updateLocatorConfidence(elementId, alternative, false);
        }
      }

      if (!result.success) {
        logger.warn('Self-healing failed - no working alternatives found', {
          elementId,
          originalLocator,
          alternativesTried: result.alternativesAttempted.length
        });
      }

      return result;
    } catch (error) {
      logger.error('Self-healing attempt failed', { elementId, originalLocator, error });
      return result;
    }
  }

  /**
   * Learn a new locator for an element
   */
  async learnNewLocator(
    elementId: string,
    newLocator: string,
    context: RunContext
  ): Promise<void> {
    if (!this.learningEnabled) {
      return;
    }

    try {
      const strategy = this.extractLocatorStrategy(newLocator);
      
      // Record the new locator with high confidence initially
      await this.recordLocatorUsage({
        elementId,
        locator: newLocator,
        strategy,
        success: true,
        timestamp: new Date(),
        context: {
          runId: context.runId,
          stepId: context.stepId,
          testCaseId: context.testCaseId,
        }
      });

      logger.info('Learned new locator', {
        elementId,
        newLocator,
        strategy,
        runId: context.runId
      });
    } catch (error) {
      logger.error('Failed to learn new locator', { elementId, newLocator, error });
    }
  }

  /**
   * Get locator statistics for analysis
   */
  async getLocatorStats(elementId?: string): Promise<{
    totalElements: number;
    totalLocators: number;
    averageConfidence: number;
    topPerformingStrategies: Array<{ strategy: string; count: number; avgConfidence: number }>;
  }> {
    try {
      const whereClause = elementId ? { elementId } : {};
      
      const records = await prisma.selectorHistory.findMany({
        where: whereClause,
      });

      const stats = {
        totalElements: new Set(records.map(r => r.elementId)).size,
        totalLocators: 0,
        averageConfidence: 0,
        topPerformingStrategies: [] as Array<{ strategy: string; count: number; avgConfidence: number }>
      };

      const strategyStats = new Map<string, { count: number; confidenceSum: number }>();
      let totalConfidence = 0;
      let locatorCount = 0;

      for (const record of records) {
        const selectors = JSON.parse(record.selectors as string);
        
        for (const selector of selectors) {
          locatorCount++;
          totalConfidence += selector.confidence;
          
          const strategy = selector.strategy || this.extractLocatorStrategy(selector.locator);
          if (!strategyStats.has(strategy)) {
            strategyStats.set(strategy, { count: 0, confidenceSum: 0 });
          }
          
          const strategyStat = strategyStats.get(strategy)!;
          strategyStat.count++;
          strategyStat.confidenceSum += selector.confidence;
        }
      }

      stats.totalLocators = locatorCount;
      stats.averageConfidence = locatorCount > 0 ? totalConfidence / locatorCount : 0;

      // Calculate top performing strategies
      stats.topPerformingStrategies = Array.from(strategyStats.entries())
        .map(([strategy, stat]) => ({
          strategy,
          count: stat.count,
          avgConfidence: stat.count > 0 ? stat.confidenceSum / stat.count : 0
        }))
        .sort((a, b) => b.avgConfidence - a.avgConfidence)
        .slice(0, 10);

      return stats;
    } catch (error) {
      logger.error('Failed to get locator stats', { elementId, error });
      return {
        totalElements: 0,
        totalLocators: 0,
        averageConfidence: 0,
        topPerformingStrategies: []
      };
    }
  }

  /**
   * Clean up old locator history
   */
  async cleanupOldHistory(olderThanDays: number = 90): Promise<number> {
    try {
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - olderThanDays);

      const result = await prisma.selectorHistory.deleteMany({
        where: {
          lastUsed: {
            lt: cutoffDate
          },
          // Only delete if success count is low
          successCount: {
            lt: 2
          }
        }
      });

      logger.info('Cleaned up old locator history', {
        deletedRecords: result.count,
        cutoffDate: cutoffDate.toISOString()
      });

      return result.count;
    } catch (error) {
      logger.error('Failed to cleanup old history', { error });
      return 0;
    }
  }

  // Private methods

  private async recordLocatorUsage(usage: LocatorUsage): Promise<void> {
    try {
      // Get existing record or create new one
      let record = await prisma.selectorHistory.findFirst({
        where: { elementId: usage.elementId }
      });

      const selectorData = {
        locator: usage.locator,
        strategy: usage.strategy,
        confidence: usage.success ? 0.8 : 0.2, // Initial confidence
        lastUsed: usage.timestamp,
        successCount: usage.success ? 1 : 0,
        failureCount: usage.success ? 0 : 1
      };

      if (record) {
        // Update existing record
        const selectors = JSON.parse(record.selectors as string) as any[];
        const existingSelector = selectors.find(s => s.locator === usage.locator);
        
        if (existingSelector) {
          // Update existing selector stats
          if (usage.success) {
            existingSelector.successCount++;
          } else {
            existingSelector.failureCount++;
          }
          
          // Recalculate confidence
          const totalUsage = existingSelector.successCount + existingSelector.failureCount;
          existingSelector.confidence = existingSelector.successCount / totalUsage;
          existingSelector.lastUsed = usage.timestamp;
        } else {
          // Add new selector
          selectors.push(selectorData);
        }

        // Update record
        await prisma.selectorHistory.update({
          where: { id: record.id },
          data: {
            selectors: JSON.stringify(selectors),
            lastUsed: usage.timestamp,
            successCount: usage.success ? { increment: 1 } : undefined,
            failCount: usage.success ? undefined : { increment: 1 }
          }
        });
      } else {
        // Create new record
        await prisma.selectorHistory.create({
          data: {
            elementId: usage.elementId,
            selectors: JSON.stringify([selectorData]),
            lastUsed: usage.timestamp,
            successCount: usage.success ? 1 : 0,
            failCount: usage.success ? 0 : 1
          }
        });
      }
    } catch (error) {
      logger.error('Failed to record locator usage', { usage, error });
      throw error;
    }
  }

  private async calculateLocatorConfidence(elementId: string, locator: string): Promise<number> {
    try {
      const record = await prisma.selectorHistory.findFirst({
        where: { elementId }
      });

      if (!record) {
        return 0.5; // Default confidence for unknown locators
      }

      const selectors = JSON.parse(record.selectors as string);
      const selector = selectors.find((s: any) => s.locator === locator);
      
      return selector?.confidence || 0.5;
    } catch (error) {
      logger.error('Failed to calculate locator confidence', { elementId, locator, error });
      return 0.5;
    }
  }

  private async updateLocatorConfidence(
    elementId: string, 
    locator: string, 
    success: boolean
  ): Promise<void> {
    try {
      const record = await prisma.selectorHistory.findFirst({
        where: { elementId }
      });

      if (record) {
        const selectors = JSON.parse(record.selectors as string);
        const selector = selectors.find((s: any) => s.locator === locator);
        
        if (selector) {
          if (success) {
            selector.successCount++;
          } else {
            selector.failureCount++;
          }
          
          const totalUsage = selector.successCount + selector.failureCount;
          selector.confidence = selector.successCount / totalUsage;
          selector.lastUsed = new Date();

          await prisma.selectorHistory.update({
            where: { id: record.id },
            data: {
              selectors: JSON.stringify(selectors),
              lastUsed: new Date(),
              successCount: success ? { increment: 1 } : undefined,
              failCount: success ? undefined : { increment: 1 }
            }
          });
        }
      }
    } catch (error) {
      logger.error('Failed to update locator confidence', { elementId, locator, success, error });
    }
  }

  private extractLocatorStrategy(locator: string): string {
    // Simple strategy extraction based on locator pattern
    if (locator.startsWith('//') || locator.startsWith('./')) {
      return 'xpath';
    } else if (locator.startsWith('#')) {
      return 'css';
    } else if (locator.startsWith('.')) {
      return 'css';
    } else if (locator.includes('Name:')) {
      return 'uia-name';
    } else if (locator.includes('AutomationId:')) {
      return 'uia-automation-id';
    } else if (locator.includes('[data-testid')) {
      return 'test-id';
    } else if (locator.includes('role=')) {
      return 'role';
    } else {
      return 'unknown';
    }
  }
} 