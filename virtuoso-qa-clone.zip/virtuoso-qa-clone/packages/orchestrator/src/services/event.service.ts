import { EventEmitter } from 'events';
import WebSocket from 'ws';
import { logger } from '@hybrid-qa/common';
import { 
  OrchestratorEvent, 
  WebSocketMessage, 
  WebSocketMessageSchema,
  EventValidator 
} from '../types/events.types';

/**
 * WebSocket client connection information
 */
interface ClientConnection {
  id: string;
  ws: WebSocket;
  connectedAt: Date;
  lastActivity: Date;
  subscriptions: Set<string>; // Event types the client is subscribed to
  metadata: Record<string, any>;
}

/**
 * Event service for managing real-time event broadcasting
 */
export class EventService extends EventEmitter {
  private readonly clients = new Map<string, ClientConnection>();
  private server?: WebSocket.Server;
  private heartbeatInterval?: NodeJS.Timeout;
  private readonly heartbeatIntervalMs = 30000; // 30 seconds

  constructor() {
    super();
    this.setupHeartbeat();
  }

  /**
   * Initialize WebSocket server
   */
  initialize(port: number = 3002, host: string = 'localhost'): Promise<void> {
    return new Promise((resolve, reject) => {
      try {
        this.server = new WebSocket.Server({ port, host });
        
        this.server.on('connection', (ws, req) => {
          this.handleConnection(ws, req);
        });

        this.server.on('error', (error) => {
          logger.error('WebSocket server error', { error });
          reject(error);
        });

        this.server.on('listening', () => {
          logger.info('Event service WebSocket server started', { port, host });
          resolve();
        });

        // Handle graceful shutdown
        process.on('SIGTERM', () => this.shutdown());
        process.on('SIGINT', () => this.shutdown());

      } catch (error) {
        logger.error('Failed to initialize event service', { error });
        reject(error);
      }
    });
  }

  /**
   * Broadcast an event to all connected clients
   */
  broadcastEvent(event: OrchestratorEvent): void {
    // Validate event first
    const validation = EventValidator.validate(event);
    if (!validation.valid) {
      logger.warn('Invalid event attempted to broadcast', { 
        eventType: (event as any).type,
        error: validation.error 
      });
      return;
    }

    const message: WebSocketMessage = {
      id: this.generateMessageId(),
      event: validation.data!,
      timestamp: new Date()
    };

    // Broadcast to all connected clients
    this.broadcastMessage(message);

    // Also emit on EventEmitter for internal listeners
    this.emit('event', validation.data!);
    
    logger.debug('Event broadcasted', { 
      eventType: event.type, 
      clientCount: this.clients.size,
      runId: (event as any).runId 
    });
  }

  /**
   * Send event to specific client
   */
  sendEventToClient(clientId: string, event: OrchestratorEvent): void {
    const client = this.clients.get(clientId);
    if (!client) {
      logger.warn('Attempted to send event to non-existent client', { clientId });
      return;
    }

    // Validate event
    const validation = EventValidator.validate(event);
    if (!validation.valid) {
      logger.warn('Invalid event attempted to send to client', { 
        clientId,
        eventType: (event as any).type,
        error: validation.error 
      });
      return;
    }

    const message: WebSocketMessage = {
      id: this.generateMessageId(),
      event: validation.data!,
      clientId,
      timestamp: new Date()
    };

    this.sendMessageToClient(clientId, message);
  }

  /**
   * Subscribe client to specific event types
   */
  subscribeClient(clientId: string, eventTypes: string[]): void {
    const client = this.clients.get(clientId);
    if (!client) {
      logger.warn('Attempted to subscribe non-existent client', { clientId });
      return;
    }

    eventTypes.forEach(eventType => {
      client.subscriptions.add(eventType);
    });

    logger.debug('Client subscribed to events', { clientId, eventTypes });
  }

  /**
   * Unsubscribe client from event types
   */
  unsubscribeClient(clientId: string, eventTypes: string[]): void {
    const client = this.clients.get(clientId);
    if (!client) {
      return;
    }

    eventTypes.forEach(eventType => {
      client.subscriptions.delete(eventType);
    });

    logger.debug('Client unsubscribed from events', { clientId, eventTypes });
  }

  /**
   * Get connected clients information
   */
  getConnectedClients(): Array<{
    id: string;
    connectedAt: Date;
    lastActivity: Date;
    subscriptions: string[];
    metadata: Record<string, any>;
  }> {
    return Array.from(this.clients.values()).map(client => ({
      id: client.id,
      connectedAt: client.connectedAt,
      lastActivity: client.lastActivity,
      subscriptions: Array.from(client.subscriptions),
      metadata: client.metadata
    }));
  }

  /**
   * Disconnect a specific client
   */
  disconnectClient(clientId: string, reason?: string): void {
    const client = this.clients.get(clientId);
    if (client) {
      client.ws.close(1000, reason || 'Disconnected by server');
      this.removeClient(clientId);
    }
  }

  /**
   * Get event statistics
   */
  getEventStats(): {
    connectedClients: number;
    totalEventsProcessed: number;
    uptime: number;
  } {
    return {
      connectedClients: this.clients.size,
      totalEventsProcessed: this.listenerCount('event'),
      uptime: process.uptime()
    };
  }

  /**
   * Shutdown the event service
   */
  async shutdown(): Promise<void> {
    logger.info('Shutting down event service...');

    // Clear heartbeat
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
    }

    // Close all client connections
    for (const [clientId, client] of this.clients) {
      client.ws.close(1001, 'Server shutdown');
      this.removeClient(clientId);
    }

    // Close WebSocket server
    if (this.server) {
      this.server.close();
    }

    logger.info('Event service shut down complete');
  }

  // Private methods

  private handleConnection(ws: WebSocket, req: any): void {
    const clientId = this.generateClientId();
    const clientIp = req.socket.remoteAddress;
    
    const client: ClientConnection = {
      id: clientId,
      ws,
      connectedAt: new Date(),
      lastActivity: new Date(),
      subscriptions: new Set(),
      metadata: {
        ip: clientIp,
        userAgent: req.headers['user-agent'] || 'Unknown'
      }
    };

    this.clients.set(clientId, client);

    logger.info('Client connected', { clientId, clientIp, totalClients: this.clients.size });

    // Send welcome message
    this.sendMessageToClient(clientId, {
      id: this.generateMessageId(),
      event: {
        type: 'connection:established' as any,
        timestamp: new Date(),
        runId: 'system',
        clientId,
        message: 'Connected to Hybrid QA Orchestrator'
      },
      timestamp: new Date()
    });

    // Handle incoming messages
    ws.on('message', (data) => {
      this.handleClientMessage(clientId, data);
    });

    // Handle client disconnect
    ws.on('close', (code, reason) => {
      logger.info('Client disconnected', { 
        clientId, 
        code, 
        reason: reason.toString(),
        totalClients: this.clients.size - 1 
      });
      this.removeClient(clientId);
    });

    // Handle errors
    ws.on('error', (error) => {
      logger.error('Client WebSocket error', { clientId, error });
      this.removeClient(clientId);
    });
  }

  private handleClientMessage(clientId: string, data: WebSocket.Data): void {
    const client = this.clients.get(clientId);
    if (!client) {
      return;
    }

    client.lastActivity = new Date();

    try {
      const message = JSON.parse(data.toString());
      
      // Handle different message types
      switch (message.type) {
        case 'subscribe':
          if (message.eventTypes && Array.isArray(message.eventTypes)) {
            this.subscribeClient(clientId, message.eventTypes);
          }
          break;
          
        case 'unsubscribe':
          if (message.eventTypes && Array.isArray(message.eventTypes)) {
            this.unsubscribeClient(clientId, message.eventTypes);
          }
          break;
          
        case 'ping':
          this.sendMessageToClient(clientId, {
            id: this.generateMessageId(),
            event: {
              type: 'pong' as any,
              timestamp: new Date(),
              runId: 'system'
            },
            timestamp: new Date()
          });
          break;
          
        default:
          logger.debug('Unknown client message type', { clientId, messageType: message.type });
      }
    } catch (error) {
      logger.warn('Failed to parse client message', { clientId, error });
    }
  }

  private broadcastMessage(message: WebSocketMessage): void {
    const messageStr = JSON.stringify(message);
    let sentCount = 0;
    let errorCount = 0;

    for (const [clientId, client] of this.clients) {
      // Check if client is subscribed to this event type
      if (client.subscriptions.size > 0 && !client.subscriptions.has(message.event.type)) {
        continue;
      }

      try {
        if (client.ws.readyState === WebSocket.OPEN) {
          client.ws.send(messageStr);
          client.lastActivity = new Date();
          sentCount++;
        } else {
          this.removeClient(clientId);
        }
      } catch (error) {
        logger.warn('Failed to send message to client', { clientId, error });
        errorCount++;
        this.removeClient(clientId);
      }
    }

    if (errorCount > 0) {
      logger.debug('Message broadcast completed with errors', { 
        eventType: message.event.type,
        sentCount,
        errorCount 
      });
    }
  }

  private sendMessageToClient(clientId: string, message: WebSocketMessage): void {
    const client = this.clients.get(clientId);
    if (!client) {
      return;
    }

    try {
      if (client.ws.readyState === WebSocket.OPEN) {
        client.ws.send(JSON.stringify(message));
        client.lastActivity = new Date();
      } else {
        this.removeClient(clientId);
      }
    } catch (error) {
      logger.warn('Failed to send message to client', { clientId, error });
      this.removeClient(clientId);
    }
  }

  private removeClient(clientId: string): void {
    const client = this.clients.get(clientId);
    if (client) {
      try {
        if (client.ws.readyState === WebSocket.OPEN) {
          client.ws.close();
        }
      } catch (error) {
        // Ignore errors during cleanup
      }
      
      this.clients.delete(clientId);
      
      // Emit client disconnected event
      this.emit('client:disconnected', { clientId });
    }
  }

  private setupHeartbeat(): void {
    this.heartbeatInterval = setInterval(() => {
      const now = new Date();
      const timeoutMs = this.heartbeatIntervalMs * 2; // 60 seconds timeout
      
      for (const [clientId, client] of this.clients) {
        const timeSinceActivity = now.getTime() - client.lastActivity.getTime();
        
        if (timeSinceActivity > timeoutMs) {
          logger.debug('Client timed out due to inactivity', { clientId });
          this.removeClient(clientId);
        } else if (client.ws.readyState === WebSocket.OPEN) {
          // Send ping
          try {
            client.ws.ping();
          } catch (error) {
            logger.debug('Failed to ping client', { clientId, error });
            this.removeClient(clientId);
          }
        }
      }
    }, this.heartbeatIntervalMs);
  }

  private generateClientId(): string {
    return `client-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  private generateMessageId(): string {
    return `msg-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }
} 