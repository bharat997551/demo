import { promises as fs } from 'fs';
import path from 'path';
import { logger } from '@hybrid-qa/common';
import { ArtifactCreatedEvent, EventTypes } from '../types/events.types';
import { EventEmitter } from 'events';

/**
 * Artifact metadata structure
 */
export interface ArtifactMetadata {
  id: string;
  runId: string;
  stepId?: string;
  type: 'screenshot' | 'video' | 'log' | 'report' | 'data';
  filename: string;
  originalFilename?: string;
  path: string;
  size: number;
  contentType?: string;
  createdAt: Date;
  metadata: Record<string, any>;
}

/**
 * Artifact service for managing test execution artifacts
 */
export class ArtifactService extends EventEmitter {
  private readonly baseArtifactDir: string;
  private readonly artifacts = new Map<string, ArtifactMetadata>();

  constructor(baseArtifactDir = './artifacts') {
    super();
    this.baseArtifactDir = path.resolve(baseArtifactDir);
  }

  /**
   * Initialize the artifact service
   */
  async initialize(): Promise<void> {
    try {
      await fs.mkdir(this.baseArtifactDir, { recursive: true });
      logger.info('Artifact service initialized', { baseDir: this.baseArtifactDir });
    } catch (error) {
      logger.error('Failed to initialize artifact service', { error });
      throw error;
    }
  }

  /**
   * Create a directory for a test run
   */
  async createRunDirectory(runId: string): Promise<string> {
    const runDir = path.join(this.baseArtifactDir, runId);
    
    try {
      await fs.mkdir(runDir, { recursive: true });
      
      // Create subdirectories
      const subdirs = ['screenshots', 'videos', 'logs', 'reports', 'data'];
      await Promise.all(
        subdirs.map(subdir => fs.mkdir(path.join(runDir, subdir), { recursive: true }))
      );
      
      logger.debug('Created run directory', { runId, runDir });
      return runDir;
    } catch (error) {
      logger.error('Failed to create run directory', { runId, error });
      throw error;
    }
  }

  /**
   * Store an artifact
   */
  async storeArtifact(
    runId: string,
    type: ArtifactMetadata['type'],
    filename: string,
    data: Buffer | string,
    options: {
      stepId?: string;
      contentType?: string;
      metadata?: Record<string, any>;
    } = {}
  ): Promise<ArtifactMetadata> {
    const artifactId = this.generateArtifactId();
    const runDir = path.join(this.baseArtifactDir, runId);
    const typeDir = path.join(runDir, `${type}s`); // screenshots, videos, etc.
    const filePath = path.join(typeDir, filename);

    try {
      // Ensure type directory exists
      await fs.mkdir(typeDir, { recursive: true });

      // Write the file
      if (typeof data === 'string') {
        await fs.writeFile(filePath, data, 'utf8');
      } else {
        await fs.writeFile(filePath, data);
      }

      // Get file stats
      const stats = await fs.stat(filePath);

      // Create artifact metadata
      const artifact: ArtifactMetadata = {
        id: artifactId,
        runId,
        stepId: options.stepId,
        type,
        filename,
        originalFilename: filename,
        path: filePath,
        size: stats.size,
        contentType: options.contentType || this.inferContentType(filename),
        createdAt: new Date(),
        metadata: options.metadata || {}
      };

      // Store metadata
      this.artifacts.set(artifactId, artifact);

      // Write metadata file
      await this.writeArtifactMetadata(artifact);

      logger.debug('Artifact stored', { 
        artifactId, 
        runId, 
        type, 
        filename, 
        size: stats.size 
      });

      // Emit artifact created event
      this.emit('event', {
        type: EventTypes.ARTIFACT_CREATED,
        timestamp: new Date(),
        runId,
        artifactId,
        artifactType: type,
        filename,
        path: filePath,
        size: stats.size,
        stepId: options.stepId,
        metadata: options.metadata
      } as ArtifactCreatedEvent);

      return artifact;
    } catch (error) {
      logger.error('Failed to store artifact', { runId, type, filename, error });
      throw error;
    }
  }

  /**
   * Store a screenshot artifact
   */
  async storeScreenshot(
    runId: string,
    screenshotData: Buffer,
    options: {
      stepId?: string;
      filename?: string;
      metadata?: Record<string, any>;
    } = {}
  ): Promise<ArtifactMetadata> {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const filename = options.filename || `screenshot-${timestamp}.png`;
    
    return this.storeArtifact(runId, 'screenshot', filename, screenshotData, {
      ...options,
      contentType: 'image/png'
    });
  }

  /**
   * Store a log artifact
   */
  async storeLog(
    runId: string,
    logContent: string,
    options: {
      stepId?: string;
      filename?: string;
      level?: 'debug' | 'info' | 'warn' | 'error';
      metadata?: Record<string, any>;
    } = {}
  ): Promise<ArtifactMetadata> {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const level = options.level || 'info';
    const filename = options.filename || `${level}-${timestamp}.log`;
    
    return this.storeArtifact(runId, 'log', filename, logContent, {
      ...options,
      contentType: 'text/plain',
      metadata: {
        ...options.metadata,
        level
      }
    });
  }

  /**
   * Store a test report
   */
  async storeReport(
    runId: string,
    reportContent: string | Buffer,
    format: 'html' | 'json' | 'xml' | 'pdf',
    options: {
      filename?: string;
      metadata?: Record<string, any>;
    } = {}
  ): Promise<ArtifactMetadata> {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const filename = options.filename || `report-${timestamp}.${format}`;
    const contentType = this.getReportContentType(format);
    
    return this.storeArtifact(runId, 'report', filename, reportContent, {
      ...options,
      contentType,
      metadata: {
        ...options.metadata,
        format
      }
    });
  }

  /**
   * Store extracted data
   */
  async storeData(
    runId: string,
    data: any,
    options: {
      stepId?: string;
      filename?: string;
      format?: 'json' | 'csv' | 'txt';
      metadata?: Record<string, any>;
    } = {}
  ): Promise<ArtifactMetadata> {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const format = options.format || 'json';
    const filename = options.filename || `data-${timestamp}.${format}`;
    
    let content: string;
    let contentType: string;

    switch (format) {
      case 'json':
        content = JSON.stringify(data, null, 2);
        contentType = 'application/json';
        break;
      case 'csv':
        content = this.convertToCSV(data);
        contentType = 'text/csv';
        break;
      case 'txt':
        content = typeof data === 'string' ? data : String(data);
        contentType = 'text/plain';
        break;
      default:
        throw new Error(`Unsupported data format: ${format}`);
    }
    
    return this.storeArtifact(runId, 'data', filename, content, {
      ...options,
      contentType,
      metadata: {
        ...options.metadata,
        format,
        dataType: typeof data
      }
    });
  }

  /**
   * Get artifact by ID
   */
  getArtifact(artifactId: string): ArtifactMetadata | undefined {
    return this.artifacts.get(artifactId);
  }

  /**
   * Get artifacts for a run
   */
  getRunArtifacts(runId: string): ArtifactMetadata[] {
    return Array.from(this.artifacts.values()).filter(artifact => artifact.runId === runId);
  }

  /**
   * Get artifacts by type
   */
  getArtifactsByType(type: ArtifactMetadata['type']): ArtifactMetadata[] {
    return Array.from(this.artifacts.values()).filter(artifact => artifact.type === type);
  }

  /**
   * Read artifact content
   */
  async readArtifact(artifactId: string): Promise<Buffer> {
    const artifact = this.artifacts.get(artifactId);
    if (!artifact) {
      throw new Error(`Artifact not found: ${artifactId}`);
    }

    try {
      return await fs.readFile(artifact.path);
    } catch (error) {
      logger.error('Failed to read artifact', { artifactId, path: artifact.path, error });
      throw error;
    }
  }

  /**
   * Delete an artifact
   */
  async deleteArtifact(artifactId: string): Promise<void> {
    const artifact = this.artifacts.get(artifactId);
    if (!artifact) {
      throw new Error(`Artifact not found: ${artifactId}`);
    }

    try {
      await fs.unlink(artifact.path);
      await fs.unlink(`${artifact.path}.metadata.json`);
      this.artifacts.delete(artifactId);
      
      logger.debug('Artifact deleted', { artifactId, path: artifact.path });
    } catch (error) {
      logger.error('Failed to delete artifact', { artifactId, error });
      throw error;
    }
  }

  /**
   * Clean up old artifacts
   */
  async cleanup(olderThanDays: number = 30): Promise<number> {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - olderThanDays);

    let deletedCount = 0;
    const artifactsToDelete = Array.from(this.artifacts.values()).filter(
      artifact => artifact.createdAt < cutoffDate
    );

    for (const artifact of artifactsToDelete) {
      try {
        await this.deleteArtifact(artifact.id);
        deletedCount++;
      } catch (error) {
        logger.warn('Failed to delete old artifact during cleanup', { 
          artifactId: artifact.id, 
          error 
        });
      }
    }

    logger.info('Artifact cleanup completed', { 
      deletedCount, 
      totalChecked: artifactsToDelete.length 
    });

    return deletedCount;
  }

  /**
   * Get run directory path
   */
  getRunDirectory(runId: string): string {
    return path.join(this.baseArtifactDir, runId);
  }

  /**
   * Check if run directory exists
   */
  async runDirectoryExists(runId: string): Promise<boolean> {
    const runDir = path.join(this.baseArtifactDir, runId);
    try {
      const stats = await fs.stat(runDir);
      return stats.isDirectory();
    } catch {
      return false;
    }
  }

  /**
   * Load artifacts from disk for a run
   */
  async loadRunArtifacts(runId: string): Promise<ArtifactMetadata[]> {
    const runDir = path.join(this.baseArtifactDir, runId);
    const artifacts: ArtifactMetadata[] = [];

    try {
      const subdirs = await fs.readdir(runDir, { withFileTypes: true });
      
      for (const subdir of subdirs.filter(d => d.isDirectory())) {
        const subdirPath = path.join(runDir, subdir.name);
        const files = await fs.readdir(subdirPath);
        
        for (const file of files) {
          if (file.endsWith('.metadata.json')) {
            continue; // Skip metadata files
          }
          
          const metadataPath = path.join(subdirPath, `${file}.metadata.json`);
          try {
            const metadataContent = await fs.readFile(metadataPath, 'utf8');
            const metadata: ArtifactMetadata = JSON.parse(metadataContent);
            
            // Update in-memory store
            this.artifacts.set(metadata.id, metadata);
            artifacts.push(metadata);
          } catch (error) {
            logger.warn('Failed to load artifact metadata', { 
              file, 
              metadataPath, 
              error 
            });
          }
        }
      }
      
      logger.debug('Loaded run artifacts', { runId, count: artifacts.length });
      return artifacts;
    } catch (error) {
      logger.error('Failed to load run artifacts', { runId, error });
      return [];
    }
  }

  // Private helper methods

  private generateArtifactId(): string {
    return `artifact-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  private async writeArtifactMetadata(artifact: ArtifactMetadata): Promise<void> {
    const metadataPath = `${artifact.path}.metadata.json`;
    const metadataContent = JSON.stringify(artifact, null, 2);
    
    try {
      await fs.writeFile(metadataPath, metadataContent, 'utf8');
    } catch (error) {
      logger.error('Failed to write artifact metadata', { 
        artifactId: artifact.id, 
        metadataPath, 
        error 
      });
      throw error;
    }
  }

  private inferContentType(filename: string): string {
    const ext = path.extname(filename).toLowerCase();
    const contentTypes: Record<string, string> = {
      '.png': 'image/png',
      '.jpg': 'image/jpeg',
      '.jpeg': 'image/jpeg',
      '.gif': 'image/gif',
      '.mp4': 'video/mp4',
      '.webm': 'video/webm',
      '.log': 'text/plain',
      '.txt': 'text/plain',
      '.json': 'application/json',
      '.xml': 'application/xml',
      '.html': 'text/html',
      '.css': 'text/css',
      '.js': 'application/javascript',
      '.csv': 'text/csv',
      '.pdf': 'application/pdf'
    };
    
    return contentTypes[ext] || 'application/octet-stream';
  }

  private getReportContentType(format: string): string {
    const contentTypes: Record<string, string> = {
      html: 'text/html',
      json: 'application/json',
      xml: 'application/xml',
      pdf: 'application/pdf'
    };
    
    return contentTypes[format] || 'application/octet-stream';
  }

  private convertToCSV(data: any): string {
    if (!Array.isArray(data)) {
      return String(data);
    }

    if (data.length === 0) {
      return '';
    }

    // Simple CSV conversion
    const headers = Object.keys(data[0]);
    const csvLines = [
      headers.join(','),
      ...data.map(row => 
        headers.map(header => 
          JSON.stringify(row[header] || '')
        ).join(',')
      )
    ];

    return csvLines.join('\n');
  }
} 