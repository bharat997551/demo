import prisma from '../database/client';
import { Project, ProjectSchema } from '@virtuoso/dsl';
import { logger } from '../utils/logger';

export class ProjectService {
  async createProject(data: Omit<Project, 'id' | 'metadata'>): Promise<Project> {
    logger.info('Creating new project', { name: data.name });
    
    const projectData = {
      name: data.name,
      description: data.description,
      settings: data.settings,
      metadata: {
        createdAt: new Date(),
        updatedAt: new Date(),
        version: '1.0.0',
      },
    };

    const project = await prisma.project.create({
      data: {
        ...projectData,
        settings: JSON.stringify(projectData.settings),
        metadata: JSON.stringify(projectData.metadata),
      },
    });

    return this.mapPrismaProject(project);
  }

  async getProject(id: string): Promise<Project | null> {
    const project = await prisma.project.findUnique({
      where: { id },
      include: {
        flows: true,
      },
    });

    return project ? this.mapPrismaProject(project) : null;
  }

  async getAllProjects(): Promise<Project[]> {
    const projects = await prisma.project.findMany({
      include: {
        flows: true,
      },
      orderBy: {
        updatedAt: 'desc',
      },
    });

    return projects.map(this.mapPrismaProject);
  }

  async updateProject(id: string, data: Partial<Project>): Promise<Project> {
    logger.info('Updating project', { id, name: data.name });
    
    const updateData: any = {};
    if (data.name) updateData.name = data.name;
    if (data.description !== undefined) updateData.description = data.description;
    if (data.settings) updateData.settings = JSON.stringify(data.settings);

    const project = await prisma.project.update({
      where: { id },
      data: updateData,
      include: {
        flows: true,
      },
    });

    return this.mapPrismaProject(project);
  }

  async deleteProject(id: string): Promise<void> {
    logger.info('Deleting project', { id });
    
    await prisma.project.delete({
      where: { id },
    });
  }

  private mapPrismaProject(project: any): Project {
    return ProjectSchema.parse({
      id: project.id,
      name: project.name,
      description: project.description,
      settings: typeof project.settings === 'string' 
        ? JSON.parse(project.settings) 
        : project.settings,
      metadata: typeof project.metadata === 'string'
        ? JSON.parse(project.metadata)
        : project.metadata,
    });
  }
} 