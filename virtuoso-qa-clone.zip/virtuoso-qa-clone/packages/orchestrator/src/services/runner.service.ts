import { EventEmitter } from 'events';
import { validateDSL, compileToPlan, TestCase, TestSuite, Step, ExecutionPlan } from '@hybrid-qa/dsl';
import { logger } from '@hybrid-qa/common';
import { IEngine, RunContext, StepExecutionResult } from '../interfaces/engine.interface';
import { 
  OrchestratorEvent, 
  RunStartedEvent, 
  RunFinishedEvent, 
  StepStartedEvent, 
  StepEndedEvent,
  EventTypes 
} from '../types/events.types';
import { ArtifactService } from './artifact.service';
import { SelfHealingService } from './self-healing.service';

/**
 * Execution configuration
 */
export interface RunConfig {
  /** Environment profile to use */
  environment?: string;
  /** Variable overrides */
  variables?: Record<string, any>;
  /** Tags to filter test cases */
  tags?: string[];
  /** Maximum parallel execution limit */
  maxConcurrency?: number;
  /** Timeout for the entire run */
  timeout?: number;
  /** Continue execution on step failures */
  continueOnFailure?: boolean;
  /** Screenshot settings */
  screenshots?: {
    onFailure?: boolean;
    onSuccess?: boolean;
    onStep?: boolean;
  };
  /** Self-healing configuration */
  healing?: {
    enabled?: boolean;
    maxRetries?: number;
    learnFromSuccess?: boolean;
  };
}

/**
 * Execution state tracking
 */
interface ExecutionState {
  runId: string;
  status: 'pending' | 'running' | 'completed' | 'failed' | 'cancelled';
  startTime: Date;
  endTime?: Date;
  totalSteps: number;
  completedSteps: number;
  failedSteps: number;
  skippedSteps: number;
  currentParallelGroup?: string;
  stepResults: Map<string, StepExecutionResult>;
  artifacts: string[];
  variables: Record<string, any>;
  dataRowIndex?: number; // For data-driven execution
}

/**
 * Data-driven execution context
 */
interface DataDrivenContext {
  dataTable: any;
  currentRowIndex: number;
  totalRows: number;
  rowData: Record<string, any>;
}

/**
 * Core Runner service for executing DSL test cases and suites
 */
export class RunnerService extends EventEmitter {
  private readonly engines = new Map<string, IEngine>();
  private readonly activeRuns = new Map<string, ExecutionState>();
  private readonly artifactService: ArtifactService;
  private readonly selfHealingService: SelfHealingService;

  constructor(
    artifactService: ArtifactService,
    selfHealingService: SelfHealingService
  ) {
    super();
    this.artifactService = artifactService;
    this.selfHealingService = selfHealingService;
  }

  /**
   * Register an engine with the runner
   */
  registerEngine(engineType: string, engine: IEngine): void {
    this.engines.set(engineType, engine);
    logger.info('Engine registered', { 
      engineType, 
      engineName: engine.config.name,
      supportedSteps: engine.getSupportedStepKinds().length 
    });
  }

  /**
   * Get registered engine by type
   */
  getEngine(engineType: string): IEngine | undefined {
    return this.engines.get(engineType);
  }

  /**
   * Get all registered engines
   */
  getEngines(): Array<{ type: string; engine: IEngine }> {
    return Array.from(this.engines.entries()).map(([type, engine]) => ({ type, engine }));
  }

  /**
   * Execute a test case with data-driven support
   */
  async executeTestCase(
    testCase: TestCase, 
    config: RunConfig = {}
  ): Promise<{ runId: string; results: StepExecutionResult[] }> {
    // Validate DSL
    const validation = validateDSL(testCase);
    if (!validation.valid) {
      throw new Error(`Invalid test case: ${validation.errors?.map(e => e.message).join(', ')}`);
    }

    // Check if test case uses data tables
    const dataTable = testCase.dataTables.find(dt => 
      testCase.steps.some(step => step.engine === 'flow' && step.options.dataTable === dt.id)
    );

    if (dataTable) {
      return this.executeDataDrivenTestCase(testCase, dataTable, config);
    } else {
      return this.executeSingleTestCase(testCase, config);
    }
  }

  /**
   * Execute a test suite
   */
  async executeTestSuite(
    testSuite: TestSuite,
    config: RunConfig = {}
  ): Promise<{ runId: string; results: Map<string, StepExecutionResult[]> }> {
    // Validate DSL
    const validation = validateDSL(testSuite);
    if (!validation.valid) {
      throw new Error(`Invalid test suite: ${validation.errors?.map(e => e.message).join(', ')}`);
    }

    const runId = this.generateRunId();
    const results = new Map<string, StepExecutionResult[]>();
    
    logger.info('Starting test suite execution', { 
      runId, 
      testSuite: testSuite.name,
      testCases: testSuite.testCases.length 
    });

    // Filter test cases by tags if specified
    const filteredTestCases = this.filterTestCasesByTags(testSuite.testCases, config.tags);
    
    // Execute test cases based on suite configuration
    if (testSuite.settings.parallel) {
      const parallelResults = await this.executeTestCasesInParallel(
        filteredTestCases, 
        testSuite.settings.maxConcurrency,
        config
      );
      
      parallelResults.forEach((result, testCaseId) => {
        results.set(testCaseId, result.results);
      });
    } else {
      // Sequential execution with dependency resolution
      const executionOrder = this.resolveExecutionOrder(filteredTestCases, testSuite.execution.dependencies);
      
      for (const testCaseRef of executionOrder) {
        try {
          const testCase = typeof testCaseRef === 'string' 
            ? await this.loadTestCase(testCaseRef) 
            : testCaseRef;
          
          const result = await this.executeSingleTestCase(testCase, config);
          results.set(testCase.id, result.results);
          
          if (!config.continueOnFailure && result.results.some(r => r.status === 'failed')) {
            logger.warn('Stopping test suite execution due to failure', { runId, testCase: testCase.name });
            break;
          }
        } catch (error) {
          logger.error('Test case execution failed', { error, runId });
          if (!config.continueOnFailure) {
            break;
          }
        }
      }
    }

    return { runId, results };
  }

  /**
   * Execute single test case
   */
  private async executeSingleTestCase(
    testCase: TestCase,
    config: RunConfig
  ): Promise<{ runId: string; results: StepExecutionResult[] }> {
    const runId = this.generateRunId();
    const startTime = new Date();

    // Initialize execution state
    const state: ExecutionState = {
      runId,
      status: 'running',
      startTime,
      totalSteps: testCase.steps.length,
      completedSteps: 0,
      failedSteps: 0,
      skippedSteps: 0,
      stepResults: new Map(),
      artifacts: [],
      variables: this.mergeVariables(testCase.variables, config.variables)
    };

    this.activeRuns.set(runId, state);

    // Create artifact directory
    const artifactDir = await this.artifactService.createRunDirectory(runId);

    // Emit run started event
    this.emitEvent({
      type: EventTypes.RUN_STARTED,
      timestamp: startTime,
      runId,
      testCaseId: testCase.id,
      totalSteps: testCase.steps.length,
      environment: config.environment ? { profile: config.environment } : undefined,
      tags: testCase.tags
    } as RunStartedEvent);

    const results: StepExecutionResult[] = [];

    try {
      // Build execution plan
      const plan = compileToPlan(testCase, {
        variables: state.variables,
        settings: config,
        engines: Object.fromEntries(
          Array.from(this.engines.keys()).map(key => [key, true])
        )
      });

      // Execute steps based on plan
      if (plan.strategy === 'parallel') {
        results.push(...await this.executeStepsInParallel(plan.steps, state, config, artifactDir));
      } else {
        results.push(...await this.executeStepsSequentially(plan.steps, state, config, artifactDir));
      }

      state.status = results.some(r => r.status === 'failed') ? 'failed' : 'completed';
    } catch (error) {
      logger.error('Test case execution failed', { error, runId, testCase: testCase.name });
      state.status = 'failed';
      throw error;
    } finally {
      state.endTime = new Date();
      
      // Emit run finished event
      this.emitEvent({
        type: EventTypes.RUN_FINISHED,
        timestamp: state.endTime,
        runId,
        status: state.status === 'completed' ? 'completed' : 'failed',
        duration: state.endTime.getTime() - state.startTime.getTime(),
        totalSteps: state.totalSteps,
        passedSteps: results.filter(r => r.status === 'completed').length,
        failedSteps: results.filter(r => r.status === 'failed').length,
        skippedSteps: results.filter(r => r.status === 'skipped').length,
        artifacts: state.artifacts
      } as RunFinishedEvent);

      this.activeRuns.delete(runId);
    }

    return { runId, results };
  }

  /**
   * Execute test case with data table rows
   */
  private async executeDataDrivenTestCase(
    testCase: TestCase,
    dataTable: any,
    config: RunConfig
  ): Promise<{ runId: string; results: StepExecutionResult[] }> {
    const allResults: StepExecutionResult[] = [];
    const runId = this.generateRunId();

    logger.info('Starting data-driven test execution', {
      runId,
      testCase: testCase.name,
      dataRows: dataTable.rows.length
    });

    for (let i = 0; i < dataTable.rows.length; i++) {
      const rowData = this.mapDataTableRow(dataTable, i);
      
      // Override variables with data table row values
      const rowConfig = {
        ...config,
        variables: {
          ...config.variables,
          ...rowData
        }
      };

      try {
        const result = await this.executeSingleTestCase(testCase, rowConfig);
        allResults.push(...result.results);
      } catch (error) {
        logger.error('Data-driven execution failed for row', { runId, rowIndex: i, error });
        if (!config.continueOnFailure) {
          break;
        }
      }
    }

    return { runId, results: allResults };
  }

  /**
   * Execute steps sequentially
   */
  private async executeStepsSequentially(
    planSteps: any[],
    state: ExecutionState,
    config: RunConfig,
    artifactDir: string
  ): Promise<StepExecutionResult[]> {
    const results: StepExecutionResult[] = [];

    for (let i = 0; i < planSteps.length; i++) {
      const planStep = planSteps[i];
      const step = planStep.step;

      // Check dependencies
      const dependenciesMet = this.checkStepDependencies(planStep.dependencies, state.stepResults);
      if (!dependenciesMet) {
        results.push(this.createSkippedStepResult(step, 'Dependencies not met'));
        continue;
      }

      const result = await this.executeStep(step, state, config, artifactDir, i + 1);
      results.push(result);
      state.stepResults.set(step.id, result);

      if (result.status === 'failed' && !config.continueOnFailure) {
        // Skip remaining steps
        for (let j = i + 1; j < planSteps.length; j++) {
          results.push(this.createSkippedStepResult(planSteps[j].step, 'Previous step failed'));
        }
        break;
      }
    }

    return results;
  }

  /**
   * Execute steps in parallel
   */
  private async executeStepsInParallel(
    planSteps: any[],
    state: ExecutionState,
    config: RunConfig,
    artifactDir: string
  ): Promise<StepExecutionResult[]> {
    // Group steps by parallel group or create individual promises
    const stepGroups = new Map<string, any[]>();
    
    planSteps.forEach(planStep => {
      const groupKey = planStep.parallelGroup || planStep.step.id;
      if (!stepGroups.has(groupKey)) {
        stepGroups.set(groupKey, []);
      }
      stepGroups.get(groupKey)!.push(planStep);
    });

    const results: StepExecutionResult[] = [];
    const maxConcurrency = config.maxConcurrency || 3;

    // Execute groups with concurrency limit
    const groupPromises: Promise<StepExecutionResult[]>[] = [];
    for (const [groupKey, steps] of stepGroups) {
      if (groupPromises.length >= maxConcurrency) {
        // Wait for some to complete
        const completed = await Promise.race(groupPromises);
        results.push(...completed);
        groupPromises.splice(groupPromises.findIndex(p => p === Promise.resolve(completed)), 1);
      }

      const groupPromise = Promise.all(
        steps.map((planStep, index) => 
          this.executeStep(planStep.step, state, config, artifactDir, index + 1)
        )
      );
      
      groupPromises.push(groupPromise);
    }

    // Wait for all remaining groups
    const remainingResults = await Promise.all(groupPromises);
    remainingResults.forEach(groupResults => results.push(...groupResults));

    return results;
  }

  /**
   * Execute a single step
   */
  private async executeStep(
    step: Step,
    state: ExecutionState,
    config: RunConfig,
    artifactDir: string,
    stepNumber: number
  ): Promise<StepExecutionResult> {
    const startTime = new Date();

    // Emit step started event
    this.emitEvent({
      type: EventTypes.STEP_STARTED,
      timestamp: startTime,
      runId: state.runId,
      stepId: step.id,
      stepName: step.name,
      stepKind: step.kind,
      engine: step.engine,
      stepNumber,
      totalSteps: state.totalSteps
    } as StepStartedEvent);

    // Get appropriate engine
    const engine = this.engines.get(step.engine);
    if (!engine) {
      const error = `No engine registered for type: ${step.engine}`;
      logger.error(error, { stepId: step.id, engineType: step.engine });
      return this.createFailedStepResult(step, error, startTime);
    }

    // Validate step
    const validation = engine.validateStep(step);
    if (!validation.valid) {
      const error = `Step validation failed: ${validation.errors?.join(', ')}`;
      return this.createFailedStepResult(step, error, startTime);
    }

    // Prepare execution context
    const context: RunContext = {
      runId: state.runId,
      testCaseId: step.id, // This would normally come from the test case
      stepId: step.id,
      variables: state.variables,
      environment: config.environment ? { profile: config.environment } : {},
      artifactDir,
      timeout: step.timeout || 30000,
      screenshots: {
        onFailure: config.screenshots?.onFailure ?? true,
        onSuccess: config.screenshots?.onSuccess ?? false,
        onStep: config.screenshots?.onStep ?? false
      },
      previousResults: Array.from(state.stepResults.values()),
      healing: {
        enabled: config.healing?.enabled ?? true,
        maxRetries: config.healing?.maxRetries ?? 3,
        learnFromSuccess: config.healing?.learnFromSuccess ?? true
      }
    };

    let result: StepExecutionResult;
    let retryCount = 0;
    const maxRetries = step.retryCount || 0;

    // Execute step with retry logic
    do {
      try {
        result = await engine.runStep(step, context);
        
        // Record successful locators for self-healing
        if (result.status === 'completed' && result.healing?.locatorUsed && context.healing.learnFromSuccess) {
          await this.selfHealingService.recordSuccessfulLocator(
            step.id,
            result.healing.locatorUsed,
            context
          );
        }
        
        break; // Success, exit retry loop
      } catch (error) {
        retryCount++;
        logger.warn('Step execution failed', { 
          stepId: step.id, 
          attempt: retryCount, 
          maxRetries, 
          error: error instanceof Error ? error.message : 'Unknown error' 
        });

        if (retryCount > maxRetries) {
          result = this.createFailedStepResult(
            step,
            error instanceof Error ? error.message : 'Step execution failed',
            startTime,
            retryCount - 1
          );
        } else {
          // Wait before retry
          await new Promise(resolve => setTimeout(resolve, step.retryDelay || 1000));
        }
      }
    } while (retryCount <= maxRetries);

    // Update state
    if (result!.status === 'completed') {
      state.completedSteps++;
    } else if (result!.status === 'failed') {
      state.failedSteps++;
    } else {
      state.skippedSteps++;
    }

    // Emit step ended event
    this.emitEvent({
      type: EventTypes.STEP_ENDED,
      timestamp: result!.endTime || new Date(),
      runId: state.runId,
      stepId: step.id,
      stepName: step.name,
      status: result!.status === 'completed' ? 'completed' : result!.status === 'failed' ? 'failed' : 'skipped',
      duration: result!.duration || 0,
      retryAttempt: retryCount,
      error: result!.error,
      extractedData: result!.extractedData,
      screenshots: result!.screenshots,
      healing: result!.healing
    } as StepEndedEvent);

    return result!;
  }

  // Helper methods...
  
  private generateRunId(): string {
    return `run-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  private mergeVariables(testCaseVars: any[] = [], configVars: Record<string, any> = {}): Record<string, any> {
    const merged: Record<string, any> = {};
    
    // Add test case variables
    testCaseVars.forEach(variable => {
      merged[variable.name] = variable.value;
    });
    
    // Override with config variables
    Object.assign(merged, configVars);
    
    return merged;
  }

  private filterTestCasesByTags(testCases: any[], tags?: string[]): any[] {
    if (!tags || tags.length === 0) {
      return testCases;
    }
    
    return testCases.filter(testCase => {
      if (typeof testCase === 'string') return true; // Cannot filter references
      return tags.some(tag => testCase.tags?.includes(tag));
    });
  }

  private resolveExecutionOrder(testCases: any[], dependencies: any[] = []): any[] {
    // Simple topological sort for dependency resolution
    // In a full implementation, this would be more sophisticated
    return testCases; // For now, return as-is
  }

  private checkStepDependencies(dependencies: string[], completedResults: Map<string, StepExecutionResult>): boolean {
    return dependencies.every(depId => 
      completedResults.has(depId) && completedResults.get(depId)?.status === 'completed'
    );
  }

  private async loadTestCase(testCaseId: string): Promise<TestCase> {
    // This would load from storage in a real implementation
    throw new Error(`Test case loading not implemented: ${testCaseId}`);
  }

  private mapDataTableRow(dataTable: any, rowIndex: number): Record<string, any> {
    const rowData: Record<string, any> = {};
    const row = dataTable.rows[rowIndex];
    
    dataTable.columns.forEach((column: any, index: number) => {
      rowData[column.name] = row[index];
    });
    
    return rowData;
  }

  private async executeTestCasesInParallel(
    testCases: any[], 
    maxConcurrency: number,
    config: RunConfig
  ): Promise<Map<string, { runId: string; results: StepExecutionResult[] }>> {
    const results = new Map();
    const promises: Promise<void>[] = [];
    
    for (const testCaseRef of testCases) {
      if (promises.length >= maxConcurrency) {
        await Promise.race(promises);
      }
      
      const testCase = typeof testCaseRef === 'string' 
        ? await this.loadTestCase(testCaseRef)
        : testCaseRef;
      
      const promise = this.executeSingleTestCase(testCase, config).then(result => {
        results.set(testCase.id, result);
      });
      
      promises.push(promise);
    }
    
    await Promise.all(promises);
    return results;
  }

  private createSkippedStepResult(step: Step, reason: string): StepExecutionResult {
    return {
      stepId: step.id,
      status: 'skipped',
      startTime: new Date(),
      endTime: new Date(),
      duration: 0,
      error: reason,
      screenshots: [],
      logs: []
    };
  }

  private createFailedStepResult(step: Step, error: string, startTime: Date, retryCount = 0): StepExecutionResult {
    const endTime = new Date();
    return {
      stepId: step.id,
      status: 'failed',
      startTime,
      endTime,
      duration: endTime.getTime() - startTime.getTime(),
      error,
      screenshots: [],
      logs: [],
      metrics: {
        startTime,
        endTime,
        duration: endTime.getTime() - startTime.getTime(),
        retryCount
      }
    };
  }

  private emitEvent(event: OrchestratorEvent): void {
    this.emit('event', event);
  }
} 