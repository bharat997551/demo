import { EventEmitter } from 'events';
import { LocatorManager, HealedLocator, LocatorVariant, LocatorHealingResult } from '../locator-manager';
import { logger } from '@hybrid-qa/common';

export interface LocatorHealingEvent {
  type: 'healing_suggested' | 'healing_accepted' | 'healing_rejected' | 'locator_success' | 'locator_failure';
  data: any;
  timestamp: Date;
}

export class LocatorHealingService extends EventEmitter {
  private locatorManager: LocatorManager;
  private runIdToTestIdMap = new Map<string, string>();

  constructor() {
    super();
    this.locatorManager = new LocatorManager({
      enableAutoHealing: true,
      maxAlternativesToTry: 10,
      minConfidenceThreshold: 0.7,
      recordDomSnapshots: true,
      recordWindowHierarchy: true
    });

    this.setupEventHandlers();
  }

  private setupEventHandlers(): void {
    // Forward locator manager events
    this.locatorManager.on('healingSuggestion', (suggestion: HealedLocator) => {
      this.emit('event', {
        type: 'healing_suggested',
        data: suggestion,
        timestamp: new Date()
      } as LocatorHealingEvent);
    });

    this.locatorManager.on('healingAccepted', (healing: HealedLocator) => {
      this.emit('event', {
        type: 'healing_accepted',
        data: healing,
        timestamp: new Date()
      } as LocatorHealingEvent);
    });

    this.locatorManager.on('locatorSuccess', (data: any) => {
      this.emit('event', {
        type: 'locator_success',
        data,
        timestamp: new Date()
      } as LocatorHealingEvent);
    });

    this.locatorManager.on('locatorFailure', (data: any) => {
      this.emit('event', {
        type: 'locator_failure',
        data,
        timestamp: new Date()
      } as LocatorHealingEvent);
    });
  }

  /**
   * Record successful locator usage
   */
  async recordSuccess(
    runId: string,
    stepId: string,
    locator: LocatorVariant,
    context: {
      domSnapshot?: string;
      windowHierarchy?: any;
      executionTimeMs: number;
    }
  ): Promise<void> {
    const testId = this.getTestId(runId);
    await this.locatorManager.recordSuccess(testId, stepId, locator, context);
    
    logger.info('Locator success recorded', {
      testId,
      stepId,
      locatorType: locator.type,
      selector: locator.selector
    });
  }

  /**
   * Record failed locator attempt
   */
  async recordFailure(
    runId: string,
    stepId: string,
    failedLocator: LocatorVariant,
    attemptedAlternatives: LocatorVariant[],
    context: {
      domSnapshot?: string;
      windowHierarchy?: any;
      executionTimeMs: number;
    }
  ): Promise<void> {
    const testId = this.getTestId(runId);
    await this.locatorManager.recordFailure(
      testId,
      stepId,
      failedLocator,
      attemptedAlternatives,
      context
    );

    logger.warn('Locator failure recorded', {
      testId,
      stepId,
      locatorType: failedLocator.type,
      selector: failedLocator.selector,
      alternativesCount: attemptedAlternatives.length
    });
  }

  /**
   * Attempt to heal a failed locator
   */
  async attemptHealing(
    runId: string,
    stepId: string,
    originalLocator: LocatorVariant,
    currentContext: {
      domSnapshot?: string;
      windowHierarchy?: any;
      pageUrl?: string;
      windowTitle?: string;
    }
  ): Promise<LocatorHealingResult> {
    const testId = this.getTestId(runId);
    
    logger.info('Attempting locator healing', {
      testId,
      stepId,
      originalLocator
    });

    const result = await this.locatorManager.attemptHealing(
      testId,
      stepId,
      originalLocator,
      currentContext
    );

    if (result.success) {
      logger.info('Locator healing successful', {
        testId,
        stepId,
        healedLocator: result.locatorUsed,
        confidence: result.healingSuggestion?.confidence
      });
    } else {
      logger.warn('Locator healing failed', {
        testId,
        stepId,
        attemptedCount: result.attemptedLocators.length
      });
    }

    return result;
  }

  /**
   * Accept a healing suggestion
   */
  async acceptHealing(healingId: string, acceptedBy: string): Promise<void> {
    await this.locatorManager.acceptHealing(healingId, acceptedBy);
    
    logger.info('Healing suggestion accepted', {
      healingId,
      acceptedBy
    });
  }

  /**
   * Get healed locators with optional filtering
   */
  async getHealedLocators(filter?: {
    testId?: string;
    accepted?: boolean;
    minConfidence?: number;
  }): Promise<HealedLocator[]> {
    return this.locatorManager.getHealedLocators(filter);
  }

  /**
   * Get healing statistics
   */
  async getStats(testId?: string): Promise<any> {
    const storage = (this.locatorManager as any).storage;
    return storage.getHistoryStats(testId);
  }

  /**
   * Set up locator try handler for a specific run
   */
  setupLocatorTryHandler(
    runId: string,
    handler: (locator: LocatorVariant) => Promise<{ success: boolean; error?: string }>
  ): void {
    const testId = this.getTestId(runId);
    
    // Listen for tryLocator events
    const tryHandler = async (data: { testId: string; stepId: string; locator: LocatorVariant }) => {
      if (data.testId === testId) {
        const result = await handler(data.locator);
        this.locatorManager.emit(`locatorTryResult:${data.testId}:${data.stepId}`, result);
      }
    };

    this.locatorManager.on('tryLocator', tryHandler);

    // Clean up handler when run completes
    this.once(`runComplete:${runId}`, () => {
      this.locatorManager.removeListener('tryLocator', tryHandler);
    });
  }

  /**
   * Map run ID to test ID
   */
  setRunTestMapping(runId: string, testId: string): void {
    this.runIdToTestIdMap.set(runId, testId);
  }

  /**
   * Get test ID from run ID
   */
  private getTestId(runId: string): string {
    return this.runIdToTestIdMap.get(runId) || runId;
  }

  /**
   * Clean up resources for a run
   */
  cleanupRun(runId: string): void {
    this.runIdToTestIdMap.delete(runId);
    this.emit(`runComplete:${runId}`);
  }

  /**
   * Clean up all resources
   */
  async cleanup(): Promise<void> {
    await this.locatorManager.cleanup();
    this.removeAllListeners();
  }
} 