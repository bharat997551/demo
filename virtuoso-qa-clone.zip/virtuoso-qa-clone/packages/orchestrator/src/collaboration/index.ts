/**
 * Collaboration Module Exports
 */

export { CollaborationServiceImpl } from './collaboration.service';
export type { CollaborationService } from './collaboration.service';

// Re-export types from common
export type {
  User,
  Project,
  Team,
  TeamMember,
  Permission,
  UserRole,
  GitRepository,
  GitCommit,
  TestVersion,
  Activity,
  CollaborationSession,
  AuditLog,
  DEFAULT_ROLES
} from '@hybrid-qa/common/src/collaboration/types'; 