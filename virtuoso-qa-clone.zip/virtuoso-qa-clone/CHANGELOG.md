# Changelog

All notable changes to Hybrid QA will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- Comprehensive documentation including Developer README, User Manual, and sample projects
- Self-healing locators with AI-powered selector recovery
- AI Assistant for natural language test creation
- Runs Dashboard with filtering and search capabilities
- Inline artifact viewers for images, HAR files, JSON, and 3270 text grids
- Baseline comparison mode for visual testing
- Export functionality for standalone HTML reports and PDF generation
- Security module with Windows DPAPI and encrypted file storage
- Environment profiles (DEV/UAT/PROD) with secure credential management
- Electron app packaging with signed Windows installer
- First-run wizard for environment validation
- CI/CD workflows for linting, testing, building, and nightly regression
- Mock servers for mainframe and API testing

### Changed
- Improved test orchestration with better error handling
- Enhanced desktop recorder with smart element detection
- Updated UI components to use shadcn/ui design system

### Fixed
- Memory leaks in long-running test sessions
- WebSocket connection stability issues
- Desktop automation reliability on Windows 11

### Security
- Implemented secure credential storage using Windows DPAPI
- Added masking for sensitive data in logs and reports
- Enhanced API token management with expiration handling

## [1.0.0] - 2024-01-15

### Added
- Initial release of Hybrid QA platform
- Web automation engine using Playwright
- Desktop automation engine using pywinauto
- Mainframe automation engine using s3270
- API testing engine with REST, GraphQL, and gRPC support
- Visual flow builder with drag-and-drop interface
- Test recorder for web and desktop applications
- Real-time test execution with live logs
- Comprehensive test reporting with artifacts
- DSL/YAML test definition format
- Electron-based desktop application
- Orchestrator service for test management
- Basic CI/CD integration examples

### Known Issues
- Desktop automation limited to Windows
- Mainframe engine requires s3270 installation
- Some UWP applications may not be automatable

## [0.9.0-beta] - 2023-12-01

### Added
- Beta release for early adopters
- Core automation engines
- Basic UI functionality
- Initial documentation

### Changed
- Significant architecture improvements
- Performance optimizations

### Fixed
- Various stability issues from alpha releases

## [0.5.0-alpha] - 2023-10-15

### Added
- Alpha release for internal testing
- Proof of concept for multi-engine architecture
- Basic web and desktop recording

### Known Issues
- Not suitable for production use
- Limited error handling
- Incomplete documentation

---

## Version Numbering

We use Semantic Versioning (MAJOR.MINOR.PATCH):
- **MAJOR**: Incompatible API changes
- **MINOR**: Backwards-compatible new features
- **PATCH**: Backwards-compatible bug fixes

## Release Schedule

- **Patch releases**: As needed for critical fixes
- **Minor releases**: Monthly with new features
- **Major releases**: Quarterly with significant changes

## Deprecation Policy

- Features marked for deprecation will be maintained for at least two minor versions
- Deprecation warnings will be shown in logs and documentation
- Migration guides will be provided for breaking changes

[Unreleased]: https://github.com/hybrid-qa/hybrid-qa/compare/v1.0.0...HEAD
[1.0.0]: https://github.com/hybrid-qa/hybrid-qa/compare/v0.9.0-beta...v1.0.0
[0.9.0-beta]: https://github.com/hybrid-qa/hybrid-qa/compare/v0.5.0-alpha...v0.9.0-beta
[0.5.0-alpha]: https://github.com/hybrid-qa/hybrid-qa/releases/tag/v0.5.0-alpha 