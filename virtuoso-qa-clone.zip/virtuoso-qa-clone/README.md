# Hybrid QA

A comprehensive desktop test automation platform supporting web, desktop, mainframe, and API testing with intelligent orchestration, self-healing selectors, and advanced reporting capabilities.

## 🚀 Features

- **Multi-Engine Support**: Web (Playwright), Desktop (pywinauto), Mainframe (s3270), and API testing
- **Visual Flow Builder**: Drag-and-drop interface for creating complex test flows
- **Self-Healing Selectors**: AI-powered element detection with fallback strategies
- **Real-time Recording**: Capture interactions across all supported platforms
- **Advanced Orchestration**: Parallel execution, conditional flows, loops, and data-driven testing
- **Comprehensive Reporting**: Detailed test results with screenshots, videos, and logs
- **Desktop Application**: Electron-based GUI with modern React interface
- **AI Assistant**: Natural language test creation and optimization
- **Observability**: Structured logging, metrics collection, and opt-in telemetry

## 🏗️ Architecture

This monorepo contains the following packages:

### Applications
- **`apps/desktop`**: Electron desktop application with React frontend
  
### Core Services  
- **`packages/orchestrator`**: Node.js orchestration service with Express API and WebSocket support
- **`packages/dsl`**: TypeScript DSL definitions and validation schemas
- **`packages/common`**: Shared utilities, logging, error handling, security, and Prisma schema

### Automation Engines
- **`packages/engine-web`**: Playwright-based web automation engine
- **`packages/engine-desktop`**: Python-based Windows desktop automation (pywinauto)
- **`packages/engine-mainframe`**: Python-based mainframe automation (s3270)
- **`packages/engine-api`**: Node.js-based API testing engine

## 📋 Prerequisites

- **Node.js** >= 18.0.0
- **pnpm** >= 8.0.0
- **Python** >= 3.11 (for desktop and mainframe engines)
- **Windows 10/11** (for desktop engine)

## 🚀 Quick Start

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd hybrid-qa
   ```

2. **Install dependencies**
   ```bash
   pnpm install
   ```

3. **Setup Python engines** (Windows only)
   ```bash
   # Desktop engine
   cd packages/engine-desktop
   ./venv-setup.bat  # or ./venv-setup.sh on Linux
   
   # Mainframe engine
   cd ../engine-mainframe
   ./venv-setup.bat  # or ./venv-setup.sh on Linux
   ```

4. **Install Playwright browsers**
   ```bash
   pnpm --filter engine-web install:browsers
   ```

5. **Start development servers**
   ```bash
   pnpm dev
   ```

This will start:
- Orchestrator service on http://localhost:3001
- Desktop app (Electron) with hot reload
- All automation engines

## 📊 Observability

Hybrid QA includes comprehensive observability features:

### Structured Logging
- **Pino** (Node.js) - High-performance JSON logging
- **structlog** (Python) - Structured logging for engines
- Configurable log levels via UI
- Automatic sensitive data redaction

### Metrics Collection
- Prometheus-compatible metrics endpoint (`/metrics`)
- Test execution and performance metrics
- Resource usage monitoring
- Real-time performance dashboards

### Telemetry (Opt-in)
- Privacy-first approach with explicit consent
- Anonymized error reporting
- Usage analytics for feature improvement
- No personal data collection

Configure observability:
```bash
# Environment variables
LOG_LEVEL=debug
METRICS_ENABLED=true
TELEMETRY_ENABLED=false  # Opt-in only
```

## 📝 Development Scripts

### Root Level
- `pnpm dev` - Start all development servers
- `pnpm build` - Build all packages  
- `pnpm test` - Run all tests
- `pnpm lint` - Lint all packages
- `pnpm clean` - Clean all build artifacts

### Package-Specific
- `pnpm dev:orchestrator` - Start orchestrator service only
- `pnpm dev:desktop` - Start desktop app only
- `pnpm dev:web-engine` - Start web engine only

## 🗄️ Database

The application uses SQLite with Prisma ORM. Database migrations and schema are managed in the `packages/common` package.

```bash
cd packages/common
pnpm db:generate  # Generate Prisma client
pnpm db:push      # Push schema to database
pnpm db:migrate   # Create new migration
pnpm db:studio    # Open Prisma Studio
```

## 🧪 Testing

Each package includes its own test suite:

```bash
# Run all tests
pnpm test

# Run tests for specific package
pnpm --filter orchestrator test
pnpm --filter engine-web test
```

## 📖 API Documentation

### Orchestrator API
- **Base URL**: http://localhost:3001
- **Health Check**: GET /health
- **Metrics**: GET /metrics (Prometheus format)
- **Test Runs**: GET /runs
- **Test Cases**: GET /cases
- **Engines**: GET /engines
- **Artifacts**: GET /artifacts

### Engine APIs
- **Web Engine**: http://localhost:8001
- **Desktop Engine**: http://localhost:8002  
- **Mainframe Engine**: http://localhost:8003
- **API Engine**: http://localhost:8004

Each engine provides:
- `GET /health` - Health check
- `POST /runStep` - Execute a test step
- `POST /record/start/{sessionId}` - Start recording
- `POST /record/stop/{sessionId}` - Stop recording

## 🏗️ Building for Production

```bash
# Build all packages
pnpm build

# Package desktop app
pnpm --filter desktop package
```

The desktop application will be packaged as a Windows installer in `apps/desktop/release/`.

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/amazing-feature`
3. Commit your changes: `git commit -m 'feat: add amazing feature'`
4. Push to the branch: `git push origin feature/amazing-feature`
5. Open a Pull Request

### Commit Convention

This project uses [Conventional Commits](https://www.conventionalcommits.org/):

- `feat:` - New feature
- `fix:` - Bug fix
- `docs:` - Documentation changes
- `style:` - Code style changes
- `refactor:` - Code refactoring
- `test:` - Test changes
- `chore:` - Build/tooling changes

## 📄 License

MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 Support

- 📖 [Documentation](./docs/)
- 🐛 [Issue Tracker](https://github.com/your-org/hybrid-qa/issues)
- 💬 [Discussions](https://github.com/your-org/hybrid-qa/discussions) 