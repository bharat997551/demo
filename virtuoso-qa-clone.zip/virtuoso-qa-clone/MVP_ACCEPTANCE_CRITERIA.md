# MVP Acceptance Criteria

This document defines the minimum acceptance criteria that must be met for the Hybrid QA platform to be considered ready for MVP release.

## Overview

The MVP must demonstrate core functionality across all major components:
- Web automation with Playwright
- Desktop automation on Windows
- API testing capabilities
- Visual flow orchestration
- Successful packaging and deployment

## 1. Web Automation (Playwright)

### Recording Criteria
✅ **User can record a simple login flow**
- [ ] Launch recorder from desktop app
- [ ] Navigate to a test website (e.g., https://demo.playwright.dev/todomvc)
- [ ] Record at least 5 interactions:
  - Navigate to URL
  - Click on input field
  - Type text
  - Click button
  - Verify element exists
- [ ] Stop recording and save test

### Replay Criteria
✅ **Recorded test can be replayed successfully**
- [ ] Execute test in headless mode
- [ ] Test completes without errors
- [ ] All assertions pass
- [ ] Execution time is logged

### Artifact Criteria
✅ **Artifacts are captured and accessible**
- [ ] Screenshot captured for each step
- [ ] Final screenshot shows successful state
- [ ] Console logs captured
- [ ] HAR file generated (if enabled)
- [ ] All artifacts visible in UI with inline viewers

### Test Scenario: Web Login
```yaml
name: Simple Web Login Test
steps:
  - action: navigate
    url: "https://example-app.com/login"
  
  - action: fill
    selector: "#username"
    value: "testuser"
  
  - action: fill
    selector: "#password"
    value: "password123"
  
  - action: click
    selector: "#login-button"
  
  - action: waitForSelector
    selector: ".dashboard-welcome"
    state: visible
  
  - action: assertText
    selector: ".user-name"
    expected: "Test User"
```

## 2. Desktop Automation (Windows)

### Recording Criteria
✅ **User can record a Notepad flow**
- [ ] Launch desktop recorder
- [ ] Open Notepad application
- [ ] Record interactions:
  - Type text in Notepad
  - Use menu to save file (File → Save)
  - Enter filename in dialog
  - Click Save button
  - Close Notepad
- [ ] Stop recording and save test

### Replay Criteria
✅ **Recorded test can be replayed successfully**
- [ ] Execute test on Windows
- [ ] All UI elements found
- [ ] Actions completed successfully
- [ ] File created with correct content

### Screenshot Criteria
✅ **Screenshots captured at key points**
- [ ] Screenshot after Notepad opens
- [ ] Screenshot after text entry
- [ ] Screenshot of save dialog
- [ ] Screenshot of final state
- [ ] All screenshots accessible in UI

### Test Scenario: Notepad Automation
```yaml
name: Notepad File Creation Test
steps:
  - action: launchApp
    path: "notepad.exe"
  
  - action: waitForWindow
    title: "Untitled - Notepad"
  
  - action: typeText
    text: "Hello from Hybrid QA!\nThis is an automated test."
  
  - action: sendKeys
    keys: "ctrl+s"
  
  - action: waitForDialog
    title: "Save As"
  
  - action: typeInDialog
    selector: "Edit1"
    text: "test_output.txt"
  
  - action: clickButton
    text: "Save"
  
  - action: verifyFileExists
    path: "test_output.txt"
  
  - action: closeWindow
    title: "test_output.txt - Notepad"
```

## 3. API Testing

### Request Execution Criteria
✅ **User can define and execute API request**
- [ ] Create API test in UI or YAML
- [ ] Configure request:
  - Method: GET/POST
  - URL with parameters
  - Headers
  - Body (for POST)
- [ ] Execute request
- [ ] Response received

### Assertion Criteria
✅ **Response validation works correctly**
- [ ] Assert status code (e.g., 200)
- [ ] Assert response body contains expected data
- [ ] Assert response time threshold
- [ ] Assert header values
- [ ] All assertions show pass/fail status

### Test Scenario: API CRUD Operations
```yaml
name: API User Management Test
steps:
  - action: api.request
    method: POST
    url: "https://jsonplaceholder.typicode.com/users"
    headers:
      Content-Type: "application/json"
    body:
      name: "Test User"
      email: "test@example.com"
    
  - action: api.expect
    status: 201
    body:
      name: "Test User"
      email: "test@example.com"
    
  - action: api.extract
    from: body.id
    to: userId
  
  - action: api.request
    method: GET
    url: "https://jsonplaceholder.typicode.com/users/{{userId}}"
  
  - action: api.expect
    status: 200
    body:
      id: "{{userId}}"
      name: "Test User"
```

## 4. Flow Builder Integration

### DAG Creation Criteria
✅ **User can create multi-engine flow**
- [ ] Create new flow in visual builder
- [ ] Add web automation node
- [ ] Add desktop automation node  
- [ ] Add API test node
- [ ] Connect nodes in sequence
- [ ] Configure data passing between nodes
- [ ] Save flow

### Sequential Execution Criteria
✅ **Combined flow executes successfully**
- [ ] Web steps complete first
- [ ] Desktop steps execute after web
- [ ] API steps execute last
- [ ] Data passed correctly between steps
- [ ] All steps show success status
- [ ] Total execution time logged

### Test Scenario: End-to-End Flow
```yaml
name: Multi-Engine Integration Test
flow:
  - id: web_login
    type: web
    name: "Login to Web App"
    outputs:
      - sessionToken
  
  - id: desktop_export  
    type: desktop
    name: "Export Data via Desktop App"
    inputs:
      - web_login.sessionToken
    outputs:
      - exportedFile
  
  - id: api_verify
    type: api
    name: "Verify Export via API"
    inputs:
      - desktop_export.exportedFile
```

### Visual Flow Requirements
- [ ] Nodes show execution status (pending/running/success/failed)
- [ ] Execution path highlighted during run
- [ ] Click node to see step details
- [ ] Artifacts accessible from each node
- [ ] Error states clearly visible

## 5. Packaging & Deployment

### Installer Creation Criteria
✅ **Electron Builder produces working installer**
- [ ] Run build command: `pnpm --filter desktop package`
- [ ] Windows EXE installer created
- [ ] Installer size < 200MB
- [ ] Digital signature applied (if cert available)
- [ ] Version number correct

### Installation Criteria
✅ **Clean installation on Windows VM**
- [ ] Fresh Windows 10/11 VM
- [ ] Run installer as standard user
- [ ] Installation completes without errors
- [ ] Desktop shortcut created
- [ ] Start menu entry created
- [ ] App launches successfully

### First-Run Wizard Criteria
✅ **Environment validation passes**
- [ ] First-run wizard appears on initial launch
- [ ] Checks performed:
  - [x] Python detected or bootstrap offered
  - [x] Node.js version compatible
  - [x] Playwright browsers installed or download offered
  - [x] Required permissions validated
  - [x] Port availability checked
- [ ] "Fix" buttons work for missing dependencies
- [ ] Can proceed after all checks pass

### Dependency Installation
- [ ] Python virtual environments created
- [ ] Python packages installed (pywinauto, etc.)
- [ ] Playwright browsers downloaded
- [ ] All engines start successfully

## 6. UI/UX Requirements

### Core UI Elements
✅ **Essential UI components functional**
- [ ] Left sidebar navigation works
- [ ] Test list/tree view populated
- [ ] Run button triggers execution
- [ ] Stop button halts execution
- [ ] Status indicators update in real-time
- [ ] Logs panel shows execution details

### Test Results Display
✅ **Results clearly presented**
- [ ] Pass/fail status obvious
- [ ] Step-by-step breakdown available
- [ ] Timing information shown
- [ ] Error messages helpful
- [ ] Screenshots viewable inline
- [ ] Artifacts downloadable

## 7. Data Persistence

### Test Storage
✅ **Tests saved and retrievable**
- [ ] Tests saved to local SQLite database
- [ ] Tests survive app restart
- [ ] Test history maintained
- [ ] Can duplicate/rename tests

### Results Storage
✅ **Execution results persisted**
- [ ] Run results saved
- [ ] Artifacts stored locally
- [ ] Results survive app restart
- [ ] Can view historical runs

## Validation Checklist

### Smoke Test Sequence
1. **Install on clean Windows 10 VM**
   ```powershell
   # Download installer
   # Run as standard user
   # Complete first-run wizard
   ```

2. **Record and run web test**
   ```
   - Open app
   - Click "New Test" → "Web"
   - Record login to demo site
   - Save test
   - Run test
   - Verify artifacts
   ```

3. **Record and run desktop test**
   ```
   - Click "New Test" → "Desktop"  
   - Record Notepad automation
   - Save test
   - Run test
   - Verify screenshots
   ```

4. **Create and run API test**
   ```
   - Click "New Test" → "API"
   - Configure GET request
   - Add assertions
   - Run test
   - Verify results
   ```

5. **Build combined flow**
   ```
   - Open Flow Builder
   - Add all three test types
   - Connect in sequence
   - Run flow
   - Verify all steps pass
   ```

## Success Metrics

### Performance Targets
- App launch time: < 5 seconds
- Test execution overhead: < 10%
- Memory usage: < 500MB idle
- Artifact storage: Efficient compression

### Reliability Targets
- Test replay success rate: > 95%
- No crashes during normal operation
- Graceful error handling
- Clear error messages

### Usability Targets
- Record test in < 2 minutes
- Run test in < 1 click
- View results immediately
- No manual configuration needed

## Known Limitations (Acceptable for MVP)

1. **No cloud execution** - Local only
2. **Basic reporting** - No advanced analytics
3. **Limited integrations** - No CI/CD plugins yet
4. **Single user** - No collaboration features active
5. **Windows only** - No macOS/Linux support
6. **English only** - No internationalization

## Definition of Done

The MVP is considered complete when:

✅ All criteria marked with checkboxes are satisfied
✅ Smoke test sequence passes on 3 different Windows machines
✅ 5 beta users successfully complete basic tasks
✅ No critical bugs in issue tracker
✅ Documentation covers basic usage
✅ Installer downloadable from releases page

## Post-MVP Roadmap

Once MVP criteria are met, prioritize:
1. Cloud execution capabilities
2. Enhanced reporting/analytics  
3. CI/CD integrations
4. Team collaboration features
5. Cross-platform support
6. Advanced AI features

---

**Last Updated**: January 2025
**Version**: 1.0.0
**Status**: In Development 