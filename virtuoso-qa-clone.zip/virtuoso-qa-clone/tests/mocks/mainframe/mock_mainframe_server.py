#!/usr/bin/env python3
"""
Mock mainframe server for testing
Simulates basic 3270 terminal responses
"""

import socket
import threading
import time
import logging
from datetime import datetime

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class MockMainframeServer:
    def __init__(self, host='0.0.0.0', port=3270):
        self.host = host
        self.port = port
        self.running = False
        self.server_socket = None
        self.screens = {
            'initial': self.get_initial_screen(),
            'login_prompt': self.get_login_prompt_screen(),
            'password_prompt': self.get_password_prompt_screen(),
            'main_menu': self.get_main_menu_screen(),
            'cics_signon': self.get_cics_signon_screen(),
            'cics_main': self.get_cics_main_screen(),
            'account_inquiry': self.get_account_inquiry_screen(),
            'account_details': self.get_account_details_screen()
        }
        self.current_screen = 'initial'
        
    def get_initial_screen(self):
        """Initial connection screen"""
        screen = [[' ' for _ in range(80)] for _ in range(24)]
        self._write_text(screen, 1, 30, 'MOCK MAINFRAME SYSTEM')
        self._write_text(screen, 3, 25, 'Test Environment - Not Production')
        self._write_text(screen, 10, 20, 'Enter LOGON command to continue')
        self._write_text(screen, 24, 2, 'READY')
        return screen
    
    def get_login_prompt_screen(self):
        """Login prompt screen"""
        screen = [[' ' for _ in range(80)] for _ in range(24)]
        self._write_text(screen, 1, 30, 'SYSTEM LOGIN')
        self._write_text(screen, 10, 20, 'Userid:')
        self._write_text(screen, 11, 20, 'Password:')
        self._write_text(screen, 24, 2, 'Enter userid and password')
        return screen
    
    def get_password_prompt_screen(self):
        """Password prompt screen"""
        screen = [[' ' for _ in range(80)] for _ in range(24)]
        self._write_text(screen, 1, 30, 'SYSTEM LOGIN')
        self._write_text(screen, 10, 20, 'Password:')
        self._write_text(screen, 24, 2, 'Enter password')
        return screen
    
    def get_main_menu_screen(self):
        """Main menu screen"""
        screen = [[' ' for _ in range(80)] for _ in range(24)]
        self._write_text(screen, 1, 30, 'MAIN MENU')
        self._write_text(screen, 3, 10, f'Welcome TESTUSER - {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
        self._write_text(screen, 6, 10, '1. CICS Transaction Processing')
        self._write_text(screen, 7, 10, '2. TSO/ISPF')
        self._write_text(screen, 8, 10, '3. IMS')
        self._write_text(screen, 9, 10, '4. Batch Job Submission')
        self._write_text(screen, 10, 10, '5. System Status')
        self._write_text(screen, 11, 10, 'X. Exit')
        self._write_text(screen, 24, 2, 'Enter selection:')
        return screen
    
    def get_cics_signon_screen(self):
        """CICS sign-on screen"""
        screen = [[' ' for _ in range(80)] for _ in range(24)]
        self._write_text(screen, 1, 30, 'CICS SIGN-ON')
        self._write_text(screen, 10, 20, 'Userid:')
        self._write_text(screen, 11, 20, 'Password:')
        self._write_text(screen, 24, 2, 'Enter CICS credentials')
        return screen
    
    def get_cics_main_screen(self):
        """CICS main screen"""
        screen = [[' ' for _ in range(80)] for _ in range(24)]
        self._write_text(screen, 1, 1, 'CICS')
        self._write_text(screen, 1, 30, 'TRANSACTION MENU')
        self._write_text(screen, 5, 10, 'Available Transactions:')
        self._write_text(screen, 7, 10, 'ACCT - Account Inquiry')
        self._write_text(screen, 8, 10, 'CUST - Customer Maintenance')
        self._write_text(screen, 9, 10, 'TRAN - Transaction History')
        self._write_text(screen, 10, 10, 'CESF - Sign off')
        self._write_text(screen, 24, 2, 'Enter transaction:')
        return screen
    
    def get_account_inquiry_screen(self):
        """Account inquiry screen"""
        screen = [[' ' for _ in range(80)] for _ in range(24)]
        self._write_text(screen, 1, 30, 'ACCOUNT INQUIRY')
        self._write_text(screen, 5, 20, 'Account Number:')
        self._write_text(screen, 24, 2, 'Enter account number or PF3 to exit')
        return screen
    
    def get_account_details_screen(self):
        """Account details screen"""
        screen = [[' ' for _ in range(80)] for _ in range(24)]
        self._write_text(screen, 1, 30, 'ACCOUNT DETAILS')
        self._write_text(screen, 5, 10, 'Account Number: 1234567890')
        self._write_text(screen, 7, 10, 'Account Type: CHECKING')
        self._write_text(screen, 8, 10, 'Customer Name: TEST CUSTOMER')
        self._write_text(screen, 10, 20, 'Balance: $10,543.21')
        self._write_text(screen, 12, 10, 'Last Transaction: 2024-01-15')
        self._write_text(screen, 13, 10, 'Status: ACTIVE')
        self._write_text(screen, 24, 2, 'PF3=Exit PF7=Prev PF8=Next')
        return screen
    
    def _write_text(self, screen, row, col, text):
        """Write text to screen at specified position"""
        row = row - 1  # Convert to 0-based
        col = col - 1
        for i, char in enumerate(text):
            if col + i < 80:
                screen[row][col + i] = char
    
    def _screen_to_string(self, screen):
        """Convert screen array to string"""
        return '\n'.join([''.join(row) for row in screen])
    
    def handle_client(self, client_socket, address):
        """Handle client connection"""
        logger.info(f"Client connected from {address}")
        
        try:
            # Send initial screen
            screen_data = self._screen_to_string(self.screens[self.current_screen])
            client_socket.send(screen_data.encode('utf-8'))
            
            while True:
                # Receive data from client
                data = client_socket.recv(1024)
                if not data:
                    break
                
                command = data.decode('utf-8').strip().upper()
                logger.info(f"Received command: {command}")
                
                # Process commands and transition screens
                if self.current_screen == 'initial':
                    if 'LOGON' in command:
                        self.current_screen = 'login_prompt'
                
                elif self.current_screen == 'login_prompt':
                    if 'TESTUSER' in command:
                        self.current_screen = 'password_prompt'
                
                elif self.current_screen == 'password_prompt':
                    if 'TESTPASS' in command:
                        self.current_screen = 'main_menu'
                
                elif self.current_screen == 'main_menu':
                    if command == '1' or 'CICS' in command:
                        self.current_screen = 'cics_signon'
                    elif command == 'CESN':
                        self.current_screen = 'cics_signon'
                
                elif self.current_screen == 'cics_signon':
                    if 'CICSUSER' in command:
                        time.sleep(0.5)  # Simulate processing
                    elif 'CICSPASS' in command:
                        self.current_screen = 'cics_main'
                
                elif self.current_screen == 'cics_main':
                    if command == 'ACCT':
                        self.current_screen = 'account_inquiry'
                    elif command == 'CESF':
                        self.current_screen = 'main_menu'
                
                elif self.current_screen == 'account_inquiry':
                    if command.isdigit() and len(command) == 10:
                        self.current_screen = 'account_details'
                    elif 'PF3' in command or 'EXIT' in command:
                        self.current_screen = 'cics_main'
                
                elif self.current_screen == 'account_details':
                    if 'PF3' in command or 'EXIT' in command:
                        self.current_screen = 'account_inquiry'
                
                # Send updated screen
                screen_data = self._screen_to_string(self.screens[self.current_screen])
                client_socket.send(screen_data.encode('utf-8'))
                
        except Exception as e:
            logger.error(f"Error handling client: {e}")
        finally:
            client_socket.close()
            logger.info(f"Client disconnected from {address}")
    
    def start(self):
        """Start the mock server"""
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server_socket.bind((self.host, self.port))
        self.server_socket.listen(5)
        self.running = True
        
        logger.info(f"Mock mainframe server listening on {self.host}:{self.port}")
        
        while self.running:
            try:
                client_socket, address = self.server_socket.accept()
                client_thread = threading.Thread(
                    target=self.handle_client,
                    args=(client_socket, address)
                )
                client_thread.daemon = True
                client_thread.start()
            except Exception as e:
                if self.running:
                    logger.error(f"Server error: {e}")
    
    def stop(self):
        """Stop the mock server"""
        self.running = False
        if self.server_socket:
            self.server_socket.close()
        logger.info("Mock mainframe server stopped")


if __name__ == '__main__':
    server = MockMainframeServer()
    try:
        server.start()
    except KeyboardInterrupt:
        logger.info("Shutting down mock mainframe server...")
        server.stop() 