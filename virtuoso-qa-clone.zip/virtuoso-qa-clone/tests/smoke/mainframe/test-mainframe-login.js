const { test, expect } = require('@playwright/test');

test.describe('Mainframe Engine Smoke Tests (Mocked)', () => {
  let orchestratorUrl = process.env.ORCHESTRATOR_URL || 'http://localhost:3001';
  let mainframeEngineUrl = process.env.MAINFRAME_ENGINE_URL || 'http://localhost:8003';

  test.beforeAll(async () => {
    // Verify services are running
    const orchestratorHealth = await fetch(`${orchestratorUrl}/health`);
    expect(orchestratorHealth.ok).toBeTruthy();
    
    const mainframeEngineHealth = await fetch(`${mainframeEngineUrl}/health`);
    expect(mainframeEngineHealth.ok).toBeTruthy();
  });

  test('Mainframe login flow', async () => {
    const testSteps = [
      {
        type: 'mainframe.connect',
        host: 'localhost',
        port: 3270,
        model: '3278-2',
        description: 'Connect to mock mainframe'
      },
      {
        type: 'mainframe.waitForField',
        row: 24,
        col: 2,
        text: 'READY',
        timeout: 5000,
        description: 'Wait for ready prompt'
      },
      {
        type: 'mainframe.type',
        text: 'LOGON TESTUSER',
        description: 'Enter logon command'
      },
      {
        type: 'mainframe.sendKey',
        key: 'ENTER',
        description: 'Submit logon'
      },
      {
        type: 'mainframe.waitForField',
        row: 10,
        col: 20,
        text: 'Password',
        timeout: 3000,
        description: 'Wait for password prompt'
      },
      {
        type: 'mainframe.type',
        text: 'TESTPASS',
        row: 10,
        col: 30,
        description: 'Enter password'
      },
      {
        type: 'mainframe.sendKey',
        key: 'ENTER',
        description: 'Submit password'
      },
      {
        type: 'mainframe.waitForField',
        row: 1,
        col: 30,
        text: 'MAIN MENU',
        timeout: 5000,
        description: 'Wait for main menu'
      },
      {
        type: 'mainframe.capture',
        filename: 'mainframe-main-menu.png',
        description: 'Capture main menu screen'
      }
    ];

    // Execute test via orchestrator
    const response = await fetch(`${orchestratorUrl}/runs`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: 'Mainframe Login Smoke Test',
        engine: 'mainframe',
        steps: testSteps
      })
    });

    const run = await response.json();
    expect(run.id).toBeTruthy();

    // Poll for completion
    let runStatus;
    for (let i = 0; i < 30; i++) {
      const statusResponse = await fetch(`${orchestratorUrl}/runs/${run.id}`);
      runStatus = await statusResponse.json();
      
      if (runStatus.status === 'completed' || runStatus.status === 'failed') {
        break;
      }
      
      await new Promise(resolve => setTimeout(resolve, 1000));
    }

    expect(runStatus.status).toBe('completed');
    expect(runStatus.result.success).toBeTruthy();
  });

  test('CICS transaction test', async () => {
    const testSteps = [
      {
        type: 'mainframe.connect',
        host: 'localhost',
        port: 3270
      },
      {
        type: 'mainframe.waitForField',
        row: 24,
        col: 2,
        text: 'READY',
        timeout: 5000
      },
      {
        type: 'mainframe.type',
        text: 'CESN',
        description: 'Enter CICS sign-on transaction'
      },
      {
        type: 'mainframe.sendKey',
        key: 'ENTER'
      },
      {
        type: 'mainframe.waitForField',
        row: 10,
        col: 20,
        text: 'Userid'
      },
      {
        type: 'mainframe.type',
        text: 'CICSUSER',
        row: 10,
        col: 30
      },
      {
        type: 'mainframe.type',
        text: 'CICSPASS',
        row: 11,
        col: 30
      },
      {
        type: 'mainframe.sendKey',
        key: 'ENTER'
      },
      {
        type: 'mainframe.waitForField',
        row: 1,
        col: 1,
        text: 'CICS',
        timeout: 5000
      },
      {
        type: 'mainframe.type',
        text: 'ACCT',
        description: 'Enter account inquiry transaction'
      },
      {
        type: 'mainframe.sendKey',
        key: 'ENTER'
      },
      {
        type: 'mainframe.waitForField',
        row: 5,
        col: 20,
        text: 'Account Number'
      },
      {
        type: 'mainframe.type',
        text: '1234567890',
        row: 5,
        col: 40
      },
      {
        type: 'mainframe.sendKey',
        key: 'ENTER'
      },
      {
        type: 'mainframe.expect',
        row: 10,
        col: 20,
        text: 'Balance:',
        description: 'Verify balance field appears'
      },
      {
        type: 'mainframe.capture',
        filename: 'account-inquiry.txt',
        format: 'text',
        description: 'Capture screen as text'
      }
    ];

    const response = await fetch(`${orchestratorUrl}/runs`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: 'CICS Transaction Test',
        engine: 'mainframe',
        steps: testSteps
      })
    });

    const run = await response.json();
    
    // Wait for completion
    await new Promise(resolve => setTimeout(resolve, 15000));
    
    const statusResponse = await fetch(`${orchestratorUrl}/runs/${run.id}`);
    const runStatus = await statusResponse.json();
    
    expect(runStatus.status).toBe('completed');
    
    // Check artifacts
    const artifactsResponse = await fetch(`${orchestratorUrl}/runs/${run.id}/artifacts`);
    const artifacts = await artifactsResponse.json();
    
    expect(artifacts.length).toBeGreaterThan(0);
    const textArtifact = artifacts.find(a => a.filename.endsWith('.txt'));
    expect(textArtifact).toBeTruthy();
  });
}); 