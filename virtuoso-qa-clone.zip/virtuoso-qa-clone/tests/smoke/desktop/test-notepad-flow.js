const { test, expect } = require('@playwright/test');

test.describe('Desktop Engine Smoke Tests - Notepad', () => {
  let orchestratorUrl = process.env.ORCHESTRATOR_URL || 'http://localhost:3001';
  let desktopEngineUrl = process.env.DESKTOP_ENGINE_URL || 'http://localhost:8002';

  test.beforeAll(async () => {
    // Verify services are running
    const orchestratorHealth = await fetch(`${orchestratorUrl}/health`);
    expect(orchestratorHealth.ok).toBeTruthy();
    
    const desktopEngineHealth = await fetch(`${desktopEngineUrl}/health`);
    expect(desktopEngineHealth.ok).toBeTruthy();
  });

  test('Notepad - Create and save file', async () => {
    const testSteps = [
      {
        type: 'desktop.launch',
        application: 'notepad.exe',
        description: 'Launch Notepad'
      },
      {
        type: 'desktop.waitFor',
        window: {
          title_re: '.*Notepad.*',
          class_name: 'Notepad'
        },
        timeout: 5000,
        description: 'Wait for Notepad window'
      },
      {
        type: 'desktop.type',
        text: 'Hello from Hybrid QA!\nThis is an automated test.',
        description: 'Type test content'
      },
      {
        type: 'desktop.keyboard',
        keys: 'Ctrl+S',
        description: 'Open Save dialog'
      },
      {
        type: 'desktop.waitFor',
        window: {
          title: 'Save As',
          class_name: '#32770'
        },
        timeout: 3000,
        description: 'Wait for Save dialog'
      },
      {
        type: 'desktop.type',
        text: 'test_output_' + Date.now() + '.txt',
        description: 'Enter filename'
      },
      {
        type: 'desktop.click',
        locator: {
          type: 'name',
          value: 'Save'
        },
        description: 'Click Save button'
      },
      {
        type: 'desktop.keyboard',
        keys: 'Alt+F4',
        description: 'Close Notepad'
      }
    ];

    // Execute test via orchestrator
    const response = await fetch(`${orchestratorUrl}/runs`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: 'Notepad Smoke Test',
        engine: 'desktop',
        steps: testSteps
      })
    });

    const run = await response.json();
    expect(run.id).toBeTruthy();

    // Poll for completion
    let runStatus;
    for (let i = 0; i < 30; i++) {
      const statusResponse = await fetch(`${orchestratorUrl}/runs/${run.id}`);
      runStatus = await statusResponse.json();
      
      if (runStatus.status === 'completed' || runStatus.status === 'failed') {
        break;
      }
      
      await new Promise(resolve => setTimeout(resolve, 1000));
    }

    expect(runStatus.status).toBe('completed');
    expect(runStatus.result.success).toBeTruthy();
    
    // Verify file was created
    const fs = require('fs');
    const files = fs.readdirSync(process.env.USERPROFILE || '.');
    const testFile = files.find(f => f.startsWith('test_output_') && f.endsWith('.txt'));
    expect(testFile).toBeTruthy();
    
    // Cleanup
    if (testFile) {
      fs.unlinkSync(testFile);
    }
  });

  test('Notepad - Menu navigation', async () => {
    const testSteps = [
      {
        type: 'desktop.launch',
        application: 'notepad.exe'
      },
      {
        type: 'desktop.waitFor',
        window: { title_re: '.*Notepad.*' },
        timeout: 5000
      },
      {
        type: 'desktop.keyboard',
        keys: 'Alt+F',
        description: 'Open File menu'
      },
      {
        type: 'desktop.waitFor',
        control: {
          type: 'menu_item',
          name: 'New'
        },
        timeout: 2000
      },
      {
        type: 'desktop.keyboard',
        keys: 'Escape',
        description: 'Close menu'
      },
      {
        type: 'desktop.keyboard',
        keys: 'Alt+H',
        description: 'Open Help menu'
      },
      {
        type: 'desktop.waitFor',
        control: {
          type: 'menu_item',
          name: 'About Notepad'
        },
        timeout: 2000
      },
      {
        type: 'desktop.keyboard',
        keys: 'Escape',
        description: 'Close menu'
      },
      {
        type: 'desktop.keyboard',
        keys: 'Alt+F4',
        description: 'Close Notepad'
      }
    ];

    const response = await fetch(`${orchestratorUrl}/runs`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: 'Notepad Menu Test',
        engine: 'desktop',
        steps: testSteps
      })
    });

    const run = await response.json();
    
    // Wait for completion
    await new Promise(resolve => setTimeout(resolve, 10000));
    
    const statusResponse = await fetch(`${orchestratorUrl}/runs/${run.id}`);
    const runStatus = await statusResponse.json();
    
    expect(runStatus.status).toBe('completed');
  });
}); 