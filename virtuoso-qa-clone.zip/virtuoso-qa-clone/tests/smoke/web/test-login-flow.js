const { test, expect } = require('@playwright/test');

test.describe('Web Engine Smoke Tests', () => {
  let orchestratorUrl = process.env.ORCHESTRATOR_URL || 'http://localhost:3001';
  let webEngineUrl = process.env.WEB_ENGINE_URL || 'http://localhost:8001';

  test.beforeAll(async () => {
    // Verify services are running
    const orchestratorHealth = await fetch(`${orchestratorUrl}/health`);
    expect(orchestratorHealth.ok).toBeTruthy();
    
    const webEngineHealth = await fetch(`${webEngineUrl}/health`);
    expect(webEngineHealth.ok).toBeTruthy();
  });

  test('Login flow test', async ({ page }) => {
    // Define test steps
    const testSteps = [
      {
        type: 'web.navigate',
        url: 'https://example.com/login',
        waitUntil: 'networkidle'
      },
      {
        type: 'web.fill',
        selector: '#username',
        value: 'testuser@example.com'
      },
      {
        type: 'web.fill',
        selector: '#password',
        value: 'testpassword123'
      },
      {
        type: 'web.click',
        selector: 'button[type="submit"]'
      },
      {
        type: 'web.waitForSelector',
        selector: '.dashboard',
        timeout: 10000
      },
      {
        type: 'web.expect',
        selector: 'h1',
        text: 'Welcome, Test User'
      }
    ];

    // Execute test via orchestrator
    const response = await fetch(`${orchestratorUrl}/runs`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: 'Login Flow Smoke Test',
        engine: 'web',
        steps: testSteps
      })
    });

    const run = await response.json();
    expect(run.id).toBeTruthy();

    // Poll for completion
    let runStatus;
    for (let i = 0; i < 30; i++) {
      const statusResponse = await fetch(`${orchestratorUrl}/runs/${run.id}`);
      runStatus = await statusResponse.json();
      
      if (runStatus.status === 'completed' || runStatus.status === 'failed') {
        break;
      }
      
      await new Promise(resolve => setTimeout(resolve, 1000));
    }

    expect(runStatus.status).toBe('completed');
    expect(runStatus.result.success).toBeTruthy();
  });

  test('Screenshot capture test', async ({ page }) => {
    const testSteps = [
      {
        type: 'web.navigate',
        url: 'https://example.com'
      },
      {
        type: 'web.screenshot',
        filename: 'homepage.png',
        fullPage: true
      }
    ];

    const response = await fetch(`${orchestratorUrl}/runs`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: 'Screenshot Smoke Test',
        engine: 'web',
        steps: testSteps
      })
    });

    const run = await response.json();
    
    // Wait for completion
    await new Promise(resolve => setTimeout(resolve, 5000));
    
    // Check artifacts
    const artifactsResponse = await fetch(`${orchestratorUrl}/runs/${run.id}/artifacts`);
    const artifacts = await artifactsResponse.json();
    
    expect(artifacts.length).toBeGreaterThan(0);
    expect(artifacts[0].type).toBe('screenshot');
  });
}); 