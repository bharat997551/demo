# Hybrid QA - User Manual

## Table of Contents

1. [Getting Started](#getting-started)
2. [Recording Tests](#recording-tests)
   - [Web Recording](#web-recording)
   - [Desktop Recording](#desktop-recording)
3. [Building Test Flows](#building-test-flows)
   - [Visual Flow Builder](#visual-flow-builder)
   - [DSL Editor](#dsl-editor)
4. [Using the AI Assistant](#using-the-ai-assistant)
5. [Running Tests](#running-tests)
6. [Interpreting Reports](#interpreting-reports)
7. [Advanced Features](#advanced-features)

## Getting Started

### First Launch

When you first launch Hybrid QA, the application will:

1. **Check Dependencies**: Verify all required components are installed
2. **Setup Wizard**: Guide you through initial configuration
3. **Create Project**: Help you create your first test project

### Main Interface Overview

![Main Interface](images/main-interface.png)

The main interface consists of:

- **Left Sidebar**: Navigation between different sections
- **Top Bar**: Run controls and global actions
- **Central Area**: Main workspace for current activity
- **Bottom Panel**: Logs and output
- **Floating Panels**: Recorder widgets and debugger

### Creating Your First Project

1. Click **"New Project"** on the welcome screen
2. Choose project type:
   - Web Testing
   - Desktop Testing
   - API Testing
   - Combined (Multi-engine)
3. Enter project details:
   - Name
   - Description
   - Target application URL/path
4. Click **"Create"**

## Recording Tests

### Web Recording

Web recording captures interactions with web applications using browser automation.

#### Starting Web Recording

1. Navigate to **Tests** → **New Test**
2. Click the **"Record Web"** button
3. Enter the starting URL
4. Choose browser (Chrome, Firefox, Edge)
5. Click **"Start Recording"**

#### Recording Actions

The recorder captures:
- **Clicks**: Button clicks, link navigation
- **Text Input**: Form filling, search boxes
- **Navigation**: Page loads, back/forward
- **Assertions**: Text verification, element presence
- **Screenshots**: Visual checkpoints

**Recording Controls:**

![Web Recorder Widget](images/web-recorder.png)

- **Pause/Resume**: Temporarily stop recording
- **Add Assertion**: Verify page content
- **Take Screenshot**: Capture current state
- **Add Wait**: Insert explicit waits
- **Stop**: End recording session

#### Best Practices for Web Recording

1. **Wait for Page Loads**: Let pages fully load before interacting
2. **Use Unique Selectors**: Click on elements with unique identifiers
3. **Add Assertions**: Verify expected outcomes after actions
4. **Keep It Simple**: Record one scenario at a time
5. **Clean Up**: Remove unnecessary actions after recording

### Desktop Recording

Desktop recording captures interactions with Windows applications.

#### Starting Desktop Recording

1. Navigate to **Tests** → **New Test**
2. Click the **"Record Desktop"** button
3. Select target application:
   - Running application from list
   - Launch new application
4. Click **"Start Recording"**

#### Recording Desktop Actions

The recorder captures:
- **Mouse Actions**: Clicks, double-clicks, right-clicks
- **Keyboard Input**: Text typing, shortcuts
- **Window Operations**: Minimize, maximize, close
- **Menu Navigation**: File menus, context menus
- **Drag & Drop**: File operations, UI manipulation

**Desktop Recorder Overlay:**

![Desktop Recorder Overlay](images/desktop-recorder.png)

- **Highlight Mode**: Shows which element will be interacted with
- **Capture Region**: Define specific areas for validation
- **Smart Detection**: Automatically identifies UI controls
- **Pause Recording**: Temporarily stop without losing progress

#### Tips for Desktop Recording

1. **Close Unnecessary Apps**: Reduce interference
2. **Use Keyboard Shortcuts**: More reliable than mouse clicks
3. **Record at Normal Speed**: Don't rush through actions
4. **Verify Window State**: Ensure windows are in expected state
5. **Add Context**: Use descriptions for complex actions

## Building Test Flows

### Visual Flow Builder

The visual flow builder lets you create complex test scenarios using a drag-and-drop interface.

#### Creating a Flow

1. Open **Flow Builder** from the sidebar
2. Drag components from the palette:
   - **Actions**: Click, Type, Navigate
   - **Assertions**: Verify, Check, Compare
   - **Control Flow**: If/Else, Loops, Parallel
   - **Data**: Variables, Data Sets, Generators
3. Connect components to define execution order
4. Configure each component's properties

#### Flow Components

**Basic Actions:**
- **Navigate**: Go to URL/open application
- **Click**: Click element/button
- **Type**: Enter text
- **Wait**: Pause execution
- **Screenshot**: Capture screen

**Assertions:**
- **Text Contains**: Verify text presence
- **Element Exists**: Check element visibility
- **Value Equals**: Compare values
- **Image Match**: Visual comparison

**Control Flow:**
- **Conditional**: If/Then/Else logic
- **Loop**: Repeat actions
- **Parallel**: Run actions simultaneously
- **Try/Catch**: Error handling

**Data Operations:**
- **Set Variable**: Store values
- **Read Data**: Load from file/API
- **Generate**: Create test data
- **Transform**: Modify data

#### Example Flow

```
[Start] → [Navigate to Login] → [Enter Username] → [Enter Password] 
    ↓
[Click Login] → [Wait for Dashboard] → [Verify Welcome Message]
    ↓
[If Admin User] → [Navigate to Admin Panel] → [Verify Admin Access]
    ↓
[Take Screenshot] → [Logout] → [End]
```

### DSL Editor

The DSL (Domain Specific Language) editor provides a text-based way to write tests.

#### Basic DSL Syntax

```yaml
name: Login Test
description: Test user login functionality
engine: web

steps:
  - action: navigate
    url: https://example.com/login
    
  - action: fill
    selector: "#username"
    value: "testuser@example.com"
    
  - action: fill
    selector: "#password"
    value: "{{ password }}"
    
  - action: click
    selector: "button[type='submit']"
    
  - action: waitFor
    selector: ".dashboard"
    timeout: 10000
    
  - action: expect
    selector: "h1"
    text: "Welcome, Test User"
```

#### DSL Features

**Variables:**
```yaml
variables:
  username: testuser@example.com
  password: "{{ env.TEST_PASSWORD }}"
  baseUrl: https://example.com

steps:
  - action: navigate
    url: "{{ baseUrl }}/login"
```

**Loops:**
```yaml
steps:
  - action: forEach
    items: "{{ users }}"
    as: user
    steps:
      - action: fill
        selector: "#username"
        value: "{{ user.email }}"
```

**Conditionals:**
```yaml
steps:
  - action: if
    condition: "{{ isAdmin }}"
    then:
      - action: click
        selector: "#admin-panel"
    else:
      - action: click
        selector: "#user-dashboard"
```

**Data-Driven Tests:**
```yaml
data:
  source: ./test-data/users.csv
  
steps:
  - action: navigate
    url: "{{ baseUrl }}/login"
    
  - action: fill
    selector: "#username"
    value: "{{ data.username }}"
```

## Using the AI Assistant

The AI Assistant helps you create and optimize tests using natural language.

### Accessing the Assistant

1. Click the **AI Assistant** button in the toolbar
2. Or press `Ctrl+Shift+A` anywhere in the app

### Assistant Capabilities

#### 1. Natural Language to Test Steps

**You type:**
> "Test login with valid credentials and verify dashboard appears"

**Assistant generates:**
```yaml
steps:
  - action: navigate
    url: "${baseUrl}/login"
  - action: fill
    selector: "#username"
    value: "${validUsername}"
  - action: fill
    selector: "#password"
    value: "${validPassword}"
  - action: click
    selector: "button[type='submit']"
  - action: waitFor
    selector: ".dashboard"
  - action: expect
    selector: ".dashboard h1"
    text: "Dashboard"
```

#### 2. Test Optimization

**You type:**
> "Optimize this test for better reliability"

**Assistant suggests:**
- Add explicit waits after navigation
- Use more specific selectors
- Add error handling
- Include validation steps

#### 3. Failure Analysis

**You type:**
> "Why did my test fail?"

**Assistant analyzes:**
- Reviews error logs
- Identifies root cause
- Suggests fixes
- Provides alternative approaches

#### 4. Locator Suggestions

**You type:**
> "Find better selector for login button"

**Assistant provides:**
```
Recommended selectors (in order of preference):
1. [data-testid="login-submit"]
2. button[aria-label="Sign in"]
3. #login-form button[type="submit"]
4. .login-container .submit-button
```

### Assistant Workflow

1. **Describe Your Intent**: Type what you want to test
2. **Review Suggestions**: Assistant provides test steps
3. **Refine**: Ask for modifications or alternatives
4. **Accept/Reject**: Choose which suggestions to use
5. **Apply**: Add to your test flow

### Tips for Using the Assistant

- Be specific about what you want to test
- Provide context (application type, technology)
- Review generated steps before accepting
- Use for learning DSL syntax
- Ask for explanations of complex steps

## Running Tests

### Quick Run

1. Select test from the test list
2. Click **"Run"** button
3. Monitor progress in real-time

### Run Configuration

**Basic Options:**
- **Browser**: Chrome, Firefox, Edge, Safari
- **Mode**: Headed (visible) or Headless
- **Speed**: Normal, Slow (for debugging), Fast
- **Screenshots**: On failure, Always, Never

**Advanced Options:**
- **Parallel Execution**: Run multiple tests simultaneously
- **Retry Failed**: Number of retry attempts
- **Timeout**: Global timeout for test execution
- **Environment**: Dev, Test, Staging, Production

### Debugging Tests

#### Debug Mode Features

1. **Breakpoints**: Pause at specific steps
2. **Step Through**: Execute one step at a time
3. **Variable Inspector**: View current variable values
4. **Element Inspector**: Highlight elements on page
5. **Network Monitor**: View API calls
6. **Console Logs**: Application and test logs

#### Using the Debugger

1. Click **"Debug"** instead of "Run"
2. Set breakpoints by clicking step numbers
3. Use debug controls:
   - **Continue**: Run to next breakpoint
   - **Step Over**: Execute current step
   - **Step Into**: Dive into sub-flows
   - **Stop**: End debug session

### Scheduled Runs

Configure tests to run automatically:

1. Open test settings
2. Navigate to **Schedule** tab
3. Configure:
   - **Frequency**: Daily, Weekly, Custom
   - **Time**: When to run
   - **Notifications**: Email, Slack, Teams
   - **Conditions**: Only on changes, specific branches

## Interpreting Reports

### Test Results Dashboard

![Results Dashboard](images/results-dashboard.png)

**Key Metrics:**
- **Pass Rate**: Percentage of successful tests
- **Duration**: Total execution time
- **Trend**: Pass rate over time
- **Failures**: Detailed failure information

### Report Sections

#### 1. Summary

- Overall status (Passed/Failed)
- Execution time
- Environment details
- Test configuration

#### 2. Step Details

For each step:
- Status (Success/Failure/Skipped)
- Duration
- Screenshots (if captured)
- Logs
- Error details (for failures)

#### 3. Artifacts

- **Screenshots**: Visual evidence
- **Videos**: Full test recordings
- **HAR Files**: Network traffic
- **Logs**: Detailed execution logs
- **Data**: Input/output data

#### 4. Failure Analysis

For failed tests:
- **Error Message**: What went wrong
- **Stack Trace**: Technical details
- **Screenshot**: State at failure
- **Suggested Fixes**: AI-powered suggestions
- **History**: Previous failures

### Understanding Common Failures

**Element Not Found:**
- Element doesn't exist
- Page not fully loaded
- Selector changed
- **Fix**: Update selector, add wait

**Timeout:**
- Action took too long
- Application slow
- Network issues
- **Fix**: Increase timeout, optimize app

**Assertion Failed:**
- Unexpected content
- Wrong value
- Missing element
- **Fix**: Update expectation, verify data

**Application Error:**
- JavaScript errors
- Server errors
- Crashes
- **Fix**: Report bug, add error handling

### Trend Analysis

![Trend Analysis](images/trend-analysis.png)

**Metrics to Monitor:**
- **Pass Rate Trend**: Improving or declining
- **Duration Trend**: Getting slower/faster
- **Flaky Tests**: Inconsistent results
- **Failure Patterns**: Common failure causes

### Exporting Reports

**Export Formats:**
- **HTML**: Interactive web report
- **PDF**: Printable document
- **JSON**: Raw data for processing
- **JUnit XML**: CI/CD integration
- **Excel**: Spreadsheet analysis

**Export Options:**
1. Click **"Export"** in report view
2. Choose format
3. Select sections to include
4. Configure options (embed artifacts, etc.)
5. Save or share

## Advanced Features

### Self-Healing Locators

When elements change, Hybrid QA automatically:
1. Detects failures
2. Finds alternative locators
3. Suggests updates
4. Optionally auto-fixes

**Managing Healed Locators:**
1. Open **Healed Selectors** panel
2. Review suggestions
3. Accept or reject changes
4. View confidence scores

### Data-Driven Testing

**Using CSV Files:**
```yaml
data:
  source: ./data/users.csv
  
forEach: data
steps:
  - action: fill
    selector: "#email"
    value: "{{ item.email }}"
```

**Using Excel:**
```yaml
data:
  source: ./data/testdata.xlsx
  sheet: Users
  range: A2:C100
```

**Using API:**
```yaml
data:
  source: https://api.example.com/test-data
  headers:
    Authorization: "Bearer {{ token }}"
```

### Cross-Browser Testing

Run same test across multiple browsers:

```yaml
browsers:
  - chrome
  - firefox
  - edge
  - safari

parallel: true
```

### Visual Testing

Compare screenshots across runs:

```yaml
steps:
  - action: screenshot
    name: homepage
    
  - action: compareVisual
    baseline: homepage
    threshold: 0.1  # 10% difference allowed
```

### API Testing Integration

Combine UI and API tests:

```yaml
steps:
  # API call
  - action: api.request
    method: POST
    url: https://api.example.com/users
    body:
      name: "Test User"
      
  # Verify in UI
  - action: navigate
    url: https://example.com/users
    
  - action: expect
    selector: ".user-list"
    text: "Test User"
```

### Custom Actions

Create reusable custom actions:

```yaml
customActions:
  login:
    parameters:
      - username
      - password
    steps:
      - action: navigate
        url: "${baseUrl}/login"
      - action: fill
        selector: "#username"
        value: "{{ username }}"
      - action: fill
        selector: "#password"
        value: "{{ password }}"
      - action: click
        selector: "button[type='submit']"

steps:
  - action: custom.login
    username: "testuser"
    password: "testpass"
```

### Environment Management

Switch between environments easily:

```yaml
environments:
  dev:
    baseUrl: https://dev.example.com
    apiUrl: https://api.dev.example.com
    
  staging:
    baseUrl: https://staging.example.com
    apiUrl: https://api.staging.example.com
    
  production:
    baseUrl: https://example.com
    apiUrl: https://api.example.com
```

### Parallel Execution

Run tests in parallel for faster execution:

```yaml
parallel:
  maxWorkers: 4
  strategy: "distribute"  # or "duplicate"
  
groups:
  - name: "Critical"
    tests: ["login", "checkout", "payment"]
    
  - name: "Secondary"
    tests: ["profile", "settings", "help"]
```

---

For more help, visit our [documentation site](https://docs.hybridqa.io) or contact support. 