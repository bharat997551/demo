# Hybrid QA Deployment Checklist for Windows Administrators

This checklist guides IT administrators through deploying Hybrid QA in enterprise Windows environments.

## Pre-Deployment Requirements

### System Requirements
- [ ] **Operating System**: Windows 10 (1909+) or Windows 11
- [ ] **Architecture**: x64 (64-bit)
- [ ] **RAM**: Minimum 8GB, Recommended 16GB
- [ ] **Storage**: 5GB free space (plus space for test artifacts)
- [ ] **Display**: 1920x1080 or higher recommended
- [ ] **.NET Framework**: 4.7.2 or higher
- [ ] **Visual C++ Redistributables**: 2015-2022 (x64)

### Network Requirements
- [ ] **Internet Access** (for initial setup):
  - `registry.npmjs.org` (npm packages)
  - `pypi.org` (Python packages)
  - `playwright.azureedge.net` (Browser downloads)
  - `github.com` (Updates and resources)
- [ ] **Internal Ports** (localhost only):
  - `3001` - Orchestrator API
  - `3002` - WebSocket communication
  - `8001` - Web automation engine
  - `8002` - Desktop automation engine
  - `8004` - API testing engine
- [ ] **Firewall**: Configure Windows Defender Firewall exceptions

### User Permissions
- [ ] **Installation**: Local Administrator (one-time)
- [ ] **Runtime**: Standard User (daily use)
- [ ] **Special Permissions**:
  - Read/Write to `%APPDATA%\hybrid-qa`
  - Execute from `%PROGRAMFILES%\Hybrid QA`
  - UI Automation permissions for desktop testing

## Deployment Methods

### Method 1: Interactive Installation (Single Machine)
```powershell
# 1. Download installer
Invoke-WebRequest -Uri "https://releases.hybridqa.io/latest/HybridQA-Setup.exe" `
                  -OutFile "HybridQA-Setup.exe"

# 2. Verify installer signature (if signed)
Get-AuthenticodeSignature "HybridQA-Setup.exe"

# 3. Run installer
Start-Process "HybridQA-Setup.exe" -Wait

# 4. Verify installation
Test-Path "C:\Program Files\Hybrid QA\Hybrid QA.exe"
```

### Method 2: Silent Installation (Mass Deployment)
```powershell
# Silent install with logging
Start-Process "HybridQA-Setup.exe" -ArgumentList "/S", "/D=C:\Program Files\Hybrid QA" -Wait

# Or using msiexec if MSI available
msiexec /i "HybridQA.msi" /qn /l*v "install.log" `
        INSTALLDIR="C:\Program Files\Hybrid QA" `
        ADDLOCAL=ALL
```

### Method 3: SCCM/Intune Deployment
```xml
<!-- SCCM Application Detection Method -->
<DetectionMethod>
  <File>
    <Path>C:\Program Files\Hybrid QA</Path>
    <FileName>Hybrid QA.exe</FileName>
    <Version>1.0.0.0</Version>
  </File>
</DetectionMethod>

<!-- Installation Command -->
<InstallCommand>HybridQA-Setup.exe /S</InstallCommand>
<UninstallCommand>C:\Program Files\Hybrid QA\Uninstall.exe /S</UninstallCommand>
```

## Post-Installation Configuration

### 1. First-Run Setup Automation
```powershell
# Create first-run configuration
$config = @{
    acceptEula = $true
    downloadBrowsers = $true
    setupPython = $true
    telemetry = @{
        enabled = $false
        crashReports = $false
    }
}

$configPath = "$env:APPDATA\hybrid-qa\first-run-config.json"
New-Item -Path (Split-Path $configPath) -ItemType Directory -Force
$config | ConvertTo-Json | Set-Content $configPath
```

### 2. Browser Installation
```powershell
# Pre-install Playwright browsers for all users
$env:PLAYWRIGHT_BROWSERS_PATH = "C:\ProgramData\hybrid-qa\browsers"
New-Item -Path $env:PLAYWRIGHT_BROWSERS_PATH -ItemType Directory -Force

# Install browsers
Set-Location "C:\Program Files\Hybrid QA"
.\node_modules\.bin\playwright install chromium firefox webkit
```

### 3. Python Environment Setup
```powershell
# Setup Python virtual environments
$pythonPath = "C:\Program Files\Hybrid QA\python\python.exe"

# Desktop engine
& $pythonPath -m venv "C:\Program Files\Hybrid QA\engines\desktop\venv"
& "C:\Program Files\Hybrid QA\engines\desktop\venv\Scripts\pip.exe" `
    install -r "C:\Program Files\Hybrid QA\engines\desktop\requirements.txt"

# Mainframe engine (if needed)
& $pythonPath -m venv "C:\Program Files\Hybrid QA\engines\mainframe\venv"
& "C:\Program Files\Hybrid QA\engines\mainframe\venv\Scripts\pip.exe" `
    install -r "C:\Program Files\Hybrid QA\engines\mainframe\requirements.txt"
```

### 4. Security Configuration

#### Windows Defender Exclusions
```powershell
# Add folder exclusions
Add-MpPreference -ExclusionPath "C:\Program Files\Hybrid QA"
Add-MpPreference -ExclusionPath "$env:APPDATA\hybrid-qa"
Add-MpPreference -ExclusionPath "C:\ProgramData\hybrid-qa"

# Add process exclusions
Add-MpPreference -ExclusionProcess "Hybrid QA.exe"
Add-MpPreference -ExclusionProcess "node.exe"
Add-MpPreference -ExclusionProcess "python.exe"
```

#### AppLocker Rules (if applicable)
```xml
<AppLockerPolicy Version="1">
  <RuleCollection Type="Exe">
    <FilePublisherRule Id="hybrid-qa-exe" Name="Allow Hybrid QA" 
                       Description="Allow Hybrid QA execution" 
                       UserOrGroupSid="S-1-1-0" Action="Allow">
      <Conditions>
        <FilePublisherCondition PublisherName="O=Hybrid QA Inc" 
                                ProductName="Hybrid QA" 
                                BinaryName="*" />
      </Conditions>
    </FilePublisherRule>
  </RuleCollection>
</AppLockerPolicy>
```

## Group Policy Configuration

### 1. Create GPO for Hybrid QA
```powershell
# Create new GPO
New-GPO -Name "Hybrid QA Configuration"

# Link to appropriate OU
New-GPLink -Name "Hybrid QA Configuration" -Target "OU=QA,DC=company,DC=com"
```

### 2. Registry Settings
```reg
Windows Registry Editor Version 5.00

[HKEY_LOCAL_MACHINE\SOFTWARE\Policies\HybridQA]
"InstallPath"="C:\\Program Files\\Hybrid QA"
"AutoUpdate"=dword:00000000
"TelemetryEnabled"=dword:00000000
"DefaultLogLevel"="INFO"
"MaxLogSizeMB"=dword:00000064

[HKEY_LOCAL_MACHINE\SOFTWARE\Policies\HybridQA\Proxy]
"UseSystemProxy"=dword:00000001
"ProxyServer"=""
"ProxyBypass"="localhost;127.0.0.1;*.local"
```

### 3. User Environment Variables
```powershell
# Set via GPO Preferences
[Environment]::SetEnvironmentVariable("HYBRID_QA_HOME", "C:\Program Files\Hybrid QA", "Machine")
[Environment]::SetEnvironmentVariable("PLAYWRIGHT_BROWSERS_PATH", "C:\ProgramData\hybrid-qa\browsers", "Machine")
```

## Service Account Setup (Optional)

For automated test execution:

```powershell
# Create service account
New-ADUser -Name "svc_hybridqa" `
           -Description "Hybrid QA Service Account" `
           -PasswordNeverExpires $true `
           -CannotChangePassword $true

# Grant necessary permissions
$acl = Get-Acl "C:\Program Files\Hybrid QA"
$permission = "DOMAIN\svc_hybridqa","ReadAndExecute","Allow"
$accessRule = New-Object System.Security.AccessControl.FileSystemAccessRule $permission
$acl.SetAccessRule($accessRule)
Set-Acl "C:\Program Files\Hybrid QA" $acl

# Add to necessary groups
Add-ADGroupMember -Identity "Remote Desktop Users" -Members "svc_hybridqa"
```

## Monitoring and Logging

### 1. Event Log Configuration
```powershell
# Create custom event log
New-EventLog -LogName "Hybrid QA" -Source "HybridQA"

# Set log properties
Limit-EventLog -LogName "Hybrid QA" -MaximumSize 100MB -OverflowAction OverwriteAsNeeded
```

### 2. Performance Counters
```powershell
# Monitor key metrics
$counters = @(
    "\Process(Hybrid QA)\% Processor Time"
    "\Process(Hybrid QA)\Working Set"
    "\Process(Hybrid QA)\Handle Count"
)

# Create data collector set
$dcs = New-Object -COM Pla.DataCollectorSet
$dcs.DisplayName = "Hybrid QA Performance"
$dcs.Duration = 0
$dcs.add($counters)
$dcs.start()
```

## Validation Steps

### 1. Installation Verification
```powershell
# Run validation script
& "C:\Program Files\Hybrid QA\scripts\validate-installation.ps1"

# Check all components
Get-Service | Where-Object {$_.Name -like "*HybridQA*"}
Get-Process | Where-Object {$_.Name -like "*Hybrid QA*"}
Test-NetConnection -ComputerName localhost -Port 3001
```

### 2. Functionality Test
```powershell
# Launch application
Start-Process "C:\Program Files\Hybrid QA\Hybrid QA.exe"

# Wait for startup
Start-Sleep -Seconds 10

# Run smoke test
Invoke-RestMethod -Uri "http://localhost:3001/health" -Method GET
```

### 3. User Access Test
```powershell
# Test as standard user
runas /user:DOMAIN\testuser "C:\Program Files\Hybrid QA\Hybrid QA.exe"
```

## Rollback Plan

If deployment fails:

```powershell
# 1. Uninstall application
Start-Process "C:\Program Files\Hybrid QA\Uninstall.exe" -ArgumentList "/S" -Wait

# 2. Remove directories
Remove-Item -Path "C:\Program Files\Hybrid QA" -Recurse -Force
Remove-Item -Path "$env:APPDATA\hybrid-qa" -Recurse -Force
Remove-Item -Path "C:\ProgramData\hybrid-qa" -Recurse -Force

# 3. Remove registry entries
Remove-Item -Path "HKLM:\SOFTWARE\HybridQA" -Recurse -Force
Remove-Item -Path "HKCU:\SOFTWARE\HybridQA" -Recurse -Force

# 4. Remove firewall rules
Remove-NetFirewallRule -DisplayName "Hybrid QA*"

# 5. Remove event log
Remove-EventLog -LogName "Hybrid QA"
```

## Security Checklist

- [ ] Installer signed with valid certificate
- [ ] Installation directory permissions restricted
- [ ] User data encrypted at rest (DPAPI)
- [ ] No hardcoded credentials
- [ ] Secure communication (localhost only)
- [ ] Audit logging enabled
- [ ] Antivirus exclusions configured
- [ ] AppLocker/WDAC rules created
- [ ] Principle of least privilege enforced

## Support Information

### Logs Location
- Application Logs: `%APPDATA%\hybrid-qa\logs`
- Installation Logs: `%TEMP%\hybrid-qa-install.log`
- Event Viewer: Applications and Services Logs → Hybrid QA

### Registry Keys
- `HKLM\SOFTWARE\HybridQA` - Application settings
- `HKCU\SOFTWARE\HybridQA` - User preferences

### Contact
- Support Email: support@hybridqa.io
- Documentation: https://docs.hybridqa.io
- Enterprise Support: enterprise@hybridqa.io

## Sign-off

- [ ] All checklist items completed
- [ ] Validation tests passed
- [ ] Security review completed
- [ ] Rollback plan tested
- [ ] Documentation provided to users

**Deployed By**: _______________________  
**Date**: _______________________  
**Environment**: _______________________  
**Notes**: _______________________ 