# Hybrid QA Documentation

Welcome to the Hybrid QA documentation. This comprehensive guide covers everything you need to know about using and developing with the Hybrid QA test automation platform.

## 📚 Documentation Overview

### For Developers

- **[Developer README](../DEVELOPER_README.md)** - Complete guide for developers working on the Hybrid QA platform
  - Monorepo setup and structure
  - Development environment configuration
  - Debugging techniques
  - Contributing guidelines

### For Users

- **[User Manual](USER_MANUAL.md)** - Comprehensive guide for test automation users
  - Recording tests (Web & Desktop)
  - Building test flows
  - Using the AI Assistant
  - Interpreting test reports

### Sample Projects

Learn by example with our comprehensive sample projects:

1. **[Web Login & Shopping Cart](../samples/web-login-cart/README.md)**
   - E-commerce automation
   - User authentication flows
   - Shopping cart operations
   - Data-driven testing

2. **[Desktop Notepad Automation](../samples/desktop-notepad/README.md)**
   - Windows application testing
   - Keyboard and menu automation
   - File operations
   - Multi-window handling

3. **[Mainframe Mock Testing](../samples/mainframe-mock/README.md)**
   - 3270 terminal automation
   - CICS transactions
   - Batch job submission
   - Screen navigation

4. **[API CRUD Operations](../samples/api-crud-mock/README.md)**
   - REST API testing
   - GraphQL mutations
   - gRPC services
   - WebSocket real-time testing

5. **[Combined E2E Flow](../samples/e2e-combined-flow/README.md)**
   - Multi-engine orchestration
   - Complex business workflows
   - Cross-platform validation
   - Comprehensive reporting

## 🚀 Quick Start Guides

### First Time Setup

1. **Installation**
   ```bash
   # Clone repository
   git clone <repository-url>
   cd hybrid-qa
   
   # Install dependencies
   pnpm install
   
   # Setup Python engines
   cd packages/engine-desktop && python -m venv venv
   cd packages/engine-mainframe && python -m venv venv
   
   # Install Playwright browsers
   pnpm --filter engine-web install:browsers
   ```

2. **Start Development**
   ```bash
   # Start all services
   pnpm dev
   
   # Access the desktop app
   # The Electron app will launch automatically
   ```

3. **Run Your First Test**
   - Open the desktop app
   - Click "New Test"
   - Choose "Record Web"
   - Enter a URL and start recording!

### Creating Your First Test

1. **Web Test Example**
   ```yaml
   name: My First Web Test
   engine: web
   steps:
     - action: navigate
       url: "https://example.com"
     - action: click
       selector: "button.login"
     - action: fill
       selector: "#username"
       value: "testuser"
   ```

2. **Desktop Test Example**
   ```yaml
   name: My First Desktop Test
   engine: desktop
   steps:
     - action: launch
       application: "notepad.exe"
     - action: type
       text: "Hello, Hybrid QA!"
     - action: keyboard
       keys: "Ctrl+S"
   ```

## 📖 Core Concepts

### Test Engines

Hybrid QA supports multiple test engines:

- **Web Engine** - Powered by Playwright for browser automation
- **Desktop Engine** - Windows automation using pywinauto
- **Mainframe Engine** - 3270 terminal emulation with s3270
- **API Engine** - HTTP/GraphQL/gRPC testing

### Test Structure

Tests in Hybrid QA follow a consistent structure:

```yaml
name: Test Name
description: What this test does
engine: web|desktop|mainframe|api
tags: [tag1, tag2]

variables:
  key: value

steps:
  - action: actionType
    parameter: value

assertions:
  - type: assertion
    expected: value
```

### Key Features

1. **Visual Flow Builder** - Drag-and-drop test creation
2. **Self-Healing Locators** - Automatic selector updates
3. **AI Assistant** - Natural language to test steps
4. **Cross-Engine Testing** - Combine multiple engines in one test
5. **Comprehensive Reporting** - Detailed results with artifacts

## 🛠️ Advanced Topics

### Custom Actions

Create reusable custom actions:

```yaml
customActions:
  login:
    parameters: [username, password]
    steps:
      - action: fill
        selector: "#username"
        value: "{{ username }}"
      - action: fill
        selector: "#password"
        value: "{{ password }}"
      - action: click
        selector: "button[type='submit']"
```

### Data-Driven Testing

Use external data sources:

```yaml
data:
  source: ./test-data/users.csv
  
forEach: data
steps:
  - action: fill
    selector: "#email"
    value: "{{ item.email }}"
```

### Environment Management

Switch between environments easily:

```yaml
environments:
  dev:
    baseUrl: https://dev.example.com
  staging:
    baseUrl: https://staging.example.com
  production:
    baseUrl: https://example.com
```

## 🔧 Configuration

### Project Configuration

Each project includes:

- `config/` - Environment and engine settings
- `tests/` - Test files organized by feature
- `data/` - Test data files
- `page-objects/` - Reusable page definitions
- `reports/` - Generated test reports

### Global Settings

Configure global settings in the desktop app:

1. **Preferences** → **Settings**
2. Configure:
   - Default browser
   - Screenshot behavior
   - Report formats
   - AI provider settings

## 📊 Reporting & Analytics

### Report Types

1. **Test Results** - Pass/fail status with details
2. **Screenshots** - Visual evidence
3. **Performance Metrics** - Execution times
4. **Trend Analysis** - Historical performance
5. **Coverage Reports** - Test coverage metrics

### Export Options

- HTML - Interactive web reports
- PDF - Printable documents
- JSON - Raw data export
- Excel - Management summaries

## 🤝 Integration

### CI/CD Integration

Hybrid QA integrates with popular CI/CD platforms:

- GitHub Actions
- Jenkins
- GitLab CI
- Azure DevOps
- CircleCI

### Example GitHub Actions

```yaml
- name: Run Hybrid QA Tests
  uses: hybrid-qa/action@v1
  with:
    tests: ./tests
    environment: staging
    report: junit
```

## 🐛 Troubleshooting

### Common Issues

1. **"Engine not found"**
   - Ensure all engines are installed
   - Check PATH variables
   - Verify Python virtual environments

2. **"Element not found"**
   - Check selector accuracy
   - Add appropriate waits
   - Use self-healing locators

3. **"Connection timeout"**
   - Verify network connectivity
   - Check firewall settings
   - Ensure services are running

### Getting Help

- Check the [FAQ](FAQ.md)
- Search [GitHub Issues](https://github.com/hybrid-qa/issues)
- Join our [Discord Community](https://discord.gg/hybrid-qa)
- Contact [Support](mailto:support@hybrid-qa.io)

## 📚 Additional Resources

### Tutorials

- [Video: Getting Started with Hybrid QA](https://youtube.com/hybrid-qa/getting-started)
- [Blog: Best Practices for Test Automation](https://blog.hybrid-qa.io/best-practices)
- [Webinar: Advanced Testing Techniques](https://hybrid-qa.io/webinars)

### API Reference

- [DSL Reference](api/dsl-reference.md)
- [Engine APIs](api/engine-apis.md)
- [Plugin Development](api/plugin-development.md)

### Community

- [Discord Server](https://discord.gg/hybrid-qa)
- [GitHub Discussions](https://github.com/hybrid-qa/discussions)
- [Stack Overflow Tag](https://stackoverflow.com/questions/tagged/hybrid-qa)

## 🔄 Version History

See [CHANGELOG.md](../CHANGELOG.md) for version history and updates.

## 📄 License

Hybrid QA is licensed under the MIT License. See [LICENSE](../LICENSE) for details.

---

**Need more help?** Don't hesitate to reach out to our community or support team. We're here to help you succeed with test automation! 