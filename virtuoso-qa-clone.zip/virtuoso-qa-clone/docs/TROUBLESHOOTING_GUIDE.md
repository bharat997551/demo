# Hybrid QA Troubleshooting Guide

This guide helps resolve common issues with Hybrid QA installation and operation.

## Quick Diagnostics

Run this PowerShell script for a quick system check:

```powershell
# Quick diagnostic script
Write-Host "=== Hybrid QA Diagnostics ===" -ForegroundColor Cyan

# Check installation
$installed = Test-Path "C:\Program Files\Hybrid QA\Hybrid QA.exe"
Write-Host "Installed: $installed" -ForegroundColor $(if($installed){"Green"}else{"Red"})

# Check ports
$ports = @(3001, 3002, 8001, 8002, 8004)
foreach ($port in $ports) {
    $listener = Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue
    $status = if($listener) {"BLOCKED"} else {"AVAILABLE"}
    $color = if($listener) {"Red"} else {"Green"}
    Write-Host "Port $port : $status" -ForegroundColor $color
}

# Check Python
try {
    $pythonVersion = python --version 2>&1
    Write-Host "Python: $pythonVersion" -ForegroundColor Green
} catch {
    Write-Host "Python: NOT FOUND" -ForegroundColor Red
}

# Check Node
try {
    $nodeVersion = node --version
    Write-Host "Node.js: $nodeVersion" -ForegroundColor Green
} catch {
    Write-Host "Node.js: NOT FOUND" -ForegroundColor Red
}
```

## Common Issues and Solutions

### 1. Playwright Browser Issues

#### Problem: "Playwright browsers not found"
```
Error: browserType.launch: Executable doesn't exist at C:\Users\...\chromium.exe
```

**Solution 1: Install browsers via UI**
1. Open Hybrid QA
2. Go to Settings → Environment
3. Click "Download Browsers"
4. Wait for completion

**Solution 2: Manual installation**
```powershell
# Navigate to app directory
cd "C:\Program Files\Hybrid QA"

# Install all browsers
.\node_modules\.bin\playwright install

# Or specific browser
.\node_modules\.bin\playwright install chromium
```

**Solution 3: Offline installation**
```powershell
# If behind proxy/firewall, download offline package
# From internet-connected machine:
npx playwright install --dry-run

# Copy browser archives to target machine
# Then install from local files:
$env:PLAYWRIGHT_DOWNLOAD_CONNECTION_TIMEOUT = "120000"
.\node_modules\.bin\playwright install --with-deps
```

#### Problem: "Browser launch timeout"
```
Error: Timeout 30000ms exceeded
```

**Solutions:**
1. Increase timeout in test settings
2. Check Windows Defender exclusions
3. Disable sandbox mode (testing only):
   ```yaml
   config:
     launchOptions:
       args: ['--no-sandbox', '--disable-setuid-sandbox']
   ```

### 2. Python Virtual Environment Issues

#### Problem: "Python venv activation fails"
```
Error: The system cannot find the path specified
\venv\Scripts\activate : The term is not recognized
```

**Solution 1: Recreate venv**
```powershell
# Remove corrupted venv
Remove-Item "C:\Program Files\Hybrid QA\engines\desktop\venv" -Recurse -Force

# Recreate
$python = "C:\Program Files\Hybrid QA\python\python.exe"
& $python -m venv "C:\Program Files\Hybrid QA\engines\desktop\venv"

# Install requirements
& "C:\Program Files\Hybrid QA\engines\desktop\venv\Scripts\pip.exe" install -r requirements.txt
```

**Solution 2: Fix execution policy**
```powershell
# Check current policy
Get-ExecutionPolicy

# If Restricted, temporarily allow
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser

# Or bypass for single session
powershell -ExecutionPolicy Bypass -File "activate.ps1"
```

#### Problem: "pip install fails with SSL error"
```
Error: Could not fetch URL https://pypi.org/simple/pip/: 
There was a problem confirming the ssl certificate
```

**Solutions:**
1. **Corporate proxy setup:**
   ```powershell
   # Set proxy for pip
   $env:HTTP_PROXY = "http://proxy.company.com:8080"
   $env:HTTPS_PROXY = "http://proxy.company.com:8080"
   
   # Or in pip config
   pip config set global.proxy http://proxy.company.com:8080
   ```

2. **Trusted host (temporary):**
   ```powershell
   pip install --trusted-host pypi.org --trusted-host files.pythonhosted.org package_name
   ```

3. **Offline installation:**
   ```powershell
   # Download wheels on internet machine
   pip download -r requirements.txt -d offline_packages
   
   # Install from local
   pip install --no-index --find-links offline_packages -r requirements.txt
   ```

### 3. Permission Errors

#### Problem: "Access denied to %APPDATA%\hybrid-qa"
```
Error: EACCES: permission denied, mkdir 'C:\Users\user\AppData\Roaming\hybrid-qa'
```

**Solution 1: Fix folder permissions**
```powershell
# Take ownership
takeown /f "$env:APPDATA\hybrid-qa" /r /d y

# Grant full permissions
icacls "$env:APPDATA\hybrid-qa" /grant "${env:USERNAME}:(OI)(CI)F" /T

# Reset permissions
icacls "$env:APPDATA\hybrid-qa" /reset /T
```

**Solution 2: Run as administrator (once)**
```powershell
# Right-click Hybrid QA → Run as administrator
# This creates folders with correct permissions
# Then run normally as standard user
```

#### Problem: "Cannot write to Program Files"
```
Error: EPERM: operation not permitted, open 'C:\Program Files\Hybrid QA\...'
```

**Solution:** Application should not write to Program Files. Check configuration:
```powershell
# Ensure app uses correct paths
$env:HYBRID_QA_DATA = "$env:APPDATA\hybrid-qa"
$env:HYBRID_QA_TEMP = "$env:TEMP\hybrid-qa"
```

### 4. Desktop Automation Issues

#### Problem: "Window not found" during desktop recording
```
Error: Could not find window with title: Notepad
```

**Solutions:**
1. **Ensure window is visible:**
   ```python
   # Add wait time
   action: waitForWindow
   title: "Notepad"
   timeout: 10000
   ```

2. **Use partial title match:**
   ```python
   window_contains: "Notepad"  # Instead of exact match
   ```

3. **Enable CV fallback:**
   ```yaml
   config:
     cv_fallback: true
     cv_confidence: 0.8
   ```

#### Problem: "pywinauto backend error"
```
Error: Can only use Win32 backend on Windows
```

**Solution:** Ensure correct backend:
```python
# In test config
config:
  backend: "win32"  # or "uia" for modern apps
```

### 5. Network and Port Issues

#### Problem: "Port already in use"
```
Error: listen EADDRINUSE: address already in use :::3001
```

**Solution 1: Find and stop conflicting process**
```powershell
# Find process using port
netstat -ano | findstr :3001
# Returns: TCP    0.0.0.0:3001    0.0.0.0:0    LISTENING    12345

# Stop process
Stop-Process -Id 12345 -Force
```

**Solution 2: Change port configuration**
```json
// In settings.json
{
  "orchestrator": {
    "port": 3101,  // Alternative port
    "wsPort": 3102
  }
}
```

#### Problem: "WebSocket connection failed"
```
Error: WebSocket connection to 'ws://localhost:3002' failed
```

**Solutions:**
1. Check Windows Firewall
2. Ensure orchestrator is running
3. Check proxy settings:
   ```powershell
   # Bypass proxy for localhost
   netsh winhttp set proxy proxy-server="http://proxy:8080" bypass-list="localhost;127.0.0.1"
   ```

### 6. Database Issues

#### Problem: "Database locked"
```
Error: SQLITE_BUSY: database is locked
```

**Solutions:**
1. **Close other instances:**
   ```powershell
   # Find all Hybrid QA processes
   Get-Process | Where-Object {$_.Name -like "*Hybrid*QA*"} | Stop-Process -Force
   ```

2. **Remove lock file:**
   ```powershell
   Remove-Item "$env:APPDATA\hybrid-qa\database.sqlite-journal" -ErrorAction SilentlyContinue
   ```

3. **Repair database:**
   ```powershell
   # Backup first
   Copy-Item "$env:APPDATA\hybrid-qa\database.sqlite" "$env:APPDATA\hybrid-qa\database.backup"
   
   # Run integrity check
   sqlite3 "$env:APPDATA\hybrid-qa\database.sqlite" "PRAGMA integrity_check;"
   ```

### 7. UI/Electron Issues

#### Problem: "White screen on launch"
```
Application window is blank/white
```

**Solutions:**
1. **Clear cache:**
   ```powershell
   Remove-Item "$env:APPDATA\hybrid-qa\Cache" -Recurse -Force
   Remove-Item "$env:APPDATA\hybrid-qa\GPUCache" -Recurse -Force
   ```

2. **Disable GPU acceleration:**
   ```powershell
   # Add to shortcut target
   "C:\Program Files\Hybrid QA\Hybrid QA.exe" --disable-gpu
   ```

3. **Reset settings:**
   ```powershell
   Remove-Item "$env:APPDATA\hybrid-qa\config.json" -Force
   ```

#### Problem: "Application crashes on startup"
```
Application starts then immediately closes
```

**Diagnostic steps:**
1. **Check logs:**
   ```powershell
   Get-Content "$env:APPDATA\hybrid-qa\logs\main.log" -Tail 50
   ```

2. **Run in debug mode:**
   ```powershell
   $env:ELECTRON_ENABLE_LOGGING = "true"
   $env:NODE_ENV = "development"
   & "C:\Program Files\Hybrid QA\Hybrid QA.exe"
   ```

3. **Check Event Viewer:**
   - Windows Logs → Application
   - Look for errors from "Hybrid QA"

### 8. Performance Issues

#### Problem: "Tests run slowly"
**Diagnostics:**
```powershell
# Check system resources
Get-Process "Hybrid QA" | Select-Object CPU, WS, PM, VM

# Check disk I/O
Get-Counter "\Process(Hybrid QA)\IO Data Bytes/sec"
```

**Solutions:**
1. **Optimize test configuration:**
   ```yaml
   config:
     headless: true  # Faster than headed
     video: false    # Disable if not needed
     trace: false    # Disable tracing
   ```

2. **Increase memory limit:**
   ```powershell
   # Set Node.js memory limit
   $env:NODE_OPTIONS = "--max-old-space-size=4096"
   ```

3. **Clean up old data:**
   ```powershell
   # Remove old artifacts
   Get-ChildItem "$env:APPDATA\hybrid-qa\artifacts" -Recurse | 
     Where-Object {$_.LastWriteTime -lt (Get-Date).AddDays(-7)} | 
     Remove-Item -Force
   ```

## Advanced Diagnostics

### Enable Debug Logging
```javascript
// In settings
{
  "logging": {
    "level": "debug",
    "console": true,
    "file": true
  }
}
```

### Network Trace
```powershell
# Capture network traffic
netsh trace start capture=yes tracefile=hybrid-qa.etl provider=Microsoft-Windows-WinINet
# Reproduce issue
netsh trace stop
```

### Process Monitor
1. Download Process Monitor from Microsoft
2. Set filter: Process Name contains "Hybrid QA"
3. Capture during issue reproduction
4. Look for ACCESS DENIED, FILE NOT FOUND

## Getting Help

### Collect Diagnostic Bundle
```powershell
# Run diagnostic collection script
& "C:\Program Files\Hybrid QA\scripts\collect-diagnostics.ps1"

# Creates: hybrid-qa-diagnostics-{timestamp}.zip
# Contains: logs, config, system info
```

### Information to Provide
When reporting issues, include:
1. Error message (exact text)
2. Steps to reproduce
3. Test file (if applicable)
4. Diagnostic bundle
5. Windows version
6. Antivirus software
7. Proxy/firewall configuration

### Support Channels
- Documentation: https://docs.hybridqa.io
- Community Forum: https://community.hybridqa.io
- Email Support: support@hybridqa.io
- Enterprise Support: enterprise@hybridqa.io

## Preventive Measures

### Regular Maintenance
```powershell
# Weekly cleanup script
$hybridQAData = "$env:APPDATA\hybrid-qa"

# Clean old logs (>30 days)
Get-ChildItem "$hybridQAData\logs" -Filter "*.log" | 
    Where-Object {$_.LastWriteTime -lt (Get-Date).AddDays(-30)} | 
    Remove-Item

# Clean old artifacts (>7 days)
Get-ChildItem "$hybridQAData\artifacts" -Recurse | 
    Where-Object {$_.LastWriteTime -lt (Get-Date).AddDays(-7)} | 
    Remove-Item -Force

# Compact database
sqlite3 "$hybridQAData\database.sqlite" "VACUUM;"

Write-Host "Maintenance completed" -ForegroundColor Green
```

### Health Check Script
```powershell
# Save as Check-HybridQAHealth.ps1
param([switch]$Detailed)

$issues = @()

# Check services
if (-not (Test-Path "C:\Program Files\Hybrid QA\Hybrid QA.exe")) {
    $issues += "Application not installed"
}

# Check ports
$ports = @(3001, 3002, 8001, 8002, 8004)
foreach ($port in $ports) {
    if (Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue) {
        $issues += "Port $port is blocked"
    }
}

# Check disk space
$drive = (Get-Item $env:APPDATA).PSDrive
if ($drive.Free -lt 1GB) {
    $issues += "Low disk space: $([Math]::Round($drive.Free/1GB, 2))GB free"
}

# Report
if ($issues.Count -eq 0) {
    Write-Host "✓ All systems healthy" -ForegroundColor Green
} else {
    Write-Host "✗ Issues found:" -ForegroundColor Red
    $issues | ForEach-Object { Write-Host "  - $_" -ForegroundColor Yellow }
}

if ($Detailed) {
    # Additional checks...
}
``` 