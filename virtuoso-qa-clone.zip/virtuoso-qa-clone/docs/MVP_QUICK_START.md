# MVP Quick Start Guide

This guide helps you quickly validate that the Hybrid QA MVP meets all acceptance criteria.

## 🚀 5-Minute Quick Test

Follow these steps to validate core functionality in under 5 minutes:

### 1. Install and Launch (1 minute)
```powershell
# Run installer
.\HybridQA-Setup-1.0.0.exe

# Launch from desktop shortcut
# Complete first-run wizard (click "Fix All")
```

### 2. Web Test (1 minute)
1. Click **"New Test"** → **"Web"**
2. Click **"Start Recording"**
3. Navigate to: `https://demo.playwright.dev/todomvc`
4. Type: "Buy milk" → Press Enter
5. Type: "Walk dog" → Press Enter  
6. Click first item's checkbox
7. Click **"Stop Recording"**
8. Click **"Run"** → Verify green checkmarks

### 3. Desktop Test (1 minute)
1. Click **"New Test"** → **"Desktop"**
2. Click **"Start Recording"**
3. Open Notepad (Win+R → notepad → Enter)
4. Type: "MVP Test Passed!"
5. Press Ctrl+S
6. Type filename: "mvp_test.txt"
7. Click Save, then close Notepad
8. Click **"Stop Recording"**
9. Click **"Run"** → Verify file created

### 4. API Test (1 minute)
1. Click **"New Test"** → **"API"**
2. Set Method: **GET**
3. Set URL: `https://jsonplaceholder.typicode.com/users/1`
4. Add Assertion: Status Code = 200
5. Click **"Save"**
6. Click **"Run"** → Verify green checkmark

### 5. Combined Flow (1 minute)
1. Click **"Flow Builder"**
2. Drag your 3 tests onto canvas
3. Connect: Web → Desktop → API
4. Click **"Run Flow"**
5. Watch all 3 execute in sequence
6. Verify all show green status

**✅ If all steps completed successfully, MVP criteria are met!**

## 📋 Detailed Test Scenarios

### Scenario 1: E-Commerce Login Test

**Objective**: Validate web recording with form interactions

```yaml
Test: E-Commerce Login
URL: https://demo.playwright.dev/todomvc
Steps:
1. Record navigation
2. Record text input
3. Record button clicks  
4. Add assertions
5. Run headless
Expected: All steps pass, screenshots captured
```

### Scenario 2: Notepad Report Generation

**Objective**: Validate desktop automation with file operations

```yaml
Test: Generate Report
App: notepad.exe
Steps:
1. Launch Notepad
2. Type multi-line report
3. Save with timestamp
4. Verify file exists
5. Close application
Expected: File created, content correct
```

### Scenario 3: REST API CRUD

**Objective**: Validate API testing with all HTTP methods

```yaml
Test: User Management API
Base URL: https://jsonplaceholder.typicode.com
Steps:
1. GET /users (list)
2. POST /users (create)
3. PUT /users/1 (update)
4. DELETE /users/1
Expected: Correct status codes, response validation
```

### Scenario 4: Multi-Engine Workflow

**Objective**: Validate data flow between engines

```yaml
Flow: Login → Export → Verify
Nodes:
1. Web: Login and get token
2. Desktop: Export data using token
3. API: Verify export completed
Expected: Data passes correctly, sequential execution
```

## 🔍 What to Look For

### ✅ Good Signs
- Tests record in < 30 seconds
- Replay works first time
- Clear status indicators
- Helpful error messages
- Artifacts accessible
- Smooth UI experience

### ⚠️ Warning Signs  
- Recording misses actions
- Replay fails randomly
- Unclear error messages
- UI freezes or lags
- Missing artifacts
- Memory leaks

### ❌ Blocking Issues
- Installer fails
- App won't launch
- Recording doesn't work
- Tests won't run
- Data loss
- Crashes

## 🛠️ Troubleshooting

### Issue: "Playwright browsers not found"
**Fix**: In first-run wizard, click "Download Browsers"

### Issue: "Desktop recording not working"
**Fix**: Run as Administrator once, then normal user

### Issue: "API tests timeout"
**Fix**: Check internet connection and firewall

### Issue: "Flow builder is blank"
**Fix**: Refresh view or restart app

### Issue: "Cannot save tests"
**Fix**: Check `%APPDATA%\hybrid-qa` permissions

## 📊 Performance Benchmarks

Acceptable performance for MVP:

| Operation | Target Time |
|-----------|------------|
| App Launch | < 5 seconds |
| Start Recording | < 2 seconds |
| Simple Test Execution | < 10 seconds |
| Flow with 3 Nodes | < 30 seconds |
| View Results | Instant |
| Export Artifacts | < 5 seconds |

## 🎯 MVP Success Metrics

The MVP is successful if:

1. **Installation**: ✅ Installs on clean Windows 10/11
2. **Recording**: ✅ Can record all 3 engine types
3. **Replay**: ✅ Tests replay successfully
4. **Artifacts**: ✅ Screenshots/logs accessible
5. **Flow Builder**: ✅ Multi-engine flows work
6. **Stability**: ✅ No crashes in normal use
7. **Performance**: ✅ Meets timing targets
8. **Usability**: ✅ Intuitive for new users

## 📝 Feedback Template

After testing, provide feedback using this template:

```
MVP Test Report
===============
Date: [DATE]
Tester: [NAME]
Version: [VERSION]

Overall Result: [ ] PASS [ ] FAIL

Working Features:
- [List what worked well]

Issues Found:
- [List any problems]

Suggestions:
- [List improvements]

Would you use this tool? [ ] Yes [ ] No
Why: [Your reason]
```

## 🚦 Go/No-Go Decision

**GO Criteria** (All must be YES):
- [ ] Installs without issues
- [ ] Records and replays web test
- [ ] Records and replays desktop test  
- [ ] Executes API test with assertions
- [ ] Flow builder combines engines
- [ ] No data loss bugs
- [ ] Performance acceptable

**NO-GO if any are YES**:
- [ ] Installation fails on clean system
- [ ] Cannot record basic tests
- [ ] Tests fail to replay
- [ ] Flow builder doesn't work
- [ ] Frequent crashes
- [ ] Data corruption
- [ ] Security vulnerabilities

---

**Thank you for validating the Hybrid QA MVP!** 🎉 