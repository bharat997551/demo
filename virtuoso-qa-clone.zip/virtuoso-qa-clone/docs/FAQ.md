# Frequently Asked Questions (FAQ)

## General Questions

### What is Hybrid QA?

Hybrid QA is a comprehensive test automation platform that supports testing across web, desktop, mainframe, and API applications. It provides a unified interface for creating, managing, and executing automated tests across different technologies.

### What platforms does Hybrid QA support?

- **Operating Systems**: Windows 10/11 (full support), macOS and Linux (limited desktop automation)
- **Web Browsers**: Chrome, Firefox, Edge, Safari
- **Desktop Apps**: Windows applications (via UI Automation and Win32 APIs)
- **Mainframe**: IBM 3270 terminal emulation
- **APIs**: REST, GraphQL, gRPC, WebSocket

### Do I need programming knowledge to use Hybrid QA?

No! Hybrid QA offers multiple ways to create tests:
- **Record & Playback**: Record your actions and replay them
- **Visual Flow Builder**: Drag-and-drop interface
- **AI Assistant**: Describe tests in plain English
- **DSL/YAML**: Simple configuration format (for advanced users)

## Installation & Setup

### How do I install Hybrid QA?

1. Download the installer from our website
2. Run the installer (requires Administrator privileges on Windows)
3. Follow the setup wizard
4. The installer will automatically set up required dependencies

### What are the system requirements?

**Minimum Requirements:**
- Windows 10 version 1903 or later
- 8 GB RAM
- 2 GB free disk space
- .NET Framework 4.7.2 or later

**Recommended:**
- Windows 11
- 16 GB RAM
- SSD with 10 GB free space
- Multi-core processor

### Why does the installer need Administrator privileges?

Administrator privileges are required to:
- Install Windows services
- Set up Python environments
- Configure WinAppDriver for desktop automation
- Install browser drivers for web testing

## Testing Features

### Can I test applications on remote machines?

Yes! Hybrid QA supports:
- Remote desktop testing via RDP
- Selenium Grid for distributed web testing
- Remote mainframe connections
- API testing against any accessible endpoint

### How do self-healing locators work?

When a test fails due to a changed selector:
1. Hybrid QA analyzes the page/window
2. Finds similar elements using AI
3. Suggests alternative locators
4. You can accept or modify suggestions
5. Tests automatically use the healed locators

### Can I integrate with my existing test framework?

Yes, Hybrid QA provides:
- CLI for CI/CD integration
- REST API for programmatic control
- Export to common formats (JUnit XML, etc.)
- Plugin system for custom integrations

## Common Issues

### Why can't I record desktop applications?

Common causes:
1. **Application running as Administrator**: Run Hybrid QA as Administrator too
2. **UWP/Modern apps**: Enable Developer Mode in Windows Settings
3. **Protected applications**: Some security software blocks automation

### Web recording doesn't capture anything

Solutions:
1. Check browser extensions aren't blocking
2. Disable strict CSP headers in test environment
3. Ensure Playwright browsers are installed: `pnpm --filter engine-web install:browsers`

### Mainframe connection fails

Check:
1. Network connectivity to mainframe
2. Correct port (usually 23 or 992 for SSL)
3. Valid credentials
4. s3270 emulator is installed and in PATH

### API tests timeout

Common fixes:
1. Increase timeout in test configuration
2. Check API endpoint is accessible
3. Verify authentication credentials
4. Check for proxy/firewall issues

## Best Practices

### How should I organize my tests?

```
project/
├── tests/
│   ├── smoke/          # Quick validation tests
│   ├── regression/     # Comprehensive test suites
│   ├── e2e/           # End-to-end scenarios
│   └── performance/    # Load and performance tests
├── data/              # Test data files
├── page-objects/      # Reusable components
└── config/            # Environment settings
```

### How do I handle sensitive data?

1. Use environment variables for credentials
2. Enable secure storage (Windows DPAPI)
3. Mask sensitive values in logs/reports
4. Never commit credentials to version control

### What's the best way to handle dynamic content?

1. Use flexible locators (data-testid, aria-label)
2. Implement proper waits (not hard delays)
3. Use regular expressions for dynamic text
4. Leverage self-healing locators

## Advanced Topics

### Can I create custom actions?

Yes! Create custom actions in YAML:

```yaml
customActions:
  loginWithOAuth:
    parameters: [provider]
    steps:
      - action: click
        selector: ".login-{{ provider }}"
      - action: handleOAuthPopup
        provider: "{{ provider }}"
```

### How do I debug failing tests?

1. Run in debug mode: `hybridqa debug test.yaml`
2. Set breakpoints in the visual editor
3. Use step-through execution
4. Check screenshots and logs
5. Enable verbose logging

### Can I run tests in parallel?

Yes, configure parallel execution:

```yaml
parallel:
  workers: 4
  strategy: "distribute"  # or "duplicate"
```

### How do I generate test data?

Use built-in data generators:

```yaml
variables:
  email: "{{ faker.email }}"
  phone: "{{ faker.phone }}"
  uuid: "{{ uuid() }}"
  timestamp: "{{ now() }}"
```

## Licensing & Support

### Is Hybrid QA free to use?

Hybrid QA offers:
- **Community Edition**: Free for personal use
- **Professional**: For teams (subscription)
- **Enterprise**: Custom pricing with support

### How do I get support?

- **Community**: Discord, GitHub Discussions
- **Professional**: Email support, priority response
- **Enterprise**: Dedicated support, SLA

### Can I contribute to Hybrid QA?

Yes! We welcome contributions:
1. Fork the repository
2. Create a feature branch
3. Submit a pull request
4. See [CONTRIBUTING.md](../CONTRIBUTING.md)

## Security

### Is my test data secure?

- All credentials are encrypted at rest
- Uses Windows DPAPI for secure storage
- Network traffic uses TLS/SSL
- No telemetry without consent

### Can I use Hybrid QA in regulated environments?

Yes, Hybrid QA:
- Supports air-gapped installations
- Provides audit logs
- Allows custom security policies
- Complies with common standards

## Updates & Maintenance

### How do I update Hybrid QA?

1. Check for updates in the app
2. Download the latest version
3. Run the installer (preserves settings)
4. Or use auto-update if enabled

### Will updates break my tests?

We follow semantic versioning:
- **Patch updates**: Bug fixes only
- **Minor updates**: New features, backward compatible
- **Major updates**: May require test updates

### How often are updates released?

- **Patches**: As needed for critical fixes
- **Minor releases**: Monthly
- **Major releases**: Quarterly

---

**Don't see your question?** Ask on our [Discord](https://discord.gg/hybrid-qa) or create a [GitHub issue](https://github.com/hybrid-qa/issues)! 