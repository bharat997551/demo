# QA Team Onboarding Guide for Hybrid QA

Welcome to Hybrid QA! This guide will walk you through the platform's capabilities with hands-on exercises designed to build your skills progressively.

## Prerequisites

Before starting, ensure:
- [ ] Hybrid QA is installed and activated
- [ ] You have access to the sample applications in `samples/`
- [ ] Your user account has appropriate permissions
- [ ] You've completed the environment check (Help → Environment Check)

## Getting Started

### First Launch
1. Launch Hybrid QA from Start Menu or Desktop shortcut
2. Complete the first-run wizard if prompted
3. Navigate to Settings → About to verify version

### UI Overview
- **Left Sidebar**: Navigation between major features
  - Projects: Manage test projects
  - Flows: Visual test flow designer
  - Recorders: Web and desktop recording tools
  - Runs: Test execution history
  - Reports: Test results and analytics
- **Top Bar**: Quick actions and run controls
- **Central Pane**: Main workspace
- **Status Bar**: Connection status and notifications

## Exercise 1: Web Automation - Login Flow (30 minutes)

### Objective
Record and replay a web login test with assertions.

### Setup
1. Open the sample e-commerce site:
   ```
   cd samples/web-login-cart
   npm install
   npm start
   ```
2. Site will open at http://localhost:3000

### Steps

#### Part A: Recording
1. In Hybrid QA, click **Recorders** → **Web Recorder**
2. Click **Start Recording**
3. Enter URL: `http://localhost:3000`
4. Perform these actions:
   - Click "Login" button
   - Enter username: `testuser`
   - Enter password: `testpass123`
   - Click "Sign In"
   - Verify welcome message appears
5. Click **Stop Recording**
6. Save test as "Exercise1_WebLogin"

#### Part B: Adding Assertions
1. Open test in **Test Editor**
2. After login step, add assertion:
   ```yaml
   - action: web.expect
     selector: .welcome-message
     text: "Welcome, testuser!"
     timeout: 5000
   ```
3. Add screenshot capture:
   ```yaml
   - action: web.screenshot
     fullPage: true
     name: "login-success"
   ```

#### Part C: Replay
1. Click **Run Test**
2. Watch real-time execution
3. Review artifacts in run details

### Expected Outcomes
- [ ] Test runs successfully (green status)
- [ ] Screenshot shows logged-in state
- [ ] Assertion passes for welcome message
- [ ] Run time < 10 seconds
- [ ] All steps show in timeline with timings

### Common Issues & Solutions
- **Timeout on login**: Increase timeout in step properties
- **Element not found**: Use recorder's "Pick Element" to update selector
- **Assertion fails**: Check exact text including spaces

## Exercise 2: Desktop Automation - Notepad Flow (30 minutes)

### Objective
Automate Windows Notepad to create, edit, and save a file.

### Steps

#### Part A: Recording
1. Click **Recorders** → **Desktop Recorder**
2. Click **Start Recording**
3. Open Windows Notepad (Win+R, type `notepad`)
4. Perform these actions:
   - Type: "Hello from Hybrid QA!"
   - Press Ctrl+S
   - Save as "test_output.txt" in Documents
   - Close Notepad
5. Click **Stop Recording**
6. Save test as "Exercise2_Notepad"

#### Part B: Enhance with Variables
1. Edit test to use variables:
   ```yaml
   variables:
     fileName: "hybrid_qa_{{timestamp}}.txt"
     content: "Automated test run at {{dateTime}}"
   
   steps:
     - action: desktop.type
       text: "{{content}}"
   ```

#### Part C: Add Verification
1. Add file existence check:
   ```yaml
   - action: desktop.checkFile
     path: "C:\\Users\\{{username}}\\Documents\\{{fileName}}"
     exists: true
   ```

### Expected Outcomes
- [ ] Notepad opens and receives typed text
- [ ] File saves with timestamp in name
- [ ] File verification passes
- [ ] No manual intervention required
- [ ] Screenshots captured at key points

### Tips
- Use **Desktop Recorder** overlay for precise clicking
- Enable "Highlight Actions" to see what's being automated
- Adjust timing between actions if needed

## Exercise 3: API Testing - CRUD Operations (30 minutes)

### Objective
Test REST API endpoints with data extraction and validation.

### Setup
1. Start API mock server:
   ```
   cd samples/api-crud-mock
   npm install
   npm start
   ```
2. API available at http://localhost:4000

### Steps

#### Part A: Create Test Manually
1. Go to **Projects** → **New Test**
2. Select "API Test" template
3. Add requests:

```yaml
name: Exercise3_API_CRUD
steps:
  # 1. Create user
  - action: api.request
    method: POST
    url: http://localhost:4000/api/users
    headers:
      Content-Type: application/json
    body:
      name: "QA Tester"
      email: "qa@example.com"
    extract:
      userId: $.id
    
  # 2. Verify creation
  - action: api.expect
    status: 201
    body:
      name: "QA Tester"
  
  # 3. Get user
  - action: api.request
    method: GET
    url: http://localhost:4000/api/users/{{userId}}
    
  # 4. Update user
  - action: api.request
    method: PUT
    url: http://localhost:4000/api/users/{{userId}}
    body:
      name: "QA Tester Updated"
      
  # 5. Delete user
  - action: api.request
    method: DELETE
    url: http://localhost:4000/api/users/{{userId}}
    
  # 6. Verify deletion
  - action: api.request
    method: GET
    url: http://localhost:4000/api/users/{{userId}}
    expect:
      status: 404
```

#### Part B: Import from OpenAPI
1. Go to **Tools** → **Import API**
2. Enter URL: `http://localhost:4000/api-docs`
3. Select endpoints to import
4. Generate test cases automatically

### Expected Outcomes
- [ ] All CRUD operations complete successfully
- [ ] userId extracted and reused in subsequent requests
- [ ] Status codes match expectations (201, 200, 404)
- [ ] Response times < 100ms
- [ ] Request/response bodies logged

### Advanced Challenge
- Add data-driven testing with multiple users
- Implement cleanup in case of failure
- Add performance assertions

## Exercise 4: Flow Builder - Multi-Engine Test (45 minutes)

### Objective
Create a complex flow combining web, API, and desktop steps.

### Scenario
Test an order processing workflow:
1. Create order via API
2. Login to web admin panel
3. Verify order appears
4. Export order details to Notepad
5. Validate exported data

### Steps

#### Part A: Build Flow Visually
1. Go to **Flows** → **New Flow**
2. Name it "Exercise4_OrderWorkflow"
3. Drag and drop nodes:
   - API Request node (Create Order)
   - Web Test node (Admin Login)
   - Condition node (Check Order Status)
   - Desktop Test node (Export to Notepad)
   - Assertion node (Validate Export)

#### Part B: Configure Nodes

**Node 1 - Create Order (API)**:
```yaml
action: api.request
method: POST
url: http://localhost:4000/api/orders
body:
  product: "Test Product"
  quantity: 5
  customer: "QA Test"
extract:
  orderId: $.orderId
  orderTotal: $.total
```

**Node 2 - Admin Login (Web)**:
```yaml
sequence:
  - action: web.navigate
    url: http://localhost:3000/admin
  - action: web.fill
    selector: #username
    text: admin
  - action: web.fill
    selector: #password
    text: admin123
  - action: web.click
    selector: button[type="submit"]
```

**Node 3 - Find Order (Web)**:
```yaml
sequence:
  - action: web.fill
    selector: #searchOrder
    text: "{{orderId}}"
  - action: web.click
    selector: .search-button
  - action: web.expect
    selector: .order-row
    text: "{{orderId}}"
```

**Node 4 - Export Details (Desktop)**:
```yaml
sequence:
  - action: desktop.openApp
    app: notepad
  - action: desktop.type
    text: |
      Order Export Report
      ==================
      Order ID: {{orderId}}
      Total: {{orderTotal}}
      Exported: {{dateTime}}
  - action: desktop.saveAs
    filename: order_{{orderId}}_export.txt
```

#### Part C: Add Error Handling
1. Right-click on nodes → Add Error Handler
2. Configure retry logic
3. Add cleanup steps

### Expected Outcomes
- [ ] Flow executes end-to-end without manual intervention
- [ ] Data flows correctly between engines (orderId used throughout)
- [ ] Each node shows success status
- [ ] Total execution time < 2 minutes
- [ ] Export file contains correct order details

### Tips
- Use Flow Variables to pass data between nodes
- Enable "Debug Mode" to pause between nodes
- Add logging nodes for troubleshooting

## Exercise 5: Advanced Features - Self-Healing & AI Assistant (45 minutes)

### Objective
Experience self-healing locators and AI-powered test generation.

### Part A: Self-Healing Locators

#### Setup
1. Open `samples/web-login-cart`
2. Run existing test "Exercise1_WebLogin"
3. Modify the site to break selectors:
   ```javascript
   // In samples/web-login-cart/src/App.js
   // Change class="welcome-message" to class="welcome-text"
   ```

#### Test Self-Healing
1. Run test again - it will fail
2. Go to **Healing** tab
3. Review suggested alternatives:
   - Text-based: `text=Welcome, testuser!`
   - Partial class: `[class*="welcome"]`
   - XPath: `//div[contains(text(),'Welcome')]`
4. Accept best suggestion
5. Re-run test - should pass

### Part B: AI Assistant

#### Generate Test from Description
1. Open **AI Assistant** panel
2. Enter: "Test the checkout process: add 3 items to cart, apply coupon code SAVE10, verify 10% discount, complete purchase"
3. Click **Generate Test**
4. Review generated steps:
   ```yaml
   # AI will generate something like:
   - action: web.click
     selector: .add-to-cart
     count: 3
   - action: web.click
     selector: .cart-icon
   - action: web.fill
     selector: #coupon-code
     text: SAVE10
   - action: web.click
     selector: .apply-coupon
   - action: web.expect
     selector: .discount-amount
     text: "-10%"
   - action: web.click
     selector: .checkout-button
   ```

#### Optimize Existing Test
1. Select a test with repetitive steps
2. Ask AI: "Optimize this test by removing redundancy"
3. Review and apply suggestions

### Part C: Failure Analysis
1. Intentionally break a test (wrong password)
2. Run test and let it fail
3. Click **Analyze Failure** in run details
4. Review AI analysis:
   - Root cause identification
   - Suggested fixes
   - Similar historical failures

### Expected Outcomes
- [ ] Self-healing successfully fixes broken selector
- [ ] AI generates valid test from natural language
- [ ] Generated test follows best practices
- [ ] Failure analysis provides actionable insights
- [ ] Healing suggestions improve over time

## Assessment Checklist

After completing all exercises, you should be able to:

### Basic Skills
- [ ] Record and replay web tests
- [ ] Record and replay desktop tests
- [ ] Create API tests manually
- [ ] Use the visual flow builder
- [ ] Review test results and artifacts

### Intermediate Skills
- [ ] Add assertions and validations
- [ ] Use variables and data extraction
- [ ] Handle dynamic content
- [ ] Create multi-step flows
- [ ] Debug failing tests

### Advanced Skills
- [ ] Implement error handling
- [ ] Use self-healing locators
- [ ] Generate tests with AI
- [ ] Optimize test performance
- [ ] Create reusable components

## Best Practices

### Test Design
1. **Keep tests atomic**: One test, one feature
2. **Use meaningful names**: `Login_ValidCredentials_ShouldSucceed`
3. **Add comments**: Explain complex logic
4. **Clean up**: Always restore initial state

### Maintenance
1. **Regular reviews**: Check for flaky tests weekly
2. **Update selectors**: Use data-testid when possible
3. **Version control**: Commit tests with code changes
4. **Documentation**: Maintain test case descriptions

### Performance
1. **Parallel execution**: Run independent tests simultaneously
2. **Headless mode**: Use for CI/CD pipelines
3. **Smart waits**: Avoid hard-coded delays
4. **Resource cleanup**: Close browsers, connections

## Troubleshooting Quick Reference

| Issue | Solution |
|-------|----------|
| Test runs slowly | Enable headless mode, disable video |
| Flaky tests | Add explicit waits, check for race conditions |
| Element not found | Update selector, use multiple attributes |
| API timeout | Increase timeout, check network |
| Desktop automation fails | Run as administrator, check focus |

## Next Steps

### Recommended Learning Path
1. **Week 1**: Complete all exercises
2. **Week 2**: Automate one real application
3. **Week 3**: Build comprehensive test suite
4. **Week 4**: Implement CI/CD integration

### Additional Resources
- **Documentation**: http://localhost:3003/docs (when app is running)
- **Sample Projects**: Explore all examples in `samples/`
- **Video Tutorials**: Available in Help menu
- **Community Forum**: Share tests and get help

### Certification Path
1. **Basic Certification**: Complete 5 exercises
2. **Advanced Certification**: Build production test suite
3. **Expert Certification**: Contribute to platform

## Support Contacts

- **Team Lead**: Schedule 1:1 for questions
- **IT Support**: For installation/environment issues
- **Hybrid QA Support**: support@hybridqa.io

## Feedback

Please provide feedback on this onboarding:
1. Which exercise was most helpful?
2. What additional topics need coverage?
3. Rate difficulty level (1-5)
4. Suggestions for improvement

---

**Welcome to the team! Happy testing!** 