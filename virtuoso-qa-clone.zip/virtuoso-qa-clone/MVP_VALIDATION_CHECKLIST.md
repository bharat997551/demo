# MVP Validation Checklist

**Date**: _______________  
**Tester**: _______________  
**Version**: _______________  
**Environment**: ☐ Clean VM ☐ Dev Machine ☐ Test Machine

## Pre-Installation

☐ Windows 10/11 (Build: _______________)  
☐ User has standard privileges (not admin)  
☐ No previous Hybrid QA installation  
☐ At least 2GB free disk space  
☐ Internet connection available  

## Installation Process

☐ Downloaded installer from releases page  
☐ Installer size < 200MB  
☐ Digital signature valid (if signed)  
☐ Installation completed without errors  
☐ Installation time: _______ minutes  

### Post-Installation Checks

☐ Desktop shortcut created  
☐ Start menu entry created  
☐ Application launches successfully  
☐ No error dialogs on first launch  
☐ Launch time < 5 seconds  

## First-Run Wizard

☐ Wizard appears on first launch  
☐ All checks have clear status indicators  

### Dependency Checks

☐ Python check:  
  - ☐ Detected existing Python OR  
  - ☐ Offered to install bundled Python  
  - ☐ Fix button works  

☐ Node.js check:  
  - ☐ Version compatible  
  - ☐ No action needed  

☐ Playwright browsers:  
  - ☐ Not installed initially  
  - ☐ Download button works  
  - ☐ Progress shown during download  
  - ☐ Installation successful  

☐ Port availability:  
  - ☐ All required ports free  
  - ☐ Clear indication if ports blocked  

☐ Can proceed after all checks pass  

## Web Automation Test

### Recording

☐ Click "New Test" → "Web"  
☐ Recorder window appears  
☐ Can navigate to: https://demo.playwright.dev/todomvc  
☐ Record these actions:  
  - ☐ Type "Test TODO item"  
  - ☐ Press Enter  
  - ☐ Click checkbox  
  - ☐ Type second item  
  - ☐ Press Enter  
☐ Stop recording works  
☐ Test saved successfully  
☐ Recording time: _______ seconds  

### Replay

☐ Run button visible and enabled  
☐ Test executes in headless mode  
☐ Progress shown during execution  
☐ All steps show success status  
☐ Execution time: _______ seconds  

### Artifacts

☐ Screenshots captured (count: _______)  
☐ Screenshots viewable inline  
☐ Console logs available  
☐ HAR file generated  
☐ Can download artifacts  

## Desktop Automation Test

### Recording

☐ Click "New Test" → "Desktop"  
☐ Recorder overlay appears  
☐ Launch Notepad manually  
☐ Record these actions:  
  - ☐ Type "Hello from MVP test"  
  - ☐ Ctrl+S to save  
  - ☐ Type filename  
  - ☐ Click Save  
  - ☐ Close Notepad  
☐ Recording captures all actions  
☐ Stop recording works  
☐ Test saved successfully  

### Replay

☐ Test launches Notepad  
☐ Text typed correctly  
☐ Save dialog handled  
☐ File created successfully  
☐ Notepad closed  
☐ No errors during execution  
☐ Execution time: _______ seconds  

### Screenshots

☐ Screenshot after launch  
☐ Screenshot after text entry  
☐ Screenshot of save dialog  
☐ Final screenshot captured  
☐ All screenshots clear and viewable  

## API Test

### Test Creation

☐ Click "New Test" → "API"  
☐ Can configure:  
  - ☐ GET request  
  - ☐ URL: https://jsonplaceholder.typicode.com/users  
  - ☐ Headers  
☐ Can add assertions:  
  - ☐ Status code = 200  
  - ☐ Response contains data  
☐ Test saves successfully  

### Execution

☐ Request sent successfully  
☐ Response received  
☐ Status code assertion passes  
☐ Body assertion passes  
☐ Response time logged  
☐ Execution time: _______ seconds  

## Flow Builder Test

### Flow Creation

☐ Open Flow Builder  
☐ Canvas loads properly  
☐ Can add nodes:  
  - ☐ Web test node  
  - ☐ Desktop test node  
  - ☐ API test node  
☐ Can connect nodes  
☐ Flow saves successfully  

### Flow Execution

☐ Run button enabled  
☐ Execution follows correct order:  
  1. ☐ Web test completes  
  2. ☐ Desktop test runs after web  
  3. ☐ API test runs last  
☐ Data passed between steps  
☐ All nodes show success  
☐ Total execution time: _______ seconds  

### Visualization

☐ Running nodes highlighted  
☐ Completed nodes show checkmark  
☐ Failed nodes show error (if any)  
☐ Can click node for details  
☐ Artifacts accessible per node  

## UI/UX Validation

### Navigation

☐ Sidebar navigation works  
☐ All menu items clickable  
☐ Views load without error  
☐ Back/forward navigation works  

### Test Management

☐ Test list shows all tests  
☐ Can rename tests  
☐ Can duplicate tests  
☐ Can delete tests  
☐ Search/filter works  

### Run Management

☐ Run history visible  
☐ Can view past runs  
☐ Run details show all steps  
☐ Logs panel populated  
☐ Status indicators accurate  

## Performance Checks

☐ App responsive during test execution  
☐ Memory usage < 500MB idle  
☐ No memory leaks after multiple runs  
☐ CPU usage reasonable  
☐ No UI freezes  

## Error Handling

☐ Clear error messages  
☐ Errors don't crash app  
☐ Can recover from errors  
☐ Failed tests show useful info  
☐ Retry mechanisms work  

## Data Persistence

☐ Tests survive app restart  
☐ Run history persists  
☐ Settings saved  
☐ Artifacts retained  
☐ Database not corrupted  

## Final Validation

### Success Criteria Met

☐ Web test records and replays  
☐ Desktop test works with screenshots  
☐ API test executes with assertions  
☐ Flow builder combines all engines  
☐ Installer works on clean system  
☐ First-run setup succeeds  

### Overall Assessment

☐ All critical features work  
☐ No blocking bugs  
☐ Performance acceptable  
☐ User experience smooth  
☐ **MVP READY**: ☐ YES ☐ NO  

## Notes and Issues

_Use this space to note any issues, observations, or suggestions:_

_______________________________________________
_______________________________________________
_______________________________________________
_______________________________________________
_______________________________________________

## Sign-off

**Tester Signature**: _______________________  
**Date**: _______________________  
**MVP Status**: ☐ APPROVED ☐ REJECTED  

**If Rejected, Blocking Issues**:
1. _______________________
2. _______________________
3. _______________________ 