# Hybrid QA - Developer Guide

Welcome to the Hybrid QA platform development guide. This document provides comprehensive information for developers working on the monorepo.

## Table of Contents

1. [Architecture Overview](#architecture-overview)
2. [Development Setup](#development-setup)
3. [Monorepo Structure](#monorepo-structure)
4. [Environment Configuration](#environment-configuration)
5. [Development Workflow](#development-workflow)
6. [Debugging Tips](#debugging-tips)
7. [Testing Guidelines](#testing-guidelines)
8. [Contributing](#contributing)
9. [Troubleshooting](#troubleshooting)

## Architecture Overview

Hybrid QA is a comprehensive test automation platform built as a monorepo using pnpm workspaces:

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│  Electron App   │────▶│  Orchestrator   │────▶│    Engines      │
│   (Frontend)    │     │   (Backend)     │     │  Web/Desktop/   │
└─────────────────┘     └─────────────────┘     │  Mainframe/API  │
                                                 └─────────────────┘
```

### Key Technologies

- **Frontend**: Electron, React, TypeScript, Vite, Tailwind CSS
- **Backend**: Node.js, Express, Socket.IO, Prisma
- **Engines**: Playwright (Web), pywinauto (Desktop), s3270 (Mainframe), Node.js (API)
- **Build Tools**: pnpm, Vite, Electron Builder
- **Testing**: Jest, Pytest, Playwright Test

## Development Setup

### Prerequisites

1. **System Requirements**
   - Windows 10/11 (required for desktop engine)
   - Node.js >= 18.0.0
   - Python >= 3.11
   - Git

2. **Global Tools**
   ```bash
   # Install pnpm globally
   npm install -g pnpm@8

   # Verify installations
   node --version
   pnpm --version
   python --version
   ```

### Bootstrap Steps

1. **Clone the Repository**
   ```bash
   git clone <repository-url>
   cd hybrid-qa
   ```

2. **Install Dependencies**
   ```bash
   # Install all Node.js dependencies
   pnpm install

   # This will:
   # - Install dependencies for all packages
   # - Set up workspace symlinks
   # - Run prepare scripts
   ```

3. **Setup Python Environments**
   
   **Windows (PowerShell):**
   ```powershell
   # Desktop Engine
   cd packages/engine-desktop
   python -m venv venv
   .\venv\Scripts\activate
   pip install -r requirements.txt
   deactivate
   cd ../..

   # Mainframe Engine
   cd packages/engine-mainframe
   python -m venv venv
   .\venv\Scripts\activate
   pip install -r requirements.txt
   deactivate
   cd ../..
   ```

   **Linux/macOS:**
   ```bash
   # Desktop Engine (Note: Limited functionality on non-Windows)
   cd packages/engine-desktop
   python -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   deactivate
   cd ../..

   # Mainframe Engine
   cd packages/engine-mainframe
   python -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   deactivate
   cd ../..
   ```

4. **Install Playwright Browsers**
   ```bash
   pnpm --filter engine-web install:browsers
   ```

5. **Setup Database**
   ```bash
   # Generate Prisma client
   pnpm --filter common db:generate

   # Create/update database schema
   pnpm --filter common db:push
   ```

6. **Environment Configuration**
   ```bash
   # Copy example env files
   cp .env.example .env
   cp apps/desktop/.env.example apps/desktop/.env
   cp packages/orchestrator/.env.example packages/orchestrator/.env
   ```

### Quick Start

```bash
# Start all development servers
pnpm dev

# This launches:
# - Orchestrator API (http://localhost:3001)
# - Desktop App (Electron with hot reload)
# - All automation engines
```

## Monorepo Structure

```
hybrid-qa/
├── apps/
│   └── desktop/                 # Electron desktop application
│       ├── src/
│       │   ├── main/           # Electron main process
│       │   ├── preload/        # Preload scripts
│       │   └── renderer/       # React application
│       └── electron-builder.yml
├── packages/
│   ├── common/                 # Shared utilities and types
│   │   ├── src/
│   │   │   ├── security/       # Encryption, DPAPI
│   │   │   └── database/       # Prisma schema
│   │   └── prisma/
│   ├── dsl/                    # Test DSL definitions
│   ├── orchestrator/           # Backend orchestration service
│   │   ├── src/
│   │   │   ├── ai/            # AI capabilities
│   │   │   └── locator-manager/ # Self-healing locators
│   │   └── tests/
│   ├── engine-web/             # Playwright web automation
│   ├── engine-desktop/         # Python desktop automation
│   ├── engine-mainframe/       # Python mainframe automation
│   └── engine-api/             # API testing engine
├── tests/                      # Integration and E2E tests
│   ├── smoke/                  # Quick validation tests
│   ├── regression/             # Comprehensive test suites
│   └── mocks/                  # Mock servers
├── scripts/                    # Build and utility scripts
├── docs/                       # Documentation
└── .github/                    # GitHub Actions workflows
```

## Environment Configuration

### Development Environment Variables

Create `.env` files based on the examples:

**Root `.env`:**
```env
NODE_ENV=development
LOG_LEVEL=debug
```

**`apps/desktop/.env`:**
```env
VITE_API_URL=http://localhost:3001
VITE_WS_URL=ws://localhost:3001
```

**`packages/orchestrator/.env`:**
```env
PORT=3001
DATABASE_URL=file:../../common/prisma/dev.db
JWT_SECRET=dev-secret-change-in-production
ENABLE_AI=true
OLLAMA_URL=http://localhost:11434
OPENAI_API_KEY=your-api-key-here
```

### Windows-Specific Setup

1. **Enable Developer Mode**
   - Settings → Update & Security → For developers → Developer Mode

2. **Install WinAppDriver** (for desktop automation)
   ```powershell
   # Download and install from:
   # https://github.com/Microsoft/WinAppDriver/releases
   ```

3. **Install s3270** (for mainframe automation)
   ```powershell
   # Download from: http://x3270.bgp.nu/download.html
   # Add to PATH after installation
   ```

## Development Workflow

### Starting Services Individually

```bash
# Start orchestrator only
pnpm dev:orchestrator

# Start desktop app only
pnpm dev:desktop

# Start specific engine
pnpm --filter engine-web dev
pnpm --filter engine-desktop dev
pnpm --filter engine-mainframe dev
pnpm --filter engine-api dev
```

### Building Packages

```bash
# Build all packages
pnpm build

# Build specific package
pnpm --filter orchestrator build

# Build and package desktop app
pnpm --filter desktop build
pnpm --filter desktop package
```

### Running Tests

```bash
# Run all tests
pnpm test

# Run tests for specific package
pnpm --filter orchestrator test
pnpm --filter engine-web test

# Run tests in watch mode
pnpm --filter orchestrator test:watch

# Run with coverage
pnpm test -- --coverage
```

### Code Quality

```bash
# Run linting
pnpm lint

# Fix linting issues
pnpm lint:fix

# Type checking
pnpm type-check

# Format code
pnpm format
```

## Debugging Tips

### 1. Debugging Electron App

**Main Process:**
- Use VS Code with the following launch configuration:

```json
{
  "type": "node",
  "request": "launch",
  "name": "Debug Main Process",
  "cwd": "${workspaceFolder}/apps/desktop",
  "runtimeExecutable": "pnpm",
  "runtimeArgs": ["electron", ".", "--inspect=5858"],
  "protocol": "inspector"
}
```

**Renderer Process:**
- Open DevTools in Electron: `Ctrl+Shift+I`
- Use React DevTools extension
- Enable React Query DevTools in development

### 2. Debugging Orchestrator

```json
{
  "type": "node",
  "request": "launch",
  "name": "Debug Orchestrator",
  "cwd": "${workspaceFolder}/packages/orchestrator",
  "runtimeExecutable": "pnpm",
  "runtimeArgs": ["dev:debug"],
  "skipFiles": ["<node_internals>/**"]
}
```

Add to `packages/orchestrator/package.json`:
```json
"scripts": {
  "dev:debug": "node --inspect=9229 dist/index.js"
}
```

### 3. Debugging Python Engines

**VS Code Python Configuration:**
```json
{
  "name": "Python: Engine Desktop",
  "type": "python",
  "request": "launch",
  "program": "${workspaceFolder}/packages/engine-desktop/src/main.py",
  "console": "integratedTerminal",
  "justMyCode": false,
  "env": {
    "PYTHONPATH": "${workspaceFolder}/packages/engine-desktop/src"
  }
}
```

### 4. Debugging Web Tests

```bash
# Run Playwright tests in debug mode
pnpm --filter engine-web test:debug

# Run specific test file
pnpm --filter engine-web test tests/login.spec.ts

# Run with headed browser
pnpm --filter engine-web test --headed
```

### 5. Common Debugging Techniques

**Enable Debug Logging:**
```bash
# Set environment variable
DEBUG=* pnpm dev

# Or in code
process.env.DEBUG = '*';
```

**Add Breakpoints in TypeScript:**
```typescript
debugger; // Browser/Node will pause here
```

**Python Debugging:**
```python
import pdb
pdb.set_trace()  # Python debugger breakpoint
```

**Electron IPC Debugging:**
```javascript
// In main process
ipcMain.on('channel', (event, arg) => {
  console.log('IPC received:', arg);
  event.reply('channel-reply', 'response');
});
```

## Testing Guidelines

### Unit Tests

1. **TypeScript/JavaScript:**
   ```typescript
   // packages/orchestrator/src/services/__tests__/test.service.spec.ts
   import { TestService } from '../test.service';

   describe('TestService', () => {
     let service: TestService;

     beforeEach(() => {
       service = new TestService();
     });

     it('should execute test successfully', async () => {
       const result = await service.execute(testData);
       expect(result.success).toBe(true);
     });
   });
   ```

2. **Python:**
   ```python
   # packages/engine-desktop/tests/test_window_manager.py
   import pytest
   from src.window_manager import WindowManager

   def test_find_window():
       manager = WindowManager()
       window = manager.find_window(title="Notepad")
       assert window is not None
   ```

### Integration Tests

```typescript
// tests/integration/orchestrator-engine.spec.ts
import { Orchestrator } from '@hybrid-qa/orchestrator';
import { WebEngine } from '@hybrid-qa/engine-web';

describe('Orchestrator-Engine Integration', () => {
  let orchestrator: Orchestrator;
  let webEngine: WebEngine;

  beforeAll(async () => {
    orchestrator = new Orchestrator();
    await orchestrator.start();
    
    webEngine = new WebEngine();
    await webEngine.connect();
  });

  afterAll(async () => {
    await webEngine.disconnect();
    await orchestrator.stop();
  });

  it('should execute web test through orchestrator', async () => {
    const result = await orchestrator.runTest({
      engine: 'web',
      steps: [/* test steps */]
    });
    expect(result.status).toBe('completed');
  });
});
```

### E2E Tests

```typescript
// tests/e2e/full-flow.spec.ts
test('Complete test flow', async ({ page }) => {
  // Start recording
  await page.goto('http://localhost:3000');
  await page.click('[data-testid="record-button"]');
  
  // Perform actions
  await page.fill('#url', 'https://example.com');
  await page.click('[data-testid="start-recording"]');
  
  // Verify recording
  await expect(page.locator('.recording-indicator')).toBeVisible();
});
```

## Contributing

### Git Workflow

1. **Branch Naming:**
   - Features: `feature/description`
   - Bugs: `fix/description`
   - Docs: `docs/description`

2. **Commit Messages:**
   Follow conventional commits:
   ```
   feat: add new AI capability
   fix: resolve memory leak in orchestrator
   docs: update API documentation
   test: add unit tests for locator healing
   refactor: optimize test execution engine
   ```

3. **Pull Request Process:**
   - Create feature branch from `develop`
   - Make changes and commit
   - Run tests and linting
   - Create PR with description
   - Ensure CI passes
   - Request review

### Code Style

- **TypeScript:** Follow ESLint configuration
- **Python:** Follow PEP 8 with Black formatting
- **React:** Functional components with hooks
- **Naming:** camelCase for variables, PascalCase for components/classes

## Troubleshooting

### Common Issues

1. **pnpm install fails**
   ```bash
   # Clear cache
   pnpm store prune
   
   # Remove node_modules
   pnpm clean
   
   # Reinstall
   pnpm install
   ```

2. **Python engine won't start**
   - Verify Python version: `python --version`
   - Check virtual environment activation
   - Reinstall dependencies: `pip install -r requirements.txt --force-reinstall`

3. **Electron app blank screen**
   - Check DevTools console for errors
   - Verify API server is running
   - Clear Electron cache: `rm -rf ~/AppData/Roaming/hybrid-qa`

4. **Database errors**
   ```bash
   # Reset database
   pnpm --filter common db:reset
   
   # Regenerate Prisma client
   pnpm --filter common db:generate
   ```

5. **Port already in use**
   ```bash
   # Find process using port
   netstat -ano | findstr :3001
   
   # Kill process
   taskkill /PID <process-id> /F
   ```

### Debug Mode Features

Enable debug mode for additional logging:

```typescript
// In main process
app.commandLine.appendSwitch('--enable-logging');
app.commandLine.appendSwitch('--v', '1');
```

### Performance Profiling

1. **Chrome DevTools Performance Tab**
   - Record performance while using the app
   - Analyze flame graphs

2. **Node.js Profiling**
   ```bash
   node --prof packages/orchestrator/dist/index.js
   node --prof-process isolate-*.log > profile.txt
   ```

## Resources

- [Electron Documentation](https://www.electronjs.org/docs)
- [Playwright Documentation](https://playwright.dev)
- [React Documentation](https://react.dev)
- [pnpm Documentation](https://pnpm.io)
- [TypeScript Documentation](https://www.typescriptlang.org/docs)

## Support

- Create an issue for bugs or feature requests
- Join our Discord for community support
- Check the FAQ in the wiki

---

Happy coding! 🚀 